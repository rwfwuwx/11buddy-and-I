function eleven_anova_behav(dataset,Factors_current,Level_number_current,Factor_withinBetween_current,Factor_level_current,Factor_name_current,parametric_type)

% input


% call function
%     eleven_rpanova
%     eleven_rpanova_mixed

% update history
%   2024-05-07 initial verstion

if parametric_type == 1
    factor_number=length(Factors_current);
    %---repeated ANOVA
    if unique(Factor_withinBetween_current)==1
        %   # one-way
        if factor_number==1
            
            %         dataset=current_data;
            condname=Factor_name_current;
            factorname=Factors_current;
            factorlevel=condname;
            
            %--- repeated anova
            disp('one-way repeated anova')
            [rm ranovatbl]=eleven_rpanova(dataset,condname,factorname,factorlevel)
%             ranovatbl
        end
        
        %   # two-way
        if factor_number==2
            %dataset=current_data;
            
            condname=Factor_name_current;
            factorname=Factors_current;
            %
            factor1_level=fix(Factor_level_current./10);
            factor1_level=num2cell(factor1_level);
            for ii=1:length(factor1_level)
                factor1_level{ii}=num2str(factor1_level{ii});
            end
            factor2_level=mod(Factor_level_current,10);
            factor2_level=num2cell(factor2_level);
            for ii=1:length(factor2_level)
                factor2_level{ii}=num2str(factor2_level{ii});
            end
            factorlevel=cell(2,length(Factor_level_current));
            factorlevel(1,:)=factor1_level;
            factorlevel(2,:)=factor2_level;
            
            %--- repeated anova
            disp('two repeated anova')
            [rm ranovatbl]=eleven_rpanova(dataset,condname,factorname,factorlevel)
            
%             tbl_rowname={'(Intercept)' 'Error' ...
%                 ['main:' Factors_current{1}] 'Error'...
%                 ['main:' Factors_current{2}] 'Error'...
%                 ['interaction:' Factors_current{1} '*' Factors_current{2}] 'Error'}';
%             ranovatbl.Properties.RowNames=tbl_rowname;
%             ranovatbl
            %}
        end
        
        %   # multi-factors
        if factor_number>2
            
        end
        
    end
    
    %---ANOVA
    if unique(Factor_withinBetween_current)==2
        %   # one-way
        if factor_number==1
            %         dataset=current_data;
            
            [p,tbl] = anova1(dataset);
            disp('one-way anova')
            tbl
            
        end
        %   # two-way
        if factor_number==2
            
        end
        %   # multi-factors
        if factor_number>2
            
        end
        
    end
    
    
    %---mixed ANOVA
    if length(unique(Factor_withinBetween_current))>1
        
        %   # two-way
        if factor_number==2
            
        end
        %   # multi-factors
        if factor_number>2
            
        end
        
    end
    
end





