function eleven_FindAndReplaceInFile(file_input,file_output,string_find,string_replace)
%Usage eleven_FindAndReplaceInFile(file_input,file_output,string_find,string_replace)
% find string_find with string_replace in file_input, and save as file_output 
%
%Input
% file_input -- 
%   file name with absolute or relative (i.e., without path) path.
%   about file format
%       #default, (any) text file. e.g., .txt, .m, etc.
%       #for non-text file, specific processing
%           currently, matlab mlx.
% file_output -- if file_output = file_input, modify the original file.Other wise, save as a new one.
%
%Update history
% 2023-11-22~23
%   Initial version.

%--- Read the content of the input file 

% get file extention
[~,~,fileExtension] = fileparts(file_input);

% set a temporay file name, according to file extention
%   !for non-text file, the basic logic is to convert it to text file; do task as text file; and then convert it back to non-text file
%       at least for mlx file, no option to do task on it directly.
%           !!!the effect depends on how and whether matlab do its own job of mlx-m-mlx conversion. 
%   (another option is to convert it to binary, and do task on the basis of binary data.
%       but this does not work for mlx file. the text-binary-text way apparently depends on specific file fomat.)
%   specific processing for non-txt file, mlx.
%       convert mlx to m file
if strcmp(fileExtension,'.mlx') 
    tmp_file = 'tmp.m';
    % convert mlx->m 
    matlab.internal.liveeditor.openAndConvert(file_input, tmp_file);
else
    tmp_file = file_input;
end

% read file to a string
fid = fopen(tmp_file, 'r');
file_content = fread(fid, '*char')';
fclose(fid);

% clean up temporary file for non-text file
if strcmp(fileExtension,'.mlx') 
    delete(tmp_file);
end

%--- Perform find and replace using regexprep
new_file_content = strrep(file_content, string_find, string_replace);

%--- Write the updated content to the output file
% get file extention
[~,~,fileExtension] = fileparts(file_output);

% set a temporay file name, according to file extention
if strcmp(fileExtension,'.mlx') 
    tmp_file = 'tmp.m';
else
    tmp_file = file_output;
end

% write file
fid = fopen(tmp_file, 'w');
fwrite(fid, new_file_content, 'char');
fclose(fid);

% m->mlx for mlx; and clean up temporal file
if strcmp(fileExtension,'.mlx') 
    matlab.internal.liveeditor.openAndSave(tmp_file,file_output);
    delete(tmp_file);
end

