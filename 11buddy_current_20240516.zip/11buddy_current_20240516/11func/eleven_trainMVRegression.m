function [beta,y_fit_validation] = eleven_trainMVRegression(x,y,learnMethod,is_validation)
% [beta,y_fit_validation] = eleven_trainMVRegression(x,y,learnMethod,is_validation)
%
%  Usage:
%   this is the multiple y version of elevenRegression.m. The differences include
%       1. Now only 'Linear' Method is available, as implemented by mvregress.m
%       2. the return MDL -> beta
%       3. for predict: e.g., y_fit_test = predict(Mdl,x_test) -> y_fit_test = [ones(size(x_test,1),1),x_test]*beta;
%       (further: mvregress does not support tabular format for input)
%   Others see elevenRegression.m.
%
% Update history
%   2021-09-28 initial version. 

%--- load option variable
eleven_MLBuddy_set_OptionVariable_customize;
load eleven_MLBuddy_OptionVariable_customize;

% |--- Train model using all data ---|
% specifies all the model options and trains the model.
if strcmp(learnMethod,'Linear')
    beta = mvregress([ones(size(x,1),1),x],y);
end

% |--- cross validation, by LOSO ---|
if is_validation == 0
    y_fit_validation = 0;
end

if is_validation == 1
    sbj_num = size(x,1);
    y_fit_validation = zeros(size(y));
    
    for leftout = 1:sbj_num
        %--- leave out the leftout subject from x and y, producing x and y of other subjects (i.e., the CV train data in each loop step)
        x_CV = x;
        x_CV(leftout,:) = [];
        
        y_CV = y;
        y_CV(leftout,:) = [];
        
        %--- Train model using CV train data
        % specifies all the model options and trains the model.
        if strcmp(learnMethod,'Linear')
            beta_CV = mvregress([ones(size(x_CV,1),1),x_CV],y_CV);
        end
        
        %--- predict y of the leftout subject from x of the leftout subject, using the CV model of other subjects
        x_tmp = x(leftout,:);
        y_fit_validation(leftout,:) = [ones(size(x_tmp,1),1),x_tmp]*beta_CV;
    end
end


