function [SDNN,RMSSD,hrv_spec_am_raw,hrv_spec_am_norm,hrv_spec_freq,LF_avg_am,HF_avg_am,LHF_avg_am_ratio,LF_peak_am,LF_peak_freq,HF_peak_am,HF_peak_freq] = eleven_ecg_hrv(IBI,am_type,FreqNorm_points)
% [SDNN,RMSSD,hrv_spec_am_raw,hrv_spec_am_norm,hrv_spec_freq,LF_avg_am,HF_avg_am,LHF_avg_am_ratio,LF_peak_am,LF_peak_freq,HF_peak_am,HF_peak_freq]...
%   = eleven_ecg_hrv(IBI,am_type,FreqNorm_points)
% Input
% Output
%
% --- update history
% 2020-10-31 ��

if nargin~=3
    disp('eleven_ecg_hrv requires 3 arguments!');
    return;
end

fs = 1/mean(IBI);

%--- high pass filter
% in case max peak frequency occurs at very low frequency
%   Note reduce filter order for very low frequency
IBI = mf_rawfilter(IBI,'IIR','high pass',0.005,2,fs);

% --- time index
SDNN = std(IBI);
RMSSD = sqrt(mean((diff(IBI).^2)));

% --- freq index

% spec
[hrv_spec_am_raw,hrv_spec_am_norm,spec_phase,hrv_spec_freq]...
    = mf_rawspec(IBI,fs,am_type,'degree',FreqNorm_points);

freq_resolution = fs/2/(length(hrv_spec_freq)-1);
% LH 0.04~0.15; HF 0.15~0.4;

% avg
LF_avg_am = mean(hrv_spec_am_norm(ceil(0.04/freq_resolution):ceil(0.15/freq_resolution)));
HF_avg_am = mean(hrv_spec_am_norm(ceil(0.15/freq_resolution):ceil(0.4/freq_resolution)));
LHF_avg_am_ratio = LF_avg_am/HF_avg_am;

% peak
LF_peak_am = max(hrv_spec_am_norm(ceil(0.04/freq_resolution):ceil(0.15/freq_resolution)));
LF_peak_freq = find(hrv_spec_am_norm(ceil(0.04/freq_resolution):ceil(0.15/freq_resolution)) == LF_peak_am)*freq_resolution;

HF_peak_am = max(hrv_spec_am_norm(ceil(0.15/freq_resolution):ceil(0.4/freq_resolution)));
HF_peak_freq = find(hrv_spec_am_norm(ceil(0.15/freq_resolution):ceil(0.4/freq_resolution)) == HF_peak_am)*freq_resolution;



