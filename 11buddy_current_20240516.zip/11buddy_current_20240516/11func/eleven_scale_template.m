function index = eleven_scale_template(scale_data)
% Input
%   scale_data.
%       currently .mat
%       other format, handle later.
% Output
%   index.
%       format: vector. index 1-n -- length(vector) 1-n
% Note: for specific scale, 'template' -> scale name
%
% todo
%   extending to specific scale, and complex situations. Zhihan
%   
% Update history
%   2020-11-05 build

index_num = % add
index = zeros(index_num,1);

% index 1
index_1_item = []; % add
scale_data = scale_data(:); % to column vector
index(1) = mean(scale_data(index_1_item));

% index 2-n 
%   add below as index 1.
