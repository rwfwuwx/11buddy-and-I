function eleven_eegSource_Import(ProtocolName,SubjectName,DataFile,CorV) 
% Usage
% Input
%   ProtocolName --- a string. 
%       (Note, consistently keep the Study name pre-assigned in the Lab standalized procedure. and other standarized variables including sbj name, condition name, ...). 
%   SubjectName --- a string.
%   DataFile --- full path of the eeg data.
%   CorV: 1 cortex; 2 volume
% Hidden Output
%   sFile_Import --- see Note 2.
%   sFile_FileName_Import --- see Note 2.
% Note
%   1. about Create new protocol. currently use GUI, because:
%       1) the options selected when creating new protocal cannot be reflected in command line.
%       2) !!! in a study, all subjects and conditions use one protocol.
%   2. !!! about Output and Hidden Output.
%       --- Background about brainstorm file organization.
%       Somehow, brainstorm uses database for file organiztion, in which specific files are "hidden" in the
%           database; and the project, specifically with the sFile stucture, is the database GUI to access hidden files. 
%       The issue is regardign the weird design of the sFile structure. 
%           1) On the one hand, all files of all subjects and conditions, and procesessed file on them, can be stored in one sFile. 
%               On the other hand, different sFiles can be used as specific purposes.
%               This inconsistency is easilly seen in script examples.
%           2) Given specifc sFile attrubues, such as sbj name, cond name, even tag, multiple files could be there, e.g., 01 02 ....
%       The problem is how to specifically select a file.
%           In GUI, selecting one specific file is possible, but confusing, due to the multiple files issue.
%           In command line, selecting file is done by "process_select_files_data". Due to the issues above, the simple thing of selecting a specific
%               file becomes much complicated. Might be impossible (or at least wasting time), due to the multiple files issue.
%       --- Solution
%       sFile.
%           This can be largely ignored for command line, and thus in automation. While keep it as hidden Output, for check data by GUI.
%           Moreover, for clarity (and for avoiding possible data
%           overlapping across steps in brainstorm), keep sFile for each main steps, as:
%               sFile_Import (in this step)
%               sFile_Inverse
%               (..., as needs)
%           Also note that, all subjects and all conditions will be in this sFile. 
%               Regardless of the organization of brainstorm, handle selecting specific file as below.
%       sFile_FileName
%           sFile.FileName is the path to "latest" file. 
%               (!!! this was tested in importing one file. may complicated for complicated situation as considered above.Change accordingly as needs)   
%           Given this, the return sFile.FileName can be a reference to the specific file.
%           !! file name should include subjects, conditions (add later), thus distinguish between them. 
%           !! This should be standarized name, thus as hidden output, saved in "current directory", following andy.
%           Together, as a hidden output, as:
%               sFile_FileName_Import (in this step)
%               sFile_FileName_Inverse
%               (..., as needs)
%           Accordingly, note that, to save it in "current directory", this func needs to be performed in "current directory". 
%        Furthr, see note about the need of sFile input in eleven_eegSource_Forward       
%   3. same brainstrom_db directory for all users.J:\analyze\soft_analyze_dir\brainstorm_db. 
%       !!add this into new use setting procedure. 
% todo
%   Note 3.
%   handle save sFile_FileName_Import in the sbj's analysis directory
% Description
%   Currently, adopt the source reconstruction implemented in BrainStorm. 
% Update history
% 2022-02-28 mark open/close bs.
% 2022-02-25 add handling ProtocolName_C (cortex) ProtocolName_V (colume)
% 2021-10-22
%   'timewindow',   [0, 137.1]);-> 'timewindow',   []); % [] refers to all time
% 2021-10-20 
%   intial version of automation
% 2021-10-19
%   Generate scripts in BrainStorm, and test (Liying).
%   previously related work from 2019~this time, see backup (add later)


% Start BrainStorm in silent mode. 
% if ~brainstorm('status')
%     brainstorm nogui
% end

% load Protocol
iProtocol = bst_get('Protocol', ProtocolName);

if ~isempty(iProtocol)
   gui_brainstorm('SetCurrentProtocol', iProtocol);
end
if isempty(iProtocol)
    error(['Unknown protocol: ' ProtocolName]);
end

%--- Import
% GUI process: Import MEG/EEG: Time
sFile_Import = bst_process('CallProcess', 'process_import_data_time', [], [], ...
    'subjectname',  SubjectName, ...
    'datafile',     {{DataFile}, 'EEG-EEGLAB'}, ...
    'timewindow',   []);

% return the file name of the sFile 
if CorV==1
    sFile_FileName_Import_C = sFile_Import.FileName;
    save sFile_FileName_Import_C sFile_FileName_Import_C;
end
if CorV==2
    sFile_FileName_Import_V = sFile_Import.FileName;
    save sFile_FileName_Import_V sFile_FileName_Import_V;
end

 % Quit Brainstorm
% brainstorm stop;   
