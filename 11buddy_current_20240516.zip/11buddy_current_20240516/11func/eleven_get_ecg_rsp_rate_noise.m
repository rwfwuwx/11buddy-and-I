function [rate,spec_am_raw,spec_am_norm,spec_freq] = eleven_get_ecg_rate(rawdata,fs,padding_time,FreqNorm_points)
% [rate,spec_am_raw,spec_am_norm,spec_freq] = eleven_get_ecg_rate(rawdata,fs,padding_time,FreqNorm_points)
% Input
% Output
%
% --- update history
% 2020-11-25 when get peak frequency,bypass 0.1hz liying
% 2020-11-20 remove cut time; rawdat_pp
% 2020-10-31 add high pass of very low freq
% 2020-10-30 ��

if nargin~=4
    disp('eleven_sc_convert requires 4 arguments!');
    return;
end


%--- cut data according to cut_time
% cut_point = round(cut_time*fs);
% rawdata = rawdata(cut_point(1):cut_point(2));
% 
% rawdata_pp = rawdata;

%--- high pass filter
% in case max peak frequency occurs at very low frequency
%   Note reduce filter order for very low frequency
rawdata = mf_rawfilter(rawdata,'IIR','high pass',0.005,2,fs);

% remove padding
padding_points = padding_time*fs;
rawdata = rawdata([padding_points+1:size(rawdata,1)-padding_points-1],:);

% spec
[spec_am_raw,spec_am_norm,spec_phase,spec_freq]...
    = mf_rawspec(rawdata,fs,'amplitude','degree',FreqNorm_points);

% get peak freq
freq_resolution = fs/2/(length(spec_freq)-1);
bypass_freq = 1;
highpass_freq= 2;
highpass_freq_point = highpass_freq/freq_resolution;
bypass_freq_point = bypass_freq/freq_resolution;
peak_freq_point = bypass_freq_point+find(spec_am_norm(bypass_freq_point+1:highpass_freq_point)==max(spec_am_norm(bypass_freq_point+1:highpass_freq_point)));
peak_freq = peak_freq_point*freq_resolution;

% get rate
rate = peak_freq*60;


