function eleven_illustrate_2DScalp_template(ch,type,corType)
% update history
%   2023-12-20 J:\11job\test\test20220309\illustrate_2DScalp_template.m ->
%           eleven_illustrate_2DScalp_template.m
%   2022-03-24 build. to display scalp ch, and with numbers and labels
% load egi_ch128_pos_2D; % load a ch position

%clear;clc;

% egi 128
load egi_ch128_pos_2D;
load egi_ch128_label;

% plot only ch
% figure;
% mf_topo2D_forDisplay(egi_ch128_pos_2D,[1:128],[1:128],zeros(1,128),1,[],egi_ch128_label,0); 
% colormap('white'); colorbar off;
% % plot ch number
% figure;
% mf_topo2D_forDisplay(egi_ch128_pos_2D,[1:128],[1:128],zeros(1,128),1,[],egi_ch128_label,1); 
% colormap('white'); colorbar off;
% plot ch label
% figure;
% mf_topo2D_forDisplay(egi_ch128_pos_2D,[1:128],[1 ch],zeros(1,128),1,[],egi_ch128_label,type); 
% colormap('white'); colorbar off;

figure;
if length(ch)>1
if corType == 0
    mf_topo2D_2(egi_ch128_pos_2D,ch,ch,zeros(1,128),1,[],egi_ch128_label,type,12,[1 0.56 0],20);
    colormap('white'); colorbar off;
end
if corType == 1
    mf_topo2D_2(egi_ch128_pos_2D,ch,ch,zeros(1,128),1,[],egi_ch128_label,type,12,[1 0 0],20);
    colormap('white'); colorbar off;
end
if corType == 2
    mf_topo2D_2(egi_ch128_pos_2D,ch,ch,zeros(1,128),1,[],egi_ch128_label,type,12,[0.12 0.56 1],20);
    colormap('white'); colorbar off;
end
end

