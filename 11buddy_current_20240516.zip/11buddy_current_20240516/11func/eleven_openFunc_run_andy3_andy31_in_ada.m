% open func
%   eleven_openFunc_run_andy3_andy31_in_ada
%
% explict Input
%   sbjIndex_step3
%   is_run_andy3
%       run this first time for an analysis
%           no need for detialed plotting
%       !!! must run when formally reporting.
%
% Update history
%   2023-12-18 but correction that andy_image_customize was not used
%   2022-08-11 
%       add option for one sbj
%       add the flexible manner to handle flexible usage of 11buddy file. same as andy ganhuola
%   2022-08-10 add is_run_andy6
%   2022-08-09 initial version

% run andy3 according to sbjIndex
%eval(sprintf('sbjIndex_step3 = %s;',tmpInputVar));
if is_andy_image_for_onesbj == 0
    if is_run_andy3
        sbjIndex_step3 = tmpInputVar;
        
        is_step3_formal = 1;
        load andy_ganhuola_3; andy_ganhuola_3(studyID,analysis_allSbjData_eeg_file,sbjIndex_step3,is_step3_formal);
    end
end

% run simple version of andy31
cd(eegData_path);
if is_customize_andy_image
    eval(sprintf(andy_image_customize));
else
    load andy_image; andy_image();
end
cd(current_analysis_dir);