function [rm ranovatbl]=eleven_rpanova(dataset,condname,factorname,factorlevel)

%input:
% dataset=[LR_Circ_stab_exp1_clean,LRf_Circ_stab_exp1_clean,UL_Circ_stab_exp1_clean,ULf_Circ_stab_exp1_clean];
% condname={'LR' 'LRf' 'UL' 'ULf'};
% factorname={'type','isfix'};
% factorlevel={...
%     'LR' 'LR' 'UL' 'UL';...
%     'nf' 'f' 'nf' 'f';...
%     };

% output statistic table

% update history
% 2024-05-09 intial version
%---------------------------------
sz = size(dataset);
varTypes=cell(1,sz(2));
for ii=1:sz(2)
varTypes{ii} = 'double';
end
t = table('Size',sz,'VariableTypes',varTypes,'VariableNames',condname);
t(:,:) = num2cell(dataset,sz);

factorlevel=factorlevel';
sz1 = size(factorlevel);
varTypes1=cell(1,sz1(2));
for ii=1:sz1(2)
varTypes1{ii} = 'string';
end
within = table('Size',sz1,'VariableTypes',varTypes1,'VariableNames',factorname);
within(:,:) = factorlevel;

temp=[];
for ii=1:length(condname)
    temp=[temp,condname{ii},','];
end
MODELSPEC=[temp(1:end-1),'~1'];
rm = fitrm(t,MODELSPEC,'WithinDesign',within);

temp=[];
for ii=1:length(factorname)
    temp=[temp,factorname{ii},'*'];
end
wm=temp(1:end-1);
ranovatbl = ranova(rm,'WithinModel',wm);





