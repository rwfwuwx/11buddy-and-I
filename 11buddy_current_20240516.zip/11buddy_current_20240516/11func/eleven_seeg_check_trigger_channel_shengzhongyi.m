function eleven_seeg_check_trigger_channel_shengzhongyi(edf_file,ch_index_trigger,cut_time)
% test Shengzhongyi trigger channel

EEG = pop_biosig(edf_file);

EEG = pop_select(EEG,'time',cut_time);

tmp = EEG.data; %
trigger_raw = tmp(ch_index_trigger,:);

figure;
for ii=1:length(ch_index_trigger)
    subplot(4,4,ii); % make this flexible later
    plot(1:10*2000, trigger_raw(ii,1:10*2000)); % plot 10s. trigger begin from the 4th s
    title(num2str(ii));
end
%