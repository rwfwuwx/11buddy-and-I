function [R_value,P_value,rmse] = eleven_trainRegression_eva(y,y_fit,is_plot)
% [R_value,P_value,rmse] = eleven_trainRegression_eva(y,y_fit,is_plot)
%
%  see eleven_trainRegression.m.
%
% Todo
%   !!! for how to statistically describe multyple y, 
%       1. currently, average across sbj, and corr between avg y and avg y_fit.
%           alternatively, can cat and corr between cat y and cat y_fit (confirm later)
%       2. for plot, plot the avg curves. 
%           This can be improved by plot avg+CI(add later)
%           refine current
% Update history
%   2021-09-29 add corr handling nan
%   2021-09-28 add multiple y. 
%   2021-09-23 initial version

if size(y,2)==1
    [R_value, P_value] = corr(y_fit,y,'rows','complete');
    rmse = sqrt(mean((y_fit - y).^2)); % rmse, not necessary
    
    if is_plot
        figure; plot(y,y_fit,'ko'); lsline
        xlabel('observed data'); ylabel('predicted data');
        title(['Prediction evaluation. ' 'R: ' num2str(R_value) '; P: ' num2str(P_value)]);
    end
end

if size(y,2)>1
    [R_value, P_value] = corr(mean(y_fit)',mean(y)','rows','complete');
    
    rmse = sqrt(mean(mean((y_fit - y).^2))); % rmse, not necessary
    
    if is_plot
        figure; plot(mean(y),'r'); 
        hold on; plot(mean(y_fit),'b');
        %xlabel('observed data'); ylabel('predicted data');
        R_value
        P_value
        title(['Prediction evaluation. ' 'R: ' num2str(R_value) '; P: ' num2str(P_value)]);
    end
end


