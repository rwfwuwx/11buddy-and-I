function eleven_DrawCircularGraph(connectMatrix,regionLabel)
%
% Update history
%   2022-03-21 initial version, on Liying's test

%figure;
%myColorMap = lines(length(connectMatrix));

%circularGraph(connectMatrix,'Colormap',myColorMap,'Label',regionLabel);
circularGraph(connectMatrix,'Label',regionLabel);
