function [eeg_raw,ch_label,eeg_ecd] = eleven_eeg_import_data(eeg_file,cut_time,is_resample, resample_rate,import_file_type,eeglab_save_name)
% [eeg_raw,ch_label,eeg_ecd] = eleven_eeg_import_data(eeg_file,cut_time,is_resample, resample_rate,import_file_type)
% Input
%   eeg_file -- eeg file
%   cut_time -- the to-be-cut time range in the edf file, in seconds. 
%       Use [starting_time ending_time].
%       use []: for whole data, i.e., no cut.
%   import_file_type -- 
%       1. Biosemi 64, Xianglab. 
%       setting description
%       Online recording. Totally 72 chs in recording (see the corresponding recording pipeline). 
%           1-64 data chanel; 65-68 eye channel (EXG1-4); 69-70 bilateral earlobe channel (EXG5-6); 71-72 unused (EXG7-8).
%       Offline handling.
%           1. when import, assign and re-ref to ref chs 69-70
%               (meantime,during import, default import 70 chs. 69-70(EXG5-6) are removed, and 71-72 (EXG7-8) are now 69-70)
%               Note, Biosemi data are ref free. re-ref duing importing is required.
%           2. Get VEOG (by 65 minus 66, as 65) and HEOG (by 67 minus 68, as 66).
%           3. then keep only EEG chs and eyemovment chs. 
%           The saved data include data channels (1:64) and VEOG (65) HEOG (66).
%       2. egi 128, Xianglab.
%       setting description.
%       Online recording. 
%           default egi setting. Totally 129 chs in recording, 129 is reference cz. 
%       Offline handling.
%           (may not need, depending on eeglab ica, and source brainstrom.    
%           Note, the current ecd handling does not for char
%               therefore, it does not handle manual marking, e.g., 'eyeclose', in such as resting record. which is no problem.
%               ! for event related, the events needs to be further check.
%       3. Neuroscan sysu, add later.
%       More
%       (add more for new equipment and settings)
%       (Neuroscan ustc. old times. not use anymore)
%   is_resample -- whether to resample. 1,yes; 0,no. 
%   resample_rate -- if is_resample=1, input a resample rate. if is_resample=0, input as [];
%       Notes about resample:
%       For standrized processing, better use sample rate of 1000. 
%       or, for low sample rate, use 500.
%       1) if original sample rate = 1000, or 500; no need to resample.
%       2) if sample rate > 1000, e.g., 2000, 1024;  resample to 1000.
%       or > 500, e.g., 512, resample to 500.
%   eeglab_save_name -- also save eeglab format file. keep name same as mfeeg eeg_raw name. 
%       if [], no save.
% Output
%   eeg_raw -- raw data in mf_eeg format.
%   ch_label -- lables of channels.
%   eeg_ecd -- ecd file in mf_eeg format.
%   (if save eeglab format file) 
%
% --- update history
% 2023-10-18
%   (when data collection is not under standard conduction, the experimentor
%   does not kown the data with triggers or not. thus, analyze the data with
%   no trigger setting.) 
%   handle window popping up by setting typefield of 'code'
%   when some resting egi data actually have triggers.
% 2022-07-17
%   bug fix for loading egi without event.
% 2022-03-16
%   bug fix for loading egi without event.
% 2022-01-07 
%   add eeg_ecd definition of egi 128. bug fix for loading egi without
%   event.
% 2021-11-18
%   for bug 1971.
%       with updates of eeglab 2020-0. EEG.event.type-> EEG.event.edftype,
%           and EEG.event.type marked boundry, conditionxx etc.
%       by this, handle the bug of boundry simply not including EEG.event.type == boundry. 
% 2020-12-11 
%   �������pop_mffimport()�������ݺ���trigger��û��trigger���������������򲻰���code����
%   ���� eleven_eeg_import_data��������Ӧ���� 
%   testing 
%   ������code�����ݣ����ȥ��code�������������Ի���ѡ��code�����Զ��Զ��������С�
%   ��ʵ 
%   ��eleven_eeg_import_data��
%       ��������code���Ӳ���
%       ԭ2--egi 128������չ�������£�
%           21��egi 128
%               211:��code
%               212:��code2
%           22��egi 256
%       ԭ��code������������code����²�����
% 2020-11-13 for egi 128, remove 129, thus total 128. this is according to eeglab, which prefers 128 in ica.
% 2020-11-11 add egi 128
% 2020-10-11 
%   further handling of missed trigger number
%   fix a double->single bug when save eeglab file
% 2020-07-31
%   add save eeglab format, for ica.
%   add ch handling 
% 2020-07-27 fix for eeglab bug 1971. see data_import_develop.docx 2020-07-27.
% 2020-07-24 done biosemi.
% 2020-06-07 initially written, via incorparating eleven_seeg_import_edf.m and mf_bdf2raw.m

if nargin~=6
    disp('eleven_eeg_import requires 6 arguments!');
    return;
end

%--- read eeg_file.
% read by eeglab, via biosig.
% EEG is the data structure of eeglab. in which, the needed info are:
%   EEG.data: ch*sample_points
%   EEG.chanlocs(ch).labels: ch lables.
%   EEG.event
%       EEG.event.type: event 
%       EEG.event.latency: event time (in sample point)
if import_file_type==1
    EEG = pop_biosig(eeg_file, 'ref',[69 70] ,'refoptions',{'keepref' 'off'});
end
if import_file_type==211
    d=dir([eeg_file,'\Event*.xml']);
    if isempty(d)
        EEG = pop_mffimport({eeg_file});
    else
        EEG = pop_mffimport({eeg_file},{'code'});
    end
end
if import_file_type==212
    EEG = pop_mffimport({eeg_file},{'code'});
end

% check other type later
%    EEG = pop_biosig(eeg_file); 


EEG.data = double(EEG.data); % somehow, the import format is single, convert to double 

%--- cut data according to cut_time
if ~isempty(cut_time)
    EEG = pop_select(EEG,'time',cut_time);
end

%--- resample
if is_resample
    EEG = pop_resample(EEG,resample_rate);
end

%--- ch handle
if import_file_type==1
    % calculate EOG. "Get VEOG (by 65 minus 66, as 65) and HEOG (by 67 minus 68, as 66)."
    EEG.data(65,:) =  EEG.data(65,:) -  EEG.data(66,:);
    EEG.data(66,:) =  EEG.data(67,:) -  EEG.data(68,:);
    
    EEG.chanlocs(65).labels = 'VEOG';
    EEG.chanlocs(66).labels = 'HEOG';
    
    % keep needed ch
    EEG=pop_select(EEG,'channel',[1:66]);
end

% for import_file_type == 2 %
if import_file_type==211 || import_file_type==212
    EEG=pop_select(EEG,'channel',[1:(length(EEG.chanlocs)-1)]); % i.e., remove the last ref ch 129. The last ch is ref, would also apply to egi 256.
end

% check other type later

% |----- for eeglab -----|
if ~isempty(eeglab_save_name)
    EEG = eeg_checkset(EEG);
    EEG = pop_saveset(EEG,[eeglab_save_name '.set'],pwd);
end

EEG.data = double(EEG.data); % somehow, the above "for eeglab" change double to single 

% |----- for mfeeg -----|
%--- get eeg signal data 
eeg_raw = EEG.data;
eeg_raw = eeg_raw'; % ch*sample -> sample*ch

%--- get ch labels
if import_file_type==1
    ch_label=cell(66,1);
    for ii=1:64
        ch_label{ii} = EEG.chanlocs(ii).labels;
    end
    ch_label{65} = 'VEOG';
    ch_label{66} = 'HEOG';
end

if import_file_type==211 || import_file_type==212
    ch_label=cell(length(EEG.chanlocs),1);
    for ii=1:length(EEG.chanlocs)
        ch_label{ii} = EEG.chanlocs(ii).labels;
    end
end

% add other type later

%--- get ecd
eeg_ecd = [];

if ~isempty(EEG.event)
    for ii=1:length(EEG.event)
        if ~strcmp(EEG.event(ii).type,'boundary')
            ecd_tmp = zeros(1,2);
            
            % type
            if import_file_type==1
                if isnumeric(EEG.event(ii).edftype) % number is assumed
                    ecd_tmp(1,1)= EEG.event(ii).edftype;
                end
                
                if ischar(EEG.event(ii).edftype)
                    if ~isempty(str2num(EEG.event(ii).edftype)) % letter(s) is not assumed. But number may be in char format, e.g. '3'.
                        ecd_tmp(1,1)= str2num(EEG.event(ii).edftype);
                    end
                end
            end
            
            if import_file_type==211
                ecd_tmp(1,1)= 11;
            end
            
           if import_file_type==212             
                if ~isempty(str2num(EEG.event(ii).code))
                    ecd_tmp(1,1)= 11;
                end
            end
            
            % latency
            if import_file_type==1 || import_file_type==212
                ecd_tmp(1,2) = round(EEG.event(ii).latency);
            end
            if import_file_type== 211
                ecd_tmp(1,2) = 60 * EEG.srate;
            end
            
            eeg_ecd = [eeg_ecd;ecd_tmp];
        end
    end
end

disp('import done.');


