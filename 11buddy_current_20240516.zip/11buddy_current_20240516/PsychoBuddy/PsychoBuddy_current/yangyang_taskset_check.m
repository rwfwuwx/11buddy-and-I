function return_task_list = yangyang_taskset_check(check_job,modified_option)
%
% Input
%   check_job
%       1. return the list of all tasks
%       2. return the list of tasks that have OptionVariable_modify.txt
%       3. return the list of tasks that have a specified modified option in OptionVariable_modify.txt.
%   modified_option
%       the modified option, input as a string, e.g., 'display_rect_size_factor'
%           [] for check_job being 1, 2
%           specify for check_job bing 3 
%   Output
%       a list of task set as specified above. 
%           if not found, return [];
%           in cell format.
% Usage examples
%   yangyang_taskset_check(1,[])  
%   yangyang_taskset_check(2,[])  
%   yangyang_taskset_check(3,'display_rect_size_factor') 
%
% to-do
%   for check_job = 3, might return repeated task name. confirm later
%
% Update history
% 2020-01-10
%   initially written
%       modified from yangyang_set_task

% which_system  1: linux; 2: windows 3: mac
if IsLinux
    task_set_path = '/home/yangyang/PsychoBuddy_directory/PsychoBuddy_task_set/ieeg_task_set'; 
end
if ispc
    task_set_path = 'D:\PsychoBuddy_directory\PsychoBuddy_task_set\ieeg_task_set'; 
end
%{
if ismac
    %handle later as needs
end
%}

return_task_list_index = 0;

task_set_list_struct = dir(task_set_path);

current_path = pwd;
for ii = 3:length(task_set_list_struct)
    cd( fullfile(task_set_path, task_set_list_struct(ii).name) );
    
    if check_job == 1
        return_task_list_index = return_task_list_index +1;
        return_task_list{return_task_list_index,1} = task_set_list_struct(ii).name;
    end
    
    if check_job == 2
        if exist('OptionVariable_modify.txt','file')
            return_task_list_index = return_task_list_index +1;
            return_task_list{return_task_list_index,1} = task_set_list_struct(ii).name;
        end
    end
    
    if check_job == 3
        if exist('OptionVariable_modify.txt','file')
            fid = fopen('OptionVariable_modify.txt');
            while 1
                tline = fgetl(fid);
                if tline == -1
                    break;
                end
                if ischar(tline)
                    if ~isempty(strfind(tline,modified_option))
                        return_task_list_index = return_task_list_index +1;
                        return_task_list{return_task_list_index,1} = task_set_list_struct(ii).name;
                    end
                end
            end
            fclose(fid);
        end
    end
    
end
cd(current_path);

if return_task_list_index == 0
    return_task_list = [];
end
