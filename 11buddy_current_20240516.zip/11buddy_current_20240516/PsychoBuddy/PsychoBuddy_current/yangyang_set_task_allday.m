% update history
%   2021-01-19 (liying)
%       modified from yangyang_set_task.m , add building task_set for all day, such as yangyang_taskset_check.m
%       add program ending tip.

clear;

% which_system  1: linux; 2: windows 3: mac
if IsLinux
    task_set_path = '/home/yangyang/PsychoBuddy_directory/PsychoBuddy_task_set/ieeg_task_set'; 
end
if ispc
    task_set_path = 'D:\PsychoBuddy_directory\PsychoBuddy_task_set\ieeg_task_set'; 
end
%{
if ismac
    %handle later as needs
end
%}

current_path = pwd;
day_list_struct = dir(current_path);

for ii = 3:length(day_list_struct)
    cd( fullfile(current_path, day_list_struct(ii).name) );
    
    task_list = importdata('task_list.txt');
    
    for jj=1:length(task_list)
        copyfile(fullfile(task_set_path, task_list{jj}),task_list{jj});
    end
    
    cd(current_path);
end

disp('job done.');

clear;