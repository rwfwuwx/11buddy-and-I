% update history
%   2020-01-10 update for different systems
%	2020-12-09 yangyang_set_task_shengzhongyi -> yangyang_set_task
%		i.e., standarize this step.
%   2020-09-28

clear;

% which_system  1: linux; 2: windows 3: mac
if IsLinux
    task_set_path = '/home/yangyang/PsychoBuddy_directory/PsychoBuddy_task_set/Study'; 
end
if ispc
    task_set_path = 'D:\PsychoBuddy_directory\PsychoBuddy_task_set\Study'; 
end
%{
if ismac
    %handle later as needs
end
%}

task_list = importdata('task_list.txt');

for ii=1:length(task_list)
    copyfile(fullfile(task_set_path, task_list{ii}),task_list{ii});
end

clear;