function eleven_GLAutojob_routine_behavRptAnaAvg(dir_root_file,dir_tree_file,behav_analyze_type_list_file,sbj_info_file,sbj_index,is_formal)
% Input
%
% Todo
%
% Note
%   # [$$ ... end $$] indicates where to modify activity, as needs.
%   # compare to eeg, behav is much simplified, see detailed code simplification.
%   particularly, 
%       no need to set further dir structure for each analyze_type. thus remove the dir_structure loop.
%       for activities of each analyze type,
%           eeg is complicated and manually set (need much optimization later)
%           behav is to simply set an activity list, and read it in a loop.
% Update history
%   2024-04-18 initial version, modify from eleven_GLAutojob_routine_eegRptAnaAvg.m

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

%--- select data based on sbj_index
sbj_index = sbj_index(:); % in case sbj_index is not input as column vector

if ~isempty(sbj_index)
    sbj_index_num = find(sbj_index==1);
    
    sbj = sbj(sbj_index_num);
    for ii=1:data_num
        tmp_var_name = sbj_info_var_name{ii+2};
        eval(sprintf('%s=%s(sbj_index_num);',tmp_var_name,tmp_var_name));
    end
end


%--- decide whether include a data
data_include_index = ones(data_num,1);

% not include data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        data_include_index(ii) = 0;
    end
end

data_include_index_num = find(data_include_index==1);



for ii = 1:length(data_include_index_num) % loop of data
    
    allsbj_data_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{[data_include_index_num(ii)]}];
    sbj_data_path = [dir_root{1} '\' 'sbjxx' '\' dir_tree{[data_include_index_num(ii)]}];
    
    current_dir_allsbj = allsbj_data_path;
    cd(current_dir_allsbj);
    
    behav_analyze_type_list = load(behav_analyze_type_list_file);
    behav_analyze_type = behav_analyze_type_list([data_include_index_num(ii)],1);
    
    %- set behav activity
    %$$ modify here as needs, be consistent with TSs defined in in eleven_behav_activity.m
    if behav_analyze_type == 1
        behav_TS_list = {'correct','RT'};
    end
    if behav_analyze_type == 2 % extend here as needs
        behav_TS_list = {'asyn','ITI'};
    end
    %end $$
    

    load cond_name;
    cond_num = length(cond_name);
    
    for ll=1:cond_num % loop of cond
        
        for jj = length(behav_TS_list) % loop of activity
            
            input_data_name = ['behav_TS_' behav_TS_list{jj} '_' cond_name{ll}];
            
            tmp_allsbj_result = 0;
            
            % loop of sbj
            num_sbj_add = 0;
            for kk = 1:length(sbj) % loop of sbj
                % whether analyze the data of this sbj
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                % handling if nan
                if isnan(tmp_is_analyzed_cond)
                    tmp_is_analyzed_cond = 0;
                end
                if tmp_is_analyzed_cond == 1
                    current_dir_sbj = strrep(sbj_data_path, 'sbjxx', sbj{kk});
                    cd(current_dir_sbj);
                    eval(sprintf('load %s;',input_data_name));
                    eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                    eval(sprintf('clear %s;',input_data_name));
                    tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                    
                    num_sbj_add = num_sbj_add + 1;
                end
            end
            
            cd(current_dir_allsbj);
            tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
            eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
            eval(sprintf('save %s %s;',input_data_name,input_data_name));
            is_avg_result = 1; save is_avg_result is_avg_result;
            
        end
    end
end

cd([dir_root{1} '\' allsbj_dirName]);
