function eleven_eeg_source(ProtocolName,SubjectName,is_individual_ch_postion,is_only_TSExtract)
% eleven_eeg_source(ProtocolName,SubjectName,is_only_TSExtract)
% Usage
%   eleven_eeg_source(ProtocolName,SubjectName,is_only_TSExtract)
%   Note: The whole source serves as a processing, scalp sensors->source regions:
%       Input: run2/ (copy as run3/) eeg_raw_pp_rbc_ica_final.set
%       Output: run3/atlas/eeg_raw_pp.mat
%       Therefore, eeg_raw_pp.mat is the same for both run1,run2,run3
%           run1/eeg_raw_pp.mat
%           run2/eeg_raw_pp.mat (after remove bad ch, and ica)
%           run3/atlas/eeg_raw_pp.mat (after sensor->source)
%       Later analyses then can be consistently performed on run1/run2/run3
% Input
%   ProtocolName --- same as studyName
%   SubjectName ---
%   is_individual_ch_postion 
%       0: default. use template. 1: use individuals. 
%   is_only_TSextract --- 0: default  all steps. 1: only run TS extract.
%       (note that the global on/off option is is_eegSource_TSExtract == 1. is_only_TSextract is added here for flexibility. would optimize later)
% external varialbe (add later)
%  -- input
%  -- option
%  -- output
% todo
%       also For different source parameters, do in separate folders,
%           !!! simply modify dirTree in calling group func.
% Note:
%   Due to brainstorm's db, (see description in eleven_eegSource_Import),
%       ProtocolName,SubjectName, and the hidden DataFile requires specific info outside 'current directry'. 
% Update history 
%   2023-05-10 
%       clarify and fix the confusion and bug of is_individual_ch_postion. further see 'source_update_20230510.docx'. 
%   2022-02-28 
%       addd open/close bs in this level.
%       keep only cortex. use DesikanKilliany as default
%           !!! the result of volume is unnormal in testing. reject volume in brainstorm
%   2022-02-25 
%       add handling ProtocolName_C (cortex) ProtocolName_V (colume)
%       add handling is_individual_ch_postion
%   2022-01-xx add save source_atlas: the name of the atlas of the current directory.
%   2021-10-25 
%       save to the andy's standard 'eeg_raw_pp'. also see old script 'eleven_eeg_brainstrom2mfeeg_source_TS_template.m'
%       Given the flexible needs, and the added file organization, add input is_only_TSExtract,
%       !!! add make dir for each atlas, the organization is as below,
%           run3/atlas1
%           run3/atlas2
%           ...
%           for the next step of the anlysis pipeline, run3/atlas#number will be 'current directory'
%       eval(sprintf('save %s %s;',outputName,outputName)); -> evalin('base',sprintf('save %s %s;',outputName,outputName));
%           thus acess the variable outside func in workspace 
%       add on/off on each step
%       initial version,based on H:\soft\11buddy\11buddy_current\11job\source_test\test_2021_10_11.

%clear;

% --- load option variables
eleven_eeg_set_OptionVariable_eegSource;
eleven_eeg_set_OptionVariable_eegSource_customize;
load eleven_eeg_OptionVariable_eegSource_customize;

% Start BrainStorm in silent mode. 
if ~brainstorm('status')
    brainstorm nogui
end

% DataFile (full path. get in the rule of 'current directry')
current_dir = pwd;
DataFile = [current_dir,'\',andy2brainstorm_fileName];

% |--- cortex ---|
CorV=1;
ProtocolName_C = [ProtocolName '_C'];
if is_only_TSExtract == 0
    %--- Import
    
    if is_eegSource_Import == 1
        disp('source Import');
        if is_individual_ch_postion==0 % use common ch template
            eleven_eegSource_Import(ProtocolName_C,SubjectName,DataFile,CorV);
        end
        % if is_individual_ch_postion==1 % use individual ch template,handle later
    end
    
    %--- Forward
    % if is_noRepeat_Forward == 1; % handle later
    if is_eegSource_Forward == 1
        disp('source Forward');
        load sFile_FileName_Import_C;
        eleven_eegSource_Forward(ProtocolName_C,SubjectName,sFile_FileName_Import_C,is_noise_cov,CorV);
    end

    
    %---Inverse
    if is_eegSource_Inverse == 1
        disp('source Inverse');
        load sFile_FileName_Import_C;
        eleven_eegSource_Inverse(ProtocolName_C,sFile_FileName_Import_C,inverseMethod,inverseMeasure,CorV);
    end
end

% |--- Volume ---|
%{
CorV=2;
ProtocolName_V = [ProtocolName '_V'];
if is_only_TSExtract == 0
    %--- Import
    if is_eegSource_Import == 1
        disp('source Import');
        eleven_eegSource_Import(ProtocolName_V,SubjectName,DataFile,CorV);
    end
    
    %--- Forward
    if is_individual_ch_postion==1
        if is_eegSource_Forward == 1
            disp('source Forward');
            load sFile_FileName_Import_V;
            eleven_eegSource_Forward(ProtocolName_V,SubjectName,sFile_FileName_Import_V,is_noise_cov,CorV);
        end
    end
    
    %---Inverse
    if is_eegSource_Inverse == 1
        disp('source Inverse');
        load sFile_FileName_Import_V;
        eleven_eegSource_Inverse(ProtocolName_V,sFile_FileName_Import_V,inverseMethod,inverseMeasure,CorV);
    end
end
%}

%--- TS extract
if is_eegSource_TSExtract == 1
    disp('source TS extract');
    
    for ii=1:length(atlasNames)
        if strcmp(atlasNames{ii},'Brodmann_YCG_copy')
            load sFile_FileName_Inverse_V;
            eleven_eegSource_TSExtract(ProtocolName_V,sFile_FileName_Inverse_V,atlasNames{ii},EEGBuddy_TSExtract_OutputName);
        end
        if strcmp(atlasNames{ii},'Destrieux')
            load sFile_FileName_Inverse_C;
            eleven_eegSource_TSExtract(ProtocolName_C,sFile_FileName_Inverse_C,atlasNames{ii},EEGBuddy_TSExtract_OutputName);
        end
        if strcmp(atlasNames{ii},'DesikanKilliany')
            load sFile_FileName_Inverse_C;
            eleven_eegSource_TSExtract(ProtocolName_C,sFile_FileName_Inverse_C,atlasNames{ii},EEGBuddy_TSExtract_OutputName);
        end
        
        % mkdir for atlas and save TS in it
        if ~exist(atlasNames{ii},'dir')
            mkdir(atlasNames{ii});
        end
        if exist(atlasNames{ii},'dir')
            cd(atlasNames{ii});
            
            % save the TS structure, which is exported to workspace by export_matlab in eleven_eegSource_TSExtract 
            outputName = [EEGBuddy_TSExtract_OutputName,'_',atlasNames{ii}];
            evalin('base',sprintf('save %s %s;',outputName,outputName));
            
            % get the TS value in TS structure,save with the andy standard name 'eeg_raw_pp'
            eval(sprintf('load %s;',outputName));
            
            eval(sprintf('tmp = %s.Value;',outputName));
            tmp = tmp';
            eval(sprintf('%s = tmp;',brainstorm2andy_fileName));
            eval(sprintf('save %s %s;',brainstorm2andy_fileName,brainstorm2andy_fileName));
            
            source_atlas = atlasNames{ii};
            save source_atlas source_atlas
            cd ../;
        end
    end
end

% Quit Brainstorm
brainstorm stop;   

