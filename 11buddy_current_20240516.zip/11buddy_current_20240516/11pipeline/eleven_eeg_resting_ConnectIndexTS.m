function eleven_eeg_resting_ConnectIndexTS
% eleven_eeg_resting_ConnectIndexTS
% Usage
%   eleven_eeg_resting_ConnectIndexTS
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2022-03-01 add setting of resting_ch_include = []; for source
%   2020-10-30 add padding handling
%   2020-10-21 written

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|

%clear;
disp('resting connectivity index time series processing');

% load option variables
load eleven_eeg_OptionVariable_customize;

tmp_dir=pwd;
if exist([tmp_dir '\' 'source_atlas.mat'],'file')
    resting_ch_include = []; % default all sources
end

% |--- on raw data ---|
% --- input
load eeg_raw_pp;

eeg_raw_pp = eeg_raw_pp([resting_padding_points+1:size(eeg_raw_pp,1)-resting_padding_points-1],:); % cut required data, by removing the starding and ending padding time

disp('  ConnectIndexTS');
eeg_resting_ConnectIndexTS_raw = mf_raw_ConnectIndexTS...
    (eeg_raw_pp,resting_connect_type,resting_ch_include,resting_connect_index,resting_moving_window,resting_moving_step);

save eeg_resting_ConnectIndexTS_raw eeg_resting_ConnectIndexTS_raw;

% | --- on AMEnv ---|
% |--- processing loop by freq band ---|
freq_band_num = length(resting_freq_band_name);

for ii=1:freq_band_num
    % --- input
    input_data_name = ['eeg_resting_AMEnv' '_' resting_freq_band_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('eeg_resting_AMEnv_tmp = %s;',input_data_name));
    
    eeg_resting_AMEnv_tmp = eeg_resting_AMEnv_tmp([resting_padding_points+1:size(eeg_resting_AMEnv_tmp,1)-resting_padding_points-1],:); 
    
    disp('  ConnectIndexTS');
    eeg_resting_ConnectIndexTS_tmp = mf_raw_ConnectIndexTS...
        (eeg_resting_AMEnv_tmp,resting_connect_type,resting_ch_include,resting_connect_index,resting_moving_window,resting_moving_step);
    
    %--- output
    output_data_name = ['eeg_resting_ConnectIndexTS' '_' resting_freq_band_name{ii}];
    eval(sprintf('%s = eeg_resting_ConnectIndexTS_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    % --- clear
    eval(sprintf('clear %s;',output_data_name));

end

%clear;
