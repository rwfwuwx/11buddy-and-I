function eleven_eeg_pp
% eleven_eeg_pp	
% Usage
%   eleven_eeg_pp
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2021-12-11 remove load exp variable
%   2021-10-26 remove design_type in pp.
%       see the corresponding update document , and the updated manual and automation, in Oct.2021. 
%   2020-11-13 add is_pp_low_pass
%   2020-10-21 separate reref from eleven_eeg_pp
%   2020-10-11 add handling of eeg_analyze_type
%   2020-07-30 add design_type
%   2020-04-08 add removing 50 Hz AC and harmonies
%   2020-03-25
%   reorgize and rewrite from Andy. 
%   2020-01-07
%       ...
%       Andy is ready
%   2020-01-06
%       ...
%	2020-01-05 initially writen

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|

%clear;
disp('pre-processing');

% load option variables
load eleven_eeg_OptionVariable_customize;

% --- input
load eeg_raw;

% --- filter
% high-pass
disp('  high-pass filter');
eeg_raw_pp = mf_rawfilter(eeg_raw,'IIR','high pass',pp_high_cutoff,4,fs);

% low-pass
if is_pp_low_pass
    disp('  low-pass filter');
    eeg_raw_pp = mf_rawfilter(eeg_raw_pp,'IIR','low pass',pp_low_cutoff,4,fs);
end

% band-stop
disp('  band-stop AC 50 Hz filter');
for ii=1:size(pp_AC_cutoff,1)
    eeg_raw_pp = mf_rawfilter(eeg_raw_pp,'IIR','band stop',pp_AC_cutoff(ii,:),4,fs);
end

% --- output
save eeg_raw_pp eeg_raw_pp;

%clear
