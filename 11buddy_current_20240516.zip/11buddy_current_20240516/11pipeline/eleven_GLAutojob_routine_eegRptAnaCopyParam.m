function eleven_GLAutojob_routine_eegRptAnaCopyParam(dir_root_file,dir_tree_file,eeg_analyze_type_list_file,sbj_info_file,is_formal)
% Input
%
% Todo
%   atlasNames is now mannualy assigned.
%   dir structure is now manually assigned
%   
% Note
%   what if different subjects has different param, e.g., patient vs. normal?
%       this is a sudo-question, comparison are assume to be under same param
%       Situation 1: many sbjs have different param. This is actually a different type of data.
%       Situation 2: few sbjs have different param. avoid this. If occurs,
%            manually specify the subjects (as a index) for allsbj, instead of using the first sbj automatically. (add as needs) 
%   the param files/variables are according to eleven_GLAutojob_routine_eegDataAnaDirPrepare, with minor change as need in work3.
%   the sbj loop and data loop are same as eleven_GLAutojob_routine_eegDataAnaDirPrepare.
%       the inner logic to find dir is the the similar to eleven_GLAutojob_routine_eegRptAnaDirPrepare.
% Update history
%   2024-01-05 add delete SbjData_eeg_file.xlsx in forlder 'allsbj' to avoid andy3 load the xlsx file in local forlder
%   2022-08-09 add handling if nan
%   2022-06-17
%       correction: 'ones(data_num);' -> ones(data_num,1); 'zeros(data_num);' -> zeros(data_num,1);
%       remove dataList_eeg_file.
%   2022-06-14
%       --- before, need the first sbj with is_analysis==1, and assume the data ==1 are the same for all sbj
%       Now, change to
    %       whther the data is to copy param
	%            the data of the sbj is analyzed
	%               param is allready copied
%       --- for allsbj path, replace data_list by dir_tree. the same as 'DirPrepare'
%   2022-01-23 
%       add is_formal, i.e., allsbj->allsbj_test when test
%       add copyfile source setting file.
%   2022-01-xx 
%       add copyfile 'source_atlas.mat'.
%   2022-01-16
%       minor updating copied para according to eleven_eeg_resultImage.
%   2022-01-15
%       initial version as a new routine. modify from eleven_GLAutojob_routine_eegDataAnaDirPrepare & eleven_GLAutojob_routine_eegRptAnaDirPrepare.

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
current_folder = pwd;
if exist([current_folder '\' sbj_info_file],'file') % check and delete local xlsx file
    delete(sbj_info_file);
end
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

%--- decide whether copy param for a data
is_CopyParam_data = ones(data_num,1);

% not copy data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        is_CopyParam_data(ii) = 0;
    end   
end

%--- initialize the switch whether param has been copied for data
is_ParamCopied_data = zeros(data_num,1);

atlasNames = {'DesikanKilliany'};

for ii = 1:length(sbj) % loop of sbj
    
    for jj = 1:data_num % loop of dir_tree\cond
        
        % whether the value of this cond == 1,of this sbj
        tmp_var_name = sbj_info_var_name{jj+2};
        eval(sprintf('tmp_is_analyzed_cond = %s(ii);',tmp_var_name));
        
        % handling if nan
        if isnan(tmp_is_analyzed_cond)
            tmp_is_analyzed_cond = 0;
        end
        
        % whther the cond is to copy param, and the cond of the sbj is analyzed
        tmp_is_analysis_cond = is_CopyParam_data(jj) & tmp_is_analyzed_cond;
        
        % and whether param is allready copied
        if tmp_is_analysis_cond == 1 & is_ParamCopied_data(jj) == 0
            
            % copy, meanwhile set is_ParamCopied_data(jj) == 1;
            is_ParamCopied_data(jj) == 1;
            
            current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
            allsbj_analysis_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{jj}];
            
            if exist(current_analysis_path,'dir')
                cd(current_analysis_path);
                
                % |--- do the job here ---|
                
                %--- routine ---
                eeg_analyze_type_list = load(eeg_analyze_type_list_file);
                eeg_analyze_type = eeg_analyze_type_list(jj,1);
                
                
                % run2
                if ~isempty(find(eeg_analyze_type == [1 2 3 42]))
                    tmp_dir = [current_analysis_path '\' 'run2'];
                    tmp_dir_allsbj = [allsbj_analysis_path '\' 'run2'];
                    
                    copyfile([tmp_dir '\eeg_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eeg_analyze_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\fs.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eleven_eeg_OptionVariable_customize.mat'],tmp_dir_allsbj);
                    
                    if eeg_analyze_type == 42
                        copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                    end
                    if eeg_analyze_type == 1
                        copyfile([tmp_dir '\resting_time.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eeg_resting_spec_freq.mat'],tmp_dir_allsbj);
                    end
                    if ~isempty(find(eeg_analyze_type == [2 3 42]))
                        copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                    end
                    if eeg_analyze_type == 3
                        copyfile([tmp_dir '\eeg_ssep_spec_freq_*.mat'],tmp_dir_allsbj);
                    end
                end
                %   sr
                if eeg_analyze_type == 4
                    tmp_dir = [current_analysis_path '\' 'run2' '\' 'srer'];
                    tmp_dir_allsbj = [allsbj_analysis_path '\' 'run2' '\' 'srer'];
                    
                    copyfile([tmp_dir '\eeg_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eeg_analyze_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\fs.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eleven_eeg_OptionVariable_customize.mat'],tmp_dir_allsbj);
                    
                    tmp_dir = [current_analysis_path '\' 'run2' '\' 'srssep'];
                    tmp_dir_allsbj = [allsbj_analysis_path '\' 'run2' '\' 'srssep'];
                    
                    copyfile([tmp_dir '\eeg_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eeg_analyze_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\fs.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eeg_ssep_spec_freq_*.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eleven_eeg_OptionVariable_customize.mat'],tmp_dir_allsbj);
                end
                
                % run3
                
                % loop of atlas
                for kk=1:length(atlasNames)
                    if ~isempty(find(eeg_analyze_type == [1 2 3 42]))
                        tmp_dir = [current_analysis_path '\' 'run3' '\' atlasNames{kk}];
                        tmp_dir_allsbj = [allsbj_analysis_path '\' 'run3' '\' atlasNames{kk}];
                        
                        copyfile([tmp_dir '\eeg_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eeg_analyze_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\fs.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eleven_eeg_OptionVariable_customize.mat'],tmp_dir_allsbj);
                        %copyfile([tmp_dir '\eleven_eeg_OptionVariable_eegSource_customize.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\source_atlas.mat'],tmp_dir_allsbj);
                        
                        if eeg_analyze_type == 42
                            copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                        end
                        if eeg_analyze_type == 1
                            copyfile([tmp_dir '\resting_time.mat'],tmp_dir_allsbj);
                            copyfile([tmp_dir '\eeg_resting_spec_freq.mat'],tmp_dir_allsbj);
                        end
                        if ~isempty(find(eeg_analyze_type == [2 3 42]))
                            copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                        end
                        if eeg_analyze_type == 3
                            copyfile([tmp_dir '\eeg_ssep_spec_freq_*.mat'],tmp_dir_allsbj);
                        end
                    end
                    % sr
                    if eeg_analyze_type == 4
                        tmp_dir = [current_analysis_path '\' 'run3' '\' atlasNames{kk} '\' 'srer'];
                        tmp_dir_allsbj = [allsbj_analysis_path '\' 'run3' '\' atlasNames{kk} '\' 'srer'];
                        
                        copyfile([tmp_dir '\eeg_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eeg_analyze_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\fs.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eleven_eeg_OptionVariable_customize.mat'],tmp_dir_allsbj);
                        %copyfile([tmp_dir '\eleven_eeg_OptionVariable_eegSource_customize.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\source_atlas.mat'],tmp_dir_allsbj);
                        
                        tmp_dir = [current_analysis_path '\' 'run3' '\' atlasNames{kk} '\' 'srssep'];
                        tmp_dir_allsbj = [allsbj_analysis_path '\' 'run3' '\' atlasNames{kk} '\' 'srssep'];
                        
                        copyfile([tmp_dir '\eeg_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eeg_analyze_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\fs.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\eeg_ssep_spec_freq_*.mat'],tmp_dir_allsbj);
                        
                        copyfile([tmp_dir '\eleven_eeg_OptionVariable_customize.mat'],tmp_dir_allsbj);
                        %copyfile([tmp_dir '\eleven_eeg_OptionVariable_eegSource_customize.mat'],tmp_dir_allsbj);
                        copyfile([tmp_dir '\source_atlas.mat'],tmp_dir_allsbj);
                    end
                end
                
                
                % |--- end job ---|
                
            end
        end
    end
    
end

cd([dir_root{1} '\' allsbj_dirName]);
