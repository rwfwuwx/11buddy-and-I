function eleven_eeg_set_OptionVariable_eegSource_customize
% eleven_eeg_set_OptionVariable_eegSource_customize	
% Usage
%   eleven_eeg_set_OptionVariable_eegSource_customize
%
% Update history 
%   2021-10-25 initial version

clear; % do not remove this

load eleven_eeg_OptionVariable_eegSource;

% |--- add customized options here, if there are ---|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_eeg_set_OptionVariable_eegSource.m here 
%       2. modify here as needs
%       3. run eleven_eeg_set_OptionVariable_eegSource_customize here (make sure in the current program directory)



% --- save
save eleven_eeg_OptionVariable_eegSource_customize;

clear; % do not remove this
