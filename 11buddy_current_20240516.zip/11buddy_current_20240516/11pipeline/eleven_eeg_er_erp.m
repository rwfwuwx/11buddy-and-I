function eleven_eeg_er_erp
% eleven_eeg_er_erp
% Usage
%   eleven_eeg_er_erp
% external varialbe (add later)
%  -- input
%  -- option
%  -- output
%
% Update history
%   2022-01-16 add erp high pass if eeg_analyze_type = 42.
%   2021-12-17 expVariable-> individual variable
%   2020-12-8
%    change eleven_eeg_OptionVariable to eleven_eeg_OptionVariable_customize;
%   2020-04-01
%       add output eeg_epo_before_erp in erp, for single trial stat in seeg
%   2020-03-25
%   reorgize and rewrite from Andy.
%   2020-01-07
%       ...
%       Andy is ready
%   2020-01-06
%       ...
%	2020-01-05 initially writen

% |-------------------------|
% |----------  erp  --------|
% |-------------------------|

%clear;
disp('erp processing');

% --- load option variables
load eleven_eeg_OptionVariable_customize;

load eeg_type;
load eeg_analyze_type;

% --- input
% exp variable
% for condition: condition name.
% (condition code is only needed in epoch)
load cond_name;

% |--- processing loop by condition ---|
cond_num = length(cond_name);

for ii=1:cond_num
    % --- input
    % epo data
    input_data_name = ['eeg_epo' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('eeg_epo_tmp = %s;',input_data_name));
    
    % --- filter
    disp('  filter');
    % low pass
    eeg_epo_tmp_filt = mf_epofilter(eeg_epo_tmp,'IIR','low pass',erp_low_cutoff,4,fs);
    % high pass
    if eeg_analyze_type == 42
        eeg_epo_tmp_filt = mf_epofilter(eeg_epo_tmp_filt,'IIR','high pass',erp_high_cutoff,4,fs);
    end
   
    % --- remove baseline
    disp('  remove baseline');
    eeg_erp_tmp_filt_rmb = mf_epormb(eeg_epo_tmp_filt,erp_baseline_range);
     
    % --- average
    disp('  average');
    eeg_erp_tmp = mf_epoavg(eeg_erp_tmp_filt_rmb);
    
    % --- output
    % output epo_before_erp
    if is_output_epo_before_erp
        output_data_name = ['eeg_epo_before_erp' '_' cond_name{ii}];
        eval(sprintf('%s = eeg_erp_tmp_filt_rmb;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
    end
    
    % output erp
    output_data_name = ['eeg_erp' '_' cond_name{ii}];
    eval(sprintf('%s = eeg_erp_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    % --- clear
    eval(sprintf('clear %s;',input_data_name));
    eval(sprintf('clear %s;',output_data_name));
end

%clear;
