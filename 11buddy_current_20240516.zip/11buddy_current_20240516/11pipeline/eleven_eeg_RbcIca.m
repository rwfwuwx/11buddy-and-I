function andy_autojob_ppRbcIca_source_test_202108
%
% todo
%  
% update history
%   2021-12-13 
%       other minor updates
%       incorporate eleven_eeg_eeglab2mfeeg_continuousData into eleven_eeg_ica_label;
%       rename andy_autojob_ppRbcIca -> eleven_eeg_RbcIca
%       -> func
%   2021-11-18 initial version, modified from andy_autojob_ppNormal_source_test_202108

% |-------------------------|
% |----------- rbc ---------|
% |-------------------------|
disp('remove bad ch');

% get bad ch
ch_bad = eleven_eeg_identify_badch;
save ch_bad ch_bad;

% replace bad ch
eleven_eeg_replace_badch;

disp('remove bad ch,done');

% |-------------------------|
% |----------- ica ---------|
% |-------------------------|
disp('ica remove noise');

% run ica
eleven_eeg_runica;

% get and remove ica_remove_component
ica_remove_component = eleven_eeg_ica_label;
save ica_remove_component ica_remove_component;

disp('ica remove noise,done');



