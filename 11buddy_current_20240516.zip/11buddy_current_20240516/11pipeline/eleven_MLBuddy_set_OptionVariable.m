function eleven_MLBuddy_set_OptionVariable
% eleven_MLBuddy_set_OptionVariable	
% Usage
%   eleven_MLBuddy_set_OptionVariable
% external varialbe (add later)
%  -- output
%
% Update history 
%   2021-09-23 initial version

clear; % do not remove this

% |------------------------------------------------------|
% |------------------------ common ----------------------|
% |------------------------------------------------------|
correlation_method = 'Pearson';
regression_method = 'Linear';
p_threshold = 0.05

% |------------------------------------------------------|
% |---------- eleven_trainRegression/Classifier ---------|
% |------------------------------------------------------|

% --- for fitlm
trainRegression_RobustOpts = 'off';
%trainRegression_RobustOpts = 'on';

%--- for fitrnet
trainRegressionClassifier_LayerSizes = [10]; % one hidden layer
%LayerSizes = [10 10]; % two hidden layer


% --- save
save eleven_MLBuddy_OptionVariable;

clear; % do not remove this

 