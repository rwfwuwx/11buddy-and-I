% the script template to produce exp condition related variables, including triggers of conditions.
%   the cond_code can be a scalar or a vector.
% Usage
%   1. copy eleven_eeg_produce_condition_tmplate.m to 'Current directory'
%   2. modify as needed. 
%       1) condition number; 
%       2) condition name 
%       3) code of each condition
%       Note: 
%       for event-related: generate cond_name ��cond_code.
%       for slow-rhythm: generate cond_name, cond_code, cond_code_sequence, cond_IOI (in s), and cond_IOI_number.
%       for ssep: generate cond_name, cond_code_sequence, and cond_sequence_length (in s).
%   3. run eleven_eeg_produce_expVariable_template.m
%   (also see corresponding pipeline for detailed samples)
% Update history
% 2020-10-11 move assigning of design type to eleven_eeg_set_OptionVariable_customize
% 2020-07-30 add design_type
% before 2020-07 build
clear;

%--- a sample for event-related
cond_name = cell(1,7); % 1 angry, 2 disgust,3 fear,4 sad,5 surprise,6 neutral, 7 happy
cond_name{1} = 'angry'; 
cond_name{2} = 'disgust';
cond_name{3} = 'fear';
cond_name{4} = 'sad';
cond_name{5} = 'surprise';
cond_name{6} = 'neutral';
cond_name{7} = 'happy';

cond_code = cell(1,7); 
cond_code{1} = [1:7:56]; 
cond_code{2} = [1:7:56]+1;
cond_code{3} = [1:7:56]+2;
cond_code{4} = [1:7:56]+3;
cond_code{5} = [1:7:56]+4;
cond_code{6} = [1:7:56]+5;
cond_code{7} = [1:7:56]+6;

%--- a sample for slow-rhythm
%
cond_name = cell(1,3); 
cond_name{1} = 'AT'; 
cond_name{2} = 'VF';
cond_name{3} = 'VR';

cond_code = cell(1,3); 
cond_code{1} = [100 101]; 
cond_code{2} = [200 201];
cond_code{3} = [300 301];

cond_code_sequence = cell(1,3); 
cond_code_sequence{1} = [100]; 
cond_code_sequence{2} = [200];
cond_code_sequence{3} = [300];

cond_IOI = [0.6+0.002];  
% 0.6 is the planned IOI. 
% 0.002 is the error on the exp laptop. note, the actual error is 0.0023, round it to 0.002, to avoid non-integer in ms. 

cond_IOI_number = [33]; % for this sample of 40 events (39 IOIs), excluding events 1-5,40, there remain 34 events (33 IOIs)   
%}

%--- a sample for ssep
%{
cond_name = cell(1,2); 
cond_name{1} = 'face'; 
cond_name{2} = 'bar';

cond_code_sequence = cell(1,2); 
cond_code_sequence{1} = [100]; 
cond_code_sequence{2} = [200];

cond_sequence_length = [20]; 
%}

save expVariable;

clear;