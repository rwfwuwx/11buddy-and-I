function eleven_eeg_reref
% eleven_eeg_reref	
% Usage
%   eleven_eeg_reref
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2021-12-11
%       update load option variables, and corresponding updates
%       remove load exp variable
%       remove design_type
%   2020-10-21 separate from eleven_eeg_pp


%clear;
disp('re-ref processing');

% load option variables
load eeg_type;
load eeg_analyze_type;
load eleven_eeg_OptionVariable_customize;

% --- input
load eeg_raw_pp;

disp('  reref');
if eeg_type == 2 %seeg
    load reref_ch;
end

eeg_raw_pp = mf_rawreref(eeg_raw_pp,reref_ch);

% --- output
save eeg_raw_pp eeg_raw_pp;

%clear
