function eleven_behav_set_OptionVariable_cfe_customize
% eleven_behav_set_OptionVariable_cfe_customize	
% Usage
%   eleven_behav_set_OptionVariable_cfe_customize
%
% Update history
%   2024-04-18 initial version, modify from eleven_eeg_set_OptionVariable_cfe_customize.m

clear; % do not remove this

eleven_behav_set_OptionVariable_cfe;
load eleven_behav_OptionVariable_cfe;


% |-------------------------------------------------|
% |--- add customized options here, if there are ---|
% |-------------------------------------------------|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_behav_set_OptionVariable.m. 
%       2. modify here as needs
%       3. run eleven_behav_set_OptionVariable_customize here (make sure in the current analysis directory)

% --- settings 


% --- save
save eleven_behav_OptionVariable_cfe_customize;

clear; % do not remove this
