function eleven_eeg_import
% eleven_eeg_import
% Usage
%   eleven_eeg_import
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2023-05-23 
%       updates incorporating seeg
%       other minor optimization
%   2021-12-11
%       other minor updates
%       remove design_type
%       remove load exp variable
%   2021-11-18 correction: eleven_eeg_import_data_testing for design_type==2, remove 'testing'
%   2020-12-11 update import_file_type == 211 || import_file_type == 212
%   2020-11-11 add egi 128
%   2020-10-11 add handling of eeg_analyze_type
%   2020-07-31 add save eeglab format, for ica.
%   2020-07-30 add design type
%	2020-07-27 initially writen

% |-------------------------|
% |--------- import --------|
% |-------------------------|

%clear;
disp('import');

% --- input

% load option variables
load eleven_eeg_OptionVariable_customize;
load eeg_type;

if eeg_type == 1
    if import_file_type == 1
        file_type_suffix = '.bdf';
    end
    if import_file_type == 211 || import_file_type == 212
        file_type_suffix = '.mff';
    end
    % add other file types later
    
    eeg_file_name = ['eeg_raw' file_type_suffix];
end

load exp_time;

% --- import
disp('  import');
if eeg_type == 1
    [eeg_raw,ch_label,eeg_ecd_raw] = eleven_eeg_import_data(...
        eeg_file_name,exp_time,is_import_resample,fs,import_file_type,'eeg_raw');
end
if eeg_type == 2
    eeg_file_name = sbjData_belong_to_which_ieegRawData_day;
    [eeg_raw,ch_label,eeg_ecd_raw] = eleven_seeg_import_edf(...
        eeg_file_name,ch_index_target,ch_index_trigger,exp_time,is_import_resample,fs,import_file_type);
end

% --- output
save eeg_raw eeg_raw;
save ch_label ch_label;
save eeg_ecd_raw eeg_ecd_raw;

%clear; 
