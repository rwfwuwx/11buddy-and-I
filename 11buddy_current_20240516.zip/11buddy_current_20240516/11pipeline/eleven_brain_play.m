clear

[k,roi] = get_outline('aal_from_MRIcron',[0 29])
load contact_insula
roi_num = 2;
elec = [1];

%% draw brain outline
brain_color{1} = [0.5 0.5 0.5];
brain_color{2} = [0.5 0.2 0.2];
for jj = 1:roi_num
    P = roi{jj}';
    ax{jj} = trisurf(k{jj},P(:,1),P(:,2),P(:,3),'FaceAlpha',0.2);
    shading interp
    hold on
end
for kk = 1:roi_num
    ff = ax{kk};
    set(ff,'FaceColor',brain_color{kk});
end

%% draw electrodes and contacts
% color = ['g','c','m','y','k'];

for ic = 1:length(elec)
contact = Contact{ic};
% % draw electrodes
% plot3(contact([1,end],1),contact([1,end],2),contact([1,end],3),'y','LineWidth',3);
% hold on

% draw contacts
plot3(contact(:,1),contact(:,2),contact(:,3),'b.','MarkerSize',25);
hold on
end


% axis([-90 90 -120 90 -80 120]);
% xlabel('x coordinate'); ylabel('y coordinate'); zlabel('z coordinate');




    
