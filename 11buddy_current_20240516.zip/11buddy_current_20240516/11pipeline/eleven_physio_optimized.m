function eleven_physio
% eleven_physio	
% Usage
%   eleven_physio
%
%   or load mike; mike()
%   (by mike = @eleven_physio; save mike mike;)
%
% |------------------------|
% |-------description------|
% |------------------------|
% for skin conductance, it is actully the same as eeg, except for (1) one ch (2) no ica, no reref, no souce ...
%   therefore, the analysis per se, is the same as eeg, except that changing settings accordingly.
%   one option is to add the setting as an additional eeg setting; the other option is to add a separate setting.
%   the former is appropriate for developer, the latter is appropriate for user.
%   !!! use option 2. 
%       logically (for user but not developer), treated it as a separate
%       type of analysis -- physio, as call it mike.
%   As the result: 
%       On the one hand,the name is mike, the seeting file is mike
%       on the other hand, the actually analysis and data are actually andy.
% for heart and respiration, the low level functions are basically still the same as eeg (since just sig),
%   specific hear and respiration fuctions are added as need.
%   (Together with skin conductance, physio would be more meaningful for user. )
% Update history
%   2020-11-25 add noise remove for sc, rsp,ecg,IBI
%	2020-10-22 modify from andy


% |----------------------------------- sc Scetion------------------------------------|
%
% clear;
% 
% % |----------------------------------------|
% % |------ pre-processing, and related -----|
% % |----------------------------------------|
% clear; load eleven_eeg_OptionVariable_customize;
% if is_pp
%     eleven_eeg_pp;
% end
% 
% load eeg_raw_pp;
% eeg_raw_pp = eleven_extremeValue_remove(eeg_raw_pp,0,2.5,50);
% save eeg_raw_pp eeg_raw_pp;
% 
% % |----------------------------------------|
% % |------------------ er ------------------|
% % |-------------- sr er part --------------|
% % |----------------------------------------|
% clear; load eleven_eeg_OptionVariable_customize;
% if is_epoch
%     eleven_eeg_er_epoch;
% end
% 
% clear; load eleven_eeg_OptionVariable_customize;
% if is_erp
%     eleven_eeg_er_erp;
% end
% 
% clear; load eleven_eeg_OptionVariable_customize;
% if is_ersd
%     eleven_eeg_er_ersd;
% end
% 
% clear; load eleven_eeg_OptionVariable_customize;
% if is_ertf
%     eleven_eeg_er_ertf;
% end

% |----------------------------------------|
% |----------------- ssep -----------------|
% |------------- sr ssep part -------------|
% |----------------------------------------|
% to-add


% |----------------------------------------|
% |--------------- resting ----------------|
% |----------------------------------------|
% clear; load eleven_eeg_OptionVariable_customize;
% if is_resting_analysis
%     eleven_eeg_resting_AMEnv;
%     eleven_eeg_resting_spec;
% end
% 
% clear;
% %}

% |----------------------------------- ecg Scetion------------------------------------|
%
clear; load eleven_ecg_OptionVariable_customize;
if is_ecg_analysis
    % rate by frequency
    disp('ecg analysis');
    load ecg_raw; load exp_time;
    %ecg_raw_pp = mf_rawfilter(ecg_raw,'IIR','band pass',[0.01,45],4,fs_origin_ecg);
    %ecg_raw_pp = smooth(ecg_raw,10);
    ecg_raw_pp = eleven_extremeValue_remove(ecg_raw,1,3.5,10);
    %ecg_raw_pp = smooth(ecg_raw_pp,10);
    save ecg_raw_pp ecg_raw_pp;
    [ecg_rate,ecg_spec_am_raw,ecg_spec_am_norm,ecg_spec_freq] = ...
        eleven_get_ecg_rsp_rate_noise(ecg_raw_pp,fs_origin_ecg,ecg_padding_time,ecg_FreqNorm_points);
    save ecg_rate ecg_rate;
    save ecg_spec_am_raw ecg_spec_am_raw;
    save ecg_spec_am_norm ecg_spec_am_norm;
    save ecg_spec_freq ecg_spec_freq;
    
%     % get IBI
%     ecg_IBI = eleven_ecg_get_IBI(ecg_raw,fs_origin_ecg,ecg_padding_time,ecg_beat_threshold,0);
%     save ecg_IBI ecg_IBI;
%     ecg_IBI_pp = eleven_extremeValue_remove(ecg_IBI,1,2.5,5);
%     save ecg_IBI_pp ecg_IBI_pp;
%     
%     % hrv
%     [SDNN,RMSSD,hrv_spec_am_raw,hrv_spec_am_norm,hrv_spec_freq,LF_avg_am,HF_avg_am,LHF_avg_am_ratio,LF_peak_am,LF_peak_freq,HF_peak_am,HF_peak_freq]...
%         = eleven_ecg_hrv(ecg_IBI_pp,'amplitude',hrv_FreqNorm_points);
%     save SDNN SDNN;
%     save RMSSD RMSSD;
%     save hrv_spec_am_raw hrv_spec_am_raw;
%     save hrv_spec_am_norm hrv_spec_am_norm;
%     save hrv_spec_freq hrv_spec_freq;
%     save LF_avg_am LF_avg_am;
%     save HF_avg_am HF_avg_am;
%     save LHF_avg_am_ratio LHF_avg_am_ratio;
%     save LF_peak_am LF_peak_am;
%     save LF_peak_freq LF_peak_freq;
%     save HF_peak_am HF_peak_am;
%     save HF_peak_freq HF_peak_freq;
end

clear;
%}

% |----------------------------------- rsp Scetion------------------------------------|
%
clear; load eleven_rsp_OptionVariable_customize;
if is_rsp_analysis
    disp('rsp analysis');
    load rsp_raw; load exp_time;
    rsp_raw_pp = eleven_extremeValue_remove(rsp_raw,1,3,50);
    save rsp_raw_pp rsp_raw_pp;
    [rsp_rate,rsp_spec_am_raw,rsp_spec_am_norm,rsp_spec_freq] = ...
        eleven_get_rsp_rate_noise(rsp_raw_pp,fs_origin_rsp,rsp_padding_time,rsp_FreqNorm_points);
    %save rsp_raw_pp rsp_raw_pp;
    save rsp_rate rsp_rate;
    save rsp_spec_am_raw rsp_spec_am_raw;
    save rsp_spec_am_norm rsp_spec_am_norm;
    save rsp_spec_freq rsp_spec_freq;
end

clear;
%

%
disp('job done.');

clear;