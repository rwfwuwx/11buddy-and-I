function eleven_CNAutojob_eeg_stand_preAna(studyName,sbj_info_file,eleven_job_path)
% This is the 'all' template for conducting 'cognitive neuroscience research' (CN).
%   By 'cognitive neuroscience research', refers to behavioral, EEG, fMRI, etc., as in a CN lab.
%   By 'all', refers to the all-in-one automation.
% Usage:
%   1. Copy this file to the '11job' of a Study/Project.
%   2. add exp_name and data(_number) to the file name, e.g., eleven_CNAutojob_source_test_202108_20211028(_1,2 ...).m.
%       !!! This is the mechanism of recording latest analyses.
%   3. unmark the parts as needed; replace the variable files and parameters with those of the current analysis of current study.
%       (The file will includes all possible parts that could be used. )
% Update history
%   2023-05-23 
%       updates incorporating seeg
%       other minor optimization
%   2023-04-17 
%       update eleven_GLAutojob_command call.
%       add eleven_job_path as func input,for error record file location.
%   2023-03-07 add 'paticipants_age_range' for chosing different age headModel. see details in the Update history of "eleven_eeg_source.m".
%   2022-06-17 unmask the final msgbox.
%   2022-02-28 add ruunning logo
%   2022-02-25 
%       add handling is_individual_ch_postion
%   2022-01-23 minor updates of variable naming -> tmp when handling extendParam, to avoid naming conflicting.
%   2022-01-16 script-> final func
%           nickname andy_ganhuola_1:  load andy_ganhuola_1; andy_ganhuola_1(studyName,sbj_info_file)  
%               (by andy_ganhuola_1 = @eleven_CNAutojob_eeg_stand_preAna; save andy_ganhuola_1 andy_ganhuola_1;)
%   2021-12-15 done part 1
%   2021-12-13 
%   separate 'standard' -> 'stand_preAna' and 'stand_dataAna'
%       'stand_preAna': totally without exp explanation.
%   2021-11-19 separate 'standard' and 'interpret' parts. The formal now runs as a routine procedure. 
%   2021-11-18 initially done whole automation
%   2021-11-17 done eeg data prepare
%   2021-10-26 initial version

myicon = imread('andy.jpg');
h=msgbox('������Ϊ������(��ǰִ������һ)���������ĵȴ�',' ','custom',myicon);

% |--------------------------------------------------------------------|
% |################# Part 1: pre analysis (preANA) ####################|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------------ common exp parameter -----------------|
% |---------------------------------------------------------|

file_name_tmp = ['extendParam_eeg_' studyName '.txt'];
load(file_name_tmp);
eval(sprintf('param_tmp = %s;',['extendParam_eeg_' studyName]));
eeg_type = param_tmp(1);
import_file_type = param_tmp(2);
by_trigger_manner = param_tmp(3);
is_individual_ch_postion = param_tmp(4);

analysis_rootDir_eeg_file = ['analysis_rootDir_eeg_' studyName '.txt'];
analysis_dirTree_eeg_file = ['analysis_dirTree_eeg_' studyName '.txt'];
analysis_dirTree_eeg_run2_file = ['analysis_dirTree_eeg_run2_' studyName '.txt'];
analysis_dirTree_eeg_run3_file = ['analysis_dirTree_eeg_run3_' studyName '.txt'];

eeg_analyze_type_list_file = ['eeg_analyze_type_list_' studyName '.txt'];


% |---------------------------------------------------------|
% |----------------- eeg data prepare ----------------------|
% |---------------------------------------------------------|
%--- (first manually copy from backup to analysis) 

% This step includes 
%   # make run2 directory 
%   # for scalpe eeg, copy and remame eeg file

%
eleven_GLAutojob_routine_eegDataPrepare( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    sbj_info_file, ...
    eeg_type);
%


% |---------------------------------------------------------|
% |----------------- set initial parameters --------------|
% |---------------------------------------------------------|
%--- this step includes
%   # eeg_type, from the input parameter:
%   # import_file_type, from the input parameter:
%   # eeg_analyze_type, from the list file
%   # eeg_analyze_type related param, from the list file
%   # by_trigger_manner
%   Note, detailed setting guidence see andy_ganhuola_accompny operation manual. 
%   # for seeg, copy copy required param from structure 

%
eleven_GLAutojob_routine_eegSetInitParam( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_run2_file, ...
    sbj_info_file, ...
    eeg_type, ...
    import_file_type, ...
    eeg_analyze_type_list_file, ...
    by_trigger_manner);
%


% |---------------------------------------------------------|
% |----------------- eeg normal preprocessing --------------|
% |---------------------------------------------------------|
%--- This step includes 
%   #set andy settings
%   #get exp_time
%   #import data
%   #typical preprocessing

%
eleven_GLAutojob_command( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_run2_file, ...
    sbj_info_file, ...
    eleven_job_path, ...
    'andy_autojob_ppNormal');
%

% |---------------------------------------------------------|
% |----------------- eeg bad ch + ica ----------------------|
% |---------------------------------------------------------|
%--- This step includes 
%   # remove bad ch
%   #ica noise removing
%   # + reref for egi (note, not biosimi, which use online ref for sensor level)

if eeg_type == 1
    %
    eleven_GLAutojob_command( ...
        analysis_rootDir_eeg_file, ...
        analysis_dirTree_eeg_run2_file, ...
        sbj_info_file, ...
        eleven_job_path, ...
        'eleven_eeg_RbcIca');
    %
    
    %
    eleven_GLAutojob_routine_eegRerefRun2( ...
        analysis_rootDir_eeg_file, ...
        analysis_dirTree_eeg_run2_file, ...
        sbj_info_file);
    %
end

% |---------------------------------------------------------|
% |------------- eeg source / seeg laplas reref-------------|
% |---------------------------------------------------------|
%--- This step includes 
%   # copy run2 -> run 3
%   # reref
%       if scalp eeg, reref for biosemi (all avg reref for source level)
%       if seeg, laplas reref
%   #if scalp eeg
%       # source 

%
eleven_GLAutojob_routine_eegCopyRun2to3( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    sbj_info_file, ...
    eeg_type);
%


%
eleven_GLAutojob_routine_eegRerefRun3( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_run3_file, ...
    sbj_info_file);
%}
    
if eeg_type == 1
    %
    eleven_GLAutojob_funcParam_eegSource( ...
        analysis_rootDir_eeg_file, ...
        analysis_dirTree_eeg_run3_file, ...
        sbj_info_file, ...
        studyName, ...
        is_individual_ch_postion, ...
        0); % if only run TSExtraction, change the last parameters from 0 to 1.
    %
end

disp('~-~ andy ganhuola 1: all jobs are done ~-~ )');

% close(h)
msgbox('���Ѿ��������1��','Success','custom',myicon);


