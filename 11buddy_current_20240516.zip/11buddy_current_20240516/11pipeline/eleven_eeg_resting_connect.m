function eleven_eeg_resting_connect
% eleven_eeg_resting_connect
% Usage
%   eleven_eeg_resting_connect
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2022-03-01 add setting of resting_ch_include = []; for source
%   2020-10-30 add padding handling
%   2020-10-21 written

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|

%clear;
disp('resting connectivity processing');

% load option variables
load eleven_eeg_OptionVariable_customize;

tmp_dir=pwd;
if exist([tmp_dir '\' 'source_atlas.mat'],'file')
    resting_ch_include = []; % default all sources
end

% |--- on raw data ---|
% --- input
load eeg_raw_pp;

eeg_raw_pp = eeg_raw_pp([resting_padding_points+1:size(eeg_raw_pp,1)-resting_padding_points-1],:); % cut required data, by removing the starding and ending padding time

disp('  connect');
[eeg_resting_connect_cm_coef_raw,eeg_resting_connect_cm_p_raw] = mf_rawconnect(eeg_raw_pp,resting_connect_type,resting_ch_include);

save eeg_resting_connect_cm_coef_raw eeg_resting_connect_cm_coef_raw;
save eeg_resting_connect_cm_p_raw eeg_resting_connect_cm_p_raw;

% | --- on AMEnv ---|
% |--- processing loop by freq band ---|
freq_band_num = length(resting_freq_band_name);

for ii=1:freq_band_num
    % --- input
    input_data_name = ['eeg_resting_AMEnv' '_' resting_freq_band_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('eeg_resting_AMEnv_tmp = %s;',input_data_name));
    
    eeg_resting_AMEnv_tmp = eeg_resting_AMEnv_tmp([resting_padding_points+1:size(eeg_resting_AMEnv_tmp,1)-resting_padding_points-1],:); 
    
    disp('  connect');
    [eeg_resting_connect_cm_coef_tmp,eeg_resting_connect_cm_p_tmp] = mf_rawconnect(eeg_resting_AMEnv_tmp,resting_connect_type,resting_ch_include);
    
    %--- output
    output_data_name = ['eeg_resting_connect_cm_coef' '_' resting_freq_band_name{ii}];
    eval(sprintf('%s = eeg_resting_connect_cm_coef_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    % --- clear
    eval(sprintf('clear %s;',output_data_name));
    
    %--- output
    output_data_name = ['eeg_resting_connect_cm_p' '_' resting_freq_band_name{ii}];
    eval(sprintf('%s = eeg_resting_connect_cm_p_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    % --- clear
    eval(sprintf('clear %s;',output_data_name));
end

%clear;
