function eleven_CNAutojob_behav_stand_dataAna(studyName,sbj_info_file,eleven_job_path)
% Usage:
%   (has been incorperated in the yangyang_ganhuola.txt) 
%   nickname
%     yangyang_ganhuola_2:  load yangyang_ganhuola_2;yangyang_ganhuola_2(params)  
%       (by yangyang_ganhuola_2 = @eleven_CNAutojob_behav_stand_dataAna; save yangyang_ganhuola_2 yangyang_ganhuola_2;)
% Note
% This is the 'all' template for conducting 'cognitive neuroscience research' (CN).
%   By 'cognitive neuroscience research', refers to behavioral, EEG, fMRI, etc., as in a CN lab.
%   By 'all', refers to the all-in-one automation.
% This stage is supposed for all types of behav anayses.
% Update history
%   2024-04-06 initial version, modify from eleven_CNAutojob_eeg_stand_dataAna.m
%       

%myicon = imread('yangyang.jpg');
%h=msgbox('������Ϊ������(��ǰִ�������)���������ĵȴ�',' ','custom',myicon);

analysis_rootDir_behav_file = ['analysis_rootDir_behav_' studyName '.txt'];
analysis_dirTree_behav_file = ['analysis_dirTree_behav_' studyName '.txt'];
%dataList_behav_file = ['dataList_behav_' studyName '.txt'];
StimRespMapingRelated_list_file = ['behav_StimRespMapingRelated_list_' studyName '.txt'];
condNameList_behav_file = ['condNameList_behav_' studyName '.txt'];
expVariable_list_file = ['behav_expVariable_list_' studyName '.txt'];



% |--------------------------------------------------------------------|
% |################# Part 2: data analysis (dataAna) ##################|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------- prepare dataAna dir structure--------------|
% |---------------------------------------------------------|
% This step includes 
%   # prepare dataAnaDir (currently for behav, just current dir './')

%
eleven_GLAutojob_routine_behavDataAnaDirPrepare( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    sbj_info_file);
%}

% |---------------------------------------------------------|
% |------------------- prepare exp param--------------------|
% |---------------------------------------------------------|
% first prepare
%   ---  StimRespMapingRelated
%   --- con_name
%   --- expVariable

%
eleven_GLAutojob_routine_behavExpParamPrepare( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    sbj_info_file, ...
    StimRespMapingRelated_list_file, ...
    condNameList_behav_file, ...
    expVariable_list_file);
%}



% |---------------------------------------------------------|
% |------------------- behav "data analysis" -----------------|
% |---------------------------------------------------------|
%
eleven_GLAutojob_command( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    sbj_info_file, ...
    eleven_job_path, ...
    'yangyang_autojob_dataAnalysis');
%}

disp('~-~ yangyang ganhuola 2: all jobs are done ~-~ )');

% close(h)
%msgbox('���Ѿ��������2��','Success','custom',myicon);
