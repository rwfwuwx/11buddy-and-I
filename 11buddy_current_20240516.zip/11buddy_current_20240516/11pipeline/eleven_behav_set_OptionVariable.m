function eleven_behav_set_OptionVariable
% eleven_behav_set_OptionVariable
% Usage
%   eleven_behav_set_OptionVariable
% external varialbe (add later)
%  -- output
%
% todo
%   
% Update history
%   2024-05-09 add
%   2024-04-18 add is_reject_not_passRtest
%   2024-04-06 initial version, modify from eleven_eeg_set_OptionVariable.m


clear;

% this param as individual variable, not saving into the combined variable.
%   (for the combined variable, 'structure' is a typical option; while avoid as far as possible)
load behav_analyze_type;

% |-------------------------|
% |----- common variable----|
% |-------------------------|


% |-------------------------|
% |--------- import --------|
% |-------------------------|
%is_import = 0;

load import_file_type;

% again, this might be duplicated for analyze type and expVariable, for eeg.
%   Now, default, use expVariable to set it.
%{
if ~isempty(find(behav_analyze_type == [2]))
    load cond_IOI;
end
%}

% |-------------------------|
% |---------- postProcessing --------|
% |-------------------------|
is_postP = 1; 


% |-------------------------|
% |---------- epoch --------|
% |-------------------------|
is_epoch = 1;

% |-------------------------|
% |----------  activity  --------|
% |-------------------------|
is_activity = 1;
is_reject_not_passRtest = 0; 
    % 0 - default; 1 - reject sequences not passing rtest
missingTap_percentage_threshold=0.15;
valid_sequence_threshold=3;

activity_outlier_SD = 3;


% --- save
clear behav_analyze_type;
save eleven_behav_OptionVariable;

clear;
