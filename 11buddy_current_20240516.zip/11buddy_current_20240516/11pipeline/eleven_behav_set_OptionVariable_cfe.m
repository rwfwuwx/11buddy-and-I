function eleven_behav_set_OptionVariable_cfe
% eleven_behav_set_OptionVariable_cfe
% Usage
%   eleven_behav_set_OptionVariable_cfe
% external varialbe (add later)
%  -- output
%
% Note 
% # componentFeature_list and cond_name (further also apply for eeg)
%   for eeg resting, componentFeature is 'standard'.
%   for behavior and event-related eeg, each data may have different cond.
%       therefore, componentFeature here refers to 'prefix', 
%       i.e., when extracting feature, actual data need to add cond_name.
%
% # add extraComponentFeature_list
%   (1)standard/simple metrics have been obtained in yangyang 2, activity,
%       which are no need to be recalculate again.
%       simply describe here, as the usual componentFeature_list.
%   (2)extra/complex metrics, may be further calulated.
%       set it as extraComponentFeature_list. if non, just non.
%       calculate in next step.
%   further, under the hood, usual and extra extraComponentFeature_list.
%       at the last step printing out for user, combind the two.
%
% todo
%   
% Update history
%   2024-05-09 add reject metrics when behav_analyze_type == 2
%   2024-04-19 add metrics for componentFeature_list when behav_analyze_type == 2
%   2024-04-18 initial version, modify from eleven_eeg_set_OptionVariable_cfe.m

clear;

% these param as individual variables, not saving into the combined variable.
%   (for the combined variable, 'structure' is a typical option; while avoid as far as possible)
load behav_analyze_type;

% |-------------------------|
% |----- common variable----|
% |-------------------------|


% |--------------------------------------------------|
% |----------------- activity   -----------------|
% |--------------------------------------------------|
if behav_analyze_type == 1
    componentFeature_list = { ...
        'behav_metric_correctRate'; ...
        'behav_metric_RT'; ...
        };
    
    extraComponentFeature_list = { ...
        };
    %--- related param for extra feature extraction

end

if behav_analyze_type == 2
    componentFeature_list = { ...
        'behav_metric_meanAsyn'; ...
        'behav_metric_meanAsyn_circ';...
        'behav_metric_meanStab_circ';...
        'behav_metric_meanAC1';...
        'behav_metric_mean_missingTap';...
        };
    
    extraComponentFeature_list = { ...
        };
    %--- related param for extra feature extraction

end
    
% --- save
clear behav_analyze_type;
save eleven_behav_OptionVariable_cfe;

clear;
