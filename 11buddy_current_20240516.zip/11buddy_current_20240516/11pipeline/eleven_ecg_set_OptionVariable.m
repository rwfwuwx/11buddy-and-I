function eleven_ecg_set_OptionVariable
% eleven_ecg_set_OptionVariable	
% Usage
%   eleven_ecg_set_OptionVariable
% external varialbe (add later)
%  -- output
% Update history 
%   2020-11-25 ecg_beat_threshold 2-> 2.5;
%   2020-10-31 modify from eleven_ecg_set_OptionVariable.m

clear;

% |-------------------------|
% |----- common variable----|
% |-------------------------|


% sample rate. for most processing steps.
fs_origin_ecg = 2000;
%fs = 200; 

% |-------------------------|
% |--------- import --------|
% |-------------------------|
% is_import = 1; % add the step import into eleven_physio later, after handling linking trigger_to_be and physio_ecd_raw 
%is_import_resample = 1;
%import_file_type = 1;

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|
%is_pp = 1;

% default 0.5 Hz.for large drift noise, can be even higher than 1.
%pp_high_cutoff = 0.5; 

% removing 50 Hz AC and harmonies
%pp_AC_cutoff = [49 51;99 101;149 151;199 201];


is_ecg_analysis = 1;

ecg_beat_threshold = 2.5;

% |---------------------------------|
% |-------- resting_FreqSpec  ------|
% |---------------------------------|
% size of FreqNorm
%   require further testing
%   for 5 min, 2000 Hz resampling, currently use 6
ecg_FreqNorm_points = 10;
ecg_padding_time = 5; % s
ecg_padding_points = ecg_padding_time*fs_origin_ecg;

hrv_FreqNorm_points = 2;

% --- save
save eleven_ecg_OptionVariable;

clear;
