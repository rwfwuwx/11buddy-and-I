function yangyang_autojob_dataAnalysis
%clear;
%
% Note
%   this autojob does job for all dataAnadir, running at dataAna_root_dir (see code).
%       for a single 'current directory', i.e., one of dataAnadir, simply go
%           there, run command: load yangyang_ana; yangyang_ana();
% Update history
%   2024-04-06 initial version, modify from andy_autojob_dataAnalysis.m

load dataAnaDir;
dataAna_root_dir = pwd;
 
for ii=1:length(dataAnaDir)
    cd(dataAnaDir{ii});
    
    %--- set yangyang 
    % yangyang is already set. if re-set is required, can do here
    eleven_behav_set_OptionVariable_customize;
    
    %--- yangyang work
    load yangyang_ana; yangyang_ana();
    
    cd(dataAna_root_dir);
end


