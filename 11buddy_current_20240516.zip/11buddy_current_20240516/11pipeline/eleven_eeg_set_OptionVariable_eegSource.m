function eleven_eeg_set_OptionVariable_eegSource
% eleven_eeg_set_OptionVariable_eegSource
% Usage
%   eleven_eeg_set_OptionVariable_eegSource
% external varialbe (add later)
%  -- output
%
% Update history 
%   2022-05-10 prepare for the param is_noRepeat_Forward, see update history of eleven_eeg_source.m
%   2022-02--25
%       mark SourceSpace
%       {'Destrieux'}->{'Brodmann_YCG_copy'};
%   2021-10-25 initial version

clear; % do not remove this

% |------------------------------------------------------|
% |------------------------ Import ---------------------|
% |------------------------------------------------------|
is_eegSource_Import = 1;
andy2brainstorm_fileName = 'eeg_raw_pp_rbc_ica_final.set';

% |------------------------------------------------------|
% |------------------------ Forward ---------------------|
% |------------------------------------------------------|
is_eegSource_Forward = 1;
%is_noRepeat_Forward = 1;
%SourceSpace = 1;
is_noise_cov = 1;

% |------------------------------------------------------|
% |------------------------ Inverse ---------------------|
% |------------------------------------------------------|
is_eegSource_Inverse = 1;
inverseMethod = 'minnorm';
inverseMeasure = 'sloreta';

% |------------------------------------------------------|
% |--------------------- TS extraction ------------------|
% |------------------------------------------------------|
is_eegSource_TSExtract = 1;
%atlasNames = {'Destrieux'};
atlasNames = {'DesikanKilliany'};

%atlasNames = {'Brodmann_YCG_copy'};
EEGBuddy_TSExtract_OutputName = 'eeg_raw_pp_eegSource_TS';
brainstorm2andy_fileName = 'eeg_raw_pp';


% --- save
save eleven_eeg_OptionVariable_eegSource;

clear; % do not remove this

 