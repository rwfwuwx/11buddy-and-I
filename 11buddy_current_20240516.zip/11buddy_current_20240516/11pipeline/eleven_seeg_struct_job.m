%-----------------------------------------------------------------------
% Job saved on 18-Mar-2020 13:48:35 by cfg_util (rev $Rev: 7345 $)
% spm SPM - SPM12 (7487)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
load current_dir;

matlabbatch{1}.spm.spatial.coreg.estwrite.ref = {[current_dir '\sMR.nii,1']};
matlabbatch{1}.spm.spatial.coreg.estwrite.source = {[current_dir '\sCT.nii,1']};
matlabbatch{1}.spm.spatial.coreg.estwrite.other = {''};
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.cost_fun = 'nmi';
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.sep = [4 2];
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.fwhm = [7 7];
matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.interp = 4;
matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.mask = 0;
matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.prefix = 'r';
matlabbatch{2}.spm.tools.oldnorm.estwrite.subj.source = {[current_dir '\sMR.nii,1']};
matlabbatch{2}.spm.tools.oldnorm.estwrite.subj.wtsrc = '';
matlabbatch{2}.spm.tools.oldnorm.estwrite.subj.resample = {[current_dir '\sMR.nii,1']};
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.template = {'H:\soft\spm12\spm12\toolbox\OldNorm\T1.nii,1'};
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.weight = '';
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.smosrc = 8;
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.smoref = 0;
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.regtype = 'mni';
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.cutoff = 25;
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.nits = 16;
matlabbatch{2}.spm.tools.oldnorm.estwrite.eoptions.reg = 1;
matlabbatch{2}.spm.tools.oldnorm.estwrite.roptions.preserve = 0;
matlabbatch{2}.spm.tools.oldnorm.estwrite.roptions.bb = [-78 -112 -70
                                                         78 76 85];
matlabbatch{2}.spm.tools.oldnorm.estwrite.roptions.vox = [1 1 1];
matlabbatch{2}.spm.tools.oldnorm.estwrite.roptions.interp = 1;
matlabbatch{2}.spm.tools.oldnorm.estwrite.roptions.wrap = [0 0 0];
matlabbatch{2}.spm.tools.oldnorm.estwrite.roptions.prefix = 'w';
matlabbatch{3}.spm.tools.oldnorm.write.subj.matname(1) = cfg_dep('Old Normalise: Estimate & Write: Norm Params File (Subj 1)', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('()',{1}, '.','params'));
matlabbatch{3}.spm.tools.oldnorm.write.subj.resample = {[current_dir '\rsCT.nii,1']};
matlabbatch{3}.spm.tools.oldnorm.write.roptions.preserve = 0;
matlabbatch{3}.spm.tools.oldnorm.write.roptions.bb = [-78 -112 -70
                                                      78 76 85];
matlabbatch{3}.spm.tools.oldnorm.write.roptions.vox = [1 1 1];
matlabbatch{3}.spm.tools.oldnorm.write.roptions.interp = 1;
matlabbatch{3}.spm.tools.oldnorm.write.roptions.wrap = [0 0 0];
matlabbatch{3}.spm.tools.oldnorm.write.roptions.prefix = 'w';
matlabbatch{4}.spm.util.imcalc.input = {
                                        [current_dir '\sMR.nii,1']
                                        [current_dir '\rsCT.nii,1']
                                        };
matlabbatch{4}.spm.util.imcalc.output = 'MRI-CT_fuse_orig';
matlabbatch{4}.spm.util.imcalc.outdir = {[current_dir '']};
matlabbatch{4}.spm.util.imcalc.expression = ' i1+i2.*(i2>100)./5';
matlabbatch{4}.spm.util.imcalc.var = struct('name', {}, 'value', {});
matlabbatch{4}.spm.util.imcalc.options.dmtx = 0;
matlabbatch{4}.spm.util.imcalc.options.mask = 0;
matlabbatch{4}.spm.util.imcalc.options.interp = 1;
matlabbatch{4}.spm.util.imcalc.options.dtype = 4;
matlabbatch{5}.spm.util.imcalc.input = {
                                        [current_dir '\wsMR.nii,1']
                                        [current_dir '\wrsCT.nii,1']
                                        };
matlabbatch{5}.spm.util.imcalc.output = 'MRI-CT_fuse_norm';
matlabbatch{5}.spm.util.imcalc.outdir = {[current_dir '']};
matlabbatch{5}.spm.util.imcalc.expression = ' i1+i2.*(i2>100)./5';
matlabbatch{5}.spm.util.imcalc.var = struct('name', {}, 'value', {});
matlabbatch{5}.spm.util.imcalc.options.dmtx = 0;
matlabbatch{5}.spm.util.imcalc.options.mask = 0;
matlabbatch{5}.spm.util.imcalc.options.interp = 1;
matlabbatch{5}.spm.util.imcalc.options.dtype = 4;
