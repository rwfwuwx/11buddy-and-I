function eleven_CNAutojob_behav_stand_rptAna(studyName,sbj_info_file,sbj_index,is_formal)
% Usage 
%   eleven_CNAutojob_behav_stand_rptAna(studyName,sbj_info_file,is_formal)
%   or, load yangyang_ganhuola_3; yangyang_ganhuola_3(studyName,sbj_info_file,is_formal)
%       (by yangyang_ganhuola_3 = @eleven_CNAutojob_behav_stand_rptAna; save yangyang_ganhuola_3 yangyang_ganhuola_3;)    
% Input
%   is_formal:
%       0: test, data at this step will be at allsbj_test directory
%       1: formal, data at this step will be at allsbj directory
%       this setting is important to separate testing and formal analysis, at the all sbj stage.
% Update history
%   2024-04-06 initial version, modify from eleven_CNAutojob_eeg_stand_rptAna.m

% myicon = imread('yangyang.jpg');
% h=msgbox('������Ϊ������(��ǰִ��������)���������ĵȴ�',' ','custom',myicon);

% |---------------------------------------------------------|
% |------------------ common exp parameter -----------------|
% |---------------------------------------------------------|

analysis_rootDir_behav_file = ['analysis_rootDir_behav_' studyName '.txt'];
analysis_dirTree_behav_file = ['analysis_dirTree_behav_' studyName '.txt'];
behav_analyze_type_list_file = ['behav_analyze_type_list_' studyName '.txt'];

% |--------------------------------------------------------------------|
% |################# Part 3: report analysis (rptAna) ##################|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------- prepare rptAna dir structure--------------|
% |---------------------------------------------------------|
% This step includes 

%
eleven_GLAutojob_routine_behavRptAnaDirPrepare( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    is_formal);
%}

% |---------------------------------------------------------|
% |------------------- copy parameters ---------------------|
% |---------------------------------------------------------|
% Note
%   currently, the body is done, copying basic params.
%   further, given requirement of yangyang_image , see below, 
%       simply fill inside requird params.
% This step includes 

%
eleven_GLAutojob_routine_behavRptAnaCopyParam( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    behav_analyze_type_list_file, ...
    sbj_info_file, ...
    is_formal);
%}

% |---------------------------------------------------------|
% |-------------------- group average ----------------------|
% |---------------------------------------------------------|
% Note
%   currently, the body is done, setting for basic behav activity.
%   further, given requirement of yangyang_image , see below, 
%       simply fill inside requird behav activity.
% This step includes 

%
eleven_GLAutojob_routine_behavRptAnaAvg( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    behav_analyze_type_list_file, ...
    sbj_info_file, ...
    sbj_index, ...
    is_formal);
%}

% |---------------------------------------------------------|
% |-------------------- yangyang_image ----------------------|
% |---------------------------------------------------------|
% Note, the end is supposed to yangyang_image, to plot grouped behav activty
%   (like andy_image ploting grouped eeg activity)
%   Usually, people don't look at behav activity, either individual or grouped level.
%   However,this does not mean that yangyang_image is not need,
%       people may refer yangyang_image, i.e., looking at behav activity,
%           as 'high-level' analysis.
% for now, yangyang prepare data throughout until group avg. i.e., activity is ready.
%   While,leave yangyang_image, i.e., looking at it, later.
%


disp('~-~ yangyang ganhuola 3: all jobs are done ~-~ )');

%close(h)
% myicon = imread('yangyang.jpg');
% msgbox('���Ѿ���ɹ���3���������Բ鿴����������','Success','custom',myicon);
