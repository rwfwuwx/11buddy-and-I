function eleven_eeg_ssep_spec
% eleven_eeg_ssep_spec	
% Usage
%   eleven_eeg_ssep_spec
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Todo
%   re-write mf_epospec, add non-phased locked.
%   
% Update history
%   add ssep_FreqNorm_method
%   2021-12-17 modify from eleven_eeg_er_erp.m and eleven_resting_spec.m


%clear;
disp('ssep spec processing');

% --- load option variables
load eleven_eeg_OptionVariable_customize;

% --- input
% exp variable
% for condition: condition name.
% (condition code is only needed in epoch)
load cond_name;

% |--- processing loop by condition ---|
cond_num = length(cond_name);

for ii=1:cond_num
    % --- input
    % epo data
    input_data_name = ['eeg_epo' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('eeg_epo_tmp = %s;',input_data_name));
    
    % --- average
    eeg_erp_tmp = mf_epoavg(eeg_epo_tmp);
    
    % data format erp->raw/ssep
    eeg_raw_tmp = eeg_erp_tmp';
    
    % cut required data, by removing the starting and ending padding time
    eeg_raw_tmp = eeg_raw_tmp([ssep_padding_points+1:size(eeg_raw_tmp,1)-ssep_padding_points-1],:); 

    % --- spec
    %disp('  spec');
    [eeg_ssep_spec_am_raw,eeg_ssep_spec_am_norm,eeg_ssep_spec_phase,eeg_ssep_spec_freq] = ...
        mf_rawspec(eeg_raw_tmp,fs,ssep_am_type,ssep_phase_type,ssep_FreqNorm_points,ssep_FreqNorm_method);
    
    % --- output
    
    output_data_name = ['eeg_ssep_spec_am_raw' '_' cond_name{ii}];
    eval(sprintf('%s = eeg_ssep_spec_am_raw;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['eeg_ssep_spec_am_norm' '_' cond_name{ii}];
    eval(sprintf('%s = eeg_ssep_spec_am_norm;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['eeg_ssep_spec_phase' '_' cond_name{ii}];
    eval(sprintf('%s = eeg_ssep_spec_phase;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['eeg_ssep_spec_freq' '_' cond_name{ii}];
    eval(sprintf('%s = eeg_ssep_spec_freq;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
end

%clear
