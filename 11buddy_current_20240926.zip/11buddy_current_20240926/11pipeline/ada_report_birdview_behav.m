% ada_report_birdview_behav
%
%Note for 11buddy keeper
%   arrange and set needs, where "$$" indicates.
%
%Update history
%   2024-04-28 simplification, by
%   # !!!. Given the time stamp mechanism, the file search&relace is not that necessary
%       In other words, only the time stamp per se. is needed for file
%           search&replace, all other variable can be save by a time stamp.
%       As a result, ada can run locally simply load an 'all together' variable with a time stamp.
%   #behav is simpler than eegBehavRelate
%   Note, the modification is majorly in the part of 'get ada need, including ada name',
%       other parts are almost intact as ada_report_birdview. 
%   2024-04-22 initial version, modified from ada_report_birdview.m
%
% Todo
%

myicon = imread('ada.jpg');
h=msgbox('������Ϊ���������������ĵȴ�',' ','custom',myicon);

% default dir for adaReport_defineVariable TimeStamp
if exist('adaReport_defineVariable_TimeStamp')~=7
    mkdir('adaReport_defineVariable_TimeStamp');
end


%--- read the ada_CondGroup_.xlsx; and save required variable for ada_ganhuola_template
T_tmp = readtable(ada_CondGroup_excel_file);

%- get groupSbjIndexDataName
groupSbjIndexDataName = T_tmp.Var1;
% clear out empty elements
tmp_index = [];
for ii = 1:length(groupSbjIndexDataName)
    if isempty(groupSbjIndexDataName{ii})
        tmp_index = [tmp_index; ii];
    end
end
groupSbjIndexDataName(tmp_index) = [];
save groupSbjIndexDataName groupSbjIndexDataName;

%- get groupSbjIndexDataName_Name
groupSbjIndexDataName_Name = cell(length(groupSbjIndexDataName),1);
for ii = 1:length(groupSbjIndexDataName)
    eval(sprintf('tmp_data = T_tmp.Var%d;',1+ii));
    % clear out empty elements
    tmp_index = [];
    for jj = 1:length(tmp_data)
        if isempty(tmp_data{jj})
            tmp_index = [tmp_index; jj];
        end
    end
    tmp_data(tmp_index) = [];
    groupSbjIndexDataName_Name{ii} = tmp_data;
end
save groupSbjIndexDataName_Name groupSbjIndexDataName_Name;

%- get groupSbjIndexDataName_Value
groupSbjIndexDataName_Value = cell(length(groupSbjIndexDataName),1);
for ii = 1:length(groupSbjIndexDataName)
    eval(sprintf('tmp_data = T_tmp.Var%d;',1+length(groupSbjIndexDataName)+ii));
    % clear out empty elements
    tmp_index = [];
    for jj = 1:length(tmp_data)
        if isnan(tmp_data(jj))
            tmp_index = [tmp_index; jj];
        end
    end
    tmp_data(tmp_index) = [];
    tmp_data = num2cell(tmp_data);
    groupSbjIndexDataName_Value{ii} = tmp_data;
end
save groupSbjIndexDataName_Value groupSbjIndexDataName_Value;

%--- read the ada_reqire_.xlsx;
%   Note, assume the vars according to the require excel
T_ada_require = readtable(ada_require_excel_file);


%|---------------------------------------|
%|------------ produce adas -------------|
%|---------------------------------------|

ada_num = length(T_ada_require.measureVar);
ada = cell(1,ada_num);
ada_need = cell(1,ada_num);

%--- get ada need, including ada name
for ii = 1:ada_num
    
    % !!! currently fix ada_need, according to fixed requirement excel. extend later
    % note, relative to eegBehavRelate, behav is now updated requring only time stamp in ada need.
    %   see Update history '2024-04-28 simplification'
    ada_need_num = 1;
    ada_need{ii} = cell(ada_need_num,2); % row: needs; col 1 and 2: replace 1 with 2
    
    %- measureVar
    measureVar = T_ada_require.measureVar{ii}; 
    
    %- adaReport_define_behav_FileName
    adaReport_define_behav_FileName = T_ada_require.adaReport_define_behav_FileName{ii};
    run([adaReport_define_behav_FileName '.m']);
    
    %- save adaReport_defineVariable TimeStamp
    % get a time stamp
    timeStamp = [num2str(datetime().Year),...
        num2str(datetime().Month),...
        num2str(datetime().Day),...
        num2str(datetime().Hour),...
        num2str(datetime().Minute),...
        num2str(round(datetime().Second*1000))];
    
    % add time stamp to the variable name
    adaReport_defineVariable_name_with_TimeStamp = ['adaReport_defineVariable' '_' timeStamp];
    
    % save the var while by a var name with a time stamp, into the default dir
    cd adaReport_defineVariable_TimeStamp;
    %   measureVar + the vars defined in the define file
    eval(sprintf(...
        'save %s measureVar Data Cond condGroup Factors Factor_name Factor_level Factor_withinBetween Factor_level_targetData;',...
        adaReport_defineVariable_name_with_TimeStamp));
    cd ../;
    
    % for the replace in ada
    tmp_text = ['load '];
    tmp_replace_text = [tmp_text adaReport_defineVariable_name_with_TimeStamp ';'];
    ada_need{ii}(1,:) = {...
        ['%[11mod]' sprintf('\n') 'load adaReport_defineVariable_[TimeStamp];'],...
        ['%[11mod]' sprintf('\n') tmp_replace_text]};
    
    pause(0.005); % i.e., avoid time overlapping with next time stamp
    
    %- output files
    ada{ii} = [T_ada_require.adaReportFileName{ii} '.mlx']; % ���븱�����ļ���
end

%--- produce adas

for ii=1:ada_num
    % initialize temporal iterate operation files, see below description
    %tmp_file_previous_operation = [];
    tmp_file_next_operation = 'tmp_file_next_operation.mlx';
    matlab.internal.liveeditor.createLiveScript(tmp_file_next_operation);
    
    tmp_ada_need_num = size(ada_need{ii},1);
    for jj=1:tmp_ada_need_num % loop of ada need
        % set input and output files
        %   for each current iterate operation,
        %       get input file from previous operation and send file for next operation,unless,
        %           for the first operation, input is the ada template
        %           for the last operation, output is the ada
        
        if jj==1
            tmp_file_input = ada_template;
        else
            tmp_file_input = tmp_file_previous_operation;
        end
        
        if jj==tmp_ada_need_num
            tmp_file_output = ada{ii};
        else
            tmp_file_output = tmp_file_next_operation;
        end
        
        %   set files after iteration done
        file_input = tmp_file_input;
        file_output = tmp_file_output;
        
        % set find string and replace string
        tmp_string_find = ada_need{ii}{jj,1};
        tmp_string_replace = ada_need{ii}{jj,2};
        
        % perform find & replace
        eleven_FindAndReplaceInFile(file_input,file_output,...
            tmp_string_find,tmp_string_replace);
        
        % update temporal iterate operation files
        if tmp_ada_need_num>1 % no need for only one need
            tmp_file_previous_operation = tmp_file_next_operation;
        end
        
    end
end

% clear out temporal iterate operation files
if exist([pwd '\' tmp_file_next_operation])
    delete(tmp_file_next_operation);
end

%|-----------------------|
%|------- ada run -------|
%|-----------------------|

%--- run adas with outputs
save studyID studyID;
save current_rawdata_Dir current_rawdata_Dir;
save current_analysis_Dir current_analysis_Dir;
save current_11job_Dir current_11job_Dir;
save current_analysis_dir current_analysis_dir;

save analysis_allSbjData_xlsx_mark analysis_allSbjData_xlsx_mark;

save ada_num ada_num;
save ada ada;


tmp_ii_abv=1;
save tmp_ii_abv tmp_ii_abv;

clear;
load tmp_ii_abv;
load ada_num;
load ada;

for ii_abv=1:ada_num
    % run
    % global variable from ada_ganhuola
    load studyID;
    load current_rawdata_Dir;
    load current_analysis_Dir;
    load current_11job_Dir;
    load current_analysis_dir;
    
    eleven_mlx_execute_convert(ada{ii_abv},'docx');
    
    tmp_ii_abv=tmp_ii_abv+1;
    save tmp_ii_abv tmp_ii_abv;
    
    clear;
    java.lang.System.gc(); % ask java to free some memory
    pause(0.01);
    
    load tmp_ii_abv;
    load ada_num;
    load ada;
    
    ii_abv=tmp_ii_abv;
end


disp('����׼���ý��������~����ȥ��һ���ɡ�')

%close(h)
myicon = imread('ada.jpg');
msgbox('���Ѿ�׼���ý��������~����ȥ��һ���ɡ�','Success','custom',myicon);
