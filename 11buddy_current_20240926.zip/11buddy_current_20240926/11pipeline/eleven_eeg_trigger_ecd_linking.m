function eleven_eeg_trigger_ecd_linking 
%   planned trigger, trigger_tobe (by eleven_produce_trigger_tobe_template.m)
%   and raw eeg ecd, eeg_ecd_raw (by eleven_seeg_import_pdf),
%   to generate eeg_ecd.
%
% to-do:
%   also see 'eleven_produce_trigger_tobe_template.m'
%
% Update history
%   2021-12-16 
%       add handling of by_trigger_manner. 1.by yangyang's manner; 2 by conventional manner
%       -> func
%   2020-04-23 initially written
%

load eeg_ecd_raw;

load by_trigger_manner;

if by_trigger_manner == 1
    
    load trigger_tobe;
    
    % --- check consistency
    % check trigger number
    if length(trigger_tobe)~=size(eeg_ecd_raw,1)
        error('the length does not match between planed trigger and trigger read from eeg, please check !');
    end
   
    
    % further manually check stim type and duration
    % e.g., diff(eeg_ecd_raw); and check whether the time interval of column2 match the planed stim type and duration
    
    % --- put planned trigger to ecd, and thus generate eeg_ecd
    eeg_ecd_raw(:,1) = trigger_tobe;
end

eeg_ecd = eeg_ecd_raw;
save eeg_ecd eeg_ecd;

