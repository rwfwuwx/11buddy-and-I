function eleven_sc_set_OptionVariable_er
% eleven_sc_set_OptionVariable_er	
% Usage
%   eleven_sc_set_OptionVariable_er
% external varialbe (add later)
%  -- output
% Update history
%	2020-11-20 modify from eleven_eeg_set_OptionVariable_er_eeg.m & eleven_sc_set_OptionVariable_resting.m

clear;

% |-------------------------|
% |----- common variable----|
% |-------------------------|
% load expVariable; % sr, IOI is necessary. er, not necessary.

% sample rate. for most processing steps.
% modify this in case of low sample rate, e.g., 500 Hz
fs_origin=2000;
fs = 1000; 

% |-------------------------|
% |--------- import --------|
% |-------------------------|
% is_import = 1; % add the step import into eleven_eeg later, after handling linking trigger_to_be and eeg_ecd_raw 
is_import_resample = 1;
%import_file_type = 1;

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|
is_pp = 1;

% default 0.5 Hz.for large drift noise, can be even higher than 1.
pp_high_cutoff = 0.5; 

% optionally add low pass, particulary for removing residual AC noise, when fs is below 500
is_pp_low_pass = 0;
pp_low_cutoff = 45;

% removing 50 Hz AC and harmonies
pp_AC_cutoff = [49 51;99 101;149 151;199 201];

% |-------------------------|
% |--------- reref ---------|
% |-------------------------|
% reref
is_reref = 0; % 0 for run1; 1 for run2 

% if import_file_type==1
%     reref_ch = 1:64;
% end
% 
% if import_file_type==2
%     reref_ch = 1:128;
% end

% |-------------------------|
% |---------- epoch --------|
% |-------------------------|
is_epoch = 1;

% for epoch: epoch length
% these information are also used later, when related time info is needed
% 1. actual epoch range -100~600 ms. This is a typical setting. modify this as exp needs.
% 2. add 400 ms, i.e., padding time, on left and right ends to avoid boundry noise.
% toatal length (400+100)+1+(600+400) ms. Given fs=1000, 1501 sample points.
% 3. baseline refers to -100~0 ms
actual_epoch_points_before_onest = 0.1*fs; % -100~-1 ms
actual_epoch_points_after_onest = 0.6*fs;  % 1~600 ms
padding_points = 0.4*fs; % 400 ms
epoch_points_before_onest = actual_epoch_points_before_onest+padding_points; % -500~-1 ms
epoch_points_after_onest = actual_epoch_points_after_onest+padding_points;  % 1~1000 ms
actual_epoch_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+1+actual_epoch_points_after_onest]; % i.e., -100~600 ms
baseline_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+1]; 

% --- for afr

% - for scalp eeg
% after ica, there is no need to perform afr for seeg.
%{
is_afr = 0; % whether to perform afr
afr_epoch_range = actual_epoch_range;
afr_criterion = 50; % this can only be determined arbitarily
afr_ch = []; % fill this with eye movement ch, depending on eeg equipment and setting.
afr_is_pp = 1;
%}

% - for seeg
% There is no need to perform afr for seeg.
%
is_afr = 0; % whether to perform afr
afr_epoch_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+1+actual_epoch_points_after_onest+1];; % i.e., the actual epoch_range
afr_criterion = 350; % this can only be determined arbitarily
afr_ch = []; % for seeg. use all ch.
afr_is_pp = 1;
%

% |-------------------------|
% |----------  erp  --------|
% |-------------------------|
is_erp = 1;

% for filter
%erp_high_cutoff = 1; % This would be supplementary to the high-pass filter on raw data, when having large drift.Can unmark and set this to 1 or 1.5.
erp_low_cutoff = 20; % instead of typical 30, 20 is better. can even set to 15 for large high-frequency noise

% for remove baseline
erp_baseline_range = baseline_range; 

% 0 for scalp eeg.1 for seeg; 
is_output_epo_before_erp = 1; 


% |-------------------------|
% |----------  ersd  --------|
% |-------------------------|
is_ersd = 0;

% define frequency bands, for filter
ersd_freq_band_name = {'theta','alpha','beta','lowGamma','highGamma','extrahighGamma'};
ersd_freq_band = [4 7;8 14;15 30;31 47;53 97;103 247];

% for normalization
ersd_baseline_range = baseline_range;
ersd_normalize_method = 3; % percent change

% 0 for scalp eeg.1 for seeg; 
is_output_epo_before_ersd = 0; 


% |-------------------------|
% |----------  tf  ---------|
% |-------------------------|
is_ertf = 1;

% for tf calculation
% tf_frequency_range = [1:247]; % for seeg result including extra high gamma
% tf_frequency_range = [1:97]; %for including high gamma
 tf_frequency_range = [1:47]; %for typical frequency range
%tf_frequency_range = [1:5]; % for quick test

% for normalization
tf_baseline_range = baseline_range;
tf_normalize_method = 3; % percent change
tf_names = {'tfboth','tfpl','tfnplone','tfnpltwo','tfplf'};

% for whether calculate tfnpltwo
is_tfnpltwo = 1;

% for whether perform normalization on single trial
is_tf_norm =1;

%      |--------------------------------------------------|
%      |----------------- resting Part   -----------------|
%      |--------------------------------------------------|
is_resting_analysis = 0;


% --- save
save eleven_eeg_OptionVariable;

clear;
