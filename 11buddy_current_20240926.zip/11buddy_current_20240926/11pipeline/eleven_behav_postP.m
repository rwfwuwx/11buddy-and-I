function eleven_behav_postP
% eleven_behav_postP	
% Usage
%   eleven_behav_postP
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Note
%   for eeg, pp; for behav, postP
%
% Update history
%   2024-04-16 initial version, modify from eleven_eeg_pp.m

% |-------------------------|
% |----- post processing -----|
% |-------------------------|

%disp('post-processing');

% load option variables
load eleven_behav_OptionVariable_customize;

% load exp related variable
load behav_analyze_type;

load stim_list;
load resp_list;
load stim_sequence;
load stim_sequence_to_response_index;

if behav_analyze_type==1
    load standard_searchResp_range;
end
if behav_analyze_type==2
    load cond_IOI;
    load sequence_num;
end

% --- input
load behav_raw_pp;

% --- Step 1: separate behav record to stim record and resp record
%- stim record
behav_raw_pp_stim = [];
for ii=1:size(behav_raw_pp,1)
    if ~isempty(find(stim_list==behav_raw_pp(ii,1)))
        behav_raw_pp_stim = [behav_raw_pp_stim;behav_raw_pp(ii,:)];
    end
end

% planned-recorded stim consistency check
%   ! Note stim_sequence is the common reference/index for all.
%       (like the sbj excel is the No 1 common reference/index)
if length(stim_sequence)~=size(behav_raw_pp_stim,1)
    error('the number of recorded stimuli is not equal to the planed number, Please check');
end

%- resp record
behav_raw_pp_resp = [];
for ii=1:size(behav_raw_pp,1)
    if ~isempty(find(resp_list==behav_raw_pp(ii,1)))
        behav_raw_pp_resp = [behav_raw_pp_resp;behav_raw_pp(ii,:)];
    end
end

% --- Step 2: in stim record,mark stim that not to respond to zero
behav_raw_postP_stim = behav_raw_pp_stim;
for ii=1:length(stim_sequence)
    if stim_sequence_to_response_index(ii)==0
        behav_raw_postP_stim(ii,:)=0;
    end
end

% --- Step 3: match response to stim
% Data structure and general match algorithm: after match, the number of resp record is equal to that of stim. 
%   for stim not to respond; set 0
%   for stim to respond, whereas invalid respond (missing, double, etc.); set nan.
% Specific match rule/algorithm: according to different behav_analyze_type 

behav_raw_postP_resp = zeros(size(behav_raw_postP_stim)); % initialize postP_resp

if behav_analyze_type==2 % construct a sequence indicating the first five of a sequence
    first_five_sequence = zeros(length(stim_sequence),1);
    for ii=1:sequence_num
        % in case varying sequence length, need modify sequence_length here
        sequence_length = length(stim_sequence)/sequence_num;
        tmp_index_first_five = sequence_length*(ii-1) + [1:5];
        first_five_sequence(tmp_index_first_five)=1:5;
    end
end

for ii=1:length(stim_sequence)
    if stim_sequence_to_response_index(ii)==1 % i.e., set 0 as initialized, for stim not to respond
        
        %- perform match
        is_matched = 0; %initialize a match state bool variable
        match_index = 0; %initialize an index variable that if matched, retun the index of matched response 
        tmp_match_index = []; % to control for multiple tapping, see details below
        
        %- for each stim, find match in all resp, by time, 
        %       following a specific match rule accroding to behav_analyze_type
        tmp_stim_time = behav_raw_postP_stim(ii,2);
        
        for jj=1:size(behav_raw_pp_resp,1) 
            tmp_resp_time = behav_raw_pp_resp(jj,2);
            
            % set searchResp_range_limit /search rule
            if behav_analyze_type == 1 % standard
                searchResp_range_limit = [tmp_stim_time,tmp_stim_time+standard_searchResp_range];
            end
            % below to confirm/optimize later,particuarly the overlapped window for tap 2-5
            if behav_analyze_type == 2 % timingSyncTap 
                if first_five_sequence(ii) == 1
                    searchResp_range_limit = [tmp_stim_time,tmp_stim_time+cond_IOI];
                end
                if first_five_sequence(ii) == 2
                    searchResp_range_limit = [tmp_stim_time,tmp_stim_time+cond_IOI]-(cond_IOI/2)*(1/5);
                end
                if first_five_sequence(ii) == 3
                    searchResp_range_limit = [tmp_stim_time,tmp_stim_time+cond_IOI]-(cond_IOI/2)*(2/5);
                end
                if first_five_sequence(ii) == 4
                    searchResp_range_limit = [tmp_stim_time,tmp_stim_time+cond_IOI]-(cond_IOI/2)*(3/5);
                end
                if first_five_sequence(ii) == 5
                    searchResp_range_limit = [tmp_stim_time,tmp_stim_time+cond_IOI]-(cond_IOI/2)*(4/5);
                end
                if first_five_sequence(ii) == 0 
                    searchResp_range_limit = [tmp_stim_time,tmp_stim_time+cond_IOI]-cond_IOI/2;
                end
            end
            
            % get search result
            %   !Note, no matter what the search rule is, the search is just the 'same' search,
            %       i.e., find it in a range
            if tmp_resp_time>searchResp_range_limit(1) && tmp_resp_time<searchResp_range_limit(2)
                tmp_match_index = [tmp_match_index;jj];
            end
        end
        
        % evaluate match result
        search_result_num = length(tmp_match_index); 
        
        if search_result_num == 1 % i.e., hit
            is_matched = 1;
            match_index = tmp_match_index;
        end
%         if search_result_num == 0, % i.e., missing response
%             leave is_matched 0 as initialized
%         end
%         if search_result_num > 1, % i.e., multiple responses
%             leave is_matched 0 as initialized
%         end
        
        %- set resp record according to match result
        if is_matched
            behav_raw_postP_resp(ii,:) = behav_raw_pp_resp(match_index,:);
        else
            behav_raw_postP_resp(ii,:) = [nan nan]; % set nan, for stim to respond, whereas invalid respond
        end
        
    end
end

% --- output
save behav_raw_postP_stim behav_raw_postP_stim;
save behav_raw_postP_resp behav_raw_postP_resp;


