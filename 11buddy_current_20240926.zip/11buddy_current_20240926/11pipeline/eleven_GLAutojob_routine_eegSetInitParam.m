function eleven_GLAutojob_routine_eegSetInitParam(dir_root_file,dir_tree_file,sbj_info_file,eeg_type,import_file_type,eeg_analyze_type_list_file,by_trigger_manner)
% Input
%   eeg_type --- scalp eeg: 1; seeg: 2
% Todo
%
% Note
%   --- fs is determined by import_file_type and eeg_analyze_type
%   ---compared to eleven_GLAutojob_command,
%       1)
%       2) implement the specific routine at "% |--- do the job here ---|"
%       Others see eleven_GLAutojob_command.
% Update history
%   2023-05-23
%       updates incorporating seeg
%       other minor optimization
%   2020-12-16
%       update 42
%       correct reading eeg_analyze_type_list file col 2
%   2020-12-11
%       add by_trigger_manner
%           1.by yangyang's manner; 2 by conventional manner
%       add eeg_analyze_type related param
%   2020-12-09 modified from eleven_GLAutojob_routine_eegDataPrepare,  handling initial parameters.

%--- load dir_root
dir_root = importdata(dir_root_file);
% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

for ii = 1:length(sbj) % loop of sbj
    % whether analyze this sbj
    tmp_var_name = sbj_info_var_name{2};
    eval(sprintf('tmp_is_analysis_sbj = %s(ii);',tmp_var_name));
    if tmp_is_analysis_sbj == 1
        for jj = 1:data_num % loop of dir_tree\cond
            % whether analyze this cond,of this sbj
            tmp_var_name = sbj_info_var_name{jj+2};
            eval(sprintf('tmp_is_analysis_cond = %s(ii);',tmp_var_name));
            if tmp_is_analysis_cond == 1
                current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
                if exist(current_analysis_path,'dir')
                    cd(current_analysis_path);
                    
                    % |--- do the job here ---|
                    
                    %--- routine eegSetInitParam ---
                    % simplay save the input eeg_type
                    save eeg_type eeg_type;
                    
                    % simplay save the input import_file_type
                    save import_file_type import_file_type;
                    
                    % get eeg_analyze_type from the list file, and save
                    eeg_analyze_type_list = load(eeg_analyze_type_list_file);
                    eeg_analyze_type = eeg_analyze_type_list(jj,1);
                    save eeg_analyze_type eeg_analyze_type;
                    
                    % get eeg_analyze_type related param from the list file, and save
                    %   resting: resting_time, default 300
                    %   er: no need, 0
                    %   ssep: cond_sequence_length, has to assign one
                    %       typically and has to, same length for all conds.
                    %   sr: cond_IOI, has to assign one
                    %       typically and has to, same length for all conds.
                    if eeg_analyze_type == 1
                        resting_time = eeg_analyze_type_list(jj,2);
                        save resting_time resting_time;
                    end
                    if eeg_analyze_type == 3
                        cond_sequence_length = eeg_analyze_type_list(jj,2);
                        save cond_sequence_length cond_sequence_length;
                    end
                    if eeg_analyze_type == 4 || eeg_analyze_type == 42
                        cond_IOI = eeg_analyze_type_list(jj,2);
                        save cond_IOI cond_IOI;
                    end
                    
                    % set fs according to import_file_type and eeg_analyze_type, and save
                    if eeg_type == 1
                        if import_file_type == 1 % biosemi 64
                            if eeg_analyze_type == 1 % resting
                                fs = 200;
                            end
                            if ~isempty(find(eeg_analyze_type == [2 3 4 42])) % non resting
                                fs = 500;
                            end
                        end
                        if import_file_type==211 || import_file_type==212 % egi 128
                            if eeg_analyze_type == 1 % resting
                                fs = 100;
                            end
                            if ~isempty(find(eeg_analyze_type == [2 3 4 42])) % non resting
                                fs = 250;
                            end
                        end
                    end
                    
                    if eeg_type == 2
                        if eeg_analyze_type == 1 % resting
                            fs = 200;
                        end
                        if ~isempty(find(eeg_analyze_type == [2 3 4 42])) % non resting
                            fs = 500;
                        end
                    end
                    
                    save fs fs;
                    
                    % simplay save the input by_trigger_manner
                    save by_trigger_manner by_trigger_manner;
                    
                    % for seeg, copy required param 
                    if eeg_type == 2
                        % from structure
                        structure_path = [dir_root{1} '\' sbj{ii} '\' 'structure'];
                        copyfile([structure_path '\' 'ch_index_target.mat']);
                        copyfile([structure_path '\' 'ch_index_trigger.mat']);
                        copyfile([structure_path '\' 'ch_grouping.mat']);
                        copyfile([structure_path '\' 'reref_ch.mat']);
                        
                        % edf file, exp_time
                        copyfile(['../sbjData_belong_to_which_ieegRawData_day.mat']);
                        copyfile(['../exp_time.mat']);
                    end
                    
                     
                    % |--- end job ---|
                    
                end
            end
        end
    end
end

cd([dir_root{1} '\allsbj']);
