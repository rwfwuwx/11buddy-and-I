function yangyang_autojob_ppNormal
% Usage yangyang_autojob_ppNormal
%
% todo
%   
% update history
%   2024-04-03 initial version, modify from andy_autojob_ppNormal.m


%--- set yangyang option ---
%disp('set yangyang setting');

% now eleven_behav_set_OptionVariable_customize runs automatically from 11pipiline.
%   first delete old version of eleven_behav_set_OptionVariable_customize.m from the current directory, if there is.
current_dir=pwd;
if exist([current_dir '\' 'eleven_behav_set_OptionVariable_customize.m'],'file')
    delete eleven_behav_set_OptionVariable_customize.m;
%    delete eleven_behav_OptionVariable.mat;
%    delete eleven_behav_OptionVariable_customize.mat;
end

% somehow, when a file is just deleted from the current dir, matlab won't search the corresponding command in path. try run, works? 
%eleven_behav_set_OptionVariable_customize;
run('eleven_behav_set_OptionVariable_customize.m');

%disp('set yangyang setting, done.');


%--- load yangyang option ---
load behav_analyze_type;
load eleven_behav_OptionVariable_customize;


% --- import ---
%function eleven_behav_import(rawdata,import_file_type);
% Note, given
%   1 for yangyang's standard record, the import is just .txt->.mat 
%   2 nonstandard/other file types are not needed yet.
%   now, directly run import here.
%   Later, as needs, extend and separate import into eleven_behav_import.m
if import_file_type==1
    behav_raw = load('behav_raw.txt');
end
save behav_raw behav_raw;

% --- pre-processing ---
% Note. yangyang does not need pre-processing,currently.
% Note. for pipeline concept consistence, and for potential future nees/extending,
%   simply make a copy of raw_pp
load behav_raw;
behav_raw_pp = behav_raw;
save behav_raw_pp behav_raw_pp;

% further backup behav_raw_pp in case required later
%copyfile('behav_raw_pp.mat','behav_raw_pp_backup_ppNormal.mat');



