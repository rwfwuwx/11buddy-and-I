function eleven_behav_set_OptionVariable
% eleven_behav_set_OptionVariable
% Usage
%   eleven_behav_set_OptionVariable
% external varialbe (add later)
%  -- output
%
% todo
%   
% Update history
%   2024-05-09 add removeNan_or_interpolation_AsynSeq
%   2024-04-18 add rejecting threshold, is_reject_not_passRtest
%   2024-04-06 initial version, modify from eleven_eeg_set_OptionVariable.m


clear;

% this param as individual variable, not saving into the combined variable.
%   (for the combined variable, 'structure' is a typical option; while avoid as far as possible)
load behav_analyze_type;

% |-------------------------|
% |----- common variable----|
% |-------------------------|


% |-------------------------|
% |--------- import --------|
% |-------------------------|
%is_import = 0;

load import_file_type;

% again, this might be duplicated for analyze type and expVariable, for eeg.
%   Now, default, use expVariable to set it.
%{
if ~isempty(find(behav_analyze_type == [2]))
    load cond_IOI;
end
%}

% |-------------------------|
% |---------- postProcessing --------|
% |-------------------------|
is_postP = 1; 


% |-------------------------|
% |---------- epoch --------|
% |-------------------------|
is_epoch = 1;

% |-------------------------|
% |----------  activity  --------|
% |-------------------------|
is_activity = 1;

removeNan_or_interpolation_AsynSeq=2;
    % 1- remove nan; 2- interpolation
    
% given a sequence not passing rayleigh test, whether reject this sequence or not
%   0 - default(do not reject); 1 - reject sequences not passing rtest
is_reject_not_passRtest = 0; 
    
% given a sequence usually has invalid taps. if the number of the invalid
%   taps reach a theshold, mark this sequence for indexing, incase ask for
% note: here missing refers to invalid, clarify later as need
missingTap_percentage_threshold=0.15;

% given a subject usually has invalid sequences. if the number of the invalid
%   sequences reach a theshold, mark this subject for indexing, incase ask for
valid_sequence_threshold=3;

activity_outlier_SD = 3;


% --- save
clear behav_analyze_type;
save eleven_behav_OptionVariable;

clear;
