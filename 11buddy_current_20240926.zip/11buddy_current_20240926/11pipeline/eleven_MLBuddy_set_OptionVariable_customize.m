function eleven_MLBuddy_set_OptionVariable_customize
% eleven_MLBuddy_set_OptionVariable_customize	
% Usage
%   eleven_MLBuddy_set_OptionVariable_customize
%
% Update history 
%   2024-06-18
%       correction: add run eleven_MLBuddy_set_OptionVariable
%       remove unrecorded, tmp customize setting
%   2021-09-23 initial version

clear; % do not remove this

eleven_MLBuddy_set_OptionVariable;
load eleven_MLBuddy_OptionVariable;

% |--- add customized options here, if there are ---|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_MLBuddy_set_OptionVariable.m here 
%       2. modify here as needs
%       3. run eleven_MLBuddy_set_OptionVariable_customize here (make sure in the current program directory)



% --- save
save eleven_MLBuddy_OptionVariable_customize;

clear; % do not remove this
