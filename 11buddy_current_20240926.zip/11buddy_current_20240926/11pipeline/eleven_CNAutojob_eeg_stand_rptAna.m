function eleven_CNAutojob_eeg_stand_rptAna(studyName,sbj_info_file,sbj_index,is_formal)
% Usage 
%       eleven_CNAutojob_eeg_stand_rptAna(studyName,sbj_info_file,is_formal)
%       or, load andy_ganhuola_3; andy_ganhuola_3(studyName,sbj_info_file,is_formal)
% Input
%   is_formal:
%       0: test, data at this step will be at allsbj_test directory
%       1: formal, data at this step will be at allsbj directory
%       this setting is important to separate testing and formal analysis, at the all sbj stage.
% Update history
%   2023-12-20
%       disable show andy, because too many andy when ada ganhuola
%   2022-06-17
%       remove redundant part 'report' to 'ML', which were priviously planned here and is now implemented in other place
%       remove dataList_eeg_file.
%   2022-02-28 add running logo
%   2022-01-23 add is_formal, i.e., allsbj->allsbj_test when test
%   2022-01-16 script-> final func
%           nickname andy_ganhuola_3:  load andy_ganhuola_3; andy_ganhuola_3(studyName,sbj_info_file)  
%               (by andy_ganhuola_3 = @eleven_CNAutojob_eeg_stand_rptAna; save andy_ganhuola_3 andy_ganhuola_3;)
%   2022-01-14
%       interpret -> stand_rptAna (standard report analysis)
%   2021-11-19 
%       separate from 'eleven_CNAutojob_standard_source_test_202108_20211028.m'
%       others see eleven_CNAutojob_stand_(preAna & dataAna). 

% myicon = imread('andy.jpg');
% h=msgbox('������Ϊ������(��ǰִ��������)���������ĵȴ�',' ','custom',myicon);

% |---------------------------------------------------------|
% |------------------ common exp parameter -----------------|
% |---------------------------------------------------------|

analysis_rootDir_eeg_file = ['analysis_rootDir_eeg_' studyName '.txt'];
analysis_dirTree_eeg_file = ['analysis_dirTree_eeg_' studyName '.txt'];
eeg_analyze_type_list_file = ['eeg_analyze_type_list_' studyName '.txt'];

% |--------------------------------------------------------------------|
% |################# Part 3: report analysis (rptAna) ##################|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------- prepare rptAna dir structure--------------|
% |---------------------------------------------------------|
% This step includes 

%
eleven_GLAutojob_routine_eegRptAnaDirPrepare( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    eeg_analyze_type_list_file, ...
    is_formal);
%}

% |---------------------------------------------------------|
% |------------------- copy parameters ---------------------|
% |---------------------------------------------------------|
% This step includes 

%
eleven_GLAutojob_routine_eegRptAnaCopyParam( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    eeg_analyze_type_list_file, ...
    sbj_info_file, ...
    is_formal);
%}

% |---------------------------------------------------------|
% |-------------------- group average ----------------------|
% |---------------------------------------------------------|
% This step includes 

%
eleven_GLAutojob_routine_eegRptAnaAvg( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    eeg_analyze_type_list_file, ...
    sbj_info_file, ...
    sbj_index, ...
    is_formal);
%}

%
disp('~-~ andy ganhuola 3: all jobs are done ~-~ )');

%close(h)
% myicon = imread('andy.jpg');
% msgbox('���Ѿ���ɹ���3���������Բ鿴����������','Success','custom',myicon);
