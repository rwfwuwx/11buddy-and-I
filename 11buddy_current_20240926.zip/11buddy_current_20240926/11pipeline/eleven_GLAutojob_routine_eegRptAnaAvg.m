function eleven_GLAutojob_routine_eegRptAnaAvg(dir_root_file,dir_tree_file,eeg_analyze_type_list_file,sbj_info_file,sbj_index,is_formal)
% Input
%
% Todo
%   handle atlasNames automatically later
%   for resting, add detailed result data later. now include those for image result
%   42 was not handling yet.
% Note
%
% Update history
%   2024-06-04
%       add eeg_resting_connect_cm_coef_highGamma and
%       eeg_resting_connect_cm_coef_lowGamma avg in 'resting' part
%   2024-05-22
%       add tfpl avg in 'sr' part
%   2024-04-24
%       add tfpl avg in 'er' part
%   2023-04-14
%       return the below update '2023-04-11' '2023-04-06' '2023-03-27' back
%       to original, for andy3 donot involve the individual level processing
%   2023-04-11
%       base on updata of 20230406, add updating the error cond index in 'analysis_allSbjData_groupSbjIndex_studyID_date.xlsx',
%       through change the error cond from 1 to 0. see line 493-496.
%   2023-04-06
%       base on updata of 20230327, add error_message to the 'sbjLoop_errorRecord.xlsx',
%       and change the error record site of andy3 to sheet5 of the excel. see line 479-491.
%   2023-03-27
%       add "try...catch..."to record wrong sbjID in 'andy3' step, and
%       return the wrong sbjID according to the reeor cause in the 'sbjLoop_errorRecord.xlsx'.
%       The excel have been built in 'J:\analyze\..\studyID\allsbj'.
%   2022-08-09
%       update that 'is_analysis' in the sbj info tabel is not need anymore. 
%       add handling if nan (a double check. not necessary)
%   2022-06-17
%       update comments to be clear.
%       remove dataList_eeg_file.
%   2022-06-15
%       --- add handling sbj_index
%       --- decide whther the data is to copy param. similar to 'CopyParam', while
%           handling sbj_index
%   2022-06-14
%       for allsbj path, replace data_list by dir_tree. the same as 'DirPrepare'.
%   2022-01-27 fix bug.eval(sprintf('save %s %s;',input_data_name)) -> eval(sprintf('save %s %s;',input_data_name,input_data_name));
%   2022-01-23 add is_formal, i.e., allsbj->allsbj_test when test
%   2022-01-16
%       initial version as a new routine. modify from eleven_GLAutojob_routine_eegRptAnaCopyParam.

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

atlasNames = {'DesikanKilliany'};

%--- select data based on sbj_index
sbj_index = sbj_index(:); % in case sbj_index is not input as column vector

if ~isempty(sbj_index)
    sbj_index_num = find(sbj_index==1);
    
    sbj = sbj(sbj_index_num);
    for ii=1:data_num
        tmp_var_name = sbj_info_var_name{ii+2};
        eval(sprintf('%s=%s(sbj_index_num);',tmp_var_name,tmp_var_name));
    end
end


%--- decide whether include a data
data_include_index = ones(data_num,1);

% not include data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        data_include_index(ii) = 0;
    end
end

data_include_index_num = find(data_include_index==1);



for ii = 1:length(data_include_index_num)
    
    allsbj_data_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{[data_include_index_num(ii)]}];
    sbj_data_path = [dir_root{1} '\' 'sbjxx' '\' dir_tree{[data_include_index_num(ii)]}];
    
    eeg_analyze_type_list = load(eeg_analyze_type_list_file);
    eeg_analyze_type = eeg_analyze_type_list([data_include_index_num(ii)],1);
  
    % |--- resting ---|
    if eeg_analyze_type == 1
        % set dir_list
        dir_list_allsbj = {[allsbj_data_path '\' 'run2'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        dir_list_sbj = {[sbj_data_path '\' 'run2'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        
        % loop of dir_list
        for jj = 1:length(dir_list_allsbj)
            current_dir_allsbj = dir_list_allsbj{jj};
            cd(current_dir_allsbj);
            
            %--- eeg_resting_spec_am_norm
            tmp_allsbj_result = 0;
            
            % loop of sbj
            num_sbj_add = 0;
            for kk = 1:length(sbj)
                % whether analyze the data of this sbj
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                % handling if nan
                if isnan(tmp_is_analyzed_cond)
                    tmp_is_analyzed_cond = 0;
                end
                if tmp_is_analyzed_cond == 1
                    current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                    cd(current_dir_sbj);
                    load eeg_resting_spec_am_norm;
                    tmp_allsbj_result = tmp_allsbj_result + eeg_resting_spec_am_norm;
                    
                    num_sbj_add = num_sbj_add + 1;
                end
            end
            
            cd(current_dir_allsbj);
            eeg_resting_spec_am_norm = tmp_allsbj_result./ num_sbj_add;
            save eeg_resting_spec_am_norm eeg_resting_spec_am_norm;
            is_avg_result = 1; save is_avg_result is_avg_result;
            
            %--- eeg_resting_connect_cm_coef_raw
            tmp_allsbj_result = 0;
            
            % loop of sbj
            num_sbj_add = 0;
            for kk = 1:length(sbj)
                % whether analyze the data of this sbj
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                % handling if nan
                if isnan(tmp_is_analyzed_cond)
                    tmp_is_analyzed_cond = 0;
                end
                if tmp_is_analyzed_cond == 1
                    current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                    cd(current_dir_sbj);
                    load eeg_resting_connect_cm_coef_raw;
                    tmp_allsbj_result = tmp_allsbj_result + eeg_resting_connect_cm_coef_raw;
                    
                    num_sbj_add = num_sbj_add + 1;
                end
            end
            
            cd(current_dir_allsbj);
            eeg_resting_connect_cm_coef_raw = tmp_allsbj_result./ num_sbj_add;
            save eeg_resting_connect_cm_coef_raw eeg_resting_connect_cm_coef_raw;
            is_avg_result = 1; save is_avg_result is_avg_result;
            
            %--- eeg_resting_connect_cm_coef_highGamma
            tmp_allsbj_result = 0;
            
            % loop of sbj
            num_sbj_add = 0;
            for kk = 1:length(sbj)
                % whether analyze the data of this sbj
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                % handling if nan
                if isnan(tmp_is_analyzed_cond)
                    tmp_is_analyzed_cond = 0;
                end
                if tmp_is_analyzed_cond == 1
                    current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                    cd(current_dir_sbj);
                    load eeg_resting_connect_cm_coef_highGamma;
                    tmp_allsbj_result = tmp_allsbj_result + eeg_resting_connect_cm_coef_highGamma;
                    
                    num_sbj_add = num_sbj_add + 1;
                end
            end
            
            cd(current_dir_allsbj);
            eeg_resting_connect_cm_coef_highGamma = tmp_allsbj_result./ num_sbj_add;
            save eeg_resting_connect_cm_coef_highGamma eeg_resting_connect_cm_coef_highGamma;
            is_avg_result = 1; save is_avg_result is_avg_result;
            
            %--- eeg_resting_connect_cm_coef_lowGamma
            tmp_allsbj_result = 0;
            
            % loop of sbj
            num_sbj_add = 0;
            for kk = 1:length(sbj)
                % whether analyze the data of this sbj
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                % handling if nan
                if isnan(tmp_is_analyzed_cond)
                    tmp_is_analyzed_cond = 0;
                end
                if tmp_is_analyzed_cond == 1
                    current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                    cd(current_dir_sbj);
                    load eeg_resting_connect_cm_coef_lowGamma;
                    tmp_allsbj_result = tmp_allsbj_result + eeg_resting_connect_cm_coef_lowGamma;
                    
                    num_sbj_add = num_sbj_add + 1;
                end
            end
            
            cd(current_dir_allsbj);
            eeg_resting_connect_cm_coef_lowGamma = tmp_allsbj_result./ num_sbj_add;
            save eeg_resting_connect_cm_coef_lowGamma eeg_resting_connect_cm_coef_lowGamma;
            is_avg_result = 1; save is_avg_result is_avg_result;
        end
    end
    
    % |--- er ---|
    if eeg_analyze_type == 2
        % set dir_list
        dir_list_allsbj = {[allsbj_data_path '\' 'run2'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        dir_list_sbj = {[sbj_data_path '\' 'run2'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        
        % loop of dir_list
        for jj = 1:length(dir_list_allsbj)
            current_dir_allsbj = dir_list_allsbj{jj};
            cd(current_dir_allsbj);
            
            load cond_name;
            cond_num = length(cond_name);
            
            %--- erp
            % loop of cond_num
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_erp' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
            %--- tf
            % loop of cond_num
            % tfnpltwo
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_tfnpltwo' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            % tfpl
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_tfpl' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
        end
    end
    
    % |--- ssep ---|
    if eeg_analyze_type == 3
        % set dir_list
        dir_list_allsbj = {[allsbj_data_path '\' 'run2'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        dir_list_sbj = {[sbj_data_path '\' 'run2'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        
        % loop of dir_list
        for jj = 1:length(dir_list_allsbj)
            current_dir_allsbj = dir_list_allsbj{jj};
            cd(current_dir_allsbj);
            
            %--- eeg_ssep_spec_am_norm
            load cond_name;
            cond_num = length(cond_name);
            
            % loop of cond_num
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_ssep_spec_am_norm' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
        end
    end
    
    % |--- sr ---|
    if eeg_analyze_type == 4
        
        % srer
        % set dir_list
        dir_list_allsbj = {[allsbj_data_path '\' 'run2' '\' 'srer'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srer']};
        dir_list_sbj = {[sbj_data_path '\' 'run2' '\' 'srer'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srer']};
        
        % loop of dir_list
        for jj = 1:length(dir_list_allsbj)
            current_dir_allsbj = dir_list_allsbj{jj};
            cd(current_dir_allsbj);
            
            load cond_name;
            cond_num = length(cond_name);
            
            %--- erp
            % loop of cond_num
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_erp' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
            %--- tf
            % loop of cond_num
            % tfnpl
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_tfnpltwo' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
            %tfpl
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_tfpl' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
        end
        
        % srssep
        % set dir_list
        dir_list_allsbj = {[allsbj_data_path '\' 'run2' '\' 'srssep'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srssep']};
        dir_list_sbj = {[sbj_data_path '\' 'run2' '\' 'srssep'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srssep']};
        
        % loop of dir_list
        for jj = 1:length(dir_list_allsbj)
            current_dir_allsbj = dir_list_allsbj{jj};
            cd(current_dir_allsbj);
            
            %--- eeg_ssep_spec_am_norm
            load cond_name;
            cond_num = length(cond_name);
            
            % loop of cond_num
            for ll=1:cond_num
                
                tmp_allsbj_result = 0;
                
                input_data_name = ['eeg_ssep_spec_am_norm' '_' cond_name{ll}];
                
                
                % loop of sbj
                num_sbj_add = 0;
                for kk = 1:length(sbj)
                    % whether analyze the data of this sbj
                    tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                    eval(sprintf('tmp_is_analyzed_cond = %s(kk);',tmp_var_name));
                    % handling if nan
                    if isnan(tmp_is_analyzed_cond)
                        tmp_is_analyzed_cond = 0;
                    end
                    if tmp_is_analyzed_cond == 1
                        current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                        cd(current_dir_sbj);
                        eval(sprintf('load %s;',input_data_name));
                        eval(sprintf('tmp_sbj_result = %s;',input_data_name));
                        eval(sprintf('clear %s;',input_data_name));
                        tmp_allsbj_result = tmp_allsbj_result + tmp_sbj_result;
                        
                        num_sbj_add = num_sbj_add + 1;
                    end
                end
                
                cd(current_dir_allsbj);
                tmp_allsbj_result = tmp_allsbj_result./ num_sbj_add;
                eval(sprintf('%s = tmp_allsbj_result;',input_data_name));
                eval(sprintf('save %s %s;',input_data_name,input_data_name));
                is_avg_result = 1; save is_avg_result is_avg_result;
            end
            
        end
    end
    
end

cd([dir_root{1} '\' allsbj_dirName]);
