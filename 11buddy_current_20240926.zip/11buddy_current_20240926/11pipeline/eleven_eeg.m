function eleven_eeg
% eleven_eeg	
% Usage
%   eleven_eeg
%
%   or load andy; andy()
%   (by andy = @eleven_eeg; save andy andy;)
%
% |------------------------|
% |-------description------|
% |------------------------|
% 1. eleven_eeg.m (andy)
% only one andy for all analyses.
% 
% eleven_eeg_pp.m % same for all types of analysis
% 
% 1.1. er
% eleven_eeg_er_epoch.m
% eleven_eeg_er_erp.m
% eleven_eeg_er_ersd.m
% eleven_eeg_er_ertf.m
% 
% 1.2. ssep
% (eleven_eeg_er_epoch.m) (same as er)
% eleven_eeg_ssep_spec.m
% eleven_eeg_ssep_envelop.m (i.e., extract amplitude change of the target frequency. for high frequency)
% eleven_eeg_ssep_wave.m (i.e., narrow filter at  the target frequency. for low frequency)
% 
% 1.3. slow rhythm
% --- er part, same as er, except:
% (1) ersd is not necessary/applicable.
% (2) including three events
% (
% eleven_eeg_er_epoch.m
% eleven_eeg_er_erp.m
% eleven_eeg_er_ertf.m
% )
%
% --- ssep part, same as ssep, excep:
% (1) envelop is not necessary/applicable.
% (2) typically, remove the first five and the last events.
% (
% eleven_eeg_ssep_epoch.m
% eleven_eeg_ssep_spec.m
% eleven_eeg_ssep_wave.m (i.e., narrow filter at  the target frequency. for low frequency)
% )
%
% 1.4. resting
% eleven_eeg_resting_freq.m
% 
% % here handle link with other connectivity toolbox. One way is to simply prepare raw data, i.e., the so-called extracted time course in fMRI, as the input to fMRI toolbox.
% eleven_eeg_resting_ConnectMatrix.m 
% 
% 
% ---2. eleven_eeg_OptionVariable.mat (options of andy)
% % only one option file for all analyses, with different option settings.
%   
%
%   todo 
%
% Update history
%   2023-05-25 
%       clarification incorporating seeg
%           !!! begin from seeg; now, finally back to it and done eeg(seeg and scalp eeg)
%                eleven_eeg_set_OptionVariable_er_seeg.m & eleven_eeg_set_OptionVariable_sr_eeg.m
%                are not no need any more.
%   2022-02-28 mark eleven_eeg_resting_ConnectIndexTS to save time. add as individual step as needs
%   2021-12-20 start ssep: 
%       epoch
%       spec
%   2021-12-11 
%       add import
%   2020-10-21
%       add eleven_eeg_reref.m, and corresponding handling
%       add eleven_eeg_resting_connect.m
%       eleven_eeg_resting_ConnectIndexTS
%   2020-10-20 add eleven_eeg_resting_spec.m
%   2020-10-16
%       eleven_eeg_resting_filter.m->eleven_eeg_resting_AMEnv.m
%   2020-10-12
%       add eleven_eeg_resting_filter.m
%   2020-10-11
%       add eleven_eeg_set_OptionVariable_resting_eeg.m;
%   2020-09-30
%       apply customize option as yangyang, by add eleven_eeg_set_OptionVariable_customize
%   2020-04-28 
%       re-design the framework, and incorparate all eeg analyses into one andy.
%       also design the relation of one andy, with one andy option file, and different option setting files. 
%       do all corresponding modifications.
%   2020-04-24 add whether-to-do option for each module
%   2020-04-08 add ersd
%   2020-03-30 re-done, as andy_er
%   2020-03-25 reorgize and rewrite from Andy. 
%   2020-01-07
%       ...
%       Andy is ready
%   2020-01-06
%       ...
%	2020-01-05 initially writen

%clear;

% |----------------------------------------|
% |----------------- import ---------------|
% |----------------------------------------|
% Note, andy is now called by andy 2.andy 1 directly call eleven_eeg_import.
%   thus, in option, related params are set, while is_import set to 0.
%   i.e., andy 1 does not needs is_import; 
%       andy 2 does not involve the step of import.
clear; load eleven_eeg_OptionVariable_customize;
if is_import
    eleven_eeg_import;
end

% |----------------------------------------|
% |------ pre-processing, and related -----|
% |----------------------------------------|
% Note, andy is now called by andy 2.andy 1 directly call eleven_eeg_pp.
%   thus, in option, related params are set, while is_import set to 0.
%   i.e., andy 1 does not needs is_pp; 
%       andy 2 does not involve the step of pp.
clear; load eleven_eeg_OptionVariable_customize;
if is_pp
    eleven_eeg_pp;
end

% |----------------------------------------|
% |---------------- reref -----------------|
% |----------------------------------------|
% Note, andy is now called by andy 2.andy 1 directly call eleven_eeg_reref.
%   thus, in option, related params are set, while is_import set to 0.
%   i.e., andy 1 does not needs is_reref; 
%       andy 2 does not involve the step of reref.
clear; load eleven_eeg_OptionVariable_customize;
if is_reref
    eleven_eeg_reref;
end
%

% |----------------------------------------|
% |------------------ er ------------------|
% |-------------- sr er part --------------|
% |----------------------------------------|
clear; load eleven_eeg_OptionVariable_customize;
if is_epoch
    eleven_eeg_er_epoch;
end

clear; load eleven_eeg_OptionVariable_customize;
if is_erp
    eleven_eeg_er_erp;
end

clear; load eleven_eeg_OptionVariable_customize;
if is_ersd
    eleven_eeg_er_ersd;
end

clear; load eleven_eeg_OptionVariable_customize;
if is_ertf
    eleven_eeg_er_ertf;
end

% |----------------------------------------|
% |----------------- ssep -----------------|
% |------------- sr ssep part -------------|
% |----------------------------------------|
% the same epoch step as er

clear; load eleven_eeg_OptionVariable_customize;
if is_ssep
    eleven_eeg_ssep_spec;
end


% |----------------------------------------|
% |--------------- resting ----------------|
% |----------------------------------------|
clear; load eleven_eeg_OptionVariable_customize;
if is_resting_analysis
    eleven_eeg_resting_AMEnv;
    eleven_eeg_resting_spec;
    eleven_eeg_resting_connect;
    %eleven_eeg_resting_ConnectIndexTS
end

disp('andy job done.');

%clear;