function eleven_GLAutojob_routine_behavExpParamPrepare(dir_root_file,dir_tree_file,sbj_info_file,StimRespMapingRelated_list_file,condName_list_file,expVariable_list_file)
% Input
%   
% Todo
%
% Note
%
% Update history
%   2024-04-015 initial version, modify from eleven_GLAutojob_routine_eegExpParamPrepare.m

%--- load dir_root
dir_root = importdata(dir_root_file);
% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

for ii = 1:length(sbj) % loop of sbj
    % whether analyze this sbj
    tmp_var_name = sbj_info_var_name{2};
    eval(sprintf('tmp_is_analysis_sbj = %s(ii);',tmp_var_name));
    if tmp_is_analysis_sbj == 1
        for jj = 1:data_num % loop of dir_tree\cond
            % whether analyze this cond,of this sbj
            tmp_var_name = sbj_info_var_name{jj+2};
            eval(sprintf('tmp_is_analysis_cond = %s(ii);',tmp_var_name));
            if tmp_is_analysis_cond == 1
                current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
                if exist(current_analysis_path,'dir')
                    cd(current_analysis_path);
                    
                    % |--- do the job here ---|
                    
                    %--- routine ---
                    
                    load dataAnaDir;
                    dataAna_root_dir = pwd;
                    
                    for kk=1:length(dataAnaDir) % do this for each of dataAnaDir
                        cd(dataAnaDir{kk});
                        
                        load behav_analyze_type;
                        
                        % --- prepare StimRespMapingRelated
                        StimRespMapingRelated_list = importdata(StimRespMapingRelated_list_file);
                        StimRespMapingRelated_name = StimRespMapingRelated_list{jj};
                        eval(sprintf('load %s;',StimRespMapingRelated_name));
                       
                        save stim_sequence stim_sequence;
                        stim_resp_maping_assign = stim_resp_maping_assign_sbj_list(ii);
                        save stim_resp_maping_assign stim_resp_maping_assign;
                        save stim_resp_maping stim_resp_maping;
                        save stim_list stim_list;
                        save resp_list resp_list;
                        save stim_to_response_list stim_to_response_list;
                        save stim_sequence_to_response_index stim_sequence_to_response_index;
                        save response_tobe response_tobe;
                        save sequence_num sequence_num;
                        
                        
                        % --- prepare cond_name
                        condName_list = eleven_importdata_txt(condName_list_file);
                        cond_name = condName_list(jj,:);
                        % remove empty ones
                        non_empty_index = [];
                        for mm=1:length(cond_name)
                            if ~isempty(cond_name{mm})
                                non_empty_index = [non_empty_index mm];
                            end
                        end
                        cond_name = cond_name(non_empty_index);
                        
                        save cond_name cond_name;
                        
                        
                        % --- prepare expVariable(s)
                        expVariable_list = importdata(expVariable_list_file);
                        expVariable_name = expVariable_list{jj};
                        eval(sprintf('load %s;',expVariable_name));
                       
                        save cond_code cond_code;
                        if behav_analyze_type == 1
                            save IOI_sequence IOI_sequence;
                            save standard_searchResp_range standard_searchResp_range;
                        end
                        if behav_analyze_type == 2
                            save cond_IOI cond_IOI;
                        end
                            
                        
                        cd(dataAna_root_dir);
                    end
                    
                    
                    % |--- end job ---|
                    
                end
            end
        end
    end
end

cd([dir_root{1} '\allsbj']);
