function eleven_eeg_set_OptionVariable_cfe
% eleven_eeg_set_OptionVariable_cfe
% Usage
%   eleven_eeg_set_OptionVariable_cfe
% external varialbe (add later)
%  -- output
%
% todo
%   
% Update history
%   2024-07-09  add ssep
%       note: this is a specific implimentation 
%           customized frequency setting is by loading a frequency 'input_target_freq'
%               which input as a scaler 
%               and also set second and third hamony
%           when length(cond_name) >1
%               customized frequency setting is by loading a frequency 'input_target_freq'
%               which input as a 1*n matrix (n=length(cond_name))
%       note: generalize late
%           
%   2022-08-12
%       add AlphaPeak_is_filter
%       add AlphaPeak_smooth_points;
%       remove AlphaPeak_is_detrend;
%   2022-08-11 
%       add AlphaPeak_is_detrend;
%       AlphaPeak_is_smooth = 0; -> 1
%	2022-06-19 initial version, modify from eleven_eeg_set_OptionVariable.m

clear;

% these two param as individual variables, not saving into the combined variable.
%   (for the combined variable, 'structure' is a typical option; while avoid as far as possible)
load eeg_type;
load eeg_analyze_type;

% |-------------------------|
% |----- common variable----|
% |-------------------------|



% |-------------------------|
% |----------  erp  --------|
% |-------------------------|




% |-------------------------|
% |----------  tf  ---------|
% |-------------------------|


% |--------------------------------------------------|
% |------------------- ssep Part   ------------------|
% |--------------------------------------------------|
if eeg_analyze_type == 3 || eeg_analyze_type == 43
    % $$ input frequency need to extract its amplitude, save as .mat in 11job
    %       option 1: input a number when all conditions extracting amplitude of same freq
    %       option 2: input a 1*n(n equals the number of conditions) matrix 
    %           when different conditions extracting amplitude of different freq correspondingly
    load input_target_freq;
    %------------------------------------------------
    
    load cond_name;
    cond_num = length(cond_name);
    
    if length(input_target_freq)==1 %option 1
        componentFeature_list=cell(1);
        iicfl=0;
        for iicn=1:cond_num
        iicfl=iicfl+1;  
        output_data_name = ['ssep_baseFreq_' cond_name{iicn}];
        componentFeature_list{iicfl}=output_data_name;
        iicfl=iicfl+1;
        output_data_name = ['ssep_2ndFreq_' cond_name{iicn}];
        componentFeature_list{iicfl}=output_data_name;
        iicfl=iicfl+1;
        output_data_name = ['ssep_3rdFreq_' cond_name{iicn}];
        componentFeature_list{iicfl}=output_data_name;
        end
    end
    
    if length(input_target_freq)>1 && length(input_target_freq)==cond_num %option 2
        componentFeature_list=cell(1);
        for iicn=1:cond_num
        output_data_name = ['ssep_baseFreq_' cond_name{iicn}];
        componentFeature_list{iicn}=output_data_name;
        end
    end
    
    componentFeature_list= componentFeature_list';
    
end

% |--------------------------------------------------|
% |----------------- resting Part   -----------------|
% |--------------------------------------------------|
if eeg_analyze_type == 1;

    componentFeature_list = { ...
        'AM_theta'; 'AM_alpha'; 'AM_beta'; 'AM_lowGamma'; ...
        'relaAM_theta'; 'relaAM_alpha'; 'relaAM_beta'; 'relaAM_lowGamma'; ...
        'AlphaPeak_AM'; 'AlphaPeak_latency'; 'AlphaPeak_snr'; ...
        'SD_raw'; 'CV_theta'; 'CV_alpha'; 'CV_beta'; 'CV_lowGamma'; ...
        'cm_raw'; 'cm_theta'; 'cm_alpha'; 'cm_beta'; 'cm_lowGamma'; ...
%         'CON_Str_raw';'CON_Str_theta';'CON_Str_alpha';'CON_Str_beta','CON_Str_lowGamma';...
        };
    
    %--- AlphaPeak
    AlphaPeak_half_win = 1; % hz
    AlphaPeak_oneSide_neigh = 1; % hz
    AlphaPeak_is_smooth = 1;
    AlphaPeak_smooth_points = 50;
%    AlphaPeak_is_detrend = 0;
    AlphaPeak_is_filter = 1;
end
    


% --- save
clear eeg_type;
clear eeg_analyze_type;
save eleven_eeg_OptionVariable_cfe;

clear;
