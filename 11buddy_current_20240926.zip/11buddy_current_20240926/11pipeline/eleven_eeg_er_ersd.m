function eleven_eeg_er_ersd
% eleven_eeg_er_ersd
% Usage
%   eleven_eeg_er_ersd
% external varialbe (add later)
%  -- input
%  -- option
%  -- output
%
% Update history
%   2021-12-17 expVariable-> individual variable
%   2020-12-16
%    change eleven_eeg_OptionVariable to eleven_eeg_OptionVariable_customize;
%   2020-04-09 write

% |-------------------------|
% |----------  ersd  --------|
% |-------------------------|

%clear;
disp('ersd processing');

% --- load option variables
load eleven_eeg_OptionVariable_customize;

% --- input
% exp variable
% for condition: condition name.
% (condition code is only needed in epoch)
load cond_name;

% |--- processing loop by 1. condition,2. freq band ---|
cond_num = length(cond_name);
freq_band_num = length(ersd_freq_band_name);

for ii=1:cond_num
    % --- input
    % epo data
    input_data_name = ['eeg_epo' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('eeg_epo_tmp = %s;',input_data_name));
    
    for jj=1:freq_band_num
        % --- filter
        disp('  filter');
        eeg_epo_tmp_filt = mf_epofilter(eeg_epo_tmp,'IIR','band pass',ersd_freq_band(jj,:),4,fs);
        
        % ---
        disp('  square');
        eeg_epo_tmp_square = eeg_epo_tmp_filt.^2;
        
        % --- normalize
        disp('  normalize');
        eeg_epo_tmp_norm = mf_eponorm(eeg_epo_tmp_square,ersd_baseline_range,3);
        
        % --- average
        disp('  average');
        eeg_ersd_tmp = mf_epoavg(eeg_epo_tmp_norm);
        
        % --- output
        % output epo_before_ersd
        if is_output_epo_before_ersd
            output_data_name = ['eeg_epo_before_ersd' '_' ersd_freq_band_name{jj} '_' cond_name{ii}];
            eval(sprintf('%s = eeg_epo_tmp_norm;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
        end
        
        % output ersd
        output_data_name = ['eeg_ersd' '_' ersd_freq_band_name{jj} '_' cond_name{ii}];
        eval(sprintf('%s = eeg_ersd_tmp;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
        
        % --- clear
        eval(sprintf('clear %s;',output_data_name));
    end
    % --- clear
    eval(sprintf('clear %s;',input_data_name));
end

%clear;
