function eleven_GLAutojob_routine_behavCfeAnaAllsbjFeature(dir_root_file,dir_tree_file,behav_analyze_type_list_file,sbj_info_file,data_index,is_formal)
% Input
%
% Todo
%
% Note
% # simplification. see Note in eleven_GLAutojob_routine_behavRptAnaAvg.m
% # analyze_type is not need for behav.
%   keep it in case future requirement.
% Update history
%   2024-08-18 fix small bug of 'generate and save componentFeature_list
%       with condname'
%   2024-07-02
%       add componentFeature_list_plusCondname(.mat and .txt)
%       seperate produce table 
%           seperate produce table for all data
%   2024-06-18 bug fix for unable to
%       write'analysis_allSbjData_metric_mark.xlsx' using the xlsx file name with date
%   2024-05-15 bug fix for imerging componentFeature_list and extraComponentFeature_list
%   2024-05-09 14:35 update table
%   2024-05-09 add saving metrics into a table
%   2024-04-18 initial version, modify from eleven_GLAutojob_routine_eegCfeAnaAllsbjFeature.m

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

%--- decide whether include a data
data_include_index = ones(data_num,1);

% not include data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        data_include_index(ii) = 0;
    end
end

% a double check that the input data_index is already analyzed
data_include_index = data_include_index & data_index;

data_include_index_num = find(data_include_index==1);

% ---for allSbjData table
feature_name=cell(1,1);
tmp_t_input=zeros(length(sbj),1);

for ii = 1:length(data_include_index_num) % loop of data
    
    allsbj_data_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{[data_include_index_num(ii)]}];
    sbj_data_path = [dir_root{1} '\' 'sbjxx' '\' dir_tree{[data_include_index_num(ii)]}];
    
    current_dir_allsbj = allsbj_data_path;
    cd(current_dir_allsbj);
    
    % decide behav_analyze_type by data
    behav_analyze_type_list = load(behav_analyze_type_list_file);
    behav_analyze_type = behav_analyze_type_list([data_include_index_num(ii)],1);
    
    
    %--- get componentFeature_list (componentFeature_list)
    eleven_behav_set_OptionVariable_cfe_customize;
    load eleven_behav_OptionVariable_cfe_customize;
    
    % combine componentFeature_list and extraComponentFeature_list
    if ~isempty(extraComponentFeature_list) % if extraComponentFeature_list is non empty
        tmp_cell = [componentFeature_list;extraComponentFeature_list];
        componentFeature_list = tmp_cell;
    end
    
    load cond_name;
    cond_num = length(cond_name);
    
        
    for jj = 1:cond_num % loop of cond
        
        for kk = 1:length(componentFeature_list) % loop of feature
            
            tmp_feature_name = [componentFeature_list{kk}  '_' cond_name{jj}];
            
            %--- initialize allsbj data
            tmp_allsbj_result = zeros(length(sbj),1);
            
            %--- loop of sbj
            for ll = 1:length(sbj)
                % whether this data is analyzed
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analysis_cond = %s(ll);',tmp_var_name));
                
                if tmp_is_analysis_cond == 1
                    current_dir_sbj = strrep(sbj_data_path, 'sbjxx', sbj{ll});
                    cd(current_dir_sbj);
                    
                    eval(sprintf('load %s;',tmp_feature_name));
                    eval(sprintf('tmp_allsbj_result(ll) = %s;',tmp_feature_name));
                else
                    eval(sprintf('tmp_allsbj_result(ll) = nan;'));
                end
            end
            
            cd(current_dir_allsbj);
            
            % --- save
            eval(sprintf('%s = tmp_allsbj_result;',tmp_feature_name));
            eval(sprintf('save %s %s;',tmp_feature_name,tmp_feature_name));
            
        end
        
    end
    
    %cd(current_dir_allsbj);
    % just for know feature list, without see option file
    save componentFeature_list componentFeature_list;
    
    file_name='componentFeature_list.txt';
    fid_w=fopen(file_name,'w');
    for row=1:size(componentFeature_list,1)
        fprintf(fid_w, '%s\r\n', componentFeature_list{row,:});
    end
    fclose(fid_w);
    
    % generate and save componentFeature_list with condname
    tmp_feature_name_oneData=cell(1,1);
    componentFeature_plus_tmp=componentFeature_list;
    for jj_cn = 1:cond_num
        tmp_name=['_' cond_name{jj_cn}];
        for ii_cn = 1:length(componentFeature_list)
            componentFeature_plus_tmp{ii_cn}=[componentFeature_list{ii_cn} tmp_name];
        end
        tmp_feature_name_oneData=[tmp_feature_name_oneData;componentFeature_plus_tmp];
    end
    
    componentFeature_list_plusCondname=tmp_feature_name_oneData(2:end);
    save componentFeature_list_plusCondname componentFeature_list_plusCondname;
    
    file_name='componentFeature_list_plusCondname.txt';
    fid_w=fopen(file_name,'w');
    for row=1:size(componentFeature_list_plusCondname,1)
        fprintf(fid_w, '%s\r\n', componentFeature_list_plusCondname{row,:});
    end
    fclose(fid_w);
    
    %--- produce table for current data
    tmp_t_input_oneData=zeros(length(sbj),length(componentFeature_list_plusCondname));
    for iitb=1:length(componentFeature_list_plusCondname)
        data_name_tmp=componentFeature_list_plusCondname{iitb};
        eval(sprintf('tmp_t_input_oneData(:,iitb)=%s;',data_name_tmp));
    end
    
    tmp_feature_name_oneData=componentFeature_list_plusCondname';
    first_headname={'sbj'};
    tmp_head_name=[first_headname tmp_feature_name_oneData];
    
    t=[sbj num2cell(tmp_t_input_oneData)];
    
    t=cell2table(t,'VariableNames',tmp_head_name);
    writetable(t,['componentFeature_list_plusCondname_' date '.xlsx']);
    
    feature_name=[feature_name tmp_feature_name_oneData];
    tmp_t_input=[tmp_t_input tmp_t_input_oneData];
    
end

%--- given table for each data, combine them into a table for all data
is_produce_table_for_allData=1;
if is_produce_table_for_allData==1
    cd([dir_root{1} '\' allsbj_dirName]);
    feature_name{1}='sbj';
    tmp_t_input=tmp_t_input(:,2:end);
    t=[sbj num2cell(tmp_t_input)];
    t=cell2table(t,'VariableNames',feature_name);
    writetable(t,['analysis_allSbjData_metric_mark_' date '.xlsx']);
end


cd([dir_root{1} '\' allsbj_dirName]);
