function eleven_behav_set_OptionVariable_customize
% eleven_behav_set_OptionVariable_customize	
% Usage
%   eleven_behav_set_OptionVariable_customize
%
% Update history 
%   2024-04-06 initial version, modify from eleven_eeg_set_OptionVariable_customize.m

clear; % do not remove this

eleven_behav_set_OptionVariable;
load eleven_behav_OptionVariable;


% |-------------------------------------------------|
% |--- add customized options here, if there are ---|
% |-------------------------------------------------|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_behav_set_OptionVariable.m. 
%       2. modify here as needs
%       3. run eleven_behav_set_OptionVariable_customize here (make sure in the current analysis directory)

% --- settings 


% --- save
save eleven_behav_OptionVariable_customize;

clear; % do not remove this
