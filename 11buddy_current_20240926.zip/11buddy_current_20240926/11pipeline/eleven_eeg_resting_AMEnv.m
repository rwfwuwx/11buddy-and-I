function eleven_eeg_resting_AMEnv
% eleven_eeg_resting_AMEnv
% Usage
%   eleven_eeg_resting_AMEnv
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2020-10-16 add amplitude envelope; 
%       change function name eleven_eeg_resting_filter to eleven_eeg_resting_AMEnve
%   2020-10-12 modify from eleven_eeg_pp and eleven_eeg_er_ersd

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|

%clear;
disp('resting AMEnv processing');

% load option variables
load eleven_eeg_OptionVariable_customize;

% --- input
load eeg_raw_pp;

% |--- processing loop by freq band ---|
freq_band_num = length(resting_freq_band_name);

for ii=1:freq_band_num
    % --- filter
    disp('  filter');
    %eeg_raw_tmp = mf_rawfilter(eeg_raw_pp,'IIR','band pass',resting_freq_band(ii,:),4,fs);
    eeg_raw_tmp = mf_rawfilter(eeg_raw_pp,'IIR','band pass',resting_freq_band(ii,:),4,fs); 
    
    disp('  amplitude envelope');
    eeg_raw_tmp = mf_rawAMEnv(eeg_raw_tmp);
    
    %--- output
    output_data_name = ['eeg_resting_AMEnv' '_' resting_freq_band_name{ii}];
    eval(sprintf('%s = eeg_raw_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    % --- clear
    eval(sprintf('clear %s;',output_data_name));
end

%clear;
