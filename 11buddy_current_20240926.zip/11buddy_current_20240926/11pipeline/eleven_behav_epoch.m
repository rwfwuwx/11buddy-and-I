function eleven_behav_epoch
% eleven_behav_epoch
% Usage
%   eleven_behav_epoch
% external varialbe (add later)
%  -- input
%  -- option
%  -- output
%
% Update history
%   2024-04-06 initial version, modify from eleven_eeg_er_epoch.m

% |-------------------------|
% |---------- epoch --------|
% |-------------------------|

%disp('epoch processing');

% --- load exp variables and option variables
load eleven_behav_OptionVariable_customize;

load cond_name;
load stim_to_response_list;

load sequence_num;

% --- input
% behav data after post-processing
load behav_raw_postP_stim;
load behav_raw_postP_resp;

% stim-resp maping related (like to ecd of eeg)
load stim_resp_maping_assign;
load response_tobe;
if stim_resp_maping_assign==1
    response_tobe_thisSbj = response_tobe{1};
end
if stim_resp_maping_assign==2
    response_tobe_thisSbj = response_tobe{2};
end

% ---- arrange raw data according to sequence, i.e., data structure stim/response*sequence_num
%   Note, this is a common data structure, no matter sequence_num ==1(default) or >1
%   Note, if varying sequence, use sequence_length directly. handle later

% raw data is 2d, thus use the 3rd dimention to represent sequence_num
sequence_length = size(behav_raw_postP_stim,1)/sequence_num;

tmp_size = [sequence_length,size(behav_raw_postP_stim,2),sequence_num];
behav_raw_postP_stim_seq = zeros(tmp_size);
behav_raw_postP_resp_seq = zeros(tmp_size);
%   plus response_tobe, which is 1d->2d
response_tobe_thisSbj_seq = zeros(sequence_length,sequence_num);

% 2d raw data -> 3d
for ii=1:sequence_num
    tmp_time_points = (sequence_length*(ii-1) + 1):(sequence_length*ii);
    behav_raw_postP_stim_seq(:,:,ii) = behav_raw_postP_stim(tmp_time_points,:);
    behav_raw_postP_resp_seq(:,:,ii) = behav_raw_postP_resp(tmp_time_points,:);
    response_tobe_thisSbj_seq(:,ii) = response_tobe_thisSbj(tmp_time_points);
end

% |--- processing loop by condition ---|
cond_num = length(cond_name);

for ii=1:cond_num
    % --- epoch
    %    disp('  epoch');
    
    %- get data of current cond
    %   note, from now on, no need keep explicit ref to stim_sequence,
    %       i.e., the length is that of each cond, not the whole stim_sequence anymore
    
    current_stim = stim_to_response_list(ii);
    % assume same number of a cond in all sequences
    current_stim_num_in_sequence = length(find(behav_raw_postP_stim_seq(:,1,1)==current_stim));
    
    behav_raw_postP_stim_seq_current = zeros(current_stim_num_in_sequence,size(behav_raw_postP_stim,2),sequence_num);
    behav_raw_postP_resp_seq_current = zeros(current_stim_num_in_sequence,size(behav_raw_postP_stim,2),sequence_num);
    response_tobe_thisSbj_seq_current = zeros(current_stim_num_in_sequence,sequence_num);
    
    for jj=1:sequence_num
        index_current_stim = find(behav_raw_postP_stim_seq(:,1,jj)==current_stim);
        behav_raw_postP_stim_seq_current(:,:,jj) = behav_raw_postP_stim_seq(index_current_stim,:,jj);
        behav_raw_postP_resp_seq_current(:,:,jj) = behav_raw_postP_resp_seq(index_current_stim,:,jj);
        response_tobe_thisSbj_seq_current(:,jj) = response_tobe_thisSbj_seq(index_current_stim,jj);
    end

    %- get time sequence (TS)
    behav_epo_stim_tmp = squeeze(behav_raw_postP_stim_seq_current(:,1,:));
    behav_epo_stimTime_tmp = squeeze(behav_raw_postP_stim_seq_current(:,2,:));
    
    behav_epo_resp_tmp = squeeze(behav_raw_postP_resp_seq_current(:,1,:));
    behav_epo_respTime_tmp = squeeze(behav_raw_postP_resp_seq_current(:,2,:));
    
    behav_epo_respTobe_tmp = response_tobe_thisSbj_seq_current;
    
    % --- output
    output_data_name = ['behav_epo_stim' '_' cond_name{ii}];
    eval(sprintf('%s = behav_epo_stim_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['behav_epo_stimTime' '_' cond_name{ii}];
    eval(sprintf('%s = behav_epo_stimTime_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['behav_epo_resp' '_' cond_name{ii}];
    eval(sprintf('%s = behav_epo_resp_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['behav_epo_respTime' '_' cond_name{ii}];
    eval(sprintf('%s = behav_epo_respTime_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    output_data_name = ['behav_epo_respTobe' '_' cond_name{ii}];
    eval(sprintf('%s = behav_epo_respTobe_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
end

