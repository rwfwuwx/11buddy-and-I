function andy_autojob_ppNormal
% Usage andy_autojob_ppNormal
%
% todo
%   
% update history
%   2023-05-23 
%       updates incorporating seeg
%       other minor optimization
%   2021-12-13 add backup of eeg_raw_pp_backup_ppNormal.mat
%   2020-12-11
%       simplify get exp time setting
%       remove switch of pp. i.e., default run it.
%       !!! done "a final version in this update", and, script -> func
%   2020-12-08~09
%       --- handle geting exp_time according to eeg_analyze_type
%           !!! Note, ssep_sequence_time,or resting_time other than 5 min. set outside by GLAutojob
%       --- !!! setting, i.e., eleven_eeg_set_OptionVariable_customize.m, now run independently and automatically.
%           if need customize, do it as a GLAutojob.
%           if run2 needs change option, no need, and doesn't matter here.
%               what is need here, i.e., in preprocessing, is just eeg_analyze_type
%       --- template fun -> func
%       --- eeg_analyze_type update
%       1. old type list
%           11 resting_eeg; 12 er_eeg; 13 sr_eeg; these are for scalp eeg
%           21 resting_seeg; 22 er_seeg; 23 sr_seeg; these are for seeg
%       -> new type list
%           11 resting_eeg; 12 er_eeg; 13 ssep_eeg; 14 sr_eeg; these are for scalp eeg
%           21 resting_seeg; 22 er_seeg; 23 ssep_eeg; 24 sr_eeg; these are for seeg
%       2. use 'eeg_analyze_type_list_(studyName).txt'
%           strictly according to each line of 'analysis_dirTree_eeg_run2_(studyName).txt', set for each line.
%       --- remove exp setting, to autojob2
%       --- remove check trigger and produce eeg_ecd, to autojob2
%       --- remove design_type
%   2020-12 
%       script-> template func
%       incorporate into the updated CNAutojob frame work.
%   2020-05-17 update
%	2020-12-09 ShengProject -> ProfLijingrongGruop
%   2020-11-13
%       add produce eeg_raw_pp.set
%   2019 initial version, used in multiple projects. 


%--- set andy option ---
disp('set andy setting');

% now eleven_eeg_set_OptionVariable_customize runs automatically from 11pipiline.
%   first delete old version of eleven_eeg_set_OptionVariable_customize.m from the current directory, if there is.
current_dir=pwd;
if exist([current_dir '\' 'eleven_eeg_set_OptionVariable_customize.m'],'file')
    delete eleven_eeg_set_OptionVariable_customize.m;
%    delete eleven_eeg_OptionVariable.mat;
%    delete eleven_eeg_OptionVariable_customize.mat;
end


% somehow, when a file is just deleted from the current dir, matlab won't search the corresponding command in path. try run, works? 
%eleven_eeg_set_OptionVariable_customize;
run('eleven_eeg_set_OptionVariable_customize.m');

disp('set andy setting, done.');

%--- load andy option ---
load eeg_type;
load eeg_analyze_type;
load eleven_eeg_OptionVariable_customize;


%--- get exp time ---
if eeg_type == 1
    if import_file_type == 1
        file_type_suffix = '.bdf';
    end
    if import_file_type == 211 || import_file_type == 212
        file_type_suffix = '.mff';
    end
    eeg_file_name = ['eeg_raw' file_type_suffix];
    
    exp_time = eleven_eeg_get_expTime(eeg_file_name);
    
    save exp_time exp_time;
end

% --- import ---
% Note, ignore possible warnings when reading seeg file
eleven_eeg_import;


% --- pre-processing ---
eleven_eeg_pp;


% ---eeg_raw_pp.mat -> eeg_raw_pp.set ---
%   for followig eeglab handling
if eeg_type == 1
    load eeg_raw_pp;
    
    EEG = pop_loadset('eeg_raw.set');
    EEG.data = eeg_raw_pp';
    EEG = eeg_checkset(EEG);
    
    EEG = pop_saveset(EEG,'eeg_raw_pp.set',pwd);
end

% further backup eeg_raw_pp in case required later
copyfile('eeg_raw_pp.mat','eeg_raw_pp_backup_ppNormal.mat');



