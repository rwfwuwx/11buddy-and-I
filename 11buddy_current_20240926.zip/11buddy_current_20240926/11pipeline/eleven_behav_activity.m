function eleven_behav_activity
% eleven_behav_activity
% Usage
%   eleven_behav_activity
% external varialbe (add later)
%  -- input
%  -- option
%  -- output
%
% Note
%   # simple metric is also included. Step 4 can load directly.
%   for complex metric, to be clear in logic and work flow, can calculate in Step 4 as usual.
%   # add as needs, further TS/Metric, and behav_analyze_type

% Refenrece
%   autocorr.m - from Economerics Toolbox of Matlab. Copyright 1999-2010 The MathWorks, Inc. 
%   fisherZ - 20080103, Thomas Zoeller (tzo@gmx.de)
%
% Update history
%   2024-07-08
%       add metric : meanVar_circ
%   2024-07-01
%       add metric the number of trials passing rtest
%   2024-06-18 
%       add linear stability 
%       add handling of invalid taps for asychrony sequence: removing nan or interpolating 
%   2024-06-13 add modeling 
%   2024-05-30 fix bugs of conducting rtest for empty sequence
%   2024-05-21 add citation for autocorr, fisherZ
%   2024-05-15 
%       fix bug for calculating metrics when rejecting some invalid trials
%       fix bug for averaging data with nan  
%   2024-05-09 add calculate reject metrics
%   2024-04-19 add activity calculation for behav_analyze_type == 2 % i.e., timingSyncTap
%   2024-04-06 initial version, modify from eleven_eeg_er_erp.m

% |-------------------------|
% |---------- activity  --------|
% |-------------------------|

%disp('activity processing');

% --- load option variables
load eleven_behav_OptionVariable_customize;

load behav_analyze_type;

load cond_name;

% |--- processing loop by condition ---|
cond_num = length(cond_name);

for ii=1:cond_num
    % --- input
    % epo data.
    %   these are common, regardless of behav_analyze_type
    input_data_name = ['behav_epo_respTobe' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('behav_epo_respTobe_tmp = %s;',input_data_name));
    
    input_data_name = ['behav_epo_resp' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('behav_epo_resp_tmp = %s;',input_data_name));
    
    input_data_name = ['behav_epo_stimTime' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('behav_epo_stimTime_tmp = %s;',input_data_name));
    
    input_data_name = ['behav_epo_respTime' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('behav_epo_respTime_tmp = %s;',input_data_name));
    
    %--- add here rejection metric of epo TS, if required
    
    if behav_analyze_type == 1 % i.e., standard
        % |---obtain time sequences (TS)---|
        % correct
        behav_TS_correct_tmp = behav_epo_respTobe_tmp == behav_epo_resp_tmp;
        % RT
        behav_TS_RT_tmp = behav_epo_respTime_tmp - behav_epo_stimTime_tmp;
        
        %--- add here rejection metric of activity TS, if required
        
        % |---obtain simple metric---|
        
        %--- obtain further rejection here, e.g. activity_outlier_SD
        
        % correctRate (not convert to %)
        %   note: for metric, no need to keep the sequence structure.
        %       i.e., one metric for one sbj.
        %   if each metric of each sequence is required, get by TS in andy 4 or ada
        %   This apply to all following metrics.
        behav_metric_correctRate_tmp = mean( nansum(behav_TS_correct_tmp,1)/size(behav_TS_correct_tmp,1) );
        % RT
        behav_metric_RT_tmp = mean( nanmean(behav_TS_RT_tmp,1) );
        
        
        % --- output
        % TS
        output_data_name = ['behav_TS_correct' '_' cond_name{ii}];
        eval(sprintf('%s = behav_TS_correct_tmp;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
        
        output_data_name = ['behav_TS_RT' '_' cond_name{ii}];
        eval(sprintf('%s = behav_TS_RT_tmp;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
        
        % metric
        output_data_name = ['behav_metric_correctRate' '_' cond_name{ii}];
        eval(sprintf('%s = behav_metric_correctRate_tmp;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
        
        output_data_name = ['behav_metric_RT' '_' cond_name{ii}];
        eval(sprintf('%s = behav_metric_RT_tmp;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
    end
    
    if behav_analyze_type == 2 % i.e., timingSyncTap
        % |---obtain time sequences (TS)---|
        load cond_IOI;
        load sequence_num
        load stim_sequence;
        event_num=length(stim_sequence)/sequence_num;
                
        % asyn (asynchrony)
        behav_TS_asyn_tmp = behav_epo_respTime_tmp - behav_epo_stimTime_tmp;
        
            % handling nan in asyn sequence 
            behav_TS_asyn_nonan_tmp=cell(1,sequence_num);
            
            if removeNan_or_interpolation_AsynSeq==1 % remove nan
                tmp_seq = behav_TS_asyn_tmp(6:end,:);
                for ii_circ=1:sequence_num
                    tmp_TS=tmp_seq(:,ii_circ);
                    tmp_TS(isnan(tmp_TS))=[]; % need exculding nan to calculate
                    behav_TS_asyn_nonan_tmp{ii_circ}=tmp_TS;
                end
            end
            
            if removeNan_or_interpolation_AsynSeq==2 % interpolation
                tmp_asyn=zeros(event_num,1);
                for ii_iti=1:sequence_num
                    for jj=1:event_num
                        if isnan(behav_TS_asyn_tmp(jj,ii_iti))==0
                            tmp_asyn(jj)=behav_TS_asyn_tmp(jj,ii_iti);
                        else
                            % get local_averaged_nma
                            % find the nearest 6 asyn (-3step+3step)
                            if jj>=4&&jj<=event_num-3
                                LOCAL_NMA_POOL=[behav_TS_asyn_tmp(jj-3,ii_iti);behav_TS_asyn_tmp(jj-2,ii_iti);behav_TS_asyn_tmp(jj-1,ii_iti);...
                                    behav_TS_asyn_tmp(jj+1,ii_iti);behav_TS_asyn_tmp(jj+2,ii_iti);behav_TS_asyn_tmp(jj+3,ii_iti)];
                                local_averaged_nma= nanmean(LOCAL_NMA_POOL);
                            end
                            
                            if jj<4
                                LOCAL_NMA_POOL=[behav_TS_asyn_tmp(jj+1,ii_iti);behav_TS_asyn_tmp(jj+2,ii_iti);behav_TS_asyn_tmp(jj+3,ii_iti);...
                                    behav_TS_asyn_tmp(jj+4,ii_iti);behav_TS_asyn_tmp(jj+5,ii_iti);behav_TS_asyn_tmp(jj+6,ii_iti)];
                                local_averaged_nma= nanmean(LOCAL_NMA_POOL);
                            end
                            
                            if jj>event_num-3
                                LOCAL_NMA_POOL=[behav_TS_asyn_tmp(jj-1,ii_iti);behav_TS_asyn_tmp(jj-2,ii_iti);behav_TS_asyn_tmp(jj-3,ii_iti);...
                                    behav_TS_asyn_tmp(jj-4,ii_iti);behav_TS_asyn_tmp(jj-5,ii_iti);behav_TS_asyn_tmp(jj-6,ii_iti)];
                                local_averaged_nma= nanmean(LOCAL_NMA_POOL);
                            end
                            
                            tmp_asyn(jj)=local_averaged_nma;
                            
                        end
                    end
                    
                    behav_TS_asyn_nonan_tmp{ii_iti}=tmp_asyn(6:end);
                end
                
            end
        
            
        % asyn_circ
        radx=1000*(180/((cond_IOI*1000)/2));
        tmpdata=behav_TS_asyn_tmp.*radx;
        behav_TS_asyn_circ_tmp=circ_ang2rad(tmpdata);
        
        behav_TS_asyn_circ_nonan_tmp=cell(1,sequence_num);
        for ii_c=1:sequence_num
            tmpdata=behav_TS_asyn_nonan_tmp{ii_c}.*radx;
            behav_TS_asyn_circ_nonan_tmp{ii_c}=circ_ang2rad(tmpdata);
        end
        
        
        % ITI (Encapsulate into a func?)
        %input: event_num sequence_num
        %input data structures: behav_epo_stimTime behav_epo_respTime behav_TS_asyn
        
        taptime=zeros(event_num,1);
        behav_TS_ITI_tmp=zeros(event_num-1,sequence_num);
        for ii_iti=1:sequence_num
            for jj=1:event_num
                if isnan(behav_epo_respTime_tmp(jj,ii_iti))==0
                    taptime(jj)=behav_epo_respTime_tmp(jj,ii_iti);
                else
                    % get local_averaged_nma
                    % find the nearest 6 asyn (-3step+3step)
                    if jj>=4&&jj<=event_num-3
                        LOCAL_NMA_POOL=[behav_TS_asyn_tmp(jj-3,ii_iti);behav_TS_asyn_tmp(jj-2,ii_iti);behav_TS_asyn_tmp(jj-1,ii_iti);...
                            behav_TS_asyn_tmp(jj+1,ii_iti);behav_TS_asyn_tmp(jj+2,ii_iti);behav_TS_asyn_tmp(jj+3,ii_iti)];
                        local_averaged_nma= nanmean(LOCAL_NMA_POOL);
                    end
                    
                    if jj<4
                        LOCAL_NMA_POOL=[behav_TS_asyn_tmp(jj+1,ii_iti);behav_TS_asyn_tmp(jj+2,ii_iti);behav_TS_asyn_tmp(jj+3,ii_iti);...
                            behav_TS_asyn_tmp(jj+4,ii_iti);behav_TS_asyn_tmp(jj+5,ii_iti);behav_TS_asyn_tmp(jj+6,ii_iti)];
                        local_averaged_nma= nanmean(LOCAL_NMA_POOL);
                    end
                    
                    if jj>event_num-3
                        LOCAL_NMA_POOL=[behav_TS_asyn_tmp(jj-1,ii_iti);behav_TS_asyn_tmp(jj-2,ii_iti);behav_TS_asyn_tmp(jj-3,ii_iti);...
                            behav_TS_asyn_tmp(jj-4,ii_iti);behav_TS_asyn_tmp(jj-5,ii_iti);behav_TS_asyn_tmp(jj-6,ii_iti)];
                        local_averaged_nma= nanmean(LOCAL_NMA_POOL);
                    end
                    
                    taptime(jj)=behav_epo_stimTime_tmp(jj,ii_iti)+local_averaged_nma;
                    
                end
            end
            
            behav_TS_ITI_tmp(:,ii_iti)=diff(taptime);
        end
        
        
        %--- add here rejection metric of activity TS, if required
        
        % missing taps
        behav_metric_missingTap=zeros(1,sequence_num);
        behav_Index_missingTap_aboveThreshold_tmp=zeros(1,sequence_num);
        tmp=behav_epo_respTime_tmp(6:end,:);
        for ii_circ=1:sequence_num
            tmp_TS=tmp(:,ii_circ);
            behav_metric_missingTap(ii_circ)=length(find(isnan(tmp_TS)==1)); % need exculding nan to calculate
            missingTap_percentage=behav_metric_missingTap(ii_circ)/length(tmp_TS);
            
            if missingTap_percentage> missingTap_percentage_threshold
                behav_Index_missingTap_aboveThreshold_tmp(ii_circ)=1;
            end
        end
        behav_metric_mean_missingTap_tmp=mean(behav_metric_missingTap);
        if length(find(behav_Index_missingTap_aboveThreshold_tmp==0))< valid_sequence_threshold
            behav_Index_missingTap_invalidTSaboveThrsh_tmp=1;
        else
            behav_Index_missingTap_invalidTSaboveThrsh_tmp=0;
        end
        
        % rtest
        behav_metric_rtestPvalue_tmp=zeros(1,sequence_num);
        for ii_circ=1:sequence_num
            tmp=behav_TS_asyn_circ_nonan_tmp{ii_circ};
            if isempty(tmp) || any(tmp)==0
                behav_metric_rtestPvalue_tmp(ii_circ)=nan;
            else
                behav_metric_rtestPvalue_tmp(ii_circ)=circ_rtest(tmp);
            end
        end
            % select TS passing rtest
        if is_reject_not_passRtest==1
            passRtest_seqIndex=find(behav_metric_rtestPvalue_tmp<0.05);
            
            behav_TS_asyn_tmp=behav_TS_asyn_tmp(:,passRtest_seqIndex);
            behav_TS_asyn_nonan_tmp=behav_TS_asyn_nonan_tmp(:,passRtest_seqIndex);
            behav_TS_asyn_circ_tmp=behav_TS_asyn_circ_tmp(:,passRtest_seqIndex);
            behav_TS_asyn_circ_nonan_tmp=behav_TS_asyn_circ_nonan_tmp(passRtest_seqIndex);
            behav_TS_ITI_tmp=behav_TS_ITI_tmp(:,passRtest_seqIndex);
        end
        passRtest_seqIndex=find(behav_metric_rtestPvalue_tmp<0.05);
        behav_metric_trialPassRtest_num_tmp=length(passRtest_seqIndex);
        if behav_metric_trialPassRtest_num_tmp < valid_sequence_threshold
            behav_Index_rtest_invalidTSaboveThrsh_tmp=1;
        else
            behav_Index_rtest_invalidTSaboveThrsh_tmp=0;
        end
        
        
        % |---obtain simple metric---|
        
        %--- obtain further rejection here, e.g. activity_outlier_SD
        
        % meanAsyn
        %   Note,consider handle the first five, here.
        %       (i.e., for local needs, it is not necessary to change 'high-level' data structure)
        tmp_asynLinear=zeros(1,length(behav_TS_asyn_nonan_tmp));
        for ii_circ=1:length(behav_TS_asyn_nonan_tmp)
            tmp_asynLinear(ii_circ)=mean(behav_TS_asyn_nonan_tmp{ii_circ},'omitnan');
        end
        behav_metric_meanAsyn_tmp = mean(tmp_asynLinear,'omitnan');
        
        % meanAsynSd
        tmp_asyn_sd=zeros(1,length(behav_TS_asyn_nonan_tmp));
        for ii_circ=1:length(behav_TS_asyn_nonan_tmp)
            tmp_asyn_sd(ii_circ)=std(behav_TS_asyn_nonan_tmp{ii_circ},'omitnan');
        end
        behav_metric_meanAsynSd_tmp = mean(tmp_asyn_sd,'omitnan');
        
        % meanAsyn_circ
        tmp_asynCirc=zeros(1,length(behav_TS_asyn_circ_nonan_tmp));
        for ii_circ=1:length(behav_TS_asyn_circ_nonan_tmp)
            tmp_asynCirc(ii_circ)=circ_mean(behav_TS_asyn_circ_nonan_tmp{ii_circ});
        end
        behav_metric_meanAsyn_circ_tmp = circ_mean(tmp_asynCirc,[],2);
        
        % meanVar_circ
        tmp_VarCirc=zeros(1,length(behav_TS_asyn_circ_nonan_tmp));
        for ii_circ=1:length(behav_TS_asyn_circ_nonan_tmp)
            tmp_VarCirc(ii_circ)=circ_var(behav_TS_asyn_circ_nonan_tmp{ii_circ});
        end
        behav_metric_meanVar_circ_tmp = mean(tmp_VarCirc,'omitnan');
        
        % meanStab_circ
        tmp_stabCirc=zeros(1,length(behav_TS_asyn_circ_nonan_tmp));
        for ii_circ=1:length(behav_TS_asyn_circ_nonan_tmp)
            tmp_stabCirc(ii_circ)=1-circ_var(behav_TS_asyn_circ_nonan_tmp{ii_circ});
        end
        behav_metric_meanStab_circ_tmp = mean(tmp_stabCirc,'omitnan');
        
        % autocorrelation lag-1
        tmp = behav_TS_ITI_tmp(6:end,:);
        tmp_ac1=zeros(1,size(behav_TS_ITI_tmp,2));
        for ii_ac1=1:size(behav_TS_ITI_tmp,2)
            tmp_tmp_ac=autocorr(tmp(:,ii_ac1));
            tmp_ac1(ii_ac1)=fisherz(tmp_tmp_ac(2));
        end
        behav_metric_meanAC1_tmp = mean(tmp_ac1,'omitnan');
        
        % modeling
        tmp_Asyn=behav_TS_asyn_nonan_tmp;
        tmp_IRI=behav_TS_ITI_tmp(6:end,:);
        tmp_alpha=zeros(1,length(behav_TS_asyn_nonan_tmp));
        tmp_T_sd=zeros(1,length(behav_TS_asyn_nonan_tmp));
        tmp_M_sd=zeros(1,length(behav_TS_asyn_nonan_tmp));
        behav_metric_meanAlpha_tmp = [];
        behav_metric_meanT_sd_tmp = [];
        behav_metric_meanM_sd_tmp = [];
        
        if removeNan_or_interpolation_AsynSeq==2
            for ii_ml=1:length(behav_TS_asyn_nonan_tmp)
                tmp_tmp_Asyn=tmp_Asyn{ii_ml};
                tmp_tmp_IRI=tmp_IRI(:,ii_ml);
                if any(tmp_tmp_Asyn)==0 || any(tmp_tmp_IRI)==0
                    tmp_alpha(ii_ml)=nan;
                    tmp_T_sd(ii_ml)=nan;
                    tmp_M_sd(ii_ml)=nan;
                else
                    [tmp_alpha(ii_ml),tmp_T_sd(ii_ml),tmp_M_sd(ii_ml)] = eleven_timingSyncTap_linearModel_paramESM_bGLS(1,tmp_tmp_IRI,tmp_tmp_Asyn,[]);
                end
            end
            behav_metric_meanAlpha_tmp = mean(tmp_alpha,'omitnan');
            behav_metric_meanT_sd_tmp = mean(tmp_T_sd,'omitnan');
            behav_metric_meanM_sd_tmp = mean(tmp_M_sd,'omitnan');
        end
        
        % --- output
        if is_reject_not_passRtest==0
            % TS
            output_data_name = ['behav_TS_asyn' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_TS_asyn_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_TS_asyn_circ' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_TS_asyn_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_TS_ITI' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_TS_ITI_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            % metric
            output_data_name = ['behav_metric_meanAsyn' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanAsyn_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAsynSd' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanAsynSd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAsyn_circ' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanAsyn_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanVar_circ' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanVar_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanStab_circ' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanStab_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAC1' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanAC1_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_rtestPvalue' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_rtestPvalue_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAlpha' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanAlpha_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanT_sd' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanT_sd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanM_sd' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanM_sd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            % reject metric
            output_data_name = ['behav_metric_mean_missingTap' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_mean_missingTap_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_trialPassRtest_num' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_trialPassRtest_num_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
                        
            output_data_name = ['behav_Index_missingTap_aboveThreshold' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_Index_missingTap_aboveThreshold_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_Index_missingTap_invalidTSaboveThrsh' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_Index_missingTap_invalidTSaboveThrsh_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_Index_rtest_invalidTSaboveThrsh' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_Index_rtest_invalidTSaboveThrsh_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
        end
        
        if is_reject_not_passRtest==1
            % TS
            output_data_name = ['behav_TS_asyn_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_TS_asyn_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_TS_asyn_circ_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_TS_asyn_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_TS_ITI_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_TS_ITI_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            % metric
            output_data_name = ['behav_metric_meanAsyn_ss' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanAsyn_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAsynSd_ss' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanAsynSd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAsyn_circ_ss' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanAsyn_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanVar_circ_ss' '_' cond_name{ii}];
            eval(sprintf('%s = behav_metric_meanVar_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanStab_circ_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanStab_circ_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanAC1_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanAC1_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
                        
            output_data_name = ['behav_metric_meanAlpha_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanAlpha_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanT_sd_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanT_sd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['behav_metric_meanM_sd_ss' '_' cond_name{ii}];
            eval(sprintf('%s =  behav_metric_meanM_sd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
        end
    end
    
end

