function andy_autojob_produce_componentFeature
%
%Todo
%
% Description
%   logic/framework.
%       follow the global framework, as andy_image: 
%           in a dir tree, read parameters, and do the job.
% Note:
%   eye chs are removed.
% Update history
%   2024-07-09 add extracting amplitude of target frequency of ssep, defined in eleven_eeg_set_OptionVariable_cfe.m, same day
%       note: generalize later, 
%           optimize code (see eleven_openFunc_eeg_TimeFreq_to_datapoint)
%   2022-08-11
%       smooth point 10->50
%       add AlphaPeak_is_filter
%           see dingding eeg/backup/alphaPeak_detection_test_20220812_impotant.mlx
%       remove AlphaPeak_is_detrend
%   2022-08-11
%       add AlphaPeak_is_detrend
%   2022-08-02/11
%       set boundy to 0.1 Hz
%       handling potential risk that alphaPeak_latency too close to the freq band boundary,
%       	by set such alphaPeak_latency nan
%        %   better let ada do this 'nan issue'. let andy do it
%   2022-06-20
%       add alphaPeak_amplitude, alphaPeak_latency, alphaPeak_snr;
%       refine removing eye ch, as needs.
%       add time series variance
%           based on andy_autojob_produce_ResultIndex_CollabProfLijingrongGroup.m
%   2022-06-19
%       make sure data are restricted by reref_ch.
%       relative AM
%       refine freq - freq point conversion -> littel func
%       define freq band automatically by resting_freq_band
%       add cm, simply rename.
%       update the logic/framework, as andy_image.
%       template->function
%   2021-09-30 
%       H:\soft\11buddy\11buddy_current\11job\CollabProfLijingrongGroup andy_autojob_produce_feature_CollabProfLJRGroup.m
%       ->H:\soft\11buddy\11buddy_current\11pipeline andy_autojob_produce_template.m
%   2021-06-18 modify from andy_autojob_produce_ResultIndex_CollabProfLJRGroup.m
% todo:
%


% |------------------------------------------|
% |------ load options, set options ---------|
% |------------------------------------------|

% --- (same as andy_image)
load fs;
time_step = 1/fs;

load eleven_eeg_OptionVariable_customize;

load eeg_analyze_type;

%--- cfe specific
eleven_eeg_set_OptionVariable_cfe_customize;
load eleven_eeg_OptionVariable_cfe_customize;


% |------------------------------------------|
% |------ load ch position and ch labe ------|
% |------------------------------------------|
% add if need. as in andy_image


% |----------------------------------------------|
% |------------------  resting ------------------|
% |----------------------------------------------|
if eeg_analyze_type == 1
    
    % componentFeature_list
    %   !!! make sure this is the same as in eleven_eeg_set_OptionVariable_cfe.m
%{
    componentFeature_list = { ...
        'AM_theta'; 'AM_alpha'; 'AM_beta'; 'AM_lowGamma'; ...
        'relaAM_theta'; 'relaAM_alpha'; 'relaAM_beta'; 'relaAM_lowGamma'; ...
        'AlphaPeak_AM'; 'AlphaPeak_latency'; 'AlphaPeak_snr'; ...
        'SD_raw'; 'CV_theta'; 'CV_alpha'; 'CV_beta'; 'CV_lowGamma'; ...
        'cm_raw'; 'cm_theta'; 'cm_alpha'; 'cm_beta'; 'cm_lowGamma'; ...
        };
%}
    
    % is source (as andy_image)
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        tmp_is_source =1;
    else
        tmp_is_source =0;
    end
    
    % |--- spectrum: AM ---|
    % spectrum band amplitude (AM). 
    %   format: ch*1
    
    %--- load spec data
    load eeg_resting_spec_am_norm;
    
    % remove eye ch, as need
    %   !! currently, only biosemi & run2
    if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
        data = eeg_resting_spec_am_norm(reref_ch,:);
    else
        data = eeg_resting_spec_am_norm;
    end
    
    % get freq and freq resolution (see andy_image)
    load eeg_resting_spec_freq;
    freq = eeg_resting_spec_freq; % all freq
    freq_resolution = eleven_get_freqResolution(fs,freq); 
    
    
    % theta
    %   note, band ranges are in resting_freq_band, set in seting file
    tmp_freq_band = resting_freq_band(1,:);
    %   convert freq band in frequency to sample point (see andy_image)
    tmp_freq_band_point = eleven_freq2point(tmp_freq_band,freq_resolution);
        
    AM_theta = data(:,[tmp_freq_band_point(1):tmp_freq_band_point(2)]);
    AM_theta = mean(AM_theta,2);
    save AM_theta AM_theta;
    
    % alpha
    tmp_freq_band = resting_freq_band(2,:);
    %   convert freq band in frequency to sample point (see andy_image)
    tmp_freq_band_point = eleven_freq2point(tmp_freq_band,freq_resolution);
    
    AM_alpha = data(:,[tmp_freq_band_point(1):tmp_freq_band_point(2)]);
    AM_alpha = mean(AM_alpha,2);
    save AM_alpha AM_alpha;
    
    % beta
    tmp_freq_band = resting_freq_band(3,:);
    %   convert freq band in frequency to sample point (see andy_image)
    tmp_freq_band_point = eleven_freq2point(tmp_freq_band,freq_resolution);
    
    AM_beta = data(:,[tmp_freq_band_point(1):tmp_freq_band_point(2)]);
    AM_beta = mean(AM_beta,2);
    save AM_beta AM_beta;
    
    % lowGamma
    tmp_freq_band = resting_freq_band(4,:);
    %   convert freq band in frequency to sample point (see andy_image)
    tmp_freq_band_point = eleven_freq2point(tmp_freq_band,freq_resolution);
    
    AM_lowGamma = data(:,[tmp_freq_band_point(1):tmp_freq_band_point(2)]);
    AM_lowGamma = mean(AM_lowGamma,2);
    save AM_lowGamma AM_lowGamma;
    
    % highGamma
    %   add highGamma later, depending on fs and lowpass in pp
    
    
    
    % |--- spectrum: relaAM ---|
    % relative spectrum band amplitude (relaAM). 
    %   format: ch*1
    
    % theta
    relaAM_theta = AM_theta ./ ((AM_theta + AM_alpha + AM_beta + AM_lowGamma)/4);
    save relaAM_theta relaAM_theta;
    % alpha
    relaAM_alpha = AM_alpha ./ ((AM_theta + AM_alpha + AM_beta + AM_lowGamma)/4);
    save relaAM_alpha relaAM_alpha;
    % beta
    relaAM_beta = AM_beta ./ ((AM_theta + AM_alpha + AM_beta + AM_lowGamma)/4);
    save relaAM_beta relaAM_beta;
    % lowGamma
    relaAM_lowGamma = AM_lowGamma ./ ((AM_theta + AM_alpha + AM_beta + AM_lowGamma)/4);
    save relaAM_lowGamma relaAM_lowGamma;
    
    
    
    % |--- spectrum: AlphaPeak ---|
    % AlphaPeak_AM; AlphaPeak_latency; AlphaPeak_snr (signal noise ratio)
    
    % option has been load; data has been load; and freq resolution has been obtained.
    
    % intialization
    [m,n] = size(data);
    AlphaPeak_AM = zeros(m,1);
    AlphaPeak_latency = zeros(m,1);
    AlphaPeak_snr = zeros(m,1);
    
    % set freq band, and corresponding freq sample point, and data
    alpha_freq_band = resting_freq_band(2,:);
    alpha_freq_band_point = eleven_freq2point(alpha_freq_band,freq_resolution);
    alpha_freq_band_points = [alpha_freq_band_point(1):alpha_freq_band_point(2)];
    
    peak_win_point_num = round(AlphaPeak_half_win/freq_resolution);
    peak_win_neigh_point_num = round(AlphaPeak_oneSide_neigh/freq_resolution);
    
    for ii = 1:m
        tmp_data = data(ii,:);
        % whether further smooth
        if AlphaPeak_is_smooth
            tmp_data = smooth(tmp_data, AlphaPeak_smooth_points);
        end
        
        %   Note, the filter data is only for latency.
        %       others, use non-filter data
        if AlphaPeak_is_filter
            tmp_data_backup = tmp_data;
            
            % cut to-be-filter data
            tmp_freq_cut_init = 3;
            tmp_freq_cut_end = 25;
            tmp_point_cut_init = round(tmp_freq_cut_init/freq_resolution);
            tmp_point_cut_end = round(tmp_freq_cut_end/freq_resolution);
            tmp_x=tmp_data(tmp_point_cut_init:tmp_point_cut_end);

            %filter
            tmp_x_filter = mf_rawfilter(tmp_x,'IIR','high pass',0.03,2,fs);
            
            % put to-be-filter data back to whole data
            tmp_data(tmp_point_cut_init:tmp_point_cut_end) = tmp_x_filter;
        end
        
        % get peak latency
        [peak,idx] = findpeaks(tmp_data(alpha_freq_band_points),'NPeaks',1,'SortStr','descend');
        
        if AlphaPeak_is_filter
            tmp_data = tmp_data_backup;
        end
        
        %[peak idx] = max(tmp_data);
        peak_latency_point = alpha_freq_band_point(1)-1 + idx;
        peak_latency_freq = peak_latency_point * freq_resolution; 
        AlphaPeak_latency(ii) =  peak_latency_freq;

        % get peak amplitude
        %peak_win_points = [peak_latency_point-round(peak_win_point_num/2):peak_latency_point+round(peak_win_point_num/2)];
        peak_win_points = [peak_latency_point-peak_win_point_num:peak_latency_point+peak_win_point_num];
        peak_amplitude = mean(tmp_data(peak_win_points));
        AlphaPeak_AM(ii) =  peak_amplitude;
        
        % calculate peak snr
        peak_win_neigh_points = [...
            (peak_win_points(1) - peak_win_neigh_point_num) : peak_win_points(1),...
            peak_win_points(2) : (peak_win_points(2) + peak_win_neigh_point_num)];
        peak_amplitude_neigh = mean(tmp_data(peak_win_neigh_points));
        peak_snr = peak_amplitude / peak_amplitude_neigh;
        AlphaPeak_snr(ii) =  peak_snr;
        
        % a control, see update history 2022-08-02/09
        %   better let ada do this 'nan issue'
        %
        %alpha_freq_band_boundary_control_point_num = 2; % totallly control for 3 freq points 
        %AFBB_freq = alpha_freq_band_boundary_control_point_num * freq_resolution;
        AFBB_freq = 0.1;
        if peak_latency_freq<=(alpha_freq_band(1)+AFBB_freq) || peak_latency_freq>=(alpha_freq_band(2)-AFBB_freq)
            AlphaPeak_latency(ii) =  nan;
            AlphaPeak_AM(ii) =  nan;
            peak_snr(ii) =  nan;
        end
        %
    end
    
    save AlphaPeak_latency AlphaPeak_latency;
    save AlphaPeak_AM AlphaPeak_AM;
    save AlphaPeak_snr AlphaPeak_snr;

    
    
    % |--- freq time series variance: SD/CV---|
    
    %--- raw
    load eeg_raw_pp;
    
    if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
        data = eeg_raw_pp(:,reref_ch);
    else
        data = eeg_raw_pp;
    end
    
    % cut required data, by removing the starting and ending padding time. (same below)
    data = data([resting_padding_points+1:size(data,1)-resting_padding_points-1],:); 
    
    SD_raw = std(data,0,1)';
    save SD_raw SD_raw;
    
    %--- theta
    load eeg_resting_AMEnv_theta;

    if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
        data = eeg_resting_AMEnv_theta(:,reref_ch);
    else
        data = eeg_resting_AMEnv_theta;
    end
    
    % cut required data, by removing the starting and ending padding time. (same below)
    data = data([resting_padding_points+1:size(data,1)-resting_padding_points-1],:); 
    
    CV_theta = abs( std(data,0,1) ./ mean(data,1) )';
    save CV_theta CV_theta;
    
    %--- alpha
    load eeg_resting_AMEnv_alpha;

    if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
        data = eeg_resting_AMEnv_alpha(:,reref_ch);
    else
        data = eeg_resting_AMEnv_alpha;
    end
    
    % cut required data, by removing the starting and ending padding time. (same below)
    data = data([resting_padding_points+1:size(data,1)-resting_padding_points-1],:); 
    
    CV_alpha = abs( std(data,0,1) ./ mean(data,1) )';
    save CV_alpha CV_alpha;
    
    %--- beta
    load eeg_resting_AMEnv_beta;

    if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
        data = eeg_resting_AMEnv_beta(:,reref_ch);
    else
        data = eeg_resting_AMEnv_beta;
    end
    
    % cut required data, by removing the starting and ending padding time. (same below)
    data = data([resting_padding_points+1:size(data,1)-resting_padding_points-1],:); 
    
    CV_beta = abs( std(data,0,1) ./ mean(data,1) )';
    save CV_beta CV_beta;
    
    %--- lowGamma
    load eeg_resting_AMEnv_lowGamma;

    if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
        data = eeg_resting_AMEnv_lowGamma(:,reref_ch);
    else
        data = eeg_resting_AMEnv_lowGamma;
    end
    
    % cut required data, by removing the starting and ending padding time. (same below)
    data = data([resting_padding_points+1:size(data,1)-resting_padding_points-1],:); 
    
    CV_lowGamma = abs( std(data,0,1) ./ mean(data,1) )';
    save CV_lowGamma CV_lowGamma;
    
    %--- highGamma
    %   add highGamma later, depending on fs and lowpass in pp
    
    
    
    % |--- freq time series connectivity: cm ---|
    % connectivity correlation matrix (cm). 
    %   format: ch*ch
    % Note, the cm feature is already produced, simply rename to standard name
    
    % raw
    load eeg_resting_connect_cm_coef_raw; cm_raw = eeg_resting_connect_cm_coef_raw; 
    save cm_raw cm_raw;
    % theta
    load eeg_resting_connect_cm_coef_theta; cm_theta = eeg_resting_connect_cm_coef_theta; 
    save cm_theta cm_theta;
    % alpha
    load eeg_resting_connect_cm_coef_alpha; cm_alpha = eeg_resting_connect_cm_coef_alpha; 
    save cm_alpha cm_alpha;
    % beta
    load eeg_resting_connect_cm_coef_beta; cm_beta = eeg_resting_connect_cm_coef_beta; 
    save cm_beta cm_beta;
    % lowGamma
    load eeg_resting_connect_cm_coef_lowGamma; cm_lowGamma = eeg_resting_connect_cm_coef_lowGamma; 
    save cm_lowGamma cm_lowGamma;
    % highGamma
    %   add highGamma later, depending on fs and lowpass in pp
    
end



% |------------------------------------------|
% |------------------ er srer ---------------|
% |------------------------------------------|

if eeg_analyze_type == 2 || eeg_analyze_type == 42
    % add later
    
    % |------------------------------------------|
    % |------------------  erp ------------------|
    % |------------------------------------------|
    
    % |------------------------------------------|
    % |------------------  tf -------------------|
    % |------------------------------------------|
end



% |----------------------------------------------|
% |----------------  ssep srssep ----------------|
% |----------------------------------------------|
if eeg_analyze_type == 3 || eeg_analyze_type == 43
    % 'input_target_freq' is set in eleven_eeg_set_OptionVariable_cfe_customize
    
     % is source (as andy_image)
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        tmp_is_source =1;
    else
        tmp_is_source =0;
    end
    
    %--- ssep amplitude of target frequency ---%
    load cond_name;
    cond_num = length(cond_name);
    
    input_freq_name = ['eeg_ssep_spec_freq' '_' cond_name{1}];
    eval(sprintf('load %s;',input_freq_name));
    eval(sprintf('freq = %s;',input_freq_name))
    
    for iicn=1:cond_num
        input_data_name = ['eeg_ssep_spec_am_norm' '_' cond_name{iicn}];
        eval(sprintf('load %s;',input_data_name));
        eval(sprintf('ssep_tmp = %s;',input_data_name));
        eval(sprintf('clear %s;',input_data_name));
        
        if import_file_type==1 && tmp_is_source ==0 % biosemi & run2
            data = ssep_tmp(reref_ch,:);
        else
            data = ssep_tmp;
        end
        
        % all conditions extracting amplitude of same freq
        if length(input_target_freq)==1
            freq_resolution = eleven_get_freqResolution(fs,freq);
            
            % 1st harmonics
            tmp_target_freq_point = eleven_freq2point(input_target_freq,freq_resolution);
            target_freqAM_tmp = data(:,tmp_target_freq_point);
            % 2nd harmonics
            tmp_target_freq_point = eleven_freq2point(2*input_target_freq,freq_resolution);
            target_freqAM_2nd_tmp = data(:,tmp_target_freq_point);
            % 3rd harmonics
            tmp_target_freq_point = eleven_freq2point(3*input_target_freq,freq_resolution);
            target_freqAM_3rd_tmp = data(:,tmp_target_freq_point);
            
            % save feature
            output_data_name = ['ssep_baseFreq_' cond_name{iicn}];
            eval(sprintf('%s = target_freqAM_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['ssep_2ndFreq_' cond_name{iicn}];
            eval(sprintf('%s = target_freqAM_2nd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
            
            output_data_name = ['ssep_3rdFreq_' cond_name{iicn}];
            eval(sprintf('%s = target_freqAM_3rd_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
        end
        
        % different conditions extracting amplitude of different freq correspondingly
        if length(input_target_freq)>1 && length(input_target_freq)==cond_num
            freq_resolution = eleven_get_freqResolution(fs,freq);
            
            tmp_target_freq_point = eleven_freq2point(input_target_freq(iicn),freq_resolution);
            target_freqAM_tmp = data(:,tmp_target_freq_point);
            
            % save feature
            output_data_name = ['ssep_baseFreq_' cond_name{iicn}];
            eval(sprintf('%s = target_freqAM_tmp;',output_data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
        end
    end
        
end



