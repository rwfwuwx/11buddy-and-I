function eleven_eeg_resultImage
% Usage
%   in a 'current directory', type
%       eleven_eeg_result_image
%       or, load andy_image; andy_image()
% Todo
%   --- many details to update
%   --- for ch
%       update ch256
% Update history
%   2024-06-04
%       add draw connectivity for high and low gamma
%   2024-04-24
%       add draw image for tfpl
%   2023-05-25
%       updates incorporating seeg
%       other minor optimization
%   2022-03-28
%       add back displaying cm
%   2022-03-01
%       add connectgram
%       add ch81 for 68 source
%       add egi 2d position
%   2022-02-28
%       other minor updates and corrections
%       add brodmann atlas info
%       add egi 3d ch position
%   2022-01-23 update freq range setting for spec.
%       the freq tipically is not integer, depending on fs. note the handling.
%   2022-01-xx decide is run3 and which atlas, by source_atlas: the name of the atlas of the current directory.
%   2022-01-14 set freq ranges for resting and ssep. add a varialbe is_source_level
%   2022-01-10 initial version starts run.
%   2022-01-05
%       script -> func, 'result_image.m'-> 'eleven_eeg_resultImage.m'
%           nickname andy_image:  load andy_image; andy_image()
%               (by andy_image = @eleven_eeg_resultImage; save andy_image andy_image;)
%       automatically, adaptively, image.
%           following 2021-10~12 automation updating, automatically image for different settings.
%   before 2022
%       since mfeeg, 'result_image' is a script template of mfeeg to image eeg results, majorly for erp and tf.
%           see all the previous result image scripts


%clear;
%close all;

% |------------------------------------------|
% |------ load options, set options ---------|
% |------------------------------------------|

% --- for time
load fs;
time_step = 1/fs;

load eleven_eeg_OptionVariable_customize;

load eeg_analyze_type;

% --- bad ch
%ch_bad = [];

% --- colormap
%colormap(jet);

pos_dim = [.01 .79 0.5 .2];

% |------------------------------------------|
% |------ load ch position and ch labe ------|
% |------------------------------------------|

% define the common 256 ch pos
ch256_pos_2D = ones(256,2);
for i =1:16
    ch256_pos_2D((i-1)*16+1:i*16,1)=repmat(i,16,1);
end
for i =1:16
    ch256_pos_2D((i-1)*16+1:i*16,2)=[16:-1:1];
end
ch256_pos_2D = ch256_pos_2D/16;

% define the common 81 ch pos
ch81_pos_2D = ones(81,2);
for i =1:9
    ch81_pos_2D((i-1)*9+1:i*9,1)=repmat(i,9,1);
end
for i =1:9
    ch81_pos_2D((i-1)*9+1:i*9,2)=[9:-1:1]+0.1;
end
ch81_pos_2D = ch81_pos_2D/9;

load eeg_type;
load import_file_type;

% biosemi 64
if eeg_type == 1
    if import_file_type == 1
        load biosemi_ch64_pos_2D;
        load biosemi_ch64_label;
        
        ch_pos_2D = biosemi_ch64_pos_2D;
        ch_label = biosemi_ch64_label;
    end
    
    % egi 128
    if import_file_type==211 || import_file_type==212
        load egi_ch128_pos_2D;
        %egi_ch128_pos_2D = round(egi_ch128_pos_2D*1000)/1000;
        load egi_ch128_label;
        
        ch_pos_2D = egi_ch128_pos_2D;
        ch_label = egi_ch128_label;
    end
end

if eeg_type == 2
    ch_pos_2D = ch256_pos_2D;
    
    load ch_label;
    ch256_label=[];
    for i = 1:size(ch_label)
        tmp = ch_label{i};
        ch256_label{i}= tmp;
    end
    ch_label = ch256_label;
end

% for source, decide by data. see below.

% |------------------------------------------|
% |------------------ er srer ---------------|
% |------------------------------------------|

if eeg_analyze_type == 2 || eeg_analyze_type == 42
    if eeg_analyze_type == 2
        time = -epoch_points_before_onest*time_step:time_step:epoch_points_after_onest*time_step; %: whole epoch length
        time = round(time*1000)/1000; % (avoid non-integer in ms)
        time_disp = -actual_epoch_points_before_onest*time_step:time_step:actual_epoch_points_after_onest*time_step; % actual epoch length without padding
        time_disp = round(time_disp*1000)/1000;
    end
    if eeg_analyze_type == 42
        time = -cond_IOI-padding_points*time_step:time_step:cond_IOI*2+padding_points*time_step; %: whole epoch length
        time = round(time*1000)/1000; % (avoid non-integer in ms)
        time_disp = -cond_IOI:time_step:cond_IOI*2; % actual epoch length without padding
        time_disp = round(time_disp*1000)/1000;
    end
    
    time_disp_lim = [time_disp(1),time_disp(end)]; % start and end time points to display, used in "lim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
    % start and end sample points in data.
    time_disp_init_point = find( time==time_disp(1) );
    time_disp_end_point = find( time==time_disp(end) );
    
    % --- for freq
    % same prosesses for freq as that for time above
    freq = tf_frequency_range; % all freq
    freq_disp = 4:freq(end); % freq to display.  used in "freq" parameter in mf_drawtf, mf_drawsyn
    freq_disp_lim = [freq_disp(1),freq_disp(end)];% start and end freq points to display, used in "clim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
    % start and end frequency sample points in data.
    freq_disp_init_point = find( freq==freq_disp(1) );
    freq_disp_end_point = find( freq==freq_disp(end) );
    
    % --- whether scaling
    is_scale_erp = 0; % 1 -- one scale for all chs use a value (lim below). 0 -- each scale for each ch, automaticly.
    is_scale_tf = 0;
    
    
    load cond_name;
    cond_num = length(cond_name);
    
    % |------------------------------------------|
    % |------------------  erp ------------------|
    % |------------------------------------------|
    
    % --- get erp cell
    cell_erp = cell(1,cond_num);
    
    for ii=1:cond_num
        % --- load erp
        input_data_name = ['eeg_erp' '_' cond_name{ii}];
        eval(sprintf('load %s;',input_data_name));
        eval(sprintf('erp_tmp = %s;',input_data_name));
        eval(sprintf('clear %s;',input_data_name));
        
        %erp_tmp(ch_bad,:) = 0;
        erp_tmp = erp_tmp(:,time_disp_init_point:time_disp_end_point);
        
        cell_erp{ii} = erp_tmp; clear erp_tmp;
    end
    
    % source region
    tmp = cell_erp{1};
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        load source_atlas
        label_name = [source_atlas,'_label'];
        load(label_name);
        node_file_name = [source_atlas '.node'];
        
        %{
        ch256_label=[];
        eval(sprintf('nn = size(%s);',label_name));
        for i = 1:nn(1)
            eval(sprintf('tmp = %s{i};',label_name));
            ch256_label{i}= tmp;
        end
        
        ch_pos_2D = ch256_pos_2D;
        ch_label = ch256_label;
        %}
        ch81_label=[];
        eval(sprintf('nn = size(%s);',label_name));
        for i = 1:nn(1)
            eval(sprintf('tmp = %s{i};',label_name));
            ch81_label{i}= tmp;
        end
        
        ch_pos_2D = ch81_pos_2D;
        ch_label = ch81_label;
    end
    
    clear tmp;
    
    % |--- individual erp
    for ii=1:cond_num
        % -- define value lim.
        tmp = cell_erp{ii};
        min_value = min(min(tmp(:)));
        max_value = max(max(tmp(:)));
        %min_value = min( [min(min(a1(:)),min(a2(:)))] );
        %max_value = max( [max(max(a1(:)),max(a2(:)))] );
        %min_value = -10; max_value=10; % can define manually
        
        % all lim mf_drawerp requires. see mf_drawerp
        lim = [time_disp_lim,min_value,max_value];
        
        
        % --- plot erp
        %   can define line type and color type.
        %       default color is red-blue-yellow-green-magenta-cyan-black
        figure;
        mf_drawerp(cell_erp(ii),ch_pos_2D,ch_label,time_disp,lim,is_scale_erp,1.5,['-','-','-'],...
            [1 0 0;0 0 1;0.75 0.75 0],1);
        %saveas(figure(11),[pwd '\erp_result',  '.fig']); % save result fig
        str = ['erp',' ',cond_name{ii}];
        annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
        
    end
    
    % |--- all erp
    if cond_num >1
        % -- define value lim.
        tmp = cell_erp{1};
        min_value = min(min(tmp(:)));
        max_value = max(max(tmp(:)));
        %min_value = min( [min(min(a1(:)),min(a2(:)))] );
        %max_value = max( [max(max(a1(:)),max(a2(:)))] );
        %min_value = -10; max_value=10; % can define manually
        
        % all lim mf_drawerp requires. see mf_drawerp
        lim = [time_disp_lim,min_value,max_value];
        
        
        % --- plot erp
        %   can define line type and color type.
        %       default color is red-blue-yellow-green-magenta-cyan-black
        figure;
        mf_drawerp(cell_erp,ch_pos_2D,ch_label,time_disp,lim,is_scale_erp,1.5,['-','-','-','-','-','-','-'],...
            [1 0 0;0 0 1;0.75 0.75 0;0 0.5 0;0.75 0 0.75;0 0.75 0.75;0 0 0],1);
        %saveas(figure(11),[pwd '\erp_result',  '.fig']); % save result fig
        str = ['all erp'];
        annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
        
        % add legend later
    end
    %
    % |---  erp subtraction---|
    % add later as needed
    
    
    % |------------------------------------------|
    % |------------------  tf -------------------|
    % |------------------------------------------|
    
    % |--- individual tf: tfboth ---|
    % tfnpltwo
    for ii=1:cond_num
        % --- load tf
        input_data_name = ['eeg_tfnpltwo' '_' cond_name{ii}];
        eval(sprintf('load %s;',input_data_name));
        eval(sprintf('tf_tmp = %s;',input_data_name));
        eval(sprintf('clear %s;',input_data_name));
        
        %tf_tmp(:,:,ch_bad) = 0;
        tf_tmp = tf_tmp( freq_disp_init_point:freq_disp_end_point,time_disp_init_point:time_disp_end_point,: );
        
        
        % --- define value lim.
        % use below two lines to determine value range
        min_value = min(min(min(tf_tmp(:))));
        max_value = max(max(max(tf_tmp(:))));
        %min_value = min( [min(min(min(b1(:)))),min(min(min(b2(:)))),min(min(min(b3(:))))] );
        %max_value = max( [max(max(max(b1(:)))),max(max(max(b2(:)))),max(max(max(b3(:))))] );
        % use below line to adjust to appropriate value range for display
        
        %min_value = -10;max_value=10;
        %min_value = -100;max_value=100;
        %min_value = -300;max_value=300;
        
        
        %min_value = 0;max_value=1;
        clim = [min_value,max_value];
        
        % --- plot tf
        figure;
        mf_drawtf(tf_tmp,ch_pos_2D,ch_label,time_disp,freq_disp,clim,is_scale_tf);
        %colormap(hot);
        %saveas(figure(21),[pwd '\tfboth_AT_result',  '.fig']);
        %str = ['tf',' ',cond_name{ii}];
        str = ['tfnpl',cond_name{ii}];
        annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
        
        %
    end
    % tfpl
    for ii=1:cond_num
        % --- load tf
        input_data_name = ['eeg_tfpl' '_' cond_name{ii}];
        eval(sprintf('load %s;',input_data_name));
        eval(sprintf('tf_tmp = %s;',input_data_name));
        eval(sprintf('clear %s;',input_data_name));
        
        %tf_tmp(:,:,ch_bad) = 0;
        tf_tmp = tf_tmp( freq_disp_init_point:freq_disp_end_point,time_disp_init_point:time_disp_end_point,: );
        
        
        % --- define value lim.
        % use below two lines to determine value range
        min_value = min(min(min(tf_tmp(:))));
        max_value = max(max(max(tf_tmp(:))));
        %min_value = min( [min(min(min(b1(:)))),min(min(min(b2(:)))),min(min(min(b3(:))))] );
        %max_value = max( [max(max(max(b1(:)))),max(max(max(b2(:)))),max(max(max(b3(:))))] );
        % use below line to adjust to appropriate value range for display
        
        %min_value = -10;max_value=10;
        %min_value = -100;max_value=100;
        %min_value = -300;max_value=300;
        
        
        %min_value = 0;max_value=1;
        clim = [min_value,max_value];
        
        % --- plot tf
        figure;
        mf_drawtf(tf_tmp,ch_pos_2D,ch_label,time_disp,freq_disp,clim,is_scale_tf);
        %colormap(hot);
        %saveas(figure(21),[pwd '\tfboth_AT_result',  '.fig']);
        %str = ['tf',' ',cond_name{ii}];
        str = ['tfpl',cond_name{ii}];
        annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
        
        %
    end
    
    % |---  tf subtraction---|
    % add later as needed.
end

% |----------------------------------------------|
% |------------------  resting ------------------|
% |----------------------------------------------|
if eeg_analyze_type == 1
    
    % --- spec
    load eeg_resting_spec_freq;
    
    freq = eeg_resting_spec_freq; % all freq
    
    freq_step = fs/2/(length(freq)-1);
    
    freq_disp_init_plan = 1; freq_disp_end_plan= 47; % freq range planed to display.
    % start and end frequency sample points in data.
    freq_disp_init_point = round(freq_disp_init_plan/freq_step)+1;
    freq_disp_end_point = round(freq_disp_end_plan/freq_step)+1;
    freq_disp = freq(freq_disp_init_point:freq_disp_end_point); % actual freq to display
    
    freq_disp_lim = [freq_disp(1),freq_disp(end)];% start and end freq points to display, used in "clim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
    
    % --- whether scaling
    is_scale_erp = 1;
    
    load eeg_resting_spec_am_norm;
    
    erp_tmp = eeg_resting_spec_am_norm(:,freq_disp_init_point:freq_disp_end_point);
    cell_erp = cell(1,1);
    cell_erp{1} = erp_tmp;
    
    % source region
    tmp = cell_erp{1};
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        load source_atlas
        label_name = [source_atlas,'_label'];
        load(label_name);
        node_file_name = [source_atlas '.node'];
        
        %{
        ch256_label=[];
        eval(sprintf('nn = size(%s);',label_name));
        for i = 1:nn(1)
            eval(sprintf('tmp = %s{i};',label_name));
            ch256_label{i}= tmp;
        end
        
        ch_pos_2D = ch256_pos_2D;
        ch_label = ch256_label;
        %}
        ch81_label=[];
        eval(sprintf('nn = size(%s);',label_name));
        for i = 1:nn(1)
            eval(sprintf('tmp = %s{i};',label_name));
            ch81_label{i}= tmp;
        end
        
        ch_pos_2D = ch81_pos_2D;
        ch_label = ch81_label;
    end
    clear tmp;
    
    min_value = min(min(erp_tmp(:)));
    max_value = max(max(erp_tmp(:)));
    
    % all lim mf_drawerp requires. see mf_drawerp
    lim = [freq_disp_lim,min_value,max_value];
    
    
    % --- plot erp
    %   can define line type and color type.
    %       default color is red-blue-yellow-green-magenta-cyan-black
    figure;
    mf_drawerp(cell_erp,ch_pos_2D,ch_label,freq_disp,lim,is_scale_erp,1.5,['-','-','-'],...
        [1 0 0;0 0 1;0.75 0.75 0],1);
    %saveas(figure(11),[pwd '\erp_result',  '.fig']); % save result fig
    str = ['spec'];
    annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
    
    
    % --- connectivity
    %
    % # eeg_resting_connect_cm_coef_raw
    % only plot source level
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        
        load eeg_resting_connect_cm_coef_raw;
        cm=eeg_resting_connect_cm_coef_raw;
        
        % --- plot cm
        figure;
        %imagesc(c1,[-1,1]);
        imagesc(cm);
        title('connectivity correlation matrix');
        xlabel('ch/region');
        ylabel('ch/region');
        colorbar;
        
        cm_pos = cm;
        cm_pos(find(cm_pos<0.5))=0;
        cm_neg = cm;
        cm_neg(find(cm_neg>-0.5))=0;
        
        % --- plot on brain use brainnet viewer
        %disp('left: positive connections; right:negative connections');
        disp('positive connections; (display negative connections as needs)');
        figure;
        %subplot(1,2,1);
        save tmp_edge.edge -ascii cm_pos;
        BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv',node_file_name,'tmp_edge.edge','brainnetviewer_option_1.mat');
        hold off;
        
        %         figure;
        %         %subplot(1,2,2);
        %         save tmp_edge.edge -ascii cm_neg;
        %         BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv',node_file_name,'tmp_edge.edge','brainnetviewer_option_1.mat');
        %         hold off;
        
        % --- circular graph
        %disp('left: positive connections; right:negative connections');
        disp('positive connections; (display negative connections as needs)');
        figure;
        %
        %subplot(1,2,1);
        eleven_DrawCircularGraph(cm_pos,ch_label);
        hold off;
        
        %         subplot(1,2,2);
        %         eleven_DrawCircularGraph(cm_neg,ch_label);
        %         %hold off;
        
    end
    
    
    % # eeg_resting_connect_cm_coef_highGamma
    % only plot source level
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        
        load eeg_resting_connect_cm_coef_highGamma;
        cm=eeg_resting_connect_cm_coef_highGamma;
        
        % --- plot cm
        figure;
        %imagesc(c1,[-1,1]);
        imagesc(cm);
        title('connectivity correlation matrix - highGamma');
        xlabel('ch/region');
        ylabel('ch/region');
        colorbar;
        
        cm_pos = cm;
        cm_pos(find(cm_pos<0.5))=0;
        cm_neg = cm;
        cm_neg(find(cm_neg>-0.5))=0;
        
        % --- plot on brain use brainnet viewer
        %disp('left: positive connections; right:negative connections');
        disp('positive connections; (display negative connections as needs)');
        figure;
        %subplot(1,2,1);
        save tmp_edge.edge -ascii cm_pos;
        BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv',node_file_name,'tmp_edge.edge','brainnetviewer_option_1.mat');
        hold off;
        
        %         figure;
        %         %subplot(1,2,2);
        %         save tmp_edge.edge -ascii cm_neg;
        %         BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv',node_file_name,'tmp_edge.edge','brainnetviewer_option_1.mat');
        %         hold off;
        
        % --- circular graph
        %disp('left: positive connections; right:negative connections');
        disp('positive connections; (display negative connections as needs)');
        figure;
        %
        %subplot(1,2,1);
        eleven_DrawCircularGraph(cm_pos,ch_label);
        hold off;
        
        %         subplot(1,2,2);
        %         eleven_DrawCircularGraph(cm_neg,ch_label);
        %         %hold off;
        
    end
    %}
    %
    % # eeg_resting_connect_cm_coef_lowGamma
    % only plot source level
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        
        load eeg_resting_connect_cm_coef_lowGamma;
        cm=eeg_resting_connect_cm_coef_lowGamma;
        
        % --- plot cm
        figure;
        %imagesc(c1,[-1,1]);
        imagesc(cm);
        title('connectivity correlation matrix - lowGamma');
        xlabel('ch/region');
        ylabel('ch/region');
        colorbar;
        
        cm_pos = cm;
        cm_pos(find(cm_pos<0.5))=0;
        cm_neg = cm;
        cm_neg(find(cm_neg>-0.5))=0;
        
        % --- plot on brain use brainnet viewer
        %disp('left: positive connections; right:negative connections');
        disp('positive connections; (display negative connections as needs)');
        figure;
        %subplot(1,2,1);
        save tmp_edge.edge -ascii cm_pos;
        BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv',node_file_name,'tmp_edge.edge','brainnetviewer_option_1.mat');
        hold off;
        
        %         figure;
        %         %subplot(1,2,2);
        %         save tmp_edge.edge -ascii cm_neg;
        %         BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv',node_file_name,'tmp_edge.edge','brainnetviewer_option_1.mat');
        %         hold off;
        
        % --- circular graph
        %disp('left: positive connections; right:negative connections');
        disp('positive connections; (display negative connections as needs)');
        figure;
        %
        %subplot(1,2,1);
        eleven_DrawCircularGraph(cm_pos,ch_label);
        hold off;
        
        %         subplot(1,2,2);
        %         eleven_DrawCircularGraph(cm_neg,ch_label);
        %         %hold off;
        
    end
    %
end

% |----------------------------------------------|
% |----------------  ssep srssep ----------------|
% |----------------------------------------------|
if eeg_analyze_type == 3 || eeg_analyze_type == 43
    
    load cond_name;
    cond_num = length(cond_name);
    
    input_freq_name = ['eeg_ssep_spec_freq' '_' cond_name{1}];
    eval(sprintf('load %s;',input_freq_name));
    eval(sprintf('freq = %s;',input_freq_name)); % all freq
    
    freq_step = fs/2/(length(freq)-1);
    
    % freq range planed to display.
    if eeg_analyze_type == 3
        freq_disp_init_plan = 1; freq_disp_end_plan= 47;
    end
    if eeg_analyze_type == 43
        freq_disp_init_plan = 1; freq_disp_end_plan= 5;
    end
    % start and end frequency sample points in data.
    freq_disp_init_point = round(freq_disp_init_plan/freq_step)+1;
    freq_disp_end_point = round(freq_disp_end_plan/freq_step)+1;
    freq_disp = freq(freq_disp_init_point:freq_disp_end_point); % actual freq to display
    
    freq_disp_lim = [freq_disp(1),freq_disp(end)];% start and end freq points to display, used in "clim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
    
    % --- whether scaling
    is_scale_erp = 0;
    
    % --- get ssep cell
    cell_erp = cell(1,cond_num);
    
    for ii=1:cond_num
        % --- load ssep
        input_data_name = ['eeg_ssep_spec_am_norm' '_' cond_name{ii}];
        eval(sprintf('load %s;',input_data_name));
        eval(sprintf('erp_tmp = %s;',input_data_name));
        eval(sprintf('clear %s;',input_data_name));
        
        cell_erp{ii} = erp_tmp(:,freq_disp_init_point:freq_disp_end_point); clear erp_tmp;
    end
    
    % source region
    tmp = cell_erp{1};
    tmp_dir=pwd;
    if exist([tmp_dir '\' 'source_atlas.mat'],'file')
        load source_atlas
        label_name = [source_atlas,'_label'];
        load(label_name);
        
        %{
        ch256_label=[];
        eval(sprintf('nn = size(%s);',label_name));
        for i = 1:nn(1)
            eval(sprintf('tmp = %s{i};',label_name));
            ch256_label{i}= tmp;
        end
        
        ch_pos_2D = ch256_pos_2D;
        ch_label = ch256_label;
        %}
        ch81_label=[];
        eval(sprintf('nn = size(%s);',label_name));
        for i = 1:nn(1)
            eval(sprintf('tmp = %s{i};',label_name));
            ch81_label{i}= tmp;
        end
        
        ch_pos_2D = ch81_pos_2D;
        ch_label = ch81_label;
    end
    clear tmp;
    
    % --- individual ssep
    for ii=1:cond_num
        tmp = cell_erp{ii};
        min_value = min(min(tmp(:)));
        max_value = max(max(tmp(:)));
        
        % all lim mf_drawerp requires. see mf_drawerp
        lim = [freq_disp_lim,min_value,max_value];
        
        
        % --- plot erp
        %   can define line type and color type.
        %       default color is red-blue-yellow-green-magenta-cyan-black
        figure;
        mf_drawerp(cell_erp(ii),ch_pos_2D,ch_label,freq_disp,lim,is_scale_erp,1.5,['-','-','-'],...
            [1 0 0;0 0 1;0.75 0.75 0],1);
        %saveas(figure(11),[pwd '\erp_result',  '.fig']); % save result fig
        str = ['spec',' ',cond_name{ii}];
        annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
    end
    
    % --- all ssep
    if cond_num >1
        % -- define value lim.
        tmp = cell_erp{1};
        min_value = min(min(tmp(:)));
        max_value = max(max(tmp(:)));
        %min_value = min( [min(min(a1(:)),min(a2(:)))] );
        %max_value = max( [max(max(a1(:)),max(a2(:)))] );
        %min_value = -10; max_value=10; % can define manually
        
        % all lim mf_drawerp requires. see mf_drawerp
        lim = [freq_disp_lim,min_value,max_value];
        
        
        % --- plot erp
        %   can define line type and color type.
        %       default color is red-blue-yellow-green-magenta-cyan-black
        figure;
        mf_drawerp(cell_erp,ch_pos_2D,ch_label,time_disp,lim,is_scale_erp,1.5,['-','-','-'],...
            [1 0 0;0 0 1;0.75 0.75 0],1);
        %saveas(figure(11),[pwd '\erp_result',  '.fig']); % save result fig
        str = ['all ssep'];
        annotation('textbox',pos_dim,'String',str,'FitBoxToText','on');
        
        % add legend later
    end
    
end
