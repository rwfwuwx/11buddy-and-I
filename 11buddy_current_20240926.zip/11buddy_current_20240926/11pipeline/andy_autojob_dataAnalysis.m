function andy_autojob_dataAnalysis
%clear;
%
% Note
%   this autojob does job for all dataAnadir, running at dataAna_root_dir (see code).
%       for a single 'current directory', i.e., one of dataAnadir, simply go
%           there, run command: load andy; andy();
% Update history
%   2021-12-24 
%   move eleven_eeg_set_OptionVariable_customize.m from
%   eleven_GLAutojob_routine_eegDataAnaDirPrepare.m to
%   andy_autojob_dataAnalysis.m
%   2021-12-16
%       separate set andy option (42 43) to preparing dataAnaDir.
%       update dataAnaDir
%       update set andy option
%   2021-12-15
%       separate setting directory structure
%       -> func template -> func
%   2021-12 start to incorporated into update framework
%   2019 andy_autojob2_(project/study name)

load dataAnaDir;
dataAna_root_dir = pwd;
 
for ii=1:length(dataAnaDir)
    cd(dataAnaDir{ii});
    
    %--- set andy 
    % andy is already set. if re-set is required, can do here
    eleven_eeg_set_OptionVariable_customize;
    
    %--- andy work
    load andy; andy();
    
    cd(dataAna_root_dir);
end


