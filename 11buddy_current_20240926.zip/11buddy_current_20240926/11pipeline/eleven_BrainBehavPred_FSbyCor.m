function [pos_featureMask_CV,neg_featureMask_CV ...
    pos_featureMask_CV_common,pos_featureMask_CV_MaskByThreshold,...
    neg_featureMask_CV_common,neg_featureMask_CV_MaskByThreshold ...
    behavData_fit,R_value_eva,P_value_eva,rmse_eva] ...
    = eleven_BrainBehavPred_FSbyCor(...
    brainData,behavData,brainData_test,behavData_test, ...
    commonFeatureSet,commonFeatureThreshold, ...
    corMethod,fs_threshold,learnMethod)
%
% Incorporate the below into an end-to-end pipeline.
%   eleven_BrainBehavPred_FSbyCor_FS
%   eleven_BrainBehavPred_FSbyCor_evaCommonFeature
%   eleven_BrainBehavPred_FSbyCor_CV
%   eleven_BrainBehavPred_FSbyCor_test
%   and evaluation
% further details see these funcs.
%
% Input
%   commonFeatureSet
%       1: use common feature for train + test. % suppose default for large data set.
%       2: use individual features for train + test
%       (3: use individual&common features for train + test) % make no sense. just leave for test
%       4: use common feature for train/CV
%       5: use individual features for train/CV
%       6: use individual&common features for train/CV  % suppose default for small data set.
%   Other params see the above funcs.
% Output
%   Other params see the above funcs.
%
% Update history
% 2024-06-20 initial version

% initialize all outputs as []
pos_featureMask_CV = [];
neg_featureMask_CV = [];
pos_featureMask_CV_common = [];
pos_featureMask_CV_MaskByThreshold = [];
neg_featureMask_CV_common = [];
neg_featureMask_CV_MaskByThreshold = [];
behavData_fit = [];
R_value_eva = [];
P_value_eva = [];
rmse_eva =[];

%- feature select
[pos_featureMask_CV,neg_featureMask_CV] = eleven_BrainBehavPred_FSbyCor_FS(...
    brainData,behavData,corMethod,fs_threshold);

% CommonFeature
[pos_featureMask_CV_common,pos_common_feature_num,pos_featureMask_CV_MaskByThreshold] = ...
    eleven_BrainBehavPred_FSbyCor_evaCommonFeature(...
    pos_featureMask_CV,commonFeatureThreshold);
[neg_featureMask_CV_common,neg_common_feature_num,neg_featureMask_CV_MaskByThreshold] = ...
    eleven_BrainBehavPred_FSbyCor_evaCommonFeature(...
    neg_featureMask_CV,commonFeatureThreshold);

% note, even for individual features, also first limit by common feature.
%   Otherwise, the result would be too poor (all sbj have no overlap), which make no sense.
if pos_common_feature_num>0 || neg_common_feature_num>0
    
    % determine using pos/neg feature 
    if pos_common_feature_num>0 && neg_common_feature_num>0
        usePosNeg = 1;
    end
    if pos_common_feature_num>0 && neg_common_feature_num==0
        usePosNeg = 2;
    end
    if pos_common_feature_num==0 && neg_common_feature_num>0
        usePosNeg = 3;
    end
    
    % determine using feature type
    if commonFeatureSet == 1 || commonFeatureSet == 4
        pos_featureMask_CV = pos_featureMask_CV_common;
        neg_featureMask_CV = neg_featureMask_CV_common;
    end
    if commonFeatureSet == 2 || commonFeatureSet == 5
        pos_featureMask_CV = pos_featureMask_CV;
        neg_featureMask_CV = neg_featureMask_CV;
    end
    if commonFeatureSet == 3 || commonFeatureSet == 6
        pos_featureMask_CV = pos_featureMask_CV_MaskByThreshold;
        neg_featureMask_CV = neg_featureMask_CV_MaskByThreshold;
    end
        
    %- train + test
    if commonFeatureSet == 1 || commonFeatureSet == 2 || commonFeatureSet == 3
        % determine using train/test data
        tmp_brainData = brainData_test;
        tmp_behavData = behavData_test;
        
        % do predict
        [behavData_fit] = eleven_BrainBehavPred_FSbyCor_TrainTest(...
            tmp_brainData,tmp_behavData,...
            pos_featureMask_CV,neg_featureMask_CV,learnMethod,usePosNeg);
    end
    
    %- train/CV
    if commonFeatureSet == 4 || commonFeatureSet == 5 || commonFeatureSet == 6
        % determine using train/test data
        tmp_brainData = brainData;
        tmp_behavData = behavData;
        
        % do predict
        [behavData_fit] = eleven_BrainBehavPred_FSbyCor_TrainCV(...
            tmp_brainData,tmp_behavData,...
            pos_featureMask_CV,neg_featureMask_CV,learnMethod,usePosNeg);
    end
    
    %- evaluation
    [R_value_eva,P_value_eva,rmse_eva] = ...
        eleven_trainRegression_eva(...
        tmp_behavData,behavData_fit,corMethod,1);

else
    disp('oops, no common sig feature');
end
