function eleven_GLAutojob_routine_behavCfeAnafeatureExtract(dir_root_file,dir_tree_file,behav_analyze_type_list_file,sbj_info_file,data_index,is_formal)
% Input
%
% Todo
%
% Note
% # simplification. see Note in eleven_GLAutojob_routine_behavRptAnaAvg.m
% # analyze_type is not need for behav.
%   keep it in case future requirement.
%
% Update history
%   2024-04-18 initial version, modify from eleven_GLAutojob_routine_eegCfeAnafeatureExtract.m

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

%--- decide whether include a data
data_include_index = ones(data_num,1);

% not include data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        data_include_index(ii) = 0;
    end
end

% a double check that the input data_index is already analyzed
data_include_index = data_include_index & data_index;

data_include_index_num = find(data_include_index==1);


for ii = 1:length(data_include_index_num)
    
    sbj_data_path = [dir_root{1} '\' 'sbjxx' '\' dir_tree{[data_include_index_num(ii)]}];
    
    behav_analyze_type_list = load(behav_analyze_type_list_file);
    behav_analyze_type = behav_analyze_type_list([data_include_index_num(ii)],1);
    
    
    % loop of sbj
    for kk = 1:length(sbj)
        
        % whether analyze this data
        tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
        eval(sprintf('tmp_is_analysis_cond = %s(kk);',tmp_var_name));
        
        if tmp_is_analysis_cond == 1
            current_dir_sbj = strrep(sbj_data_path, 'sbjxx', sbj{kk});
            cd(current_dir_sbj);
            
            
            % |--- do the job here ---|
            
            yangyang_autojob_produce_componentFeature;
            
            % |--- end do the job ---|
            
        end
        
    end
    
end


cd([dir_root{1} '\' allsbj_dirName]);
