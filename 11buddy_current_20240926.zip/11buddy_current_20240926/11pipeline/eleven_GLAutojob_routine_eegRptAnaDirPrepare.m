function eleven_GLAutojob_routine_eegRptAnaDirPrepare(dir_root_file,dir_tree_file,eeg_analyze_type_list_file,is_formal)
% Input
% Todo
%
% Note
%   This routine does not have the sbj loop.
%   set dir for all data. i.e., without individual sbj info, becuase, at first, especially in test stage, not all data are analyzed for all sbj.
% Update history
%   2022-06-17 remove dataList_eeg_file.
%   2022-06-14 for allsbj path, replace data_list by dir_tree
%   2022-01-23 add is_formal, i.e., allsbj->allsbj_test when test
%   2022-01-15 initially done.
%   2022-01-14 
%       initial version as a new routine. modify from eleven_GLAutojob_routine_eegDataAnaDirPrepare.

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree); 

atlasNames = {'DesikanKilliany'};

% --- open file to write
fid_w = fopen('rptAnaDir.txt','w');

for ii = 1:data_num % loop of dir_tree\cond
    
    current_analysis_path = [dir_root{1} '\' allsbj_dirName];
        
    % |--- do the job here ---|
    
    %--- routine ---
    eeg_analyze_type_list = load(eeg_analyze_type_list_file);
    eeg_analyze_type = eeg_analyze_type_list(ii,1);
    
    %
    tmp_dir = [current_analysis_path '\' dir_tree{ii}];
    if ~exist(tmp_dir,'dir')
        mkdir(tmp_dir);
    end
    
    % run2
    tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run2'];
    if ~exist(tmp_dir,'dir')
        mkdir(tmp_dir);
    end
    if ~isempty(find(eeg_analyze_type == [1 2 3 42]))
        fprintf(fid_w,'%s\n',tmp_dir);
    end
    %   sr
    if eeg_analyze_type == 4
        tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run2' '\' 'srer'];
        if ~exist(tmp_dir,'dir')
            mkdir(tmp_dir);
        end
        fprintf(fid_w,'%s\n',tmp_dir);
        tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run2' '\' 'srssep'];
        if ~exist(tmp_dir,'dir')
            mkdir(tmp_dir);
        end
        fprintf(fid_w,'%s\n',tmp_dir);
    end
    
    % run3
    tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run3'];
    if ~exist(tmp_dir,'dir')
        mkdir(tmp_dir);
    end
    % loop of atlas
    for jj=1:length(atlasNames)
        tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run3' '\' atlasNames{jj}];
        if ~exist(tmp_dir,'dir')
            mkdir(tmp_dir);
        end
        if ~isempty(find(eeg_analyze_type == [1 2 3 42]))
            fprintf(fid_w,'%s\n',tmp_dir);
        end
        % sr
        if eeg_analyze_type == 4
            tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run3' '\' atlasNames{jj} '\' 'srer'];
            if ~exist(tmp_dir,'dir')
                mkdir(tmp_dir);
            end
            fprintf(fid_w,'%s\n',tmp_dir);
            tmp_dir = [current_analysis_path '\' dir_tree{ii} '\' 'run3' '\' atlasNames{jj} '\' 'srssep'];
            if ~exist(tmp_dir,'dir')
                mkdir(tmp_dir);
            end
            fprintf(fid_w,'%s\n',tmp_dir);
        end
    end
    
    % |--- end job ---|
    
end


cd([dir_root{1} '\' allsbj_dirName]);

% close file
fclose(fid_w);


