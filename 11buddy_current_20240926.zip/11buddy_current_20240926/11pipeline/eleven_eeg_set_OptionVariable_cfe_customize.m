function eleven_eeg_set_OptionVariable_cfe_customize
% eleven_eeg_set_OptionVariable_cfe_customize	
% Usage
%   eleven_eeg_set_OptionVariable_cfe_customize
%
% Update history
%	2022-06-19 initial version, modify from eleven_eeg_set_OptionVariable.m

clear; % do not remove this

eleven_eeg_set_OptionVariable_cfe;
load eleven_eeg_OptionVariable_cfe;


% |-------------------------------------------------|
% |--- add customized options here, if there are ---|
% |-------------------------------------------------|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_eeg_set_OptionVariable.m. 
%       2. modify here as needs
%       3. run eleven_eeg_set_OptionVariable_customize here (make sure in the current analysis directory)

% --- settings 


% --- save
save eleven_eeg_OptionVariable_cfe_customize;

clear; % do not remove this
