function  lags_vector=autocorr_xianglab(y,nlags)

[m,n]=size(y);

if n>=2
    error('please input an vector of dimension: m x 1');
end

if m<=nlags
    error('demand too large nlags,nlags must be smaller than m');
end
M=mean(y);
lags_vector=zeros(1,nlags);

for kk=1:nlags
lags_vector(kk)=corr([M*ones(kk,1);y(1:m)],[y(1:m);M*ones(kk,1)]);
end

end