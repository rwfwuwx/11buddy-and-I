% 2022-12-19 add cd to the path

clear;

eleven_path = 'H:\soft\11buddy\11buddy_current';

cd(eleven_path);
save eleven_global_setting;

clear;