% open func
%   eleven_openFunc_produceSbjIndex_NSAnaExclude.m
%
% --- 函数初始用途
% 对于输入数据，检查 缺失值-nan, 显示报告；并生成 到非结构化数据处理阶段的 缺失值 被试索引数据。
% 如果有多份数据，分别显示报告；索引数据汇总了所有数据。
% 注：NSAnaExclude=NonStructralAnaExclude 指什么？
%   andy4以及之后的ada 进行的是结构化分析；相应的，NonStructralAna 指之前的非结构化分析。
%   本函数接收，并生成，非结构化分析阶段产生的缺失值 的索引。
% 注：关于sbjIndex_RecruitExclude
%   这是在非结构化分析之前，数据采集阶段指定的；注意，
%       已经包括在 非结构化 数据中。
%           注: 当前数据 sbjIndex_RecruitExclude 已标记在脑电数据中，但没有标记在 临床数据中。
%           如果临床数据也标记了，注意检查是否整合到 sbjIndex_RecruitExclude。
%       在这里报告的时候，专门报告 非结构化阶段 缺失值。
% 缺失值阶段总结：
%   #数据采集阶段  sbjIndex_RecruitExclude
%       注：已 nan 标记在脑电数据中。
%   #非结构化数据处理阶段 nan标记在相应数据中
%   本步骤生成的analysis_sbjIndex_NonStructralAnaExclude 包含了
%       上面两个阶段 数据 累积的
%       如果多数据 汇总的
%       缺失值。
%   再次强调：本函数 不改变输入数据。
%
% --- 函数general用途
%   本函数 最初设计用于以上初始用途。实际上，本函数功能是通用的：
%       对当前输入数据 每个数据，统计报告缺失值。
%       对当前输入数据 汇总报告缺失值。
%       生成当前输入数据 的 缺失值索引。
%   如果不考虑‘当前输入数据’的具体性，并因此不输入相应索引，那么本函数是完全通用的。
%       比如，应用场景一：“最终分析索引 - 按索引 获取 论文报告 被试信息”
%           无需生成索引，只是用于报告。
%       因此，加入 参数：isSave_SbjIndex_Exclude。
% --- 进一步general相关todo
%   如上，本函数当前两个具体用途
%       #初始用途
%       #应用场景一
%   如需进一步拓展，例如，
%       具体场景 需 save 具体index; 相应general 拓展。
%       如需更为general的全局唯一 exclude index， 拓展可参见
%           eleven_openFunc_dataCheck_rmOutlier.m Update history 2023-12-12.
% Input
%   --- sbj (sbj is just for getting the number of sbj.)
%   --- tmpInputVar. e.g.,
%   isSave_SbjIndex_Exclude.
%       0: just report.
%       1: save an index.
%           注：当前 默认 save analysis_sbjIndex_NonStructralAnaExclude.
%           用于初始用途。见上说明。如有进一步需求，按需拓展。
%[
% tmpInputVar = [...
%     eegDataName([1:end]),... % eegDataName([1:2]),...
%     clinicDataName([1:end]),...
%     basicSbjInfoDataName([1:end])...
%     ];
%]
%
% Output
%   --- 报告：每个数据中的缺失人次及编号
%   --- analysis_sbjIndex_NonStructralAnaExclude
%   --- 报告：“根据 设定要去除nan值的变量名，一共将去除被试人次”
%
% Update history
%   2023-12-12 
%       add description
%       add isSave_SbjIndex_Exclude.see descriptipn above '函数general用途'.
%[check and confirm: neglect it
%   2023-08-02 change back to 'sbjIndex_RecruitExclude'
%   2023-05-08 change 'sbjIndex_RecruitExclude' to
%    'sbjIndex_RecruitExclude_eeg', add 'sbjIndex_RecruitExclude_clinic'see line58-59
%   2022-10-22 add saying 'tmp_index_num' refers to sbjIndexNO
%]
%   2022-09-22 add display 'tmp_index_num'
%   2022-08-11 
%       for sbj*ch, update:
%           if nan for all ch, reject sbj
%           if not, interpolate.
%   2022-07-x correction for data dim
%   2022-06-23 initial version 

if isSave_SbjIndex_Exclude
    analysis_sbjIndex_NonStructralAnaExclude = zeros(length(sbj),1);
end

current_analysis_sbjIndex_Exclude = zeros(length(sbj),1);
for ii_nsae = 1:length(tmpInputVar)
    tmp_name = tmpInputVar{ii_nsae};
    eval(sprintf('tmp_data = %s;',tmp_name));
    sz=size(tmp_data);
    
    % var format: sbj*1
    if length(sz) == 2 & sz(2) == 1
        tmp1_data = tmp_data;
        tmp_index_num = find(isnan(tmp1_data)==1); 
        current_analysis_sbjIndex_Exclude(tmp_index_num) = 1;
    end
    
    % var format: sbj*ch
    if length(sz) == 2 & sz(2) > 1
        for jj_nsae = 1:size(tmp_data,1)
            tmp1_data = tmp_data(jj_nsae,:);
            if length(find(isnan(tmp1_data)==1)) == size(tmp_data,2)
                current_analysis_sbjIndex_Exclude(jj_nsae) = 1;
            end
        end
        tmp_index_num =find(current_analysis_sbjIndex_Exclude==1);
    end
    
    % var format: ch*ch*sbj
    if length(sz) == 3 
        % assume nan is the same for all ch pair
        tmp1_data = squeeze(tmp_data(1,1,:));
        tmp_index_num = find(isnan(tmp1_data)==1); 
        current_analysis_sbjIndex_Exclude(tmp_index_num) = 1;
    end
    
    sprintf('数据 %s 中 含有 %d 缺失人次',tmp_name,length(tmp_index_num))
    disp('缺失人次 编号为')
    tmp_index_num
end

sprintf('根据 设定要去除nan值的变量名，一共将去除被试人次 %d',...
    length(find(current_analysis_sbjIndex_Exclude==1))...
    -length(find(sbjIndex_RecruitExclude==1)))

if isSave_SbjIndex_Exclude
    analysis_sbjIndex_NonStructralAnaExclude = current_analysis_sbjIndex_Exclude;
    save analysis_sbjIndex_NonStructralAnaExclude analysis_sbjIndex_NonStructralAnaExclude;  
end

