% open func
% eleven_openFunc_produceResultTable
% Input
%   tmpInputVar1: Variable value, e.g. r value
%   tmpInputVar2: Variable name, e.g. {'bankssts L', 'bankssts R'}
%   tmpInputVar3: Variable value name, e.g. 'r value'
%   excel_name: e.g. 'test.xlsx';
%   tmp_stat_threshold_control: control stat value
% Output
%   a table
%   an excel
%
% Update history
%   2022-12-18 disable save excel
%   2022-11-14 build

if exist('tmp_stat_threshold_control','var') 
    stat_idx = find(abs(tmpInputVar1)<tmp_stat_threshold_control);
    tmpInputVar1(stat_idx) = [];
    tmpInputVar2(stat_idx) = [];
end

T = array2table(tmpInputVar1,'VariableNames',tmpInputVar2,'RowNames',tmpInputVar3)
%writetable(T,excel_name)
