function eleven_mlx_execute_convert(mlx_file,convert_format)
%Usage eleven_mlx_execute_convert(mlx_file,convert_format)
% run and save the mlx_file with output. 
%   In addition,if 'convert_format' is non empty, convert to a further file in the format set as
%       'html','docx', or 'pdf' (as long as support).
%Input
% 
%
%Update history
% 2023-11-23
%   Initial version.

%--- run and save the mlx file
% matlab.internal.liveeditor.executeAndSave requires full path
[filePath,fileName,fileExtension] = fileparts(mlx_file);
if isempty(filePath) % i.e., relative path
    mlx_file = fullfile(pwd,mlx_file);
end

% run
matlab.internal.liveeditor.executeAndSave(mlx_file);


%--- convert 
if ~isempty(convert_format)
    % set output converted file
    [filePath,fileName,fileExtension] = fileparts(mlx_file);
    output_convert_file = [filePath '\' fileName '.' convert_format];
    
    matlab.internal.liveeditor.openAndConvert(mlx_file, output_convert_file);
end





