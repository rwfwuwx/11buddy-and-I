function eleven_eegSource_TSExtract(ProtocolName,sFile_FileName,atlasName,EEGBuddy_TSExtract_OutputName) 
% Usage
% Input
%   ProtocolName --- see eleven_eegSource_Import.m. 
%   sFile_FileName --- that returned by eleven_eegSource_Inverse.m.
%   atlasName ---
% Hidden Output
%   [EEGBuddy_TSExtract_OutputName,'_',atlasName]
%       defaultly save in 'current directory', follow andy framework.
% todo
%   again, time window
% Note
%   Others see eleven_eegSource_Import.m.
% Description
%   Others see eleven_eegSource_Import.m.
% Update history
% 2022-02-28 mark open/close bs.
%   2022-02-25 remove SourceSpace
%   2021-10-19~20 
%       see eleven_eegSource_Import.m


% Start BrainStorm in silent mode. 
% if ~brainstorm('status')
%     brainstorm nogui
% end

% load Protocol
iProtocol = bst_get('Protocol', ProtocolName);

if ~isempty(iProtocol)
   gui_brainstorm('SetCurrentProtocol', iProtocol);
end
if isempty(iProtocol)
    error(['Unknown protocol: ' ProtocolName]);
end

%--- TS extract
% GUI Process: Scouts time series: [148 scouts]

if strcmp(atlasName,'Destrieux')
    % define atlas 
    atlas = {'Destrieux', {'G_Ins_lg_and_S_cent_ins L', 'G_Ins_lg_and_S_cent_ins R', 'G_and_S_cingul-Ant L', 'G_and_S_cingul-Ant R', 'G_and_S_cingul-Mid-Ant L', 'G_and_S_cingul-Mid-Ant R', 'G_and_S_cingul-Mid-Post L', 'G_and_S_cingul-Mid-Post R', 'G_and_S_frontomargin L', 'G_and_S_frontomargin R', 'G_and_S_occipital_inf L', 'G_and_S_occipital_inf R', 'G_and_S_paracentral L', 'G_and_S_paracentral R', 'G_and_S_subcentral L', 'G_and_S_subcentral R', 'G_and_S_transv_frontopol L', 'G_and_S_transv_frontopol R', 'G_cingul-Post-dorsal L', 'G_cingul-Post-dorsal R', 'G_cingul-Post-ventral L', 'G_cingul-Post-ventral R', 'G_cuneus L', 'G_cuneus R', 'G_front_inf-Opercular L', 'G_front_inf-Opercular R', 'G_front_inf-Orbital L', 'G_front_inf-Orbital R', 'G_front_inf-Triangul L', 'G_front_inf-Triangul R', 'G_front_middle L', 'G_front_middle R', 'G_front_sup L', 'G_front_sup R', 'G_insular_short L', 'G_insular_short R', 'G_oc-temp_lat-fusifor L', 'G_oc-temp_lat-fusifor R', 'G_oc-temp_med-Lingual L', 'G_oc-temp_med-Lingual R', 'G_oc-temp_med-Parahip L', 'G_oc-temp_med-Parahip R', 'G_occipital_middle L', 'G_occipital_middle R', 'G_occipital_sup L', 'G_occipital_sup R', 'G_orbital L', 'G_orbital R', 'G_pariet_inf-Angular L', 'G_pariet_inf-Angular R', 'G_pariet_inf-Supramar L', 'G_pariet_inf-Supramar R', 'G_parietal_sup L', 'G_parietal_sup R', 'G_postcentral L', 'G_postcentral R', 'G_precentral L', 'G_precentral R', 'G_precuneus L', 'G_precuneus R', 'G_rectus L', 'G_rectus R', 'G_subcallosal L', 'G_subcallosal R', 'G_temp_sup-G_T_transv L', 'G_temp_sup-G_T_transv R', 'G_temp_sup-Lateral L', 'G_temp_sup-Lateral R', 'G_temp_sup-Plan_polar L', 'G_temp_sup-Plan_polar R', 'G_temp_sup-Plan_tempo L', 'G_temp_sup-Plan_tempo R', 'G_temporal_inf L', 'G_temporal_inf R', 'G_temporal_middle L', 'G_temporal_middle R', 'Lat_Fis-ant-Horizont L', 'Lat_Fis-ant-Horizont R', 'Lat_Fis-ant-Vertical L', 'Lat_Fis-ant-Vertical R', 'Lat_Fis-post L', 'Lat_Fis-post R', 'Pole_occipital L', 'Pole_occipital R', 'Pole_temporal L', 'Pole_temporal R', 'S_calcarine L', 'S_calcarine R', 'S_central L', 'S_central R', 'S_cingul-Marginalis L', 'S_cingul-Marginalis R', 'S_circular_insula_ant L', 'S_circular_insula_ant R', 'S_circular_insula_inf L', 'S_circular_insula_inf R', 'S_circular_insula_sup L', 'S_circular_insula_sup R', 'S_collat_transv_ant L', 'S_collat_transv_ant R', 'S_collat_transv_post L', 'S_collat_transv_post R', 'S_front_inf L', 'S_front_inf R', 'S_front_middle L', 'S_front_middle R', 'S_front_sup L', 'S_front_sup R', 'S_interm_prim-Jensen L', 'S_interm_prim-Jensen R', 'S_intrapariet_and_P_trans L', 'S_intrapariet_and_P_trans R', 'S_oc-temp_lat L', 'S_oc-temp_lat R', 'S_oc-temp_med_and_Lingual L', 'S_oc-temp_med_and_Lingual R', 'S_oc_middle_and_Lunatus L', 'S_oc_middle_and_Lunatus R', 'S_oc_sup_and_transversal L', 'S_oc_sup_and_transversal R', 'S_occipital_ant L', 'S_occipital_ant R', 'S_orbital-H_Shaped L', 'S_orbital-H_Shaped R', 'S_orbital_lateral L', 'S_orbital_lateral R', 'S_orbital_med-olfact L', 'S_orbital_med-olfact R', 'S_parieto_occipital L', 'S_parieto_occipital R', 'S_pericallosal L', 'S_pericallosal R', 'S_postcentral L', 'S_postcentral R', 'S_precentral-inf-part L', 'S_precentral-inf-part R', 'S_precentral-sup-part L', 'S_precentral-sup-part R', 'S_suborbital L', 'S_suborbital R', 'S_subparietal L', 'S_subparietal R', 'S_temporal_inf L', 'S_temporal_inf R', 'S_temporal_sup L', 'S_temporal_sup R', 'S_temporal_transverse L', 'S_temporal_transverse R'}};
end
if strcmp(atlasName,'DesikanKilliany')
    % define atlas 
    atlas = {'Desikan-Killiany', {'bankssts L', 'bankssts R', 'caudalanteriorcingulate L', 'caudalanteriorcingulate R', 'caudalmiddlefrontal L', 'caudalmiddlefrontal R', 'cuneus L', 'cuneus R', 'entorhinal L', 'entorhinal R', 'frontalpole L', 'frontalpole R', 'fusiform L', 'fusiform R', 'inferiorparietal L', 'inferiorparietal R', 'inferiortemporal L', 'inferiortemporal R', 'insula L', 'insula R', 'isthmuscingulate L', 'isthmuscingulate R', 'lateraloccipital L', 'lateraloccipital R', 'lateralorbitofrontal L', 'lateralorbitofrontal R', 'lingual L', 'lingual R', 'medialorbitofrontal L', 'medialorbitofrontal R', 'middletemporal L', 'middletemporal R', 'paracentral L', 'paracentral R', 'parahippocampal L', 'parahippocampal R', 'parsopercularis L', 'parsopercularis R', 'parsorbitalis L', 'parsorbitalis R', 'parstriangularis L', 'parstriangularis R', 'pericalcarine L', 'pericalcarine R', 'postcentral L', 'postcentral R', 'posteriorcingulate L', 'posteriorcingulate R', 'precentral L', 'precentral R', 'precuneus L', 'precuneus R', 'rostralanteriorcingulate L', 'rostralanteriorcingulate R', 'rostralmiddlefrontal L', 'rostralmiddlefrontal R', 'superiorfrontal L', 'superiorfrontal R', 'superiorparietal L', 'superiorparietal R', 'superiortemporal L', 'superiortemporal R', 'supramarginal L', 'supramarginal R', 'temporalpole L', 'temporalpole R', 'transversetemporal L', 'transversetemporal R'}};
end
if strcmp(atlasName,'Brodmann_YCG_copy')
    % define atlas 
    atlas = {'Brodmann_YCG_copy', {'10', '100', '101', '11', '110', '111', '170', '171', '180', '181', '190', '191', '20', '200', '201', '21', '210', '211', '220', '221', '230', '231', '240', '241', '250', '251', '260', '261', '270', '271', '280', '281', '290', '291', '30', '300', '301', '31', '320', '321', '340', '341', '350', '351', '360', '361', '370', '371', '380', '381', '390', '391', '40', '400', '401', '41', '410', '411', '420', '421', '430', '431', '440', '441', '450', '451', '460', '461', '470', '471', '480', '481', '50', '51', '60', '61', '70', '71', '80', '81', '90', '91'}};
   %atlas = {'Volume 13439: Brodmann_YCG_copy', {'10', '100', '101', '11', '110', '111', '170', '171', '180', '181', '190', '191', '20', '200', '201', '21', '210', '211', '220', '221', '230', '231', '240', '241', '250', '251', '260', '261', '270', '271', '280', '281', '290', '291', '30', '300', '301', '31', '320', '321', '340', '341', '350', '351', '360', '361', '370', '371', '380', '381', '390', '391', '40', '400', '401', '41', '410', '411', '420', '421', '430', '431', '440', '441', '450', '451', '460', '461', '470', '471', '480', '481', '50', '51', '60', '61', '70', '71', '80', '81', '90', '91'}};
end

% perform TS extract
sFile_Inverse = bst_process('CallProcess', 'process_extract_scout', sFile_FileName, [], ...
    'timewindow',     [], ...
    'scouts',         atlas, ...
    'isnorm',         1);

% Export TS
outputName = [EEGBuddy_TSExtract_OutputName,'_',atlasName];
export_matlab(sFile_Inverse.FileName,outputName);

 % Quit Brainstorm
% brainstorm stop;
