function [contact_coord_region] = eleven_seeg_contact_lable2coord(contact_coord,contact_label_cell)
% [contact_coord_region] = eleven_seeg_contact_lable2coord(contact_coord,contact_label_cell)
% Input
%   
% Output
%
% Note & todo
%
% --- update history
% 2023-11-20
%   initial version.

if nargin~=2
    disp('eleven_seeg_contact_lable2coorde requires 2 arguments!');
    return;
end

contact_num = size(contact_label_cell,1);

contact_coord_region = zeros(contact_num,3);

tmp_index = cell2mat(contact_label_cell(:,2));

contact_coord_region = contact_coord(tmp_index,:);