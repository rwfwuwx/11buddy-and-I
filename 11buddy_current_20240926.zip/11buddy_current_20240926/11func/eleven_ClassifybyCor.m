function [coef,class_pred_max_index,ACC_strict,ACC_loose] = eleven_ClassifybyCor(trainData,testData,corMethod)
% [coef,class_pred_max_index,ACC_strict,ACC_loose] = eleven_ClassifybyCor(trainData,testData,corMethod)
%
% Description
%   This is an extended/customized implementation of Haxby JV, Gobbini MI, Furey ML, Ishai A, Schouten JL, Pietrini P (2001) 
%       Distributed and Overlapping Representations of Faces and Objects in Ventral Temporal Cortex. Science 293:2425–2430.
%
% Input
%   trainData: matrix. features * classes. classes >1.
%   testData: matrix. features * classes. classes>=1.
%   corMethod: 'Pearson', 'Spearman'
%
% Output
%   coef:
%       row: correspond to trainDdata; column: correspond to test data (! do not confuse row and column)
%   class_pred_max_index: for each class in testData, which class in trainData it belongs to (most like). 
%   ACC_strict: by the common sense, i.e., whether it is top most like.
%   ACC_loose: by haxby 2001.
%       for the between comparisons, what percent (how many) of them, within > between
%
% Note
% --- about relationship between algorithm/ why use haxby2001
%   #typical classification
%   50_train 50_test
%   param<-model(50_train)
%   prediction<-predict(param,50_test)
% 
%    #by similarity(corr) on single_trial
%       # ie., eleven_crossCorr
%   50_train 50_test
%   avg_50_train<-avg(50_train)
%   prediction<-cor(avg_50_train,50_test)
%   (note, there are direct ref, e.g., a erp study; get it and record)
% 
%   #by similarity(corr) on avg, i.e., haxy2001
%   50_train 50_test
%   avg_50_train<-avg(50_train)
%   avg_50_test<-avg(50_test)
%   prediction<-cor(avg_50_train,avg_50_test)
%
% Update history
%   2024-09-19
%   ---Outpu
%   # add accuracy, in terms of strict,or loose criterion.
%   # add coef of cor, for reference
%   # 'TemplateClassIndex_pred' -> 'class_pred_max_index'
%   ---change 'template' -> train; 'compare' - > test
%       i.e., more with a learning words. 
%   ---change name eleven_crossCor -> eleven_ClassifybyCor, to emphasize this is a classifier 
%       i.e., emphasize aim instead of calculation
%   2024-06-19 update corr
%   2021-09-27 initial version. 

%- corr matrix
[coef,~] = corr(trainData,testData,'Type',corMethod,'rows','complete');

%- max of the pred
[class_pred_max_value,class_pred_max_index] = max(coef);

%--- accuracy
% diag of coef. ! the max is supposed on the diag of the corr matrix.
%   below manually handling diag element, to avoid potential issue related to non-squaure matrix
%diag_coef = diag(coef); 

%- strict accuracy
%   i.e., based on, whether the max pred is on diag
ACC_strict = zeros(1,size(testData,2));
for ii=1:size(testData,2)
    diag_value = coef(ii,ii);
    ACC_strict(ii) = diag_value == class_pred_max_value(ii); % max:1, or not max: 0
end
ACC_strict = ACC_strict*100; % convert to percent

%- loose accuracy
%   i.e., based on, for the between comparisons, how many of them, within > between
ACC_loose = zeros(1,size(testData,2));
for ii=1:size(testData,2)
    diag_value = coef(ii,ii);
    
    %data removing diag_value. i.e., between comparisons
    tmpdata = coef(:,ii);
    tmpdata(tmpdata == diag_value) = [];
    
    % for the between comparisons, how many of them, within > between
    ACC_loose(ii) = length(find(diag_value>tmpdata));
end
ACC_loose = ACC_loose/(size(trainData,2)-1)*100; % convert to percent








