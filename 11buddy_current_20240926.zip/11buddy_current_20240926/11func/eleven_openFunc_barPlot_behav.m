% open func
% eleven_openFunc_barPlot_behav
%
% implicit input
%	current_data
%	Factor_name_current
%	extra options of plot properties
% output
%	typical bar plot
%		plus CI and x label
%		extra options of data properties
%
% Update history
% 2024-05-13
%   add bar_plot_type, bar_plot_type=1 common bar plot; bar_plot_type=2 bar with dots
%   of indivisual data
% 2024-05-07 intial version

%---
if bar_plot_type == 1
    
    width=0.5;
    color=[0.4 0.4 0.4];
    
    figure;
    bar([nanmean(current_data)],width,'FaceColor',color,'EdgeColor',color);
    hold on
    errorbar([nanmean(current_data)],[nanstd(current_data)],'color',[0.2 0.2 0.2],'Linestyle','None','LineWidth',1.5);
    
    set(gca,'Fontname','Arial','Fontsize',12);
    set(gca, 'XTick', sort(1:size(current_data,2)));
    set(gca,'XTickLabel',Factor_name_current);
    
end

%---
if bar_plot_type == 2
    
    dataset=current_data;
    ndata=size(dataset,1);
    ndataset=size(dataset,2);
    dataset_mean=zeros(1,ndataset);
    dataset_std=zeros(1,ndataset);
    dataset_ci=zeros(1,ndataset);
    for ii=1:ndataset
        dataset_mean(ii)=mean(dataset(:,ii));
        dataset_std(ii)=std(dataset(:,ii));
        [~,~,ci] = ttest(dataset(:,ii));
        dataset_ci(ii)=dataset_mean(ii)-ci(1);
    end
    
    figure;
    hold on;
    
    x1=zeros(1,ndataset); % for xtick drawing bar
    x2=zeros(size(dataset)); % for xtick for drawing ddots
    for ii=1:ndataset
        x1(ii)=0.5+1.5*(ii-1);
        x2(:,ii)=x1(ii)*ones(1,ndata);
    end
    
    %draw bar
    width=0.5;
    face_color=[0.8 0.8 0.8];
    
    bb=bar(x1,dataset_mean,width,'FaceColor',face_color);hold on;
    bb.FaceColor = 'flat';
    
    % draw error bar
    errorbar(x1, dataset_mean, dataset_ci, 'k', 'linestyle', 'none', 'lineWidth', 1,'CapSize',25);hold on;
    
    Yaxis_range=[min(min(current_data))-0.5 max(max(current_data))+0.5];
    set(gca,'Fontname','Arial','Fontsize',32);
%     ylabel('Stability Difference','FontName','Arial','FontSize',32,'Rotation',90);
    set(gca, 'XTick', sort(x1));
    axis([0,x1(end)+0.5,Yaxis_range]);
    set(gca,'XTickLabel',Factor_name_current);
    set(gcf,'unit','centimeters','position',[5 0 60 45]);
    
    % draw dots
    swarmchart(x2,dataset,60,'k','filled','XJitterWidth',0.2,'Xjitter','rand');
    box on;
end

