function ch_bad = eleven_eeg_identify_badch
% first clean_artifacts, which will ease the much difficulty (thus manual labor) in
%   1. identify bad chs and 2. ica.
%   notebally, this is actually a rea-time algorithm to remove noise, compared to ica.
%           by doing this first, ica will be much easier and actually not an issue anymore.
% Input
% 
% Output
% ch_bad -- bad channel
% todo
%   further check input ch, use all, or specified
%   whether param need optimization or confirm
% update history
% 2023-04-12
%   # minor update to clarify the logic.   
%   # assign rejchan_threshold = 15->10 for biosemi resting EEG data;
%             rejchan_threshold = 20->15 for egi resting EEG data.
%   logic: a balance -> decision: avoid missing
%       # if missed, 1. require manual check; which 2. makes automatic
%       analysis (e.g., covariance matrix; predict using multiple features)
%       involving multiple chs impossible
%       # if good judged as bad, not an issue, as long as not too many.
%       andy will interpolate, rather than reject bad ch.
%   note: can try even stricter threshold, if there are still missed.
% 2022-10-13
%   1. add clean_artifacts for biosemi resting EEG data.
%   2. assign rejchan_threshold = 15 for biosemi resting EEG data;
%             rejchan_threshold = 20 for egi resting EEG data.
% 2022-04-08
%   bug fix: for egi data, following save eeg_raw_pp.set, add save eeg_raw_pp.mat
%   !!! Note, about the logic for egi clean_artifacts.
%       1. This 'clean' cannot distinguish between badch and noise, it clean both. 
%       2. This 'clean' is strong.
%       as the result,
%           1. It already do the clean job. ica is now just supplementary.
%           2. the returned ch by pop_rejchan, is now not bad ch anymore.
%               1. the returned ch  is the remaining of the clean.
%               2. pop_rejchan is also supplementary.
%       3. For typical procedure identify bad ch and remove badch, as for biosemi,
%           eeg_raw_pp.set and eeg_raw_pp.mat are (1)from ppNormal; (2)replace bad ch; (3) enter into ica.
%          !!! when add clean_artifacts, as for egi,
%           eeg_raw_pp.set and eeg_raw_pp.mat are (1)from ppNormal;(2) modified and saved; (3)replace bad ch; (4) enter into ica.
% 2021-11-13
%   separate parameters, later can enter into settings
%   load setting inside to use setting
%   import_file_type -> hidden input
% 2021-11-16 initial version

% load option
load eleven_eeg_OptionVariable_customize;

EEG = pop_loadset('eeg_raw_pp.set'); 

%--- clean data by clean_artifacts, and save both eeglab and mfeeg data
%   Note:
%       !!! this has to be done before get ch_bad, otherwise there could be no good ch in the case of large noise
%       !!! this is actually a rea-time algorithm to remove noise, compared to ica.
%           by doing this first, ica will be much easier and actually not an issue anymore.
EEG = clean_artifacts(EEG,'flatline_crit','off','highpass_band','off','chancorr_crit','off',...
    'line_crit','off','window_crit','off','window_crit_tolerances','off');
EEG = eeg_checkset(EEG);
EEG = pop_saveset(EEG,'eeg_raw_pp.set',pwd);

eeg_raw_pp=EEG.data';% bug for final data don't from the corected rbc data,20220406
save eeg_raw_pp eeg_raw_pp;

%--- get ch_bad
% Note, 
%   for systems that have default EOG chs, e.g., biosemi, 65 and 66,
%       EOG chs per se.are assumed to have large noise. thus do not treat them as bad chs.
%   for systems that do not have dfault EOG chs, e.g., egi,
%       no need to specifically treat EOG chs.
%   with or without default EOG chs, is a convential setting, and will be accordingly 
%       handled in the while pipeline invoving different softwares, just confirming consistency between softwares.  
if import_file_type == 1
    rejchan_threshold = 10;
    [~,ch_bad] = pop_rejchan(EEG,'elec',1:66,'threshold',rejchan_threshold,'norm','on');
    
    ind_65 = find(ch_bad == 65);
    ch_bad(ind_65) = [];
    ind_66 = find(ch_bad == 66);
    ch_bad(ind_66) = [];    
end
if import_file_type == 211 || import_file_type == 212
    rejchan_threshold = 15;
    [~,ch_bad] = pop_rejchan(EEG,'elec',reref_ch,'threshold',rejchan_threshold,'norm','on');
end
