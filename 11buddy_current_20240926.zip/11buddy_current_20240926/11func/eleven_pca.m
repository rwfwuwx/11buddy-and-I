function [pc_score coeff pc_explained]= eleven_pca(x,total_varience_explained_threthold)
%function [pc_score coeff pc_explained]= eleven_pca(x,total_varience_explained_threthold)
% Input:
%   x:  matrix. row: sbj. col:feature.
%   total_varience_explained_threthold: practical guide, 85
% Output:
%   pc_score: matrix. row: sbj. col:principal components.
%             The first several major pcs are returned. 
%   coeff:the linear combination of pcs by orinital features.
%       This suggests the "meanning" of a pc. e.g.:
%           special use for eeg. use coeff of a pc to plot topologic map of the pc.
%   pc_explained: how many variance of a pc explained.
%
% other parameters see pca.m
%
% Note
% Update history
%   2022-08-07 
%       set pc num automatically
%       add return pc_explained
%   2022-08-02 total_varience_explained_threthold 95->80. pca algorithm: eig -> svg
%   2022-07-07 initial version.

[coeff,score,latent,tsquared,explained] = pca(x);

% automatically get number of pcs according to total_varience_explained_threthold
component_num_auto = 0;
for i = 1:length(explained)
    if sum(explained(1:i))>=total_varience_explained_threthold
        component_num_auto = i;
        break;
    end
end

% return 
pc_score = score(:,1:component_num_auto);
pc_explained = explained(1:component_num_auto);


