function idxNum_ch_interest = eleven_select_ch_interest_AlphaPeak(snr,snr_threshold,pVal_threshold_interest,two_or_one_tail)
% Input
%   snr --- AlphaPeak snr (later extand to ssep snr)
%   snr_threshold
%   two_or_one_tail: 1 deault two tail; 0 one tail
% todo
%   check one-side vs. two-side.
% Note
%   Now specific to AlphaPeak, later extend to be more general.
%   for AlphaPeak, snr_threshold set to 1. 
%       i.e., whether the peak is larger than background.
%   (for ssep peak, snr_threshold set to the specific snr, 
%       i.e., whether the peak is larger than a specific standard value.)
% Update history
% 2022-08-11 separate pVal_threshold_interest
% 2022-08-10 correction of last line
% 2022-08-08
%   line31,48: p_threshold -> pVal_threshold
% 2022-08-04
%   add two_or_one_tail
%   other minor updates
%   remove input parameter is_source. 
% 2022-07-19
%   modified from analysis_20220515_sensor_ch_interest.mlx

pVal=ones(size(snr,2),1);

for ii = 1:size(snr,2)
    if two_or_one_tail == 1
        % two-tail for larger than snr_threshold
        [h,p,ci,stats] = ttest(snr(:,ii)-snr_threshold);
        if p<=pVal_threshold_interest && stats.tstat>0
            pVal(ii) = p;
        end
    end
    
    if two_or_one_tail == 0
        % one-tail for larger than snr_threshold
        
        [h,p] = ttest(snr(:,ii),snr_threshold,'Tail','right');
        if p<=pVal_threshold_interest
            pVal(ii) = p;
        end
        
    end

end

idxNum_ch_interest = find(pVal<=pVal_threshold_interest);
