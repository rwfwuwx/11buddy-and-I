function drawBrainNode_numlabel(roi,type)

% text = importdata('Desikan-Killiany68.node');
% text = importdata('brain_node.node');
load brain_node
text_w = brain_node(roi,:);
dlmwrite('tmp_node.node', text_w,'delimiter',' ','newline','pc');
% for ii = 1:length(roi)
% %     text_w(:,ii) = text(:,roi(ii));
%     text_w = brain_node(roi(ii),:);
%      dlmwrite('tmp_node.node', text_w, '-append','delimiter',' ');
% %      dlmwrite('tmp_node.node', text_w{ii}, 'delimiter','','-append');
% %     dlmwrite('tmp_node.node', text_w, '-append');
% end

if type == 1
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_2_small_dot.mat');
end
if type == 2
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_3_small_dot.mat');
end

if type == 0
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_0.mat');
end

%{
if type == 1
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_2.mat');
end
if type == 2
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_3.mat');
end

if type == 0
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_1.mat');
end
%}

saveas(gca, '1.jpg')
close
figure;imshow('1.jpg')
end
