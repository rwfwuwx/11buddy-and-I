function eleven_bar_plot(data1,data2,Title,label,p_value,width,color,fontSize,is_new_figure_window)       
% data: n*2 matrix
% title: string
% label: 1*2 cell with string
% p_value: num
% width: num, default is 0.5. the width of bars
% color: 1*3 matrix, default is [0.3 0.3 0.3]. the color of bars
% fontSize: num, default is 15
% is_new_figure_window: 0 or 1
% % fnum: num, default is 2. set floating-point num


% ---update history---
%   2023-12-26 add is_new_figure_window
%   2023-12-20 comment figure;
%   2022-07-27 Input data->data1,data2
%   2022-06-24 add width, color, fnum
%   2021-11-05 add fontSize
%   2021-11-04 initial version

if nargin~=9
    disp('mf_drawerp requires 9 arguments!');
    return;
end

if isempty(width)==1
   width=0.5;
end

if isempty(color)==1
   color=[0.4 0.4 0.4];
end

if isempty(fontSize)==1
   fontSize=15;
end

% if ~isempty(fnum)
%     f=['%.' num2str(fnum) 'f'];
% else
%     f='%.2f';
% end

if is_new_figure_window
    figure;
end
bar([nanmean(data1),nanmean(data2)],width,'FaceColor',color,'EdgeColor',color);
hold on
errorbar([nanmean(data1),nanmean(data2)],[nanstd(data1),nanstd(data2)],'color',[0.2 0.2 0.2],'Linestyle','None','LineWidth',1.5);
mean_diff = nanmean(data2) - nanmean(data1);
title({Title;['es =', num2str(mean_diff,'%.2f'),'; p=', num2str(p_value,'%.3f')]},'FontSize',fontSize);
set(gca,'XtickLabel',label,'FontSize',fontSize);
hold off
axis square



