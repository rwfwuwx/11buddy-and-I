% open func
% 为每个groupSbjIndexDataName_Name，根据相应value, 生成（并save）索引
%   索引名为analysis_sbjIndex_[Name]
% 
% Input
%   --- groupSbjIndexDataName
%   --- groupSbjIndexDataName_Name
%   --- groupSbjIndexDataName_Value
%   these inputs now read from the CondGroup excel file in ada_report_birdview.m.
%       and load in ada_report_.m. They are, e.g.,
%[
% groupSbjIndexDataName = {...
%     'NormalPatient_doctor',...
%     'InterventionType',...
%     'PrePost'...
%     };
% groupSbjIndexDataName_Name = {...
%     {'Patient','Normal'},...
%     {'InterventionType1','InterventionType12','InterventionType2','InterventionType3','InterventionType4'},...
%     {'Pre','Post'}...
%     };
% groupSbjIndexDataName_Value = {...
%     {1,2},...
%     {1,12,2,3,4},...
%     {1,2}...
%     };
%]
%
%Output
%   for the above example, the outputs are analysis_sbjIndex_
%       Patient/Normal
%       InterventionType1/12/2/3/4
%       Pre/Post
%
% Update history
%   2023-12-12 
%       add description
%   2022-08-03 to open func
%   2022-06-23 initial version 

tmp_DataName = groupSbjIndexDataName;
tmp_DataName_DataName = groupSbjIndexDataName_Name;
tmp_DataName_Value = groupSbjIndexDataName_Value;
for ii = 1:length(tmp_DataName)
    tmp_name = tmp_DataName{ii};
    eval(sprintf('tmp_data = %s;',tmp_name));
    tmp_len=length(tmp_DataName_DataName{ii});
    for jj = 1:tmp_len
        t=tmp_DataName_DataName{ii};
        tmp_name_1=t{jj};
        
        t=tmp_DataName_Value{ii};
        tmp_value_1=t{jj};
        
        tmp_assign_name = ['analysis_sbjIndex_' tmp_name_1];
        tmp_index = zeros(length(sbj),1);
        tmp_index(find(tmp_data==tmp_value_1))=1;
        eval(sprintf('%s = tmp_index;',tmp_assign_name));
        
        eval(sprintf('save %s %s;',tmp_assign_name,tmp_assign_name));
    end
end