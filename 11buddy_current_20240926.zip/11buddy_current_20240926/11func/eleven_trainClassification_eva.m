function [accuracy,cc]= eleven_trainClassification_eva(y,y_fit)
% accuracy = eleven_trainClassification_eva(y,y_fit)
%   see eleven_trainClassification.m.
%   accuracy: The proportion of correctly classified.
%
% Update history
%   2024-06-20 add todo
%   2022-07-07 initial version
% Todo
%   substantial improve presentation (metric and plot) of classification
%   further clariry/optimize code

correctPredictions = (y_fit== y);
isMissing = isnan(y);
correctPredictions = correctPredictions(~isMissing);
accuracy = sum(correctPredictions)/length(y);
%  accuracy = sum(y == y_fit)/length(y);

tmp = unique(y);
ind = find(isnan(tmp) == 0);
classNum = tmp(ind);
cc = zeros(length(classNum),length(classNum));
for ii = 1:length(classNum)
    for jj = 1:length(classNum)
        ind_y = find(y == classNum(ii));
        cc(jj,ii) = sum(y_fit(ind_y) == classNum(jj));
    end
end
ColIndexName = cell(length(classNum),1);
for ii = 1:length(classNum)
    ColIndexName{ii}= ['observed-' num2str(classNum(ii))];
end
RowIndexName = cell(length(classNum),1);
for ii = 1:length(classNum)
    RowIndexName{ii}= ['predicted-' num2str(classNum(ii))];
end

T=array2table(cc,'VariableNames',ColIndexName,"RowNames",RowIndexName)






