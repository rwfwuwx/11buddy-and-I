% openFunc eleven_openFunc_eeg_TimeFreq_to_datapoint
% (hidden)Input
%   assume already in the func_path containing function data 
%   time_range, in second
%       [time1 time2]: a time range from time1 to time2 (time1<time2)
%           if time1==time2: return one data point
% (hidden)Output
%   time_disp
%   time_disp_init_point
%   time_disp_end_point
%   freq_disp
%   freq_disp_init_point
%   freq_disp_end_point
%   (the meaning of the output is same as andy image)
% Note
%   
% Todo
%   
% Update history
%   2024-09-18
%       simply tell the required time/freq range to time/freq disp
%           at where indicated by 'set customized time range' / 'set customized freq range'
%           ! i.e., let andy do it; and what extra should I do
%       keep the parts calculating time and freq
%       initial version, modified from eleven_eeg_resultImage.


% |------------------------------------------|
% |------ load options, set options ---------|
% |------------------------------------------|

% --- for time
load fs;
time_step = 1/fs;

%--- exp setting/param
load eleven_eeg_OptionVariable_customize;

load eeg_analyze_type;

load eeg_type;
load import_file_type;


% |------------------------------------------|
% |------------------ er srer ---------------|
% |------------------------------------------|

if eeg_analyze_type == 2 || eeg_analyze_type == 42
    if eeg_analyze_type == 2
        time = -epoch_points_before_onest*time_step:time_step:epoch_points_after_onest*time_step; %: whole epoch length
        time = round(time*1000)/1000; % (avoid non-integer in ms)
        %time_disp = -actual_epoch_points_before_onest*time_step:time_step:actual_epoch_points_after_onest*time_step; % actual epoch length without padding
        time_disp = time_range(1):time_step:time_range(2); % set customized time range
        time_disp = round(time_disp*1000)/1000;% 
    end
    if eeg_analyze_type == 42
        time = -cond_IOI-padding_points*time_step:time_step:cond_IOI*2+padding_points*time_step; %: whole epoch length
        time = round(time*1000)/1000; % (avoid non-integer in ms)
        %time_disp = -cond_IOI:time_step:cond_IOI*2; % actual epoch length without padding
        time_disp = time_range(1):time_step:time_range(2);% set customized time range
        time_disp = round(time_disp*1000)/1000;
    end
    time_disp = time_range(1):time_step:time_range(2);
    time_disp = round(time_disp*1000)/1000;% (avoid non-integer in ms)
        
    time_disp_lim = [time_disp(1),time_disp(end)]; % start and end time points to display, used in "lim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
    % start and end sample points in data.
    time_disp_init_point = find( time==time_disp(1) );
    time_disp_end_point = find( time==time_disp(end) );
    
    % --- for freq
    % same prosesses for freq as that for time above
    freq = tf_frequency_range; % all freq
    %freq_disp = 4:freq(end); % freq to display.  used in "freq" parameter in mf_drawtf, mf_drawsyn
    freq_disp = freq_range(1):freq_range(2);% set customized freq range
    freq_disp_lim = [freq_disp(1),freq_disp(end)];% start and end freq points to display, used in "clim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
    % start and end frequency sample points in data.
    freq_disp_init_point = find( freq==freq_disp(1) );
    freq_disp_end_point = find( freq==freq_disp(end) );
end

% |----------------------------------------------|
% |------------------  resting ------------------|
% |----------------------------------------------|
if eeg_analyze_type == 1
    
    % --- spec
    load eeg_resting_spec_freq;
    
    freq = eeg_resting_spec_freq; % all freq
    
    freq_step = fs/2/(length(freq)-1);
    
    %freq_disp_init_plan = 1; freq_disp_end_plan= 47; % freq range planed to display.
    freq_disp_init_plan = freq_range(1); freq_disp_end_plan= freq_range(2); % set customized freq range
    
    % start and end frequency sample points in data.
    freq_disp_init_point = round(freq_disp_init_plan/freq_step)+1;
    freq_disp_end_point = round(freq_disp_end_plan/freq_step)+1;
    freq_disp = freq(freq_disp_init_point:freq_disp_end_point); % actual freq to display
    
    freq_disp_lim = [freq_disp(1),freq_disp(end)];% start and end freq points to display, used in "clim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn

end

% |----------------------------------------------|
% |----------------  ssep srssep ----------------|
% |----------------------------------------------|
if eeg_analyze_type == 3 || eeg_analyze_type == 43
    
    load cond_name;
    cond_num = length(cond_name);
    
    input_freq_name = ['eeg_ssep_spec_freq' '_' cond_name{1}];
    eval(sprintf('load %s;',input_freq_name));
    eval(sprintf('freq = %s;',input_freq_name)); % all freq
    
    freq_step = fs/2/(length(freq)-1);
    
    % freq range planed to display.
    if eeg_analyze_type == 3
        %freq_disp_init_plan = 1; freq_disp_end_plan= 47;
        freq_disp_init_plan = freq_range(1); freq_disp_end_plan= freq_range(2); % set customized freq range
    end
    if eeg_analyze_type == 43
        %freq_disp_init_plan = 1; freq_disp_end_plan= 5;
        freq_disp_init_plan = freq_range(1); freq_disp_end_plan= freq_range(2); % set customized freq range
    end
    % start and end frequency sample points in data.
    freq_disp_init_point = round(freq_disp_init_plan/freq_step)+1;
    freq_disp_end_point = round(freq_disp_end_plan/freq_step)+1;
    freq_disp = freq(freq_disp_init_point:freq_disp_end_point); % actual freq to display
    
    freq_disp_lim = [freq_disp(1),freq_disp(end)];% start and end freq points to display, used in "clim" parameter in mf_drawerp, mf_drawtf, mf_drawsyn
 
end
