% openFunc
%eleven_openFunc_dataUpdate_by_sbjIndex.m
%
% 对于输入的analysis_groupName, 如analysis_groupName{1}为‘Patient_Pre_clean’，analysis_groupName{2}为‘Patient_Post_clean’，
% 	(注：该groupName对应的索引已经是 干净的)
% 对于输入的数据类别名，如 ‘eegDataName’;
% 	及其包含数据子类别名, 如 [eegDataName([1:end])]，(e.g., Amplitude, Latency)
% 	(注：该数据已经在 去除outlier步骤，处理标记缺失值)
% 如下更新：
% 对每个数据子类别，
% 	对analysis_groupName每个group对应的 index,
% 		根据group index，获取 该group对应的 数据
% 返回 依据分组的 数据: 如，eegDataName->eegDataNameGroup
% eegDataNameGroup = {...
%     'Amplitude_Patient_Pre_clean',...
%     'Amplitude_Patient_Post_clean',...
%     'Latency_Patient_Pre_clean',...
%     'Latency_Patient_Post_clean',...
% }
%
% 简要的说，eegDataName是数据，analysis_groupName是当前分析 的数据需要
%   该函数 根据 数据需要 对应的被试索引 获取数据，
%   所以生成的数据命名为 eegDataNameGroup.
%
% 注：!!! 本步骤之前 数据为所有被试数据，例如20个被试
%   本步骤之后，依据索引 截取 了数据，
%       例如一个group索引获取了 15个被试的数据
%       另一个group索引获取了10个被试的数据
%       !!!即：本步骤之后 如果要再次索引，就要二级(/三级)索引。!!!严格避免多级索引。
%       !!!!!!如果需要新的索引的数据，在此步骤之前处理。
%
% (注：analysis_groupName 默认初始赋值为[],
%       if not use group info, use the data directly
%       if use group info,set data according to group info.
%   早期手工输入 需求，直接使用数据，便于调试。
%   除调试用途，把需求放入 analysis_groupName数据结构，自动化处理需求。
%       避免由此引起的 '需求'和手工输入复杂性和混乱.
% )
%
% Input
%   --- analysis_groupName. e.g.,
%[
% analysis_groupName = {...
%     'Patient_Pre_clean' ...
%     };
% analysis_groupName = {...
%     'Patient_InterventionType1_Pre_clean', ...
%     'Patient_InterventionType1_Post_clean' ...
%     };
%]
%   --- tmpInputVar;tmpInputVar1. e.g.,
%[
% 设定 要更新 的 变量名，并如下填入：
%tmpInputVar = 'eegDataName';
%tmpInputVar1 = [eegDataName([1:end])];
%eleven_openFunc_dataUpdate_by_sbjIndex;

% 设定 要更新 的 变量名，并如下填入：
%tmpInputVar = 'clinicDataName';
%tmpInputVar1 = [clinicDataName([1:end])];
%eleven_openFunc_dataUpdate_by_sbjIndex;

% 设定 要更新 的 变量名，并如下填入：
%tmpInputVar = 'basicSbjInfoDataName';
%tmpInputVar1 = [basicSbjInfoDataName([1:end])];
%eleven_openFunc_dataUpdate_by_sbjIndex;
%]
%
% Output
%
% Update history
%   2024-05-06 redo bug fix for
%       when analysis_groupName is empty, no updating the name of updated
%   2023-12-14
%       hiden analysis_groupName -> tmpInputVar2; so that the analysis_groupName can be selected
%       the need is data substraction introduce analysis_groupName_sub1 and sub2.
%   2023-12-11 
%       add description
%   2022-10-12 bug fix for
%       when analysis_groupName is empty, no updating the name of updated
%       data and no saving updated data
%   2022-08-12 minor correction jj=length -> jj=1:length
%   2022-08-10 row cell -> column cell for better display
%   2022-08-09 bug fix for tmp_count value assignment
%   2022-08-08 bug fix for tmp_index_name value assignment
%   2022-08-04 bug fix for not adding '_' in file naming
%   2022-07-01 bug fixed
%   2022-06-30 initial version

if isempty(tmpInputVar2)
    tmp_DataNamegroup = cell(length(tmpInputVar1),1);
else
    tmp_DataNamegroup = cell(length(tmpInputVar1)*length(tmpInputVar2),1);
end

if isempty(tmpInputVar2)
    for ii=1:length(tmpInputVar1)
        tmp_name_dataType = tmpInputVar1{ii};
        tmp_name= [tmp_name_dataType '_clean'];
        tmp_DataNamegroup{ii} = tmp_name;

        eval(sprintf('tmp_data = %s;',tmp_name_dataType));
        eval(sprintf('%s = tmp_data;',tmp_name));
        sz=size(tmp_data);

        % var format: sbj*1
        if length(sz) == 2 & sz(2) == 1
            eval(sprintf('%s = %s(analysis_sbjIndex_finalClean);',tmp_name,tmp_name));
        end

        % var format: sbj*ch
        if length(sz) == 2 & sz(2) >1
            % assume nan is the same for all ch
            eval(sprintf('%s = %s(analysis_sbjIndex_finalClean,:);',tmp_name,tmp_name));
        end

        % var format: ch*ch*sbj
        if length(sz) == 3
            % assume nan is the same for all ch pair
            eval(sprintf('%s = %s(:,:,analysis_sbjIndex_finalClean);',tmp_name,tmp_name));
        end
        
        eval(sprintf('save %s %s;',tmp_name,tmp_name));

    end
end
    
if ~isempty(tmpInputVar2)
    %tmp_count = 1;
    for ii=1:length(tmpInputVar1)
        tmp_name_dataType = tmpInputVar1{ii};
        
        for jj=1:length(tmpInputVar2)
            tmp_name_group = tmpInputVar2{jj};
            tmp_count = (ii-1)*length(tmpInputVar2)+jj;
            tmp_name= [tmp_name_dataType '_' tmp_name_group];
            tmp_DataNamegroup{tmp_count} = tmp_name;

            eval(sprintf('tmp_data = %s;',tmp_name_dataType));
            eval(sprintf('%s = tmp_data;',tmp_name));
            sz=size(tmp_data);

            %tmp_index_name = ['analysis_sbjIndex_' tmp_name_group];
            eval(sprintf('tmp_index_name_data = %s;',['analysis_sbjIndex_' tmp_name_group]));
            tmp_index_name = find(tmp_index_name_data == 1);
            % var format: sbj*1
            if length(sz) == 2 & sz(2) == 1
                eval(sprintf('%s = %s(tmp_index_name);',tmp_name,tmp_name));
            end

            % var format: sbj*ch
            if length(sz) == 2 & sz(2) >1
                % assume nan is the same for all ch
                eval(sprintf('%s = %s(tmp_index_name,:);',tmp_name,tmp_name));
            end
             
            % var format: ch*ch*sbj
            if length(sz) == 3
                % assume nan is the same for all ch pair
                eval(sprintf('%s = %s(:,:,tmp_index_name);',tmp_name,tmp_name));
            end
            
            eval(sprintf('save %s %s;',tmp_name,tmp_name));
            
            %tmp_count = tmp_count+1;
        end
    end
    
end

% output use implicit output DataName
eval(sprintf('%s = tmp_DataNamegroup;',[tmpInputVar 'Group']));