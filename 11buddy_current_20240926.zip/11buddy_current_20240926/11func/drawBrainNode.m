function drawBrainNode(roi,type)

%text = importdata('Desikan-Killiany68.node');
text = importdata('brain_node.node');
text_w = cell(length(roi),1);
for ii = 1:length(roi)
    text_w{ii} = text{roi(ii)};
    dlmwrite('tmp_node.node', text_w{ii}, 'delimiter','','-append');
end
if type == 1
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_2.mat');
end
if type == 2
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_3.mat');
end

if type == 0
    BrainNet_MapCfg('BrainMesh_ICBM152_smoothed.nv','tmp_node.node','brainnetviewer_option_1.mat');
end

saveas(gca, '1.jpg')
close
figure;imshow('1.jpg')
end
