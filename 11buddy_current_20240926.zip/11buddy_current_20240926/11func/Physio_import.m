function Physio_import

clear
disp('import');

fs_origin = 2000;
trigger_input = [4:11];
physio_file = ['1resting.mat'];
exp_type = 1;

% get exp_time
[exp_time trigger_raw] = get_expTime(physio_file,fs_origin,trigger_input,exp_type);

% import EDA
[eeg_raw,eeg_ecd] = eleven_physio_import_data(physio_file,3,exp_time,1,100,fs_origin,trigger_raw);

% import rsp
[respi_raw,respi_ecd] = eleven_physio_import_data(physio_file,2,exp_time,0,100,fs_origin,trigger_raw);

% import ecg
[heart_raw,heart_ecd] = eleven_physio_import_data(physio_file,1,exp_time,0,100,fs_origin,trigger_raw);

save eeg_raw eeg_raw
save heart_raw heart_raw
save respi_raw respi_raw
save eeg_ecd eeg_ecd
save respi_ecd respi_ecd
save heart_ecd heart_ecd
save exp_time exp_time

disp('import done');

end