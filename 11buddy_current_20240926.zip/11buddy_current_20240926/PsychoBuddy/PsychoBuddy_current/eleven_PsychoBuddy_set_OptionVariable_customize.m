function eleven_PsychoBuddy_set_OptionVariable_customize
% eleven_PsychoBuddy_set_OptionVariable_customize	
% Usage
%   eleven_PsychoBuddy_set_OptionVariable_custermize
%
% Update history 
%   2023-02-23 fix the bug that changing pot_type whereas port address does
%       not change accordingly
%   2020-09-18 build

clear; % do not remove this

load eleven_PsychoBuddy_OptionVariable;

% |--- add custermized options here, if there are ---|
%   custermized options are produced by: 
%       1. copy to-be-change default options in eleven_PsychoBuddy_set_OptionVariable.m here 
%       2. modify here as needs
%       3. run eleven_PsychoBuddy_set_OptionVariable_custermize here (make sure in the current program directory)

%|--- begin setting ---|



%|--- end setting ---|

% below handling situations where parametr seting chage other seting
% port address
if trigger_study_type == 2 || trigger_study_type == 3
    if port_type == 1
        %{
        if which_system == 1
            % linux: handle later as needs.
        end
        %}
        if which_system == 2
            parallel_port_address = '0378';  %standard parallel (LPT1) port address. (Check this on new computers)
        end
        %{
        if which_system == 3
            % mac: handle later as needs.
        end
        %}
    end
    
    if port_type == 2
        if which_system == 1
            usbModems = dir('/dev/ttyACM*');
            parallel_port_address = fullfile('/dev',usbModems(1).name);
        end
        if which_system == 2
            parallel_port_address = 'COM9';  % (Check this on new computers, and double check if it is changed every time usb2plp is plugged)
        end
        if which_system == 3
            usbModems = dir('/dev/cu.usbmodem*');
            parallel_port_address = fullfile('/dev',usbModems(1).name); % check this before use
            %parallel_port_address = '/dev/cu.usbmodem1421';
        end
    end
    
end


% --- save
save eleven_PsychoBuddy_OptionVariable_customize;

clear; % do not remove this
