function eleven_PsychoBuddy_set_OptionVariable
% eleven_PsychoBuddy_set_OptionVariable	
% Usage
%   eleven_PsychoBuddy_set_OptionVariable
% external varialbe (add later)
%  -- output
%
% Update history 
%   2024-09-09
%   ---minor adjust flip_ahead_time 0.005->0.004., i.e., a bit more time foryangyang to do it's job.
%   further description of related param
%       flip_ahead_time is the time saved for video card to flip
%       (frame time - flip_ahead_time) is the duration where yangyang do the job); 
%       given flip_ahead_time of 5 ms, it is 
%           for 120 Hz: < 0.0083-0.005 = 0.003
%           for 60 Hz: < 0.0166-0.008 = 0.008
%   btw, trigger duration is a separate param (see the update history of today in the main yangyang)
%   2023-07-11 
%   ---add fMRI scanner setting
%   ---add description clarifying frame by frame program.
%       for background update, see corresponding develop document.
%       here, in short,
%           frame by frame program, set by param is_frame_by_frame_program,
%               is regarding selectively sending trigger in EEG program, 
%               rather than stim displaying per se.
%       for application, see opration manual.Shortly here, two most related/confused cases in EEG:
%           1.situations setting is_frame_by_frame_program=2 
%           2.rivalry study where trigger is determined by response recordding 
%   2023-1-17 trigger_study_type default 1->2; port_type default 1->2
%   2022-12-19 trigger_study_type default 2->1; port_type default 2->1
%   2021-07-15
%   trigger_duration = 0.025 -> 0.004; liying
%   2021-01-11
%   for display_rect, 
% 	1. change default setting to display_rect_mode = 2;
% 	2. set by visual angele
% 		Note:
% 			visual angle modulated by exp
% 			display_rect_center. initial parameter. computed by screen resolution and size.
%   2021-01-05
%       add which system and handle trigger
%       (recording, Linux part, as well as usb2plp part, were originally modified based on Zhang yang's instruction on 2020/12. )
%       flip_ahead_time: default 0.004->0.008
%   2020-09-29 small bug fix.
%   2020-09-17
%       add whether send trigger when key press (not release, which is too fast for sending trigger)
%           in situation such as rivalry exp
%       add fixation shape
%       add multiple instruction pages
%       add port type, and bit type
%       add frame by frame
%   2020-09-16 
%       add whether to display a backgroud image
%       add whether to display fixtion
%   2020-08-28 add display_rect_mode
%   2020-08-27 add image size modulation
%   2020-08-17 build.

clear; % do not remove this

% |-----------------------------------|
% |---------- system setting ---------|
% |-----------------------------------|
% which_system  1: linux; 2: windows 3: mac
which_system = 1; % (in case linux version cannot be recoganized)
if IsLinux
    which_system = 1;
end
if ispc
    which_system = 2;
end
if ismac
    which_system = 3;
end

% |-----------------------------------|
% |---------- vision setting ---------|
% |-----------------------------------|

%--- define colors
%gray_color = [70,70,70];
gray_color = [100,100,100];%relative to 2019 version, increase bright of gray
gray_color_1 = [150,150,150];
black_color = [0,0,0];
white_color = [255,255,255];
red_color = [255 0 0];
background_color = black_color;
fixation_color = gray_color_1; % relative to 2019 version, increase bright of fixation

%--- fixation options
%- fixation_size_factor
fixation_size_factor = 125; % fixation size = win_height/fixation_size_factor

%- whether display fixation
is_fixation = 1;% 1: default display; 0: no fixation

%- fixation shape
fixation_shape = 1; % 1: default dot; 2: cross (to add)

%--- define font
font_name = 'Times New Roman';
%font_name = 'Arial';

font_size_factor = 35; % font_size = round(win_height/35);

%--- For sending flip signal less than one frame ahead of the assigned to-be-flip time.
%   keep accurate frame timing,meantime without missing key checks.
%   Note,
%       (1) for 60Hz with a frame time 0.017s, this value can be enlarged to e.g., 0.006;
%           for high refresh rate,e.g., 120Hz, a frame time is 0.008, may reduce this value to, e.g., 0.003.
%       (2) In strict display situation, such as one image per frame, be sure to check the stimulus timing,
%           so that stimulus loading or calculation can be done in (frame time - flip_ahdad_time),
%           and meantime, flip_ahead_time is enough long so that flip will not be missed.
flip_ahead_time = 0.004;

%--- for background image
is_bg_image = 0; % 0: default blank; 1: a background image 'background.jpg' 

%--- for multiple instruction pages
instruction_page_num = 1; % default 1, 'instruction.jpg'; if > 1 (special cases), 'instruction.jpg' 'instruction 2-n.jpg'

% --- for frame by frame program
is_frame_by_frame_program = 1; % 1: default typical program; 2: frame by frame program

% |--- for display_rect ---|
% general guidence
% setting 1. for most cases, display_rect_mode = 1;display_rect_size_factor = 1;
%   this is the setting of version 2019.
%   futher, as need, change display_rect_size_factor to scale image.
% setting 2. for specific cases that requires specific visual angle, display_rect_mode = 2, and set display rect
%   2021-01-11, change to default setting
% (Note: for more details and guidence, see '�̼���С�ӽ��������?��������.docx'.)

% display_rect_mode
%   1: according to original image size
%   2: manually define display rect, i.e., pre-defined, regardless original image size
%   3 ... : more complicated situation, add later
display_rect_mode = 2;

% scaling image size, for mode 1
    % 1: original image size
    % > 1, reduce size
    % between 0 and 1, increase size
    %   Note, this not needed for mode 2.
display_rect_size_factor = 1; % display_rect = round(rect_window./display_rect_size_factor);

% if mannully defined, set display rect, for mode 2
%   for mode 1, all []; for mode 2, set values.
%   rect and its position and be separately defined or defined combindly.

%   display_rect
%       [topleft x y, bottom right x y]. 
%   |--- set display_rect ---|
view_distance = 50; % for computer, default 50 cm. usually do not change it. for phone/pad, 30 cm; handle later when needed.
visual_angle = 8; % default 8 degree. change as needs.
%   with above parameters, stimulus size is S = eleven_visual_angle(1,8,50)=7 cm 

% screen_voxel_size
% as an example, yangyang��, 0.016 cm. get as below:
%   1. screen resolution = 1920*1080 
%   2. screen size ~= 30.7*17.3 cm (�ó��Ӳ�,"ʵ����ʾ��Ļ����",ע�ⲻ��������ʾ������)
%   3. screen_voxel_size = 30.7/1920 �� = 17.3/1080 = 0.016 cm ����/��ó���?voxel sizeӦ����ȣ�?
screen_voxel_size = 0.016; % cm

%   display_rect_center
%       center x y. []: default sereen center; if manully define, set it. 
display_rect_center = []; 


% |-----------------------------------|
% |--------- audition setting --------|
% |-----------------------------------|

% |-----------------------------------|
% |---- keyboard & related setting ---|
% |-----------------------------------|
% define key
KbName('UnifyKeyNames');

key_esc = KbName('ESCAPE'); % exit program
key_space = KbName('SPACE'); % for (experimenter/self) next step, e.g., next sequence/trial 

key_p = KbName('P');
% for option selection. typically, 1 - practice; 2 formal exp
% for sysu mri scanner response box
key_1 = KbName('1!');
key_2 = KbName('2@');
key_3 = KbName('3#');
key_4 = KbName('4$');

% for fMRI RT sig
key_s = KbName('S');

%|--- for response ---|
% a typical response setting: on the keypad of a keyboard
%   one (right) hand, index finger -- left; middle finger -- down; ring finger -- right
key_left = KbName('LeftArrow');
key_right = KbName('RightArrow');
key_down = KbName('DownArrow');

% another typical response setting: on a keyboard
%   left index finger -- f; right index finger --j; 
key_f = KbName('F');
key_j = KbName('J');

% mouse
%   not necessary. add as needs.

% response box
%   add later.


% |-----------------------------------|
% |------ port setting ------|
% |-----------------------------------|

trigger_study_type = 2; % behavior 1; default EEG/SEEG 2; fMRI 3

port_type = 2; % 1: parallel port; 2 default usb2plp (usb-parallel adapter)

bit_type = 1; % 1: default 64-bit; 2 32-bit

% port address
if trigger_study_type == 2 || trigger_study_type == 3
    if port_type == 1
        %{
        if which_system == 1
            % linux: handle later as needs.
        end
        %}
        if which_system == 2
            parallel_port_address = '0378';  %standard parallel (LPT1) port address. (Check this on new computers)
        end
        %{
        if which_system == 3
            % mac: handle later as needs.
        end
        %}
    end
    
    if port_type == 2
        if which_system == 1
            usbModems = dir('/dev/ttyACM*');
            parallel_port_address = fullfile('/dev',usbModems(1).name);
        end
        if which_system == 2
            parallel_port_address = 'COM9';  % (Check this on new computers, and double check if it is changed every time usb2plp is plugged)
        end
        if which_system == 3
            usbModems = dir('/dev/cu.usbmodem*');
            parallel_port_address = fullfile('/dev',usbModems(1).name); % check this before use
            %parallel_port_address = '/dev/cu.usbmodem1421';
        end
    end
    
end

%
trigger_duration = 0.02;

%- whether send trigger for response (key press)
is_trigger_for_response = 0; % default 0: no trigger for response; 1: trigger

% |-----------------------------------|
% |------ fMRI scanner setting ------|
% |-----------------------------------|
scanner = 1; % 1: default sysu scanner 

if scanner == 1
    TR_sig = 's';
    TR_sig_key = key_s;
end

% --- save
save eleven_PsychoBuddy_OptionVariable;

clear; % do not remove this
