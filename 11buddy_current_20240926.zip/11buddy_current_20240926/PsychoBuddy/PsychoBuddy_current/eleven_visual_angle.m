function S_or_V = eleven_visual_angle(convert_manner,V_or_S, D)
%
% Input
%   convert_manner 
%       1: given V,D ->S; S -- 2Dtand(V/2)
%       2: given S,D -> V; V -- 2atand(S/2D))
%   V_or_S -- depending on convert_manner
%       V: visual angle (in degree); 
%       S: stimulus length (in cm); 
%   D -- visual distence (in cm)
% Output
% S_or_V -- depending on convert_manner
%
% Sample usage
%   S = eleven_visual_angle(1,8, 50) 
%   V = eleven_visual_angle(2,7, 50) 
%
% update history
%   2021-01-11 modify from mf_visual_ange. script -> func
%   before 2004.

if convert_manner == 1
    S_or_V = 2*D*tand(V_or_S/2);
end

if convert_manner == 2;
    S_or_V = 2*atand(V_or_S/2/D);
end



