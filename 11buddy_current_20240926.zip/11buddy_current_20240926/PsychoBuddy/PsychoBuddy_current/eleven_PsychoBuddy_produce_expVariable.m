function eleven_PsychoBuddy_produce_expVariable
% the script template to produce exp related variables.
%
% Update history
% 2023-07-17 add baseline_crt and setting baseline_correction.mat to handle starting_rest and ending_rest
% 2023-07-11
%   ---incorparate save & report total exp time.
%   ---add handling fMRI block length.
%       Note, fMRI task is natually multiple sequence.
%       Note, in terms of block length, event related design is a special
%       case in which resting block length = 0 or small numbers.
%   ---add load Option
% 2023-07-03~11 add setting stim_trigger for the frame-by-frame program
%   for produce stim_trigger, now focus on the visual condition. Extend later.
%       input: a separate variable, named 'target_stim'. the index_num of the selected stimu.
%           e.g., for stimu 1:10, target_stim = [3], or [3 5]
% 2023-03-01 update stim_delay, when length(stim_duration)>1
% 2023-01-12 fix bug for rem, generating tim_delay/IOI_sequence/stim_sequence
% 2022-12-22
%       update stim_present_order
%       add IOI_order
%       add sequence handling, update from existing task
%       for test, update handling of stim_repetition_num, and sequence_num
%       for sequence_present_order, add basic data structure now, for later if needs.
% 2022-12-21 add saving sound_num va_pair
% 2022-12-20 done basic frame work by done sample1; incorprate sample 4. 
% 2022-12-19 template script -> func
% 2020-08-27 add trigger_study_type = 2;% behavior 1; EEG/SEEG 2; fMRI 3
% 2020-08-18 modify from 'PTB_template_produce_data_template.m'

clear;

%|---| load Option
load eleven_PsychoBuddy_OptionVariable_customize;

%|---| load param
load design_stim_mapping_v.mat;
load design_stim_mapping_a.mat;
load va_pair.mat;
load eleven_PsychoBuddy_expVariableParam_customize;

%|---| produce
if trigger_study_type == 1
    starting_rest = 1;
    ending_rest = 1;
end
if trigger_study_type == 2 % so that, leave enough begin and ending blank for eeg
    starting_rest = 5;
    ending_rest = 5;
end
if trigger_study_type == 3 % so that, leave enough begin and ending blank for fMRI
    starting_rest = 12;
    ending_rest = 12;
end

if baseline_crt==1 % setting customised begin and ending blank
    load baseline_correction.mat;
end

% va_type = 1; %default 1: v; 2: a; 3: va without va_pair 4: va with va_pair
if isempty(design_stim_mapping_a) 
    va_type = 1;
    
    pic_num = size(design_stim_mapping_v,1);
    sound_num = 0;
    va_num = 0;
end
if isempty(design_stim_mapping_v) 
    va_type = 2;
    
    pic_num = 0;
    sound_num = size(design_stim_mapping_a,1);
    va_num = 0;
end

if ~isempty(design_stim_mapping_v) && ~isempty(design_stim_mapping_a)&& isempty(va_pair)
    va_type = 3;
    
    pic_num = size(design_stim_mapping_v,1);
    sound_num = size(design_stim_mapping_a,1);
    va_num = 0;
end

if ~isempty(design_stim_mapping_v) && ~isempty(design_stim_mapping_a) && ~isempty(va_pair)
    va_type = 4;
    
    pic_num = size(design_stim_mapping_v,1);
    sound_num = size(design_stim_mapping_a,1);
    va_num = size(va_pair,1);
end

% for sequence_IOI_sequence
if sequence_num==1
    sequence_IOI = []; % just set param. no use if sequence_num==1
end
if sequence_num>1
    if strcmp(sequence_IOI_order,'random_shuffle')
        tmp_divid_num = floor(sequence_num/length(sequence_IOI));
        tmp_rem = rem(sequence_num,length(sequence_IOI));
        
        sequence_IOI_sequence_idxNum = Shuffle(1:length(sequence_IOI));
        sequence_IOI_sequence_idxNum = [repmat(Shuffle(sequence_IOI_sequence_idxNum),1,tmp_divid_num), Shuffle(1:tmp_rem)];
        sequence_IOI_sequence = zeros(1,sequence_num);
        for ii_sequence_IOI=1:length(sequence_IOI_sequence)
            sequence_IOI_sequence(ii_sequence_IOI) = sequence_IOI(sequence_IOI_sequence_idxNum(ii_sequence_IOI));
        end
    end
    if strcmp(sequence_IOI_order,'Random_even')
        sequence_IOI_sequence = unifrnd(sequence_IOI(1),sequence_IOI(2),sequence_num,1);
        
        sequence_IOI_sequence = round(sequence_IOI_sequence*1000/50)*50/1000;
    end
    if strcmp(sequence_IOI_order,'fix')
        tmp_divid_num = floor(sequence_num/length(sequence_IOI));
        tmp_rem = rem(sequence_num,length(sequence_IOI));
        
        sequence_IOI_sequence = [repmat(sequence_IOI,1,tmp_divid_num), sequence_IOI(1:tmp_rem)];
    end
end

% 1: formal; 2 test
%   all the same, exept stim_repetition_num=1
for ii_ft=1:2 
    if ii_ft==2
        stim_repetition_num = ceil(stim_repetition_num/formal_test_ratio_stim_number);
        sequence_num = ceil(sequence_num/formal_test_ratio_sequence_number);
    end
    
    stim_delay_all_sequence_tmp = [];
    IOI_sequence_all_sequence_tmp = [];
    stim_sequence_all_sequence_tmp = [];
    for ii_sequence = 1:sequence_num
        
        trial_num = (pic_num+sound_num+va_num)*stim_repetition_num;
        
        % handle different pic duration and soud duration later
        if length(stim_duration) == 1
            stim_delay = ones(1,trial_num)*stim_duration;
        end
        if length(stim_duration) == (pic_num+sound_num+va_num)
            tmp_divid_num = floor(trial_num/length(stim_duration));
            tmp_rem = rem(trial_num,length(stim_duration));
            
            stim_delay = [repmat(stim_duration,1,tmp_divid_num), stim_duration(1:tmp_rem)];
        end
        % random event type. !!! repeat this step several times to make sure that one IOI is not repeated too many times
        
        % stim_sequence
        if strcmp(stim_present_order,'random_shuffle')
            stim_sequence=[Shuffle(1:pic_num)+v_index_plus Shuffle(1:sound_num)+a_index_plus Shuffle(1:va_num)+va_index_plus];
            stim_sequence=repmat(Shuffle(stim_sequence),1,stim_repetition_num);
        end
        if strcmp(stim_present_order,'fix')
            stim_sequence=[(1:pic_num)+v_index_plus (1:sound_num)+a_index_plus (1:va_num)+va_index_plus];
            stim_sequence=repmat((stim_sequence),1,stim_repetition_num);
        end
        
        
        % IOI_sequence
        if strcmp(IOI_order,'random_shuffle')
            tmp_divid_num = floor(trial_num/length(IOI));
            tmp_rem = rem(trial_num,length(IOI));
            
            IOI_sequence_idxNum = Shuffle(1:length(IOI));
            IOI_sequence_idxNum = [repmat(Shuffle(IOI_sequence_idxNum),1,tmp_divid_num), Shuffle(1:tmp_rem)];
            IOI_sequence = zeros(1,trial_num);
            for ii_IOI=1:length(IOI_sequence)
                IOI_sequence(ii_IOI) = IOI(IOI_sequence_idxNum(ii_IOI));
            end
        end
        if strcmp(IOI_order,'fix')
            tmp_divid_num = floor(trial_num/length(IOI));
            tmp_rem = rem(trial_num,length(IOI));
            
            IOI_sequence = [repmat(IOI,1,tmp_divid_num), IOI(1:tmp_rem)];
        end
        if strcmp(IOI_order,'Random_even')
            IOI_sequence = unifrnd(IOI(1),IOI(2),trial_num,1);
            
            IOI_sequence = round(IOI_sequence*1000/50)*50/1000;
        end
        
        
        stim_delay_all_sequence_tmp = [stim_delay_all_sequence_tmp; stim_delay];
        if sequence_num>1
            if trigger_study_type == 1 || trigger_study_type == 2
                IOI_sequence(trial_num) = IOI_sequence(trial_num) + sequence_IOI_sequence(ii_sequence);
            end
            if trigger_study_type == 3
                load TR;
                %load task_block_length;
                sequence_length = sum(IOI_sequence);
                task_block_length = ceil(sequence_length/TR)*TR;
                IOI_sequence(trial_num) = IOI_sequence(trial_num) + sequence_IOI_sequence(ii_sequence)...
                    + (task_block_length -sequence_length);
            end
        end
        IOI_sequence_all_sequence_tmp = [IOI_sequence_all_sequence_tmp; IOI_sequence];
        stim_sequence_all_sequence_tmp = [stim_sequence_all_sequence_tmp; stim_sequence];
    end % end sequence loop
    
    tmp = stim_delay_all_sequence_tmp;
    % Note, the sequence data structure is 2D (each sequence is a row), and then cat to 1D (all sequence in a raw one by one).
    %   if stim_present_order is not 'fix', before cat, rearrange sequence order as needs.
    tmp = reshape(tmp',1,size(tmp,1)*size(tmp,2));
    stim_delay = tmp;
    
    tmp = IOI_sequence_all_sequence_tmp;
    tmp = reshape(tmp',1,size(tmp,1)*size(tmp,2));
    IOI_sequence = tmp;
    
    tmp = stim_sequence_all_sequence_tmp;
    tmp = reshape(tmp',1,size(tmp,1)*size(tmp,2));
    stim_sequence = tmp;
    
    trial_num=trial_num*sequence_num;
    
    exp_total_time = sum(IOI_sequence) + starting_rest + ending_rest;
    exp_total_time
    save exp_total_time exp_total_time;
    
    if trigger_study_type == 3
        task_block_length
        save fMRI_varialbe_report sequence_length task_block_length;
    end
                
    if ii_ft==1
        save eleven_PsychoBuddy_expVariable starting_rest ending_rest v_index_plus a_index_plus va_index_plus...
            pic_num sound_num va_pair trial_num stim_delay IOI_sequence stim_sequence; 
    end
    if ii_ft==2
        save eleven_PsychoBuddy_expVariable_test starting_rest ending_rest v_index_plus a_index_plus va_index_plus...
            pic_num sound_num va_pair trial_num stim_delay IOI_sequence stim_sequence;
    end
    
    %--- trigger setting for the frame-by-frame program 
    if trigger_study_type == 2 && is_frame_by_frame_program == 2 && va_type == 1
        load target_stim;
        stim_trigger=zeros(length(stim_sequence),1);
        
        tmp_stim_sequence = stim_sequence - v_index_plus;
        for ii_st=1:length(target_stim)
            tmp_index=find(tmp_stim_sequence==target_stim(ii_st));
            stim_trigger(tmp_index)=1;
        end
        
        if ii_ft==1
            save eleven_PsychoBuddy_expVariable starting_rest ending_rest v_index_plus a_index_plus va_index_plus...
                pic_num sound_num va_pair trial_num stim_delay IOI_sequence stim_sequence stim_trigger;
        end
        if ii_ft==2
            save eleven_PsychoBuddy_expVariable_test starting_rest ending_rest v_index_plus a_index_plus va_index_plus...
                pic_num sound_num va_pair trial_num stim_delay IOI_sequence stim_sequence stim_trigger;
        end
    end
    
end

clear;