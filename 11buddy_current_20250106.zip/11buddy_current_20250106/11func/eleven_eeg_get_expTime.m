function [exp_time] = eleven_eeg_get_expTime(eeg_file)
% [exp_time] = eleven_eeg_get_expTime(eeg_file,trigger_manner)
% Input
%   
% Output
%   exp_time -- 
%
% todo
%   handle sysu_neuroscan, and resting without code
% --- update history
% 2024-06-03
%   handling no trigger or with unrecognized triiger of data in bdf format.
% 2023-10-23
%   move 'short_resting_data_init_time = 30;'-> eleven_eeg_OptionVariable.mat
%   set 30->10
% 2023-10-18
%   (when data collection is not under standard conduction, the experimentor
%   does not kown the data with triggers or not. thus, analyze the data with
%   no trigger setting.) 
%   handle window popping up by setting typefield of 'code'
%   when some resting egi data actually have triggers.
% 2022-07-15 corret and optimize handling eeg time < resting_time.
% 2022-07-14 handling eeg time < resting_time.
% 2022-03-16 bug fix for defined eeg_ecd of egi without event.
% 2022-01-07 add exp_time definition of egi 128. bug fix for loading egi
% without event.
% 2021-12-16
%   update 42
%   handling exp start time < 5s
% 2021-12-11
%   add by_trigger_manner to handle conventional trigger
%       1.by yangyang's manner: i.e., keep only 11
%       2 by conventional manner: i.e., all events.
%   get ecd first, same as (i.e., keep consistent with ) eleven_eeg_import_data. then handle cut time.
%   resting_time, cond_sequence_length -> hidden input
% 2021-12-09
%   add ssep
%   correct exp_time(2) for resting
%   import_file_type,eeg_analyze_type -> hidden input
% 2021-11-17 
%   modify from eleven_eeg_import_data. 
%       others see eleven_eeg_import_data.

if nargin~=1
    disp('eleven_eeg_get_expTime requires 1 arguments!');
    return;
end

disp('get exp_time.');

% load option variable
load eeg_analyze_type;
load eleven_eeg_OptionVariable_customize;
load by_trigger_manner;
%   load sbj specify variable(that has been saved)
if eeg_analyze_type ==1;
load resting_time;
end
%--- read eeg_file.
%   ! keep the same code as eleven_eeg_import_data.m
% read by eeglab, via biosig.
% EEG is the data structure of eeglab. in which, the needed info are:
%   EEG.event
%       EEG.event.edftype: event 
%       EEG.event.latency: event time (in sample point)
if import_file_type==1
    EEG = pop_biosig(eeg_file, 'ref',[69 70] ,'refoptions',{'keepref' 'off'});
end
if import_file_type==211
    d=dir([eeg_file,'\Event*.xml']);
    if isempty(d)
        EEG = pop_mffimport({eeg_file});
    else
        EEG = pop_mffimport({eeg_file},{'code'});
    end
end
if import_file_type==212
    EEG = pop_mffimport({eeg_file},{'code'});
end

eeg_actual_total_time = length(EEG.times)/EEG.srate;

if eeg_analyze_type==1
    if eeg_actual_total_time < 3*60
        error('length of resting data < 3 min. reject this data,operator please mark this data as NaN.');
    end
end

%--- get ecd. 
%   ! keep the same code as eleven_eeg_import_data.m
eeg_ecd = [];

if ~isempty(EEG.event)
    for ii=1:length(EEG.event)
        if ~strcmp(EEG.event(ii).type,'boundary')
            ecd_tmp = zeros(1,2);
            
            % type
            if import_file_type==1
                
                if isfield(EEG.event(ii),'edftype')==0  % with unrecogniazed triggers
                    continue;
                end
               
                if isnumeric(EEG.event(ii).edftype) & ~isempty(EEG.event(ii).edftype)% number is assumed
                    ecd_tmp(1,1)= EEG.event(ii).edftype;
                    ecd_tmp(1,2) = round(EEG.event(ii).latency);
                end
                
                if ischar(EEG.event(ii).edftype)
                    if ~isempty(str2num(EEG.event(ii).edftype)) % letter(s) is not assumed. But number may be in char format, e.g. '3'.
                        ecd_tmp(1,1)= str2num(EEG.event(ii).edftype);
                        ecd_tmp(1,2) = round(EEG.event(ii).latency);
                    end
                end
            end
            
            if import_file_type==212
                % assume manual trigger is 'eyec'.
                if EEG.event(ii).code == 'eyec';
                    ecd_tmp(1,1)= 11;
                    ecd_tmp(1,2) = round(EEG.event(ii).latency);                    
                end
            end
            
            % latency
%             ecd_tmp(1,2) = round(EEG.event(ii).latency);
            
            eeg_ecd = [eeg_ecd;ecd_tmp];
        end
    end  
end

% when data didn't mark trigger or trigger is not as assumed 'eyec'.
if isempty(eeg_ecd)
    ecd_tmp(1,1)= 11;
%     short_resting_data_init_time = 30;
    ecd_tmp(1,2)= short_resting_data_init_time*EEG.srate;
    eeg_ecd = [eeg_ecd;ecd_tmp];
    
elseif import_file_type==211 || eeg_ecd(2) == 0 
    ecd_tmp(1,1)= 11;
%     short_resting_data_init_time = 30;
    ecd_tmp(1,2)= short_resting_data_init_time*EEG.srate;
    eeg_ecd = [eeg_ecd;ecd_tmp];
end


%--- further handling of eeg_ecd before get exp time
% convert time point to time
eeg_ecd(:,2) = eeg_ecd(:,2) ./  EEG.srate;

% if by yangyang's manner, keep only 11 event
%   if by conventional manner, just use all events in eeg_ecd
if by_trigger_manner == 1
    tmp_index = find(eeg_ecd(:,1)~=11);
    eeg_ecd(tmp_index,:) = [];
end


%--- get exp_time
exp_time = zeros(1,2);

% resting
if eeg_analyze_type==1
    if import_file_type==1 || import_file_type==212 % biosemi and egi with code
        if by_trigger_manner == 1 || by_trigger_manner == 2 % yangyang and conventional manner, the same handling here
            % ! note, for conventional manner, first event may not be the starting event while must before it,
            %   in this case, just do preAna first, and handle before dataAna.
            exp_time(1) = eeg_ecd(1,2) - rawdata_padding_time;
            % handling exp start time < 5s. exp start time is the code starting time.
            %   assume two rawdata_padding_time of code ending time.
            if exp_time(1)<0
                exp_time(1) = exp_time(1)+rawdata_padding_time;
            end
            exp_time(2) = exp_time(1) + rawdata_padding_time + resting_time + rawdata_padding_time;
            % handling eeg time < resting_time. So change resting_time.
            %   eeg_actual_total_time = 2*rawdata_padding_time + resting_time +2* rawdata_padding_time;
            if eeg_actual_total_time<(exp_time(2)-exp_time(1))
                resting_time = eeg_actual_total_time - 4*rawdata_padding_time;
                exp_time(2) = exp_time(1) + rawdata_padding_time + resting_time + rawdata_padding_time;
             % resave resting_time. first time save in eleven_GLAutojob_routine_eegSetInitParam.m line 81.
                save resting_time resting_time;
             % mark this short data by short_resting_time.mat
                short_resting_time = 1;
                save short_resting_time short_resting_time;
            end
        end
    end
    
    if import_file_type==211 % egi without code
        if by_trigger_manner == 1 || by_trigger_manner == 2 % yangyang and conventional manner, the same handling here
            % ! note, for conventional manner, first event may not be the starting event while must before it,
            %   in this case, just do preAna first, and handle before dataAna.
            exp_time(1) = short_resting_data_init_time;
            exp_time(2) = exp_time(1) + rawdata_padding_time + resting_time + rawdata_padding_time;
            % handling eeg time < resting_time. So change resting_time.
            %   eeg_actual_total_time = 2*rawdata_padding_time + resting_time +2* rawdata_padding_time;
            if eeg_actual_total_time<(exp_time(2)-exp_time(1))
                resting_time = eeg_actual_total_time - 4*rawdata_padding_time;
                exp_time(2) = exp_time(1) + rawdata_padding_time + resting_time + rawdata_padding_time;
            % resave resting_time. first time save in eleven_GLAutojob_routine_eegSetInitParam.m line 81.
                save resting_time resting_time;
            % mark this short data by short_resting_time.mat
                short_resting_time = 1;
                save short_resting_time short_resting_time;
            end
        end
    end
end

% er and sr. note sr is the same as er when cut data.
if eeg_analyze_type==2 || eeg_analyze_type==4 || eeg_analyze_type==42
    if import_file_type==1 % biosemi
        if by_trigger_manner == 1 || by_trigger_manner == 2 % yangyang and conventional manner, the same handling here
            exp_time(1) = eeg_ecd(1,2) - rawdata_padding_time;
            exp_time(2) = eeg_ecd(end,2) + rawdata_padding_time;
        end
    end
end

% ssep
%   the difference with 12 is that, the last event needs adding cond_sequence_length
if eeg_analyze_type==3
    if import_file_type==1 % biosemi
        if by_trigger_manner == 1 || by_trigger_manner == 2 % yangyang and conventional manner, the same handling here
            % ! note, for conventional manner, 
            %   first event may not be the starting event of the first sequence  while must before it,
            %   last event  may not be the starting event of the last sequence  while must after it,
            %   in this case, just do preAna first, and handle before dataAna.            
            exp_time(1) = eeg_ecd(1,2) - rawdata_padding_time;
            exp_time(2) = eeg_ecd(end,2) + cond_sequence_length + rawdata_padding_time;
        end
    end
end


disp('get exp_time done.');


