function freq_point = eleven_freq2point(freq,freq_resolution)
% freq_point = eleven_freq2point(freq,freq_resolution)
% 
% Usage
%
% Input
%
% Output
%
% Update history
%   2022-06-22 initial version.  Make this often use conversion a func.

freq_point = round(freq ./ freq_resolution)+1;

