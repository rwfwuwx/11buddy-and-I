function [ch_StartEnd_coord] = eleven_seeg_init_chStartEndCoord(ch_label_cell,ch_grouping)
% [ch_StartEnd_coord] = eleven_seeg_init_chStartEndCoord(ch_label_cell,ch_grouping)
% Input
%   
% Output
%   ch_StartEnd_coord.
%
% Note & todo
%
% --- update history
%2024-05-01
%   Update the calculation of the name and number of ch_label
% 2023-11-16
%   initial version.

if nargin~=2
    disp('eleven_seeg_init_chStartEndCoord requires 2 arguments!');
    return;
end


ch_num = max(ch_grouping);

% 8: start label, end label, and x y z for each 
ch_StartEnd_coord = cell(ch_num,8); 

count_index=0;
for ii = 1:ch_num
    contact_num_of_ch = length(find(ch_grouping==ii));
    
    tmp_ch_label = char(ch_label_cell{count_index+1,1});
    ch_label_name_first = strrep(tmp_ch_label,'''','');
    if contact_num_of_ch < 10
        ch_label_name_last = strrep(ch_label_name_first,'1',num2str(contact_num_of_ch));
    else
        ch_label_name_last = strrep(ch_label_name_first,'01',num2str(contact_num_of_ch));
    end
    
    ch_StartEnd_coord{ii,1} = ch_label_name_first;
    ch_StartEnd_coord{ii,2} = ch_label_name_last;
    
   % ch_StartEnd_coord{ii,1} = ch_label_cell{count_index+1,1};
   % ch_StartEnd_coord{ii,2} = ch_label_cell{count_index+contact_num_of_ch,1};
    count_index=count_index+contact_num_of_ch;
end
