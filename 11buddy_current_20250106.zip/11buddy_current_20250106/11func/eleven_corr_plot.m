function eleven_corr_plot(data1,data2,Xlabel,Ylabel,title_name,p_value,r_value,width,color,lineColor,size,fontSize,labelSize,axisSize,titleSize)       
% data1: 1*N or N*1 matrix
% data2: 1*N or N*1 matrix
% Xlabel: string
% Ylabel: string
% p_value: num
% r_value: num
% width: num, the width of line, default is 1.5.
% color: 1*3 matrix, num in the matrix <1. the color of maker and line, default is [0.3 0.3 0.3]
% size: num, the size of maker, default is 8
% fontSize: num, default is 15

% todo
% update history
% 2022-09-14
%   add axis square
% 2022-09-09 
%   delete text. add bold
% 2022-07-19
%   add labelSize,axisSize,titleSize. not bold
% 2022-07-18
%   change title.
% 2022-07-04
%   modified from eleven_corr_plot_220624


if isempty(width)==1
    width = 1.5;
end
if isempty(color)==1
    color = [0.3 0.3 0.3];
end
if isempty(size)==1
    size = 8;
end
if isempty(fontSize)==1
    fontSize = 15;
end


lim_scale = 0.5;

%figure;

plot(data1,data2,'o','MarkerEdgeColor',color,'MarkerFaceColor',color,'MarkerSize',size);
h=lsline;
set(h,'LineWidth',width,'Color',lineColor); 

xlabel(Xlabel,'FontSize',labelSize,'FontWeight','bold');
ylabel(Ylabel,'FontSize',labelSize,'FontWeight','bold');
set(gca,'FontSize',fontSize,'FontWeight','bold');
%title({title_name; ['r=',num2str(r_value,'%.2f'),'; p=', num2str(p_value,'%.3f')]},'FontSize',titleSize);
title(title_name,'FontSize',titleSize,'FontWeight','bold');

%text(max(data1)*0.9,max(data2)*0.9,['r = ' num2str(r_value,'%.2f')],'fontsize',labelSize);
ax = gca();
ax.XAxis.FontSize = axisSize;
ax.YAxis.FontSize = axisSize;
xlim([min(data1) max(data1)])

axis square
