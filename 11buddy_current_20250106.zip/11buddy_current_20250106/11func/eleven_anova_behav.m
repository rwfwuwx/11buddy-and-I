function eleven_anova_behav(dataset,Factors_current,Level_number_current,Factor_withinBetween_current,Factor_level_current,Factor_name_current,parametric_type)

% input


% call function
%     eleven_rpanova
%     eleven_rpanova_mixed

% update history
%   2024-06-19 add effect size for repeated anova;
%       update display format for repeated anova
%   2024-05-07 initial verstion

if parametric_type == 1
    factor_number=length(Factors_current);
    %---repeated ANOVA
    if unique(Factor_withinBetween_current)==1
        %   # one-way
        if factor_number==1
            
            %         dataset=current_data;
            condname=Factor_name_current;
            factorname=Factors_current;
            factorlevel=condname;
            
            %--- repeated anova
            disp('one-way repeated anova')
            [rm ranovatbl]=eleven_rpanova(dataset,condname,factorname,factorlevel)

            output_tmp=ranovatbl.Variables;
            % calculate effect size
            factor_eta2=(output_tmp(3,2)*output_tmp(3,4))/(output_tmp(3,2)*output_tmp(3,4)+output_tmp(4,2));
            
            % disp results
            main_effect=sprintf('%s: F(%d,%d)=%f, p=%f, pGG=%f, eta^2=%f',...
                Factors_current{1},output_tmp(3,2),output_tmp(4,2),output_tmp(3,4),...
                output_tmp(3,5),output_tmp(3,6),factor_eta2)
                        
        end
        
        %   # two-way
        if factor_number==2
            %dataset=current_data;
            
            condname=Factor_name_current;
            factorname=Factors_current;
            %
            factor1_level=fix(Factor_level_current./10);
            factor1_level=num2cell(factor1_level);
            for ii=1:length(factor1_level)
                factor1_level{ii}=num2str(factor1_level{ii});
            end
            factor2_level=mod(Factor_level_current,10);
            factor2_level=num2cell(factor2_level);
            for ii=1:length(factor2_level)
                factor2_level{ii}=num2str(factor2_level{ii});
            end
            factorlevel=cell(2,length(Factor_level_current));
            factorlevel(1,:)=factor1_level;
            factorlevel(2,:)=factor2_level;
            
            %--- repeated anova
            disp('two repeated anova')
            [rm ranovatbl]=eleven_rpanova(dataset,condname,factorname,factorlevel)
            
            output_tmp=ranovatbl.Variables;
            % calculate effect size
            factor1_eta2=(output_tmp(3,2)*output_tmp(3,4))/(output_tmp(3,2)*output_tmp(3,4)+output_tmp(4,2));
            factor2_eta2=(output_tmp(5,2)*output_tmp(5,4))/(output_tmp(5,2)*output_tmp(5,4)+output_tmp(6,2));
            interaction_eta2=(output_tmp(7,2)*output_tmp(7,4))/(output_tmp(7,2)*output_tmp(7,4)+output_tmp(8,2));
            
            % disp results
            main_effect1=sprintf('%s: F(%d,%d)=%f, p=%f, pGG=%f, eta^2=%f',...
                Factors_current{1},output_tmp(3,2),output_tmp(4,2),output_tmp(3,4),...
                output_tmp(3,5),output_tmp(3,6),factor1_eta2)
            main_effect2=sprintf('%s: F(%d,%d)=%f, p=%f, pGG=%f, eta^2=%f',...
                Factors_current{2},output_tmp(5,2),output_tmp(6,2),output_tmp(5,4),...
                output_tmp(5,5),output_tmp(5,6),factor2_eta2)
            interaction=sprintf('%s: F(%d,%d)=%f, p=%f, pGG=%f, eta^2=%f',...
                [Factors_current{1} '*' Factors_current{2}],...
                output_tmp(7,2),output_tmp(8,2),output_tmp(7,4),...
                output_tmp(7,5),output_tmp(7,6),interaction_eta2)

            %}
        end
        
        %   # multi-factors
        if factor_number>2
            
        end
        
    end
    
    %---ANOVA
    if unique(Factor_withinBetween_current)==2
        %   # one-way
        if factor_number==1
            %         dataset=current_data;
            
            [p,tbl] = anova1(dataset);
            disp('one-way anova')
            tbl
            
        end
        %   # two-way
        if factor_number==2
            
        end
        %   # multi-factors
        if factor_number>2
            
        end
        
    end
    
    
    %---mixed ANOVA
    if length(unique(Factor_withinBetween_current))>1
        
        %   # two-way
        if factor_number==2
            
        end
        %   # multi-factors
        if factor_number>2
            
        end
        
    end
    
end





