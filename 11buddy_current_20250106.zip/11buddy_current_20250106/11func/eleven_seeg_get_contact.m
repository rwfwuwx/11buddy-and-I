function contacts = eleven_seeg_get_contact(first_contact,last_contact,contact_num)
% function contacts = eleven_seeg_get_contact(fist_contact,last_contact,contact_num)
% get the coordinates of contacts on an electrodes, given 
%   firs_contact: the coordinates of the first contact, e.g., [-22 -13 -27]
%   last_contact: the coordinates of the last contact, e.g., [-69 -8 -17]
%   contact_num: total number of contacts on the electrode.
% --- update history
% 2020-03-18 initially written

contact_distance = (last_contact - first_contact)/(contact_num-1);

contacts = zeros(contact_num,3);
contacts(1,:) = first_contact;
% contacts(end,:) = last_contact; % check whether the calculated last contact = the input last contact

for ii=1:(contact_num-1)
    contacts(ii+1,:)=contacts(ii,:)+contact_distance;
end
%contacts = round(contacts);
