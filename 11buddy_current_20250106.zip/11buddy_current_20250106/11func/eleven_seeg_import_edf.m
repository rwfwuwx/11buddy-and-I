function [eeg_raw,ch_label,eeg_ecd] = eleven_seeg_import_edf(edf_file,ch_index_target,ch_index_trigger,cut_time,is_resample, resample_rate,trigger_type)
% [eeg_raw,ch_label,eeg_ecd] = eleven_seeg_import_edf(edf_file,ch_index_target,ch_index_trigger,cut_time,is_resample, resample_rate,trigger_type)
% Input
%   edf_file -- raw edf file
%   ch_index_target -- index of interested contacts in the edf file.
%       arrage this according to the seeg structual pipiline of XiangLab.
%   ch_index_trigger -- index of trigger channels in the edf file.
%       In shengzhongyi, 16 DC channels are added for this pupose and DC09-15 are used. A decimal trigger is coded in 7 bits in DC09-15.
%       During experiment of XiangLab, for an event, the valtage goes up for 20 ms and returns to baseline. 
%   cut_time -- the to-be-cut time range in the edf file, in seconds. as [starting_time ending_time].
%       (Note: several time ranges can be specified,
%                    separated by semicolons. Example: "5 10; 12 14" will retain
%                    the indicated times ranges 5-10 and 12-14 s). further
%                    see eeglab, pop_select.
%   trigger_type -- depending on the trigger record setting, handle trigger in different manner
%       1. shengzhongyi, or like this. use 16 DC channel to record trigger.
%           the actual trigger channel are 9-16, or 9-15, or 9-14. check
%           the actual used channels.
%       2. foshanyiyuan.
%   is_resample -- whether to resample. 1,yes; 0,no. 
%   resample_rate -- if is_resample=1, input a resample rate. if is_resample=0, input as [];
%       Notes about resample:
%       For standrized processing, better use sample rate of 1000. 
%       or, for low sample rate, use 500.
%       1) if original sample rate = 1000, or 500; no need to resample.
%       2) if sample rate > 1000, e.g., 2000, 1024;  resample to 1000.
%       or > 500, e.g., 512, resample to 500.
% Output
%   eeg_raw -- raw data in mf_eeg format.
%   ch_label -- lables of channels.
%   eeg_ecd -- ecd file in mf_eeg format.
%
% --- update history
%2024-10-09 add save eeglab format file (as eleven_eeg_import_data).
%2024-06-18
%   For flanker_DH_M and flanker_DH_C, the stimulus was not a single image, but a stimulus pair consisting of three images and coded only for the first two images.
%   so just need get the code of the second picture.(Note that this is only a temporary plan, not a general plan)
%2024-04-30
%   Chang the way the voltage_criterion are calculated.
%   for new experiment,different experimental stimuli used the same trigger
%   value, i.e. decimal 11, so no voltage was applied on one of the binary channels.
% 2020-04-22
%   add resample option
%   add trigger2ecd for foshanyiyuan 
% 2020-04-07
%   revolved the trigger issues.
% 2020-04-03 
%   done
%   to-do1, check details of voltage change, and automatic calculate baseline of trigger signal. 
%   to-do2, EEG signal data get by biosig is single, currently transform to double. later check other import tool
% 2020-04-02 initially written

if nargin~=7
    disp('eleven_seeg_import_edf requires 7 arguments!');
    return;
end

%--- read .edf file.
% read by eeglab, via biosig.
% EEG is the data structure of eeglab. in which, the needed info are:
%   EEG.data: ch*sample_points
%   EEG.chanlocs(ch).labels: ch lables.
EEG = pop_biosig(edf_file);

%--- cut data according to cut_time
EEG = pop_select(EEG,'time',cut_time);

%--- resample
if is_resample
    EEG = pop_resample(EEG,resample_rate);
end

% |----- for eeglab -----|
eeglab_save_name = 'eeg_raw';
EEG = eeg_checkset(EEG);
EEG = pop_saveset(EEG,[eeglab_save_name '.set'],pwd);

EEG.data = double(EEG.data); % somehow, the above "for eeglab" change double to single 

% |----- for mfeeg -----|
%--- get eeg signal data
tmp = double(EEG.data); %
eeg_raw = tmp(ch_index_target,:);
eeg_raw = eeg_raw'; % ch*sample -> sample*ch

%--- get ch labels
ch_label=cell(length(ch_index_target),1);
for ii=1:length(ch_index_target)
    ch_label{ii} = EEG.chanlocs(ch_index_target(ii)).labels;
end

%--- get ecd
tmp = EEG.data; %
trigger_raw = tmp(ch_index_trigger,:);
trigger_raw = trigger_raw';

if trigger_type==1
    eeg_ecd = eleven_seeg_trigger2ecd_shengzhongyi(trigger_raw);
end
if trigger_type==2
    eeg_ecd = eleven_seeg_trigger2ecd_foshanyiyuan(trigger_raw);
end

disp('import done.');


% ----------------
% --- sub-func ---
% ----------------
function eeg_ecd = eleven_seeg_trigger2ecd_shengzhongyi(trigger_raw)
% eeg_ecd = eleven_seeg_trigger2ecd_shengzhongyi(trigger_raw)
% Input
%   trigger_raw --- raw data of trigger channels. sample*ch
% Output
%   eeg_ecd -- ecd file in mf_eeg format.
%
% % Note:
% see details of testing in 'test_trigger_shengzhongyi.m'

[m,n] = size(trigger_raw);

%--- change votage values to binary values
for ii=1:n
    tmp = trigger_raw(:,ii);
    voltage_baseline = mode(tmp);
  %  voltage_criterion = voltage_baseline + (max(tmp)-mode(tmp))/4;
    voltage_criterion = voltage_baseline + (max(trigger_raw(:))-mode(tmp))/4;
    tmp(find(tmp<voltage_criterion)) = 0;
    tmp(find(tmp>=voltage_criterion)) = 1;
    trigger_raw(:,ii) = tmp;
end

%--- change DC 09-> to DC ->09. 
trigger_raw = fliplr(trigger_raw);

%--- change binary values to decimal values. 
% now it's m*1 vecotor, with trigger decimal values
trigger_raw = num2str(trigger_raw);
trigger_raw = bin2dec(trigger_raw);

%--- for ecd format, add sample points (i.e., the index of trigger values) 
% ecd format: column 1 -- event trigger value, column 2 -- sample points
eeg_ecd = [trigger_raw, [1:m]'];

%--- remove no trigger sample point, i.e., trigger value = 0
eeg_ecd(find(eeg_ecd(:,1)==0),:)=[];

%--- only need the first voltage increase, remove voltage repetition during valtage duration.
% the initial change leads to a large gap of sample rate, whereas those
%   during the valtage furation had a continue sample change of 1.
%   The gap of 20 ms (i.e., interval between stimuli) should works for typical stimulus delievering. 
%   for fast ssvep, do not send trigger for each stimuli.
% exception 1: for the first trigger, add it back with a gap. 
gap = 20;
diff_ecd = [[eeg_ecd(1,1) gap]; diff(eeg_ecd)];
eeg_ecd(find(diff_ecd(:,2)<gap),:)=[];

% --- to account for the delay of voltage rise (about 2 ms), move trigger
% time back by 1 ms.
eeg_ecd(:,2) = eeg_ecd(:,2)-1;

if ~isempty(strfind(pwd,'flanker_DH_M'))||~isempty(strfind(pwd,'flanker_FH_M'))||~isempty(strfind(pwd,'flanker_DF_M'))
    eeg_ecd_stim_pair_1 = eeg_ecd(:,1);%For flanker_DH_M, the stimulus was not a single image, but a stimulus pair consisting of three images and coded only for the first two images.
    eeg_ecd_stim_pair_2 = eeg_ecd(:,2);
    eeg_ecd_1 = eeg_ecd_stim_pair_1(2:2:480);%just get the code of the second picture.
    eeg_ecd_2 = eeg_ecd_stim_pair_2(2:2:480);
    
    eeg_ecd = [eeg_ecd_1,eeg_ecd_2];
end

if ~isempty(strfind(pwd,'flanker_DH_C'))||~isempty(strfind(pwd,'flanker_FH_C'))||~isempty(strfind(pwd,'flanker_DF_C'))
    eeg_ecd_stim_pair_1 = eeg_ecd(:,1);%For flanker_DH_M, the stimulus was not a single image, but a stimulus pair consisting of three images and coded only for the first two images.
    eeg_ecd_stim_pair_2 = eeg_ecd(:,2);
    eeg_ecd_1 = eeg_ecd_stim_pair_1(2:2:560);%just get the code of the second picture.
    eeg_ecd_2 = eeg_ecd_stim_pair_2(2:2:560);
    
    eeg_ecd = [eeg_ecd_1,eeg_ecd_2];
end

function eeg_ecd = eleven_seeg_trigger2ecd_foshanyiyuan(trigger_raw)
% eeg_ecd = eleven_seeg_trigger2ecd_shengzhongyi(trigger_raw)
% Input
%   trigger_raw --- raw data of trigger channels. sample*ch
%   for foshanyiyuan, ch=1, this is a column vector.
% Output
%   eeg_ecd -- ecd file in mf_eeg format.
%
% Note:
% see details of testing in 'test_trigger_forshanyiyuan.m'
% for foshanyiyuan, only one channel 'TRIG' records triggers, and trigger
%   values can not be accurately digitized and recognized.
%   thus set all trigger value to 1.

%--- change votage values to positive
% somehow, the values are negative
trigger_raw = abs(trigger_raw);

%--- change votage values to binary values
tmp = trigger_raw;
voltage_baseline = mode(tmp);
% use 8, a small one, to avoid missing small values. 
%   if still missing, change it to even smaller, e.g., 10.
%   on the other hand, to avoid catch noise, change it to larger on,e.g.,5.
voltage_criterion = voltage_baseline + (max(tmp)-mode(tmp))/8;
tmp(find(tmp<voltage_criterion)) = 0;
tmp(find(tmp>=voltage_criterion)) = 1;
trigger_raw = tmp;

%--- for ecd format, add sample points (i.e., the index of trigger values) 
% ecd format: column 1 -- event trigger value, column 2 -- sample points
eeg_ecd = [trigger_raw, [1:length(trigger_raw)]'];

%--- remove no trigger sample point, i.e., trigger value = 0
eeg_ecd(find(eeg_ecd(:,1)==0),:)=[];

%--- only need the first voltage increase, remove voltage repetition during valtage duration.
% the initial change leads to a large gap of sample rate, whereas those
%   during the valtage furation had a continue sample change of 1.
%   The gap of 20 ms (i.e., interval between stimuli) should works for typical stimulus delievering. 
%   for fast ssvep, do not send trigger for each stimuli.
% exception 1: for the first trigger, add it back with a gap. 
gap = 20;
diff_ecd = [[eeg_ecd(1,1) gap]; diff(eeg_ecd)];
eeg_ecd(find(diff_ecd(:,2)<gap),:)=[];

% --- to account for the delay of voltage rise (about 2 ms), move trigger
% time back by 1 ms.
eeg_ecd(:,2) = eeg_ecd(:,2)-1;




