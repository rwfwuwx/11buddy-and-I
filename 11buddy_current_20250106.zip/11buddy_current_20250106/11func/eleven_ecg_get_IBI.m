function IBI = eleven_ecg_get_IBI(rawdata,fs,padding_time,beat_threshold,is_plot_ecg)
% [rate,spec_am_raw,spec_am_norm,spec_freq] = eleven_get_ecg_rate(rawdata,fs,padding_time,FreqNorm_points)
% Input
%   is_plot_ecg --- 0 or 1. 
%       1 plot cutted, band passed, padding removed, squared ecg, to help evaluate cutting threshold. 
%       (see corresponding develop file for details)
% Output
%
% --- update history
% 2020-11-20 remove cut_time
% 2020-10-31 ��. (modify partly from eleven_get_ecg_rsp_rate.m)

if nargin~=5
    disp('eleven_ecg_get_IBI requires 5 arguments!');
    return;
end


%--- cut data according to cut_time
% cut_point = round(cut_time*fs);
% rawdata = rawdata(cut_point(1):cut_point(2));

%--- band pass filter
rawdata = mf_rawfilter(rawdata,'IIR','band pass',[4 30],4,fs);

% remove padding
padding_points = padding_time*fs;
rawdata = rawdata([padding_points+1:size(rawdata,1)-padding_points-1],:);

% normaliz by /std
rawdata = rawdata/std(rawdata);

% plot ecg 
if is_plot_ecg
    plot((0:10*fs-1)*(1/fs),rawdata(1:10*fs));
end

% thresholding
%   to 0 1
rawdata(find(rawdata<beat_threshold)) = 0;
rawdata(find(rawdata>=beat_threshold)) = 1;
%   to -1 0 1, by diff. the first point of peak will be 1.
%   note this assume a sharp peak, which should be most case.
rawdata = [0;diff(rawdata)];

% get IBI
beat_point = find(rawdata==1);
beat_time = beat_point*(1/fs);

IBI = diff(beat_time);


