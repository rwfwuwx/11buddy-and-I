function [behavData_fit_test] = eleven_BrainBehavPred_FSbyCor_TrainTest(brainData,behavData,pos_featureMask_CV,neg_featureMask_CV,learnMethod,usePosNeg)
% [behavData_fit_test] = eleven_BrainBehavPred_FSbyCor_TrainTest(brainData,behavData,pos_featureMask_CV,neg_featureMask_CV,learnMethod,usePosNeg)
%   
% Input
%   see eleven_BrainBehavPred_FSbyCor_TrainCV.m
%
% Output
%   see eleven_BrainBehavPred_FSbyCor_TrainCV.m. 
%
%Todo
%
% Update history
%   2024-06-20 
%       add handling input common feature
%       func name, 'test' -> 'TrainTest'
%   2024-06-19 handle overlap
%   2021-09-26 initial version. further see eleven_BrainBehavPred_FSbyCor_FS.m

sbj_num = size(brainData,1);
feature_num = size(brainData,2);

behavData_fit_test = zeros(sbj_num,1);
    
% if input common feature, i.e., 1*feature_num,
%   expand it to sbj_num*feature_num
if size(pos_featureMask_CV,1)==1
    pos_featureMask_CV = repmat(pos_featureMask_CV,[sbj_num,1]);
    neg_featureMask_CV = repmat(neg_featureMask_CV,[sbj_num,1]);
end

% |--- model training ---|

%- feature value summarization
% get sum values of selected features
%   Note, divide by 2 to control for the fact that matrices are symmetric
sum_pos_featureData = zeros(sbj_num,1);
sum_neg_featureData = zeros(sbj_num,1);

for ii = 1:sbj_num
    sum_pos_featureData(ii) = sum(brainData(ii,:).*pos_featureMask_CV(ii,:))/2;
    sum_neg_featureData(ii) = sum(brainData(ii,:).*neg_featureMask_CV(ii,:))/2;
end

% summed feature value -> x in the model
if usePosNeg==1
    x = [sum_pos_featureData, sum_neg_featureData];
end
if usePosNeg==2
    x = [sum_pos_featureData];
end
if usePosNeg==3
    x = [sum_neg_featureData];
end

% perform train
[Mdl,~] = eleven_trainRegression(x,behavData,learnMethod,0);


% |--- model predict ---|
% predict
behavData_fit_test = predict(Mdl,x);






