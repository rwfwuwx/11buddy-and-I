function [coef,class_pred_max_index,ACC_strict,ACC_loose,coef_diff_loose] = eleven_ClassifybyCor(trainData,testData,corMethod,fake_cor_threshold)
% [coef,class_pred_max_index,ACC_strict,ACC_loose,coef_diff_loose] = eleven_ClassifybyCor(trainData,testData,corMethod,fake_cor_threshold)
%
% Description
%   This is an extended/customized implementation of Haxby JV, Gobbini MI, Furey ML, Ishai A, Schouten JL, Pietrini P (2001) 
%       Distributed and Overlapping Representations of Faces and Objects in Ventral Temporal Cortex. Science 293:2425–2430.
%
% Input
%   trainData: matrix. features * classes. classes >1.
%   testData: matrix. features * classes. classes>=1.
%   corMethod: 'Pearson', 'Spearman'
%   fake_cor_threshold: [], no control; 0~1, the value of r, as a threshold
%       if the max is less then the threshold, the corresponding ACC is marked as nan.
%       Note, p<0.05 is also controled, as default
%
% Output
%   coef:
%       row: correspond to trainDdata; column: correspond to test data (! do not confuse row and column)
%   class_pred_max_index: for each class in testData, which class in trainData it belongs to (most like). 
%   ACC_strict: by the common sense, i.e., whether it is top most like.
%       (ACC_strict is actually equal to 100% of ACC loose).
%   ACC_loose: by haxby 2001.
%       for the between comparisons, what percent (how many) of them, within > between
%   coef_diff_loose: see update 2024-10-11
%
% Note
% --- about relationship between algorithm/ why use haxby2001
%   #typical classification
%   50_train 50_test
%   param<-model(50_train)
%   prediction<-predict(param,50_test)
% 
%    #by similarity(corr) on single_trial
%       # ie., eleven_crossCorr
%   50_train 50_test
%   avg_50_train<-avg(50_train)
%   prediction<-cor(avg_50_train,50_test)
%   (note, there are direct ref, e.g., a erp study; get it and record)
% 
%   #by similarity(corr) on avg, i.e., haxy2001
%   50_train 50_test
%   avg_50_train<-avg(50_train)
%   avg_50_test<-avg(50_test)
%   prediction<-cor(avg_50_train,avg_50_test)
%
% Update history
%   2024-10-16 add fake corr control
%   2024-10-11
%   the stat value is one accuracy. and the accuracy has only very limited number of values (even only two values for two category).
%   So, how to get a continuous stat value, particularly, for a 'continuous' random sample distribution?
%   construct a continuous stat value
%       ACC: sum( indicator(within_corr>between_corr) )/ number of within vs. between (discrete)
%       ->coef difference: sum( within_corr-between_corr))/ number of within vs. between (discrete)
%       justification: similar to fmri coef difference between condition
%   2024-09-19
%   ---Outpu
%   # add accuracy, in terms of strict,or loose criterion.
%   # add coef of cor, for reference
%   # 'TemplateClassIndex_pred' -> 'class_pred_max_index'
%   ---change 'template' -> train; 'compare' - > test
%       i.e., more with a learning words. 
%   ---change name eleven_crossCor -> eleven_ClassifybyCor, to emphasize this is a classifier 
%       i.e., emphasize aim instead of calculation
%   2024-06-19 update corr
%   2021-09-27 initial version. 

%- corr matrix
[coef,pval] = corr(trainData,testData,'Type',corMethod,'rows','complete');

%- max of the pred
[class_pred_max_value,class_pred_max_index] = max(coef);

%--- accuracy
% diag of coef. ! the max is supposed on the diag of the corr matrix.
%   below manually handling diag element, to avoid potential issue related to non-squaure matrix
%diag_coef = diag(coef);

% for control fake cor
if ~isempty(fake_cor_threshold)
    diag_coef_fake = ones(1,size(testData,2));
    for ii=1:size(testData,2)
        if coef(ii,ii)<fake_cor_threshold | pval(ii,ii)>0.05
            diag_coef_fake(ii) = nan;
        end
    end
end

%- strict accuracy
%   i.e., based on, whether the max pred is on diag
ACC_strict = zeros(1,size(testData,2));
for ii=1:size(testData,2)
    diag_value = coef(ii,ii);
    ACC_strict(ii) = diag_value == class_pred_max_value(ii); % max:1, or not max: 0
end
ACC_strict = ACC_strict*100; % convert to percent
%fake control
if ~isempty(fake_cor_threshold)
    ACC_strict = ACC_strict .* diag_coef_fake;
end

%- loose accuracy
%   i.e., based on, for the between comparisons, how many of them, within > between
ACC_loose = zeros(1,size(testData,2));
coef_diff_loose = zeros(1,size(testData,2));
for ii=1:size(testData,2)
    diag_value = coef(ii,ii);
    
    %remaining data by removing diag_value. i.e., between comparisons
    tmpdata = coef(:,ii);
    tmpdata(tmpdata == diag_value) = [];
    
    % ACC_loose: for the between comparisons, how many of them, within > between
    ACC_loose(ii) = length(find(diag_value>tmpdata));
    
    % coef_diff_loose
    coef_diff_loose(ii) = mean(diag_value-tmpdata);
end
ACC_loose = ACC_loose/(size(trainData,2)-1)*100; % convert to percent
%fake control
if ~isempty(fake_cor_threshold)
    ACC_loose = ACC_loose .* diag_coef_fake;
end








