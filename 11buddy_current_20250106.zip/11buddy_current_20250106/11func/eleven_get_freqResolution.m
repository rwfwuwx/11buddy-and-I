function freq_resolution = eleven_get_freqResolution(fs,freq)
% freq_resolution = eleven_get_freqResolution(fs,freq)
% 
% Usage
%
% Input
%
% Output
%
% Update history
%   2022-06-22 initial version.  Make this often use conversion a func.

freq_resolution = fs/2/(length(freq)-1);

