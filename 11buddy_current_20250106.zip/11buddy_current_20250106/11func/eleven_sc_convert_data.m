function eeg_raw = eleven_sc_convert_data(sc_raw,cut_time,fs_origin,is_resample,resample_rate)
% eeg_raw = eleven_sc_convert_data(sc_raw,cut_time,fs_origin,is_resample, resample_rate)
% Input
% Output
%
% --- update history
% 2020-10-30 modify from eleven_eeg_import_data.m

if nargin~=5
    disp('eleven_sc_convert requires 5 arguments!');
    return;
end


%--- cut data according to cut_time
cut_point = round(cut_time*fs_origin);
sc_raw = sc_raw(cut_point(1):cut_point(2));


%--- resample
if is_resample
    sc_raw = resample(sc_raw,resample_rate,fs_origin);
end

% treat it as eeg in following analysis
eeg_raw = sc_raw;

disp('import done.');


