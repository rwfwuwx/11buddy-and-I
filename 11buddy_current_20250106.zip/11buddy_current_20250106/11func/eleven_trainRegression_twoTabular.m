function [sig_pairs_corr,sig_pairs_pred] = eleven_trainRegression_twoTabular(tableData1,tableData2,corrType,learnMethod,threshold_corr,threshold_pred,is_plot)
% [sig_pairs_corr,sig_pairs_pred] = eleven_trainRegression_twoTabular(tableData1,tableData2,corrType,learnMethod,threshold_corr,threshold_pred,is_plot)
%
%  Input:
%   tableData1: matrix. row: sbj. col:feature.
%   tableData2: matrix. row: sbj. col:feature.
%   learnMethod: see eleven_trainRegression.
%   threshold_corr:
%   threshold_pred:
%
%  Output:
%   sig_pairs_corr and sig_pairs_pred:
%     sig corr pairs between x and y. among which, further
%         sig pred pairs between x and y. if there are,  
%             plot prediction info (todo, this can be optimized by integrating into twoTabular func per se.)
%
%   Note: currently, for each prediction, as in corr, x and y are both one dimention.
%  
%  description
%   typically, tableData1 contains brain data, tableData 2 contains behavior data.
%       the program first get one-to-one pairs showing significant correlation, among which, 
%       do one-to-one prediction and return the significant pairs during prediction.
%       Note that, the program only get the significant paires. 
%   after get the pairs, prediction details can be further gotton.
%   the routine is illustrated as below by sudo data:
%       tableData1 = randn(100,15);
%       tableData2 = randn(100,8);
%
%       [sig_pairs_corr,sig_pairs_pred] = eleven_trainRegression_twoTabular(tableData1,tableData2,'Linear',0.05,0.05)
%
%       if ~isempty(sig_pairs_pred) 
%           for ii=1:size(sig_pairs_pred,1)
%           [Mdl,y_fit_validation] = eleven_trainRegression(tableData1(:,sig_pairs_pred(ii,1)),tableData2(:,sig_pairs_pred(ii,2)),'Linear',1);
%           [R_value_validation,P_value_validation,rmse_validation] = eleven_trainRegression_eva(tableData2(:,sig_pairs_pred(ii,2)),y_fit_validation,1);
%       end
%   end
%
%
% Todo
%   add excel format
%   add multiple x->y. which requires 1. given one y, identify multiple y. 2. structure of paires from matrix to cell
%       currently, munually do multiple x.
% Update history
%   2024-06-18
%       further description
%       add is_plot
%       add Spearman
%       add option setting
%       in name, twotabular->twoTabular. also as a record,twotabular was from original 2tabular.
%   2021-11-10 add control r>0
%   2021-09-29 add corr handling nan
%   2021-09-26 initial version. 

%--- load option variable
%eleven_MLBuddy_set_OptionVariable_customize;
load eleven_MLBuddy_OptionVariable_customize;

%--- Prepare data format 

%--- sig_pairs_corr
%   this works like feature selection for later predition.
%   this also serves as a check,i.e., a weak/fake correlation is unlikely pass prediction.
[r,p] = corr(tableData1,tableData2,'Type',corrType,'rows','complete');
[index1 index2]=find(p<=threshold_corr);
sig_pairs_corr = [index1 index2];

%--- sig_pairs_corr
%   given sig_pairs_corr, keep those pass LOSO prediction, with the procedure in eleven_trainRegression.
sig_pairs_pred_index = [];
for ii=1:size(sig_pairs_corr,1)
    x=tableData1(:,sig_pairs_corr(ii,1));
    y=tableData2(:,sig_pairs_corr(ii,2));
    [~,y_fit_validation] = eleven_trainRegression(x,y,learnMethod,1);
    [R_value_validation,P_value_validation,~] = eleven_trainRegression_eva(y,y_fit_validation,corrType,0);
    if P_value_validation<=threshold_pred && R_value_validation>0
        sig_pairs_pred_index = [sig_pairs_pred_index; ii];
        %plot
        if is_plot
            eleven_trainRegression_eva(y,y_fit_validation,corrType,1);
        end
    end
end
sig_pairs_pred = sig_pairs_corr(sig_pairs_pred_index,:);
