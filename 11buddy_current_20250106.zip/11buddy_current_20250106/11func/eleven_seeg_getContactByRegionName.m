function [contact_label_cell] = eleven_seeg_getContactByRegionName(ch_label_cell,contact_region,region_name,template_type,tissue_type)
% [contact_label_cell] = eleven_seeg_getContactByRegionName(ch_label_cell,contact_region,region_name,tissue_type)
% Input
%   region_name -- pick it from contact_region
%   template_type -- currently 'brodmann', 'aal'
%   tissue_type -- 1:gray matter; 2:gray&white matter; 3: white matter
% Output
%   contact_label_cell -- col 1: contact label; col 2: index. aligned with ch_label_cell.
%       (col 2 is returned for convenience, i.e., no need to get the index of contact agrain.)
%
% Note & todo
% support input multiple regions.
% for brodmann, support differenciate left and right. (via identifying sign of x coordinate)
%
% --- update history
% 2023-11-17
%   initial version.

if nargin~=5
    disp('eleven_seeg_getContactByRegionName requires 5 arguments!');
    return;
end

contact_label_index = [];

if strcmp(template_type, 'brodmann')
    region_cell = contact_region(:,2);
end
if strcmp(template_type,  'aal')
    region_cell = contact_region(:,3);
end

tissue_cell = contact_region(:,1);


for ii = 1:size(ch_label_cell,1)
    if strcmp(region_name,region_cell{ii})
        if tissue_type == 1
            if strcmp('Gray Matter',tissue_cell{ii})
                contact_label_index = [contact_label_index;ii]; 
            end
        end
        if tissue_type == 2
            if strcmp('Gray Matter',tissue_cell{ii}) || strcmp('White Matter',tissue_cell{ii})
                contact_label_index = [contact_label_index;ii]; 
            end
        end
        if tissue_type == 3
            if strcmp('White Matter',tissue_cell{ii})
                contact_label_index = [contact_label_index;ii]; 
            end
        end
        
    end
end

contact_label_cell = cell(length(contact_label_index),2);
for ii = 1:length(contact_label_index)
    contact_label_cell{ii,1} = ch_label_cell{contact_label_index(ii),1};
    contact_label_cell{ii,2} = contact_label_index(ii);
end
