% open func
%   eleven_openFunc_dataCheck_rmOutlier.m
% 检查数据分布，去除outlier, 并 指定 是否 返回/更新  到本 分布检查/outlier去除阶段的 缺失值 被试索引数据。
% !!! Q:本步骤是否改变 输入数据？
%   A: 如果 is_rmOutlier=1，输入数据 更新为 去除outlier后的 数据.
% !!! Q: outlier 索引在什么情况下更新？
%   A: 当
%       is_rmOutlier=1
%       并且，tmp_outlier_rm_method 为 nan (通常行为；影像默认插值 不影响 缺失值)
%       并且，is_updateSbjIndexOutlierExclude = 1.
% 可以不检查分布，只想去除outlier吗？
%   A: 可以，设置 is_dataCheck = 0.
% 可以不去除outlier，只想检查分布吗？
%   A: 可以，设置  is_rmOutlier = 0.
%
% 缺失值阶段总结：续 eleven_openFunc_produceSbjIndex_NSAnaExclude.m: analysis_sbjIndex_NonStructralAnaExclude
%   本步骤生成的analysis_sbjIndex_OutlierExclude 进一步 生成了
%       outlier检测阶段 发现的缺失值
%           如果多数据 汇总
%           !!! 如果多阶段，累加.见下说明。
%   再次强调 analysis_sbjIndex_NonStructralAnaExclude 累加特性
%       analysis_sbjIndex_NonStructralAnaExclude 为 outlier缺失值 统一变量
%       当 新的有缺失值的数据加入分析时，更新。
%
% Input
%   --- sbj (sbj is just for getting the number of sbj.)
%   --- tmpInputVar. e.g., tmpInputVar = [eegDataName([1:end])];
%   --- is_reset_analysis_sbjIndex_OutlierExclude.见Update history 2023-12-12 说明。
%   --- is_dataCheck. 1 or 0. 是否检查数据分布。图示化分布，并正态检测。
%       注：对于影像数据，包含多feature(多电极/脑区)，随机选取一个 feature 图示化。
%   --- is_rmOutlier. 1 or 0. 是否 执行 检测 outlier：返回outlier index以及去除outlier后的数据。
%       如果 is_dataCheck=1, 将再次 图示化分布，并正态检测；从而与去除outlier前数据比较。
%       注：!!! 该步骤改变输入数据。
%   --- tmp_outlier_rm_method. outlier_rm_method_nan = 1;outlier_rm_method_interpolation = 2.
%       影像 默认插值outlier 自动化处理。行为 默认 outlier设为nan 自动化处理。
%           注：因此
%               ! (影像数据) 插值处理outlier前后，缺失值不改变。
%               只有(行为)nan处理outlier 前后， 才牵涉 缺失值改变。
%   --- is_updateSbjIndexOutlierExclude. 1 or 0. 是否返回/更新 analysis_sbjIndex_OutlierExclude.
%       当 is_rmOutlier=1，tmp_outlier_rm_method 为 nan，并且 is_updateSbjIndexOutlierExclude=1的情况下，返回/更新该索引。
%           说明见上，只有nan处理 才牵涉缺失值改变。
%       !!! 返回/更新 指 迭代：
%           在数据处理进行中，随着不同数据的加入，或同一数据的逐步处理阶段，缺失值 会持续更新
%           返回 是首次运行本步骤；后续为更新
% Output
%   --- 如果 is_dataCheck=1，输入数据 更新为 去除outlier后的 数据.
%   --- analysis_sbjIndex_OutlierExclude. 说明见上
%   --- 报告：
%       对于每个数据，被试数，图示化分布，正态检验；
%           如果检测outlier，再次报告去除outlier后的
%       最后汇总报告 缺失人次
% 
% Update history
%   2023-12-26
%       fix bug of random select feature = 0
%   2023-12-12 
%   ---add description
%   ---bug/correction/update for: analysis_sbjIndex_OutlierExclude
%   #
%        该索引为通用累加索引，不能每次执行本函数 都 0 初始化。否则后续会引起混乱以及复杂化。
%        该索引通用指对于一个ada. 每个阿达需要reset，否则多个阿达间互相干扰。
%       solution:
%           在 ada_report_.mlx 添加 is_reset_analysis_sbjIndex_OutlierExclude = 1；
%           初次运行本函数，reset变量为1
%               0初始化 analysis_sbjIndex_OutlierExclude；同时 设置 reset变量为0
%           后续每次运行本函数，对当前数据 运行；然后累加。
%               此外，添加 分离 当前数据报告 和 累加 报告。
%   # 按上，检查 更新 ada_report_.mlx全文档 本函数的调用。
%   2022-10-24
%       add updating data if tmp_outlier_rm_method == 1 & is_updateSbjIndexOutlierExclude == 1
%   2022-10-20
%       add is_updateSbjIndexOutlierExclude
%   2022-08-11
%       add is_dataCheck
%       correction: add interpolation of outlier for sbj*ch
%       remove pdf parts, no needs.
%   2022-08-10
%       add display for sbj*ch
%       add display sbj number
%       add is_rmOutlier
%       add normal test
%   2022-07-x correction for data dim
%   2022-06-23 initial version

if is_rmOutlier 
    if tmp_outlier_rm_method == 1 & is_updateSbjIndexOutlierExclude == 1
        current_analysis_sbjIndex_OutlierExclude = zeros(length(sbj),1);
    end
end

for ii = 1:length(tmpInputVar)
    
    tmp_name = tmpInputVar{ii};
    eval(sprintf('tmp_data = %s;',tmp_name));
    sz=size(tmp_data);
    
    % !!! Note
    %   var format: sbj*1 -- check; outlier handling.
    %   for var format: sbj*ch --- no check; directly remove outlier
    %   for var format: ch*ch*sbj --- no check; no outlier handling.
    
    % var format: sbj*1
    if length(sz) == 2 & sz(2) == 1
        if is_dataCheck
            %--- plot hist before remove outlier
            figure; histogram(tmp_data,'BinMethod',hist_BinMethod);
            title(tmp_name);
            
            % display sbj number
            sprintf('数据 %s 被试数 为%d)',tmp_name,sz(1))
            
            % ks test
            tmp_x = (tmp_data-mean(tmp_data,'omitnan'))/std(tmp_data,'omitnan');
            [h,ks_p] = kstest(tmp_x);
            sprintf('数据 %s 正态(kstest)检验 ks p值为 %d)',tmp_name,ks_p)
            if ks_p>0.05
                disp('服从正态');
            else
                disp('不服从正态');
            end
        end
        
        if is_rmOutlier
            %--- rm outlier
            [tmp_data_clean, tmp_index_outlier] = eleven_rmOutlier_matrix(...
                tmp_data,1,outlier_std_criterion,tmp_outlier_rm_method);
            tmp_data = tmp_data_clean;
            
            if tmp_outlier_rm_method == 1 & is_updateSbjIndexOutlierExclude == 1
                current_analysis_sbjIndex_OutlierExclude(find(tmp_index_outlier==1)) = 1;
            end
            
            if is_dataCheck
                %--- plot hist after remove outlier
                figure; histogram(tmp_data,'BinMethod',hist_BinMethod);
                title(tmp_name);
                
                % ks test
                tmp_x = (tmp_data-mean(tmp_data,'omitnan'))/std(tmp_data,'omitnan');
                [h,ks_p] = kstest(tmp_x);
                sprintf('数据 %s 正态(kstest)检验 ks p值为 %d)',tmp_name,ks_p)
                if ks_p>0.05
                    disp('服从正态');
                else
                    disp('不服从正态');
                end
            end
            
            if tmp_outlier_rm_method == 1 & is_updateSbjIndexOutlierExclude == 0
                eval(sprintf('%s = tmp_data;',tmp_name));
            end
            
        end
    end
         

    if length(sz) == 2 & sz(2) > 1
        if is_dataCheck
            % display sbj number
            sprintf('数据 %s 被试数 为%d)',tmp_name,sz(1))
            
            % check for one ch
            ch_indx_num = round(rand*sz(2));
            if ch_indx_num == 0
                ch_indx_num = 1;
            end
            sprintf('当前选择显示 feature 为 feature  %d)',ch_indx_num)
            
            tmp_data_ch_index_num = tmp_data(:,ch_indx_num);
            
            figure; histogram(tmp_data_ch_index_num,'BinMethod',hist_BinMethod);
            title(tmp_name);
            
            % ks test
            tmp_x = (tmp_data_ch_index_num-mean(tmp_data_ch_index_num,'omitnan'))/std(tmp_data_ch_index_num,'omitnan');
            [h,ks_p] = kstest(tmp_x);
            sprintf('数据 %s 正态(kstest)检验 ks p值为 %d)',tmp_name,ks_p)
            if ks_p>0.05
                disp('服从正态');
            else
                disp('不服从正态');
            end
        end
        
        if is_rmOutlier
            %--- rm outlier
            [tmp_data_clean, tmp_index_outlier] = eleven_rmOutlier_matrix(...
                tmp_data,1,outlier_std_criterion,tmp_outlier_rm_method);
            tmp_data = tmp_data_clean;
            
            % interpolation
            eval(sprintf('%s = tmp_data;',tmp_name));
            
            if is_dataCheck
                tmp_data_ch_index_num = tmp_data(:,ch_indx_num);

                figure; histogram(tmp_data_ch_index_num,'BinMethod',hist_BinMethod);
                title(tmp_name);
                
                % ks test
                tmp_x = (tmp_data_ch_index_num-mean(tmp_data_ch_index_num,'omitnan'))/std(tmp_data_ch_index_num,'omitnan');
                [h,ks_p] = kstest(tmp_x);
                sprintf('数据 %s 正态(kstest)检验 ks p值为 %d)',tmp_name,ks_p)
                if ks_p>0.05
                    disp('服从正态');
                else
                    disp('不服从正态');
                end
            end
            
        end
        
    end
   
    
    if is_rmOutlier
        % if matix, get total number. may optimize later as need.
        sprintf('数据 %s 中 含有 %d 缺失人次 (对于feature>1, 平均feature)',tmp_name,round(length(find(tmp_index_outlier==1))/sz(2)))
    end
end

% only 0 initialize analysis_sbjIndex_OutlierExclude once for a given ada.
%   is_reset_analysis_sbjIndex_OutlierExclude is initized as 1 when the ada begins
if is_reset_analysis_sbjIndex_OutlierExclude
    analysis_sbjIndex_OutlierExclude = zeros(length(sbj),1);
    % set as 0, so that will not 0 initialize anymore.
    is_reset_analysis_sbjIndex_OutlierExclude = 0;
end

% update is_reset_analysis_sbjIndex_OutlierExclude with current_analysis_sbjIndex_OutlierExclude
if is_rmOutlier
    if tmp_outlier_rm_method == 1 & is_updateSbjIndexOutlierExclude == 1
        analysis_sbjIndex_OutlierExclude =  analysis_sbjIndex_OutlierExclude & current_analysis_sbjIndex_OutlierExclude;
        save analysis_sbjIndex_OutlierExclude analysis_sbjIndex_OutlierExclude;
    end
end

% 根据 要质量检查 的 变量名，如果 nan 处理，报告将去除被试人次
%   当前数据
if is_rmOutlier
    if tmp_outlier_rm_method == 1
        sprintf('根据 设定要去除outlier 赋值 nan值的变量名，当前数据 将去除被试人次 %d',...
            length(find(current_analysis_sbjIndex_OutlierExclude==1)))
    end
end

%   累积数据
if is_rmOutlier
    if tmp_outlier_rm_method == 1
        sprintf('根据 设定要去除outlier 赋值 nan值的变量名，累积到当前数据 共将去除被试人次 %d',...
            length(find(analysis_sbjIndex_OutlierExclude==1)))
    end
end
