% openFunc eleven_openFunc_eeg_er_erp
%
% Modified/Extra Input (relative to eleven_eeg_er_erp)
%   one_cond_name
%   trials_assigned
% Modified/Extra Output (relative to eleven_eeg_er_erp)
%   eeg_erp_tmp
% Note, the same as eleven_eeg_er_erp, excep for the following (apated for learning):
%   # cond_name (a list) -> one_cond_name(a string)
%       i.e., perform core erp algorithm on one cond
%   # add trials_assigned, for learning
%   # eeg_erp_tmp (of one cond) is directly the output.
%       no need of saving erp file for learning.
%   # minor
%   ## ii->ii_cond to avoid global iterate var conflicting
%   ##remove 'output epo_before_erp'
% ! Note, keep the common part between this adaptation and eleven_eeg_er_erp consistent.
%   i.e., directly call andy + what extra to do
%       (!!! Note, follow this logic for futher needs. i.e., if feature is spectrum, time-freq, etc.)
%
% Update history
%   2024-10-16 default low pass filter takes too long time. add smooth.
%	2024-09-17 initial version, modify based on eleven_eeg_er_erp
%
% |-------------------------|
% |----------  erp  --------|
% |-------------------------|


% --- load option variables
load eleven_eeg_OptionVariable_customize;

load eeg_type;
load eeg_analyze_type;

% --- input


% |--- processing ---|

% --- input
% epo data
input_data_name = ['eeg_epo' '_' one_cond_name];
eval(sprintf('load %s;',input_data_name));
eval(sprintf('eeg_epo_tmp = %s;',input_data_name));

% set trials
eeg_epo_tmp = eeg_epo_tmp(trials_assigned,:,:);

% --- filter
%disp('  filter');

% low pass
if epo_smooth_method==1 % default low pass filter
    eeg_epo_tmp_filt = mf_epofilter(eeg_epo_tmp,'IIR','low pass',erp_low_cutoff,4,fs);
end
if epo_smooth_method==2 % smooth
    [m,n,o] = size(eeg_epo_tmp);
    eeg_epo_tmp_filt = zeros(m,n,o);
    for i_sm_t=1:o
        for j_sm_t=1:m
            eeg_epo_tmp_filt(j_sm_t,:,i_sm_t) = smooth( eeg_epo_tmp(j_sm_t,:,i_sm_t),epo_smooth_points );
        end
    end
end

% high pass
if eeg_analyze_type == 42
    eeg_epo_tmp_filt = mf_epofilter(eeg_epo_tmp_filt,'IIR','high pass',erp_high_cutoff,4,fs);
end

% --- remove baseline
%disp('  remove baseline');
eeg_erp_tmp_filt_rmb = mf_epormb(eeg_epo_tmp_filt,erp_baseline_range);

% --- average
%disp('  average');
eeg_erp_tmp = mf_epoavg(eeg_erp_tmp_filt_rmb);

