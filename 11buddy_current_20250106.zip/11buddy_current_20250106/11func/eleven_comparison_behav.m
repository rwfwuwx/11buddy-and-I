function eleven_comparison_behav(current_data,Factor_level_current,Factor_name_current,Factor_withinBetween_current,parametric_type,is_FDR)

% input
% Factor_level_current
% Factor_name_current
% current_data
% Factor_withinBetween_current
%
% parametric_type=1; %1--parametric; 2--non parametric
% is_FDR=1; %1--conduct fdr correction; 0--no fdr correction


% output
% table:
%   stat_val: t value for parametric; z value for non parametric
%   ci: nan for non parametric.
%   others same as matlab.

% update history
%   2024-06-27
%       add multi-comparison correction: the more rigous FDR (ref. see 'eleven_fdr.m')
%   2024-06-19 
%       fix bug for non parametric paired comparison when the number of subjects less than 15
%       add effect size for parametric paired comparison (effect size of independent ttest equals the one of one-way anova,so see eleven_anova.m)
%   2024-04-28 initial version


% ---one-sample ttest---
%make a table for outputting results in excel
disp(['one-sample ttest']);
if parametric_type == 1
    disp(['����ͳ��']);
    sz = [8,length(Factor_level_current)];
    varTypes=cell(1,sz(2));
    for ii=1:sz(2)
        varTypes{ii} = 'double';
    end
    t = table('Size',sz,...
        'VariableTypes',varTypes,...
        'VariableNames',Factor_name_current,...
        'RowNames',{'mean' 'sd' 'df' 't' 'p' 'ci_lower' 'ci_upper' 'conhen_d'});
    oneSampleTtest_parametric=zeros(sz);
end

if parametric_type == 2
    disp(['�ǲ���ͳ��']);
    sz = [4,length(Factor_level_current)];
    varTypes=cell(1,sz(2));
    for ii=1:sz(2)
        varTypes{ii} = 'double';
    end
    t = table('Size',sz,...
        'VariableTypes',varTypes,...
        'VariableNames',Factor_name_current,...
        'RowNames',{'mean' 'sd' 'stat_val' 'p' });
    oneSampleTtest_non_parametric=zeros(sz);
end

for oneii=1:length(Factor_level_current)
    
    data1_index=Factor_level_current(oneii);
    data1_name= Factor_name_current{oneii};
    data1=current_data(:,oneii);
    
    
    if parametric_type == 1
        [~,p,ci,stats]=ttest(data1);
        p=roundn(p,-5);
        df=stats.df;
        t_val = stats.tstat;
        sd_val=stats.sd;
        mean_val=mean(data1);
        conhen_d=mean_val/sd_val;
        
        output_name = ['oneSampleTtest_parametric'];
        excel_name=[output_name '.xlsx'];
        tmp_t_input=[mean_val;sd_val;df;t_val;p;ci(1);ci(2);conhen_d];
        oneSampleTtest_parametric(:,oneii)=tmp_t_input;
        
        tmp_t_input = num2cell(tmp_t_input);
        t(:,oneii)=tmp_t_input;
    end
    
    if parametric_type == 2
        [p,~,stats]=signrank(data1,0,'alpha', 0.05,'tail','both','method','approximate');
        p=roundn(p,-5);
        stat_val = stats.zval;
        mean_val=mean(data1);
        sd_val=std(data1);
        
        
        output_name = ['oneSampleTtest_non_parametric'];
        excel_name=[output_name '.xlsx'];
        tmp_t_input=[mean_val;sd_val;stat_val;p];
        oneSampleTtest_non_parametric(:,oneii)=tmp_t_input;
        
        tmp_t_input = num2cell(tmp_t_input);
        t(:,oneii)=tmp_t_input;
    end
end
t
writetable(t,excel_name);
save([output_name '.mat'],output_name);


% ---two-wample ttest---
disp(['two-sample ttest']);
sz = [length(Factor_level_current),length(Factor_level_current)];
t2_cell=cell(sz);

mean_diff_matrix=zeros(sz);
sd_matrix=zeros(sz);
stat_matrix=zeros(sz);
p_matrix=zeros(sz);
ci_cell=cell(sz);
cohen_d_matrix=zeros(sz);

if parametric_type ==1 % ����ͳ��
    disp(['����ͳ��']);
    for oneii=1:length(Factor_level_current)
        
        if unique(Factor_withinBetween_current)==1
            for twoii=1:length(Factor_level_current)
                data1=current_data(:,oneii);
                data2=current_data(:,twoii);
                
                data1_name=Factor_name_current{oneii};
                data2_name=Factor_name_current{twoii};
                
                if strcmp(data1_name,data2_name)==1
                    t2_cell{oneii,twoii}=nan;
                else
                    [~,p,ci,stats]=ttest(data1,data2);
                    
                    df=stats.df;
                    t_val = stats.tstat;
                    sd_val=stats.sd;
                    mean_diff=mean(data1) - mean(data2);
                    conhen_d=mean_diff/sd_val;
                    
                    tmp_t_input=['mean_diff=' num2str(mean_diff) '\t\n'...
                        'sd=' num2str(sd_val) '\t\n'...
                        'df=' num2str(df) '\t\n'...
                        't=' num2str(t_val) '\t\n'...
                        'p=' num2str(p) '\t\n'...
                        'ci=' num2str(ci') '\t\n'...
                        'conhen_d=' num2str(conhen_d)];
                    t2_cell{oneii,twoii} = sprintf(tmp_t_input);
                    
                    mean_diff_matrix(oneii,twoii)=mean_diff;
                    sd_matrix(oneii,twoii)=sd_val;
                    stat_matrix(oneii,twoii)=t_val;
                    p_matrix(oneii,twoii)=p;
                    ci_cell{oneii,twoii}=ci';
                    cohen_d_matrix(oneii,twoii)=conhen_d;
                end
                
            end
            output_name=['twoSampleTtest_paired_parametric'];
            excel_name = [output_name '.xlsx'];
        end
        
        if unique(Factor_withinBetween_current)==2
            for twoii=1:length(Factor_level_current)
                data1=current_data(:,oneii);
                data2=current_data(:,twoii);
                
                data1_name=Factor_name_current{oneii};
                data2_name=Factor_name_current{twoii};
                
                if strcmp(data1_name,data2_name)==1
                    t2_cell{oneii,twoii}=nan;
                else
                    [~,p,ci,stats]=ttest2(data1,data2);
                    
                    df=stats.df;
                    t_val = stats.tstat;
                    sd_val=stats.sd;
                    mean_diff=mean(data1) - mean(data2);
                    
                    tmp_t_input=['mean_diff=' num2str(mean_diff) '\t\n'...
                        'sd=' num2str(sd_val) '\t\n'...
                        'df=' num2str(df) '\t\n'...
                        't=' num2str(t_val) '\t\n'...
                        'p=' num2str(p) '\t\n'...
                        'ci=' num2str(ci') ];
                    t2_cell{oneii,twoii} = sprintf(tmp_t_input);
                    
                    mean_diff_matrix(oneii,twoii)=mean_diff;
                    sd_matrix(oneii,twoii)=sd_val;
                    stat_matrix(oneii,twoii)=t_val;
                    p_matrix(oneii,twoii)=p;
                    ci_cell{oneii,twoii}=ci';
                end
                
            end
            output_name = ['twoSampleTtest_independ_parametric'];
            excel_name = [output_name '.xlsx'];
        end
        
        if length(unique(Factor_withinBetween_current))>1
            
        end
        
    end
        
    % -generate a result table
    t2=cell2table(t2_cell,...
        'VariableNames',Factor_name_current,...
        'RowNames',Factor_name_current);
    t2
    writetable(t2,excel_name);
    
    % - multi-comparison correction
    if is_FDR
        tmp_tril_p=tril(p_matrix,-1); % get the lower triangle of the correlation matrix
        tmp_index=find(tmp_tril_p~=0);
        tmp_p=tmp_tril_p(tmp_index);
        
        tmp_index_ns=find(tmp_p>0.05);
        ns_val=tmp_p(tmp_index_ns);
        
        fdr_p=mafdr(tmp_p,'BHFDR',true);
        tmp_tril_p(tmp_index)=fdr_p;
        fdr_matrix=tmp_tril_p;
        
%         fdr_matrix(tmp_index_ns)=ns_val;
        
        disp('--- ��ˮƽ�����Ƚϣ����ؽ�����pֵ')
        fdr_matrix
    end
    
%     save([output_name '.mat'],'mean_diff_matrix','sd_matrix','stat_matrix','p_matrix','ci_cell','cohen_d_matrix');
end

if parametric_type ==2 % �ǲ���ͳ��
    disp(['�ǲ���ͳ��']);
    for oneii=1:length(Factor_level_current)
        
        if unique(Factor_withinBetween_current)==1
            for twoii=1:length(Factor_level_current)
                data1=current_data(:,oneii);
                data2=current_data(:,twoii);
                
                data1_name=Factor_name_current{oneii};
                data2_name=Factor_name_current{twoii};
                
                if strcmp(data1_name,data2_name)==1
                    t2_cell{oneii,twoii}=nan;
                else
                    [p,~,stats]=signrank(data1,data2,'alpha', 0.05,'tail','both','method','approximate');
                    
                    stat_val = stats.signedrank;
                    mean_diff=mean(data1) - mean(data2);
                    
                    tmp_t_input=['mean_diff=' num2str(mean_diff) '\t\n'...
                        'stat_val=' num2str(stat_val) '\t\n'...
                        'p=' num2str(p) '\t\n'];
                    t2_cell{oneii,twoii} = sprintf(tmp_t_input);
                    
                    mean_diff_matrix(oneii,twoii)=mean_diff;
                    stat_matrix(oneii,twoii)=stat_val;
                    p_matrix(oneii,twoii)=p;
                end
                
            end
            output_name = ['twoSampleTtest_paired_nonparametric'];
            excel_name = [output_name '.xlsx'];
        end
        
        if unique(Factor_withinBetween_current)==2
            for twoii=1:length(Factor_level_current)
                data1=current_data(:,oneii);
                data2=current_data(:,twoii);
                
                data1_name=Factor_name_current{oneii};
                data2_name=Factor_name_current{twoii};
                
                if strcmp(data1_name,data2_name)==1
                    t2_cell{oneii,twoii}=nan;
                else
                    [p,~,stats]=ranksum(data1,data2);
                    
                    stat_val = stats.zval;
                    stat_matrix(oneii,twoii)=stat_val;
                    mean_diff=mean(data1) - mean(data2);
                    
                    tmp_t_input=['mean_diff=' num2str(mean_diff) '\t\n'...
                        'stat_val=' num2str(stat_val) '\t\n'...
                        'p=' num2str(p) '\t\n'];
                    t2_cell{oneii,twoii} = sprintf(tmp_t_input);
                    
                    mean_diff_matrix(oneii,twoii)=mean_diff;
                    stat_matrix(oneii,twoii)=stat_val;
                    p_matrix(oneii,twoii)=p;
                    
                end
                
            end
            output_name = ['twoSampleTtest_independ_nonparametric'];
            excel_name = [output_name '.xlsx'];
        end
        
        if length(unique(Factor_withinBetween_current))>1
            
        end
        
    end
    
    % -generate a result table
    t2=cell2table(t2_cell,...
        'VariableNames',Factor_name_current,...
        'RowNames',Factor_name_current);
    t2
    writetable(t2,excel_name);
    
    % - multi-comparison correction
    if is_FDR
        tmp_tril_p=tril(p_matrix,-1); % get the lower triangle of the correlation matrix
        tmp_index=find(tmp_tril_p~=0);
        tmp_p=tmp_tril_p(tmp_index);
        
        tmp_index_ns=find(tmp_p>0.05);
        ns_val=tmp_p(tmp_index_ns);
        
        fdr_p=mafdr(tmp_p,'BHFDR',true);
        tmp_tril_p(tmp_index)=fdr_p;
        fdr_matrix=tmp_tril_p;
        
%         fdr_matrix(tmp_index_ns)=ns_val;
        
        disp('--- ��ˮƽ�����Ƚϣ����ؽ�����pֵ')
        fdr_matrix
    end
    
%     save([output_name '.mat'],'mean_diff_matrix','stat_matrix','p_matrix');
end



