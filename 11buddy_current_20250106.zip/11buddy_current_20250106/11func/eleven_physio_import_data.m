function [physio_raw,physio_ecd] = eleven_physio_import_data(physio_file,data_type,cut_time,is_resample,resample_rate,fs_origin)
% [physio_raw,physio_ecd] = eleven_physio_import_data(physio_file,data_type,cut_time,is_resample,resample_rate,fs_origin)
% Input
%   eeg_file -- physio file
%   data_type -- 1: ECG; 2 - respiration; 3 - sc. 
%       deponding on the current collecting setting, generalize later.
%   cut_time,is_resample, resample_rate -- see eleven_eeg_import_data
%   fs_origin -- origin sampling rate
% Output
%   physio_raw -- raw data in mf_eeg format.
%   physio_ecd -- ecd file in mf_eeg format.
% Update history
%       see physio_���ܴ�������.docx
%   before 2020-11-17 initial build Liying


% read physio_file
% physio = load(physio_file);
eval(sprintf('load %s;',physio_file));
physio_raw = physio_raw.data(:,data_type);

% cut data according to cut_time
cut_point = round(cut_time*fs_origin);
physio_raw = physio_raw(cut_point(1):cut_point(2));

% resample
if is_resample
    physio_raw = resample(physio_raw,resample_rate,fs_origin);
end

physio_ecd = 0;
% ecd, handle later
%{
% get ecd
physio_ecd = physio_trigger2ecd(trigger_raw,is_resample,resample_rate,fs_origin);

end

function physio_ecd = physio_trigger2ecd(trigger_raw,is_resample,resample_rate,fs_origin)

trigger_point = find(trigger_raw ~= 0);
trigger_event = trigger_raw(trigger_point);
if is_resample
    trigger_time = trigger_point*(1/fs_origin);
    ecd_point =  round(trigger_time*resample_rate);
    tmp_ecd = [trigger_event ecd_point];
    [~,ind] = unique(tmp_ecd(:,2));
    physio_ecd = tmp_ecd(ind,:);
else
    physio_ecd = [trigger_event trigger_point];
end
%}

end
