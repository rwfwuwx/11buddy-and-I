function [first_trigger_time] = eleven_physio_get_exp_startTime(physio_file,fs,trigger_channel)
% [first_trigger_time] = eleven_physio_get_exp_startTime(physio_file,fs,trigger_channel)
% Input
%   physio file --- in .mat format
%   fs -- sampling rate
%   trigger_channel -- trigger channel in physio data. for shengzhongdian
%       data, trigger input is [4 11].
% Output
%   first_trigger_Time
% Update history
%   2020-11-17
%       see physio_���ܴ�������.docx
%   before 2020-11-17, initial build Liying

% read physio_file
eval(sprintf('load %s;',physio_file));

%physio = load(physio_file);

% trigger covert: binary -> decimalism
trigger_raw = physio_raw.data(:,trigger_channel);
[m,n] = size(trigger_raw);

% in biopac, channel data is 0 or 5, thus turn 5->1; i.e., to binary. for more general, turn >5 -> 1 (may further check later)
trigger_raw(find(trigger_raw>0))=1;

%--- change DC 1-8-> to DC ->8-1. 
trigger_raw = fliplr(trigger_raw);

%--- change binary values to decimal values. 
% now it's m*1 vecotor, with trigger decimal values
trigger_raw = num2str(trigger_raw);
trigger_raw = bin2dec(trigger_raw);

trigger_point = find(trigger_raw > 0);
first_trigger_point = trigger_point(1);
first_trigger_time = (first_trigger_point-1)*(1/fs);

end