function [alpha,T_sd,M_sd] = eleven_timingSyncTap_linearModel_paramESM_bGLS(model_type,IRI,Asyn,rejectInitialEvent)
%
% Input
%   seq_type: model_type. 
%       1: isochronous with phase correction
%       2. isochronous with phase correction and period correction
%       ... (add as needs according to bGLS)
%   Asyn: asynchrony
%       format: seq_len*seq_num. for one subject.
%   IRI: inter-response-interval.
%       format: seq_len*seq_num. for one subject.
%   rejectInitialEvent:
%       []: no rejection
%       a number: reject the initial events of this number. default 5.
% Output
%   alpha: the phase correction
%   T_sd: sd of the internal interval T
%   M_sd: sd of the motor delay M
%
% Update history
%   2024-06-13 adding row for IRI
%   2024-06-07 initial version

%--- preprocessing

%- reject inital events
if ~isempty(rejectInitialEvent)
    Asyn = Asyn(5:end,:);
    IRI = IRI(5:end,:);
end

%- clean
% Note
%   including, remove/interpolate outlier/missing
%   these are supposed done outside this func. if not, add as needs.


% add initial row for IRI (R(t)=OR(t)-OR(t-1))
IRI_mean=mean(IRI);
IRI=[IRI_mean;IRI];


%--- model param estimate
Asyn_mean=mean(Asyn);
IRI_mean=mean(IRI);
[alpha,T_sd,M_sd] = bGLS_phase_model_single_and_multiperson(IRI,Asyn,Asyn_mean,IRI_mean);

