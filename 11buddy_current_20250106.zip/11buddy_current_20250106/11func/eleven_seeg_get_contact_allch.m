function [contact_coord] = eleven_seeg_get_contact_allch(ch_label_cell,ch_grouping,ch_StartEnd_coord)
% [contact_coord] = eleven_seeg_get_contact_allch(ch_label_cell,ch_grouping,ch_StartEnd_coord)
% Input
%   
% Output
%   contact_coord -- matrix, all contacts * xyz. contacts are alligned with ch_label_cell.
%
% Note & todo
%
% --- update history
% 2023-11-16
%   initial version.

if nargin~=3
    disp('eleven_seeg_get_contact_allch requires 3 arguments!');
    return;
end

contact_coord = zeros(size(ch_label_cell,1),3); % contacts * xyz

ch_num = max(ch_grouping);

count_index=0;
for ii = 1:ch_num
    % initialize current ch contacts
    contact_num_of_ch = length(find(ch_grouping==ii));
    %ch_contact_coord = zeros(contact_num_of_ch,3);
    
    % get info from ch_StartEnd_coord
    ch_start_contact_index = str2num(ch_StartEnd_coord{ii,1}(end-1:end)); % e.g., 'A01'->'01'->1
    ch_end_contact_index = str2num(ch_StartEnd_coord{ii,2}(end-1:end)); % e.g., 'A16'->'16'->16
    %ch_start_contact_index = str2num(ch_StartEnd_coord{ii,1}(2:3)); % e.g., 'A01'->'01'->1
    %ch_end_contact_index = str2num(ch_StartEnd_coord{ii,2}(2:3)); % e.g., 'A16'->'16'->16
    ch_start_contact_coord = cell2mat(ch_StartEnd_coord(ii,3:5));
    ch_end_contact_coord = cell2mat(ch_StartEnd_coord(ii,(6:8)));
    
    % compute, and fill out current ch contacts
    %   Note: actuall clinic may not use all contacts of a ch (see manual).
    %       those contacts not used, i.e., identified when fill out ch_StartEnd_coord,
    %       are given coordinate 0 0 0, which is not either gray or white matter.
    %   computer coordinates of contacts of current ch, based on  ch_StartEnd_coord
    tmp_contact_num = ch_end_contact_index - ch_start_contact_index + 1;
    tmp_contact=round(eleven_seeg_get_contact(ch_start_contact_coord,ch_end_contact_coord,tmp_contact_num));
    %   fill out
    tmp_indexing = count_index + (ch_start_contact_index:ch_end_contact_index);
    contact_coord(tmp_indexing,:) = tmp_contact;
    
    % updating counting
    count_index=count_index+contact_num_of_ch;
end
