% open func
% eleven_openFunc_CommonStat_ResultReport_text
% Input
%    p and stat_val, from any stat
%    MultipleCorrect_method
%        0: no correction
%        1: FDR
%        ... (to add)
%    MultipleCorrect_isPosNeg
%        0: MC for all
%        1: MC for pos and neg separately
%    is_select_ch_interest
%        !!! Note !!!
%        # if select, sig only refer to the selected, neglecting non selected.
%            Accordingly, MC is only regarding the selected.
%            which means, do not taking sig about non selected anymore !!!.
%        # the returned index is already converted back the the index before select.
%            which means, no need to manually consider/convert.
%            more clearly, for example, select 36 from 128 ch.
%                the returned index refers to 128, not 36.
%   is_pca
%
% Output
%    idx_sig
%    idx_sig_pos
%    idx_sig_neg
%    p_MC
%    idx_sig_MC
%    idx_sig_pos_MC
%    idx_sig_neg_MC
%
% Update history
%   2022-10-18
%       idxNum -> idxNO
%   2022-08-23
%       bug fix for array data fomat,p_for_table
%   2022-08-10 
%       update mafdr usage
%       distingush displaying p in table between p and p_MC
%   2022-08-08 bug fix: 
%   1,when p_pos_tmp and p_neg_tmp is empty, mafdr can't work.
%   2,t_length assignment
%   3,tmp_Result2Report
%   4,array2table input matrix
%   5,bug fix for p_orig write error
%   6,report sig feature num
%   2022-08-05 initial version, based on, and update, from previous scripts.

if is_select_ch_interest == 0
    %   none action
end
if is_select_ch_interest == 1 && is_pca == 0
    p_orig = p;
    stat_val_orig = stat_val;
    
    p = p(idxNO_ch_interest);
    stat_val = stat_val(idxNO_ch_interest);
end

idx_pos = find(stat_val>0); % pos index
idx_neg = find(stat_val<0); % neg index

idx_sig = find(p<=pval_default); % sig index
idx_sig_pos = intersect(idx_sig,idx_pos); % sig pos index
idx_sig_neg = intersect(idx_sig,idx_neg); % sig neg index

if MultipleCorrect_method == 0
    % P_MC = p, & no matter isPosNeg
    p_MC = p;
    
    idx_sig_MC = idx_sig;
    idx_sig_pos_MC = idx_sig_pos;
    idx_sig_neg_MC = idx_sig_neg;
end

if MultipleCorrect_method == 1
    if MultipleCorrect_isPosNeg == 0
        [p_corrected,FDR,Q] = eleven_fdr(p);
        p_MC = p_corrected;
    end
    
    if MultipleCorrect_isPosNeg == 1
        p_MC = p;
        % pos
        p_pos_tmp = p(idx_pos);
        if length(p_pos_tmp)>1
            [p_corrected_pos_tmp,FDR_pos_tmp,Q] = eleven_fdr(p_pos_tmp);
            p_MC(idx_pos) = p_corrected_pos_tmp;
        end
        
        % neg
        p_neg_tmp = p(idx_neg);
        if length(p_neg_tmp)>1
            [p_corrected_neg_tmp,FDR_neg_tmp,Q] = eleven_fdr(p_neg_tmp);
            p_MC(idx_neg) = p_corrected_neg_tmp;
        end
    end
    
    idx_sig_MC = find(p_MC<=pval_default); % sig index
    idx_sig_pos_MC = intersect(idx_sig_MC,idx_pos); % sig pos index
    idx_sig_neg_MC = intersect(idx_sig_MC,idx_neg); % sig neg index
end

% convert index back from ch_interest to all ch
if is_select_ch_interest == 0
    %   no convertion
end
if is_select_ch_interest == 1  && is_pca == 0
    % origin
    %   convert index
    idx_sig = idxNO_ch_interest(idx_sig);
    idx_sig_pos = idxNO_ch_interest(idx_sig_pos);
    idx_sig_neg = idxNO_ch_interest(idx_sig_neg);
    
    %   recover p and stat_val
    p = p_orig;
    stat_val = stat_val_orig;
    
    % MC
    %   convert index
    tmp_idx_sig_MC = idx_sig_MC; % temporally keep for below usage
    idx_sig_MC = idxNO_ch_interest(idx_sig_MC);
    idx_sig_pos_MC = idxNO_ch_interest(idx_sig_pos_MC);
    idx_sig_neg_MC = idxNO_ch_interest(idx_sig_neg_MC);
    
    %   recover p and stat_val
    %   if select interest, MC only performed on the selected.
    %       for the non-interest part, just assngh value: P_MC = p
    tmp_p_MC = p_orig;
    tmp_p_MC(idx_sig_MC) = p_MC(tmp_idx_sig_MC);
    p_MC = tmp_p_MC;
end



% @@ 统计结果报告
% 未矫正 统计值
stat_result_name = {...
    'idx_sig',...
    'idx_sig_pos',...
    'idx_sig_neg',...
    'idx_sig_MC',...
    'idx_sig_pos_MC',...
    'idx_sig_neg_MC',...
    };

disp('以下显示 统计文字/表格报告');
for kk_srn = 1:length(stat_result_name)
    % 显示结果种类
    disp(stat_result_name{kk_srn});
    % 显示达到显著 feature数目
    
    % 以下为自动化报告代码
    sprintf('t_length = length(%s);',stat_result_name{kk_srn});
    eval(sprintf('t_length = length(%s);',stat_result_name{kk_srn}));
    
    sprintf('number of sig: %d;',t_length)
    
    if kk_srn<=3
        p_for_table = p;
    end
    if kk_srn>3
        p_for_table = p_MC;
    end
    
    if size(p_for_table,1)>size(p_for_table,2)
        p_for_table = p_for_table';
    end
     if size(stat_val,1)>size(stat_val,2)
        stat_val=stat_val';
    end
    
    if t_length > 0 % i.e., not empty
        eval(sprintf('tmp_Result2Report = %s;',stat_result_name{kk_srn}));
        
        VariableName = cell(1,length(tmp_Result2Report));
        for ii_trr = 1:length(tmp_Result2Report)
            tmp_index = tmp_Result2Report(ii_trr);
            VariableName{ii_trr}=['feature' num2str(tmp_index)];
        end
        RowName = {'p value','stat value'};
        T = array2table([p_for_table(tmp_Result2Report); stat_val(tmp_Result2Report)],'VariableNames',VariableName,'RowNames',RowName)
    end
end
