function eleven_plot_sig(sig,sig_range,is_scale)
% input:
%   sig. data points * number of sig.
%   sig_range. 1*2 matrix. e.g.,
%       [0.1 0.3]. which can represent 0.1-0.3 s for time
%       [10 30]. which can represent 10-30 Hz fro req.
%   is_scale. (see mf_drawerp)
%
%   Note
%   for further specific needs, add/modify as in eleven_eeg_resultImage, mf_drawerp, mf_drawtf, mf_drawsyn.
%   #this func serves as a rather 'general' func to plot sig.
%
%   Todo
%   (mfeeg might already have similar func such as ploting a time course or matrix.
%       check integrate later.)
%
% update history
% 2024-09-20
%   # add set figure shape
%   # what is the need
%       the need at this time is not to plot an erp of one ch (handle as need later)
%       rather, particularly after feature extraction, the need is simply
%           to plot a sig/sigs, even regardless whether the sig in on time domain or freq domain.
%       the only required for ploting the sig is the x clic, in time, or freq
%   #func_seeg_erp_plot_sepr_20240903 -> eleven_plot_sig
% 2024-09-03 modiried from andy31

%- set y
y = sig;

%- set x
sig_step = (sig_range(2)-sig_range(1)) / (size(y,1)-1);
x = sig_range(1):sig_step:sig_range(2);

%-set lim
min_value = min(min(y(:)));
max_value = max(max(y(:)));
lim = [sig_range(1),sig_range(2),min_value,max_value];

%--- plot
figure;
hold on;

%- set figure option/param
line_width=2;
% furthe allow set/modify default color later
color={'#0072BD' '#D95319' 	'#EDB120' ...
    '#7E2F8E' '#77AC30' '#4DBEEE' '#A2142F' ...
    '#FF0000' '#00FF00' '#0000FF' '#00FFFF' ...
    '#FF00FF' '#FFFF00'};

for ii=1:size(y,2) % loop of sig
    tmp_y = y(:,ii);
    
    subplot(1,size(y,2),ii);hold on;
    plot(x,tmp_y,'-','Color',color{ii},'LineWidth',line_width); %plot erp
    plot(x,zeros(1,length(x)),'k-','LineWidth',1); % zero line
    
    %-scale
    if is_scale
        axis(lim);
    end
    
    %-figure shape
    %axis equal; % does not work
    % Adjust position for square shape
    sub_plot_total_size = 0.9/size(y,2);
    sub_plot_size = sub_plot_total_size/10*9;
    %sub_plot_interval = sub_plot_total_size/10;
    set(gca, 'Position', [0.05 + (ii-1)*sub_plot_total_size, 0.1, sub_plot_size, sub_plot_size*1.5]);  % [left, bottom, width, height]
end

hold off;


