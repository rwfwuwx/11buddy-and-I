function [featureMask_CV_common,common_feature_num,featureMask_CV_MaskByThreshold] = eleven_BrainBehavPred_FSbyCor_evaCommonFeature(featureMask_CV,commonFeatureThreshold)
% [featureMask_CV_common,common_feature_num,featureMask_CV_MaskByThreshold] = eleven_BrainBehavPred_FSbyCor_evaOverlap(featureMask_CV,commonFeatureThreshold)
%
% What is the issue?/What does this func do?
%   --- first see update history of eleven_BrainBehavPred_FSbyCor_FS.m, for the background regarding overlap.
%   --- In brief, this again comes from the "old trouble": within/between subject
%   --- Let's first consider the typical ML procedure, not involving the within subject trouble
%   # feature selection
%       pre-set, either in model specific, i,e., manullay 'fix' set as a model; 
%           or in artificial network, i.e., automatically 'flexibly' set as a network structure.
%       Note, the features are the same for all item/sbj.
%   # train. i.e., get weights/params for features.
%   # train and cross-validation (CV)
%       Note, this train-plus CV
%           (1) for train purpose, can be considered as help evaluate train
%           (2) for test purpose, the leave-one-sbj-out (LOSA) in practice, can be considered as testing
%   # test. apply the features and weights for new item/sbj.
%   --- the above ML procedure can be directly used in cognitive neuroscice; 
%       if, between subject. Say, a fMRI study.
%   # feature selection
%       FS step 1: For each sbj, get a ROI.
%       FS step 2: set a common ROI from indivisual ROIs.
%   # train. 
%   # train+CV
%   # test. 
%   ---Now, see how issue arise, when involving within subject.
%       still, considring a fMRI study.
%   # feature selection
%       FS step 1: For each sbj, get a ROI.
%       !!!FS step 2: set a common ROI from indivisual ROIs
%   the issue/question: since test data are also from the same subjects, 
%       why not/should use individual ROIs, instead of a common ROI.
%   This is just the common sense: use you own data to predict you. Make sense.
%   Pros: individual sensitivity
%   Cons: not for between subject. similarly, you should not use someone else's data to predict me.
%   deep diviving -- overlap: the core
%       what does it means, say?
%           individual ROIs overlap 0%
%           individual ROIs overlap 100%
%       it means, for effective prediction (not interpretation), you and me
%       shall have some in common, ie., overlap; and its the overlap decide
%       a good prediction.
%       for ref, see e.g.,
%           for connectivity data, Rosenberg MD, Finn ES, Scheinost D, Papademetris X, Shen X, Constable RT, Chun MM (2016) A neuromarker of sustained attention from whole-brain functional connectivity. Nat Neurosci 19:165–171.
%           for fMRI data, Esterman M, Tamber-Rosenau BJ, Chiu Y-C, Yantis S (2010) Avoiding non-independence in fMRI data analysis: Leave one subject out. NeuroImage 50:572–576.
%   in addition, if set a common ROI, the overlap is arbitary, depending on a threshold
%       for continuous value, such as fMRI activation, it is a t/p value
%       for discrete value, such as binary connectivity, it is a, here, a percent of overlap
%
%       the trade-off is, the threshold, that used to define the size of the ROI.
%       if using a high threshold, e.g., p=0.001. the overlap, i.e., the ROI is mall, or even lacking.
%           while, this small ROI is more likely to be common in all subjects, and help predict (even for new sbj).
%       if using a low threshold, e.g., p=0.1. the overlap is large.
%           however, this large ROI does not make much sense (consider use all features, ie.g., no selection).
%
%       a high percent, e.g., 80, corresponding to a high threshold for ROI.
%       a low percent, e.g., 20, corresponding to a low threshold for ROI.
%   in addtion, a variant combining individual ROIs and common ROI
%       FS step 2: set a common ROI from indivisual ROIs
%       -> individual ROIs && common ROI
%   --- So, shall use a common ROI? if use, what threshold should use?
%   if the above is clear, then the issue is, in some sense, a philosophical issue; which we will not further consider.
%   instead, we leave options, and recommand practical pipeline.
%   !!! only performance on test data, is the golden criterion. (if not consider interpretation)
%
%
%   --- pipeline in practice of 11buddy
%   # feature selection
%       FS step 1: For each sbj, get a ROI.
%           i.e., featureMask_CV.
%       FS step 2: 
%           set a common ROI from indivisual ROIs.
%               i.e., featureMask_CV_common
%           individual ROIs && common ROI. 
%               i.e., featureMask_CV_MaskByThreshold
%   # train
%       between subject: use featureMask_CV_common
%       within subject:
%           option 1: use featureMask_CV_MaskByThreshold
%           option 2: use featureMask_CV
%   # train+CV
%       Note, CV in practice refers to predict in one data. i.e., within.
%       use featureMask same as in train.
%   # test. 
%       use featureMask same as in train.
%
%
% Input
%   featureMask_CV: sbj*feature_num, returnded from eleven_BrainBehavPred_FSbyCor_FS
%   commonFeatureThreshold: percent,1 ~ 100,e.g., 50. 
%       for connectivity data, use percent as overlap threshold (see the above description).
%       the percent is according to hisogram distribution.
%
% Output
%   featureMask_CV_common: 1*feature_num. The common mask.
%       common_feature_num: simply the number of features in featureMask_CV_common, for convenient use.
%   featureMask_CV_MaskByThreshold: featureMask_CV masked by the threshold. sbj*feature_num.
%
% Update history
%   2024-06-18~20 
%       func name: evaOverlap -> evaCommonFeature
%       add description; code clarification
%   2021-06-27 initial version

sbj_num = size(featureMask_CV,1);
feature_num = size(featureMask_CV,2);

%- get featureMask_CV_common
%   the threshold, percent, is according to histogram distribution
featureMask_CV_common = zeros(1,feature_num);
hist_percent = sum(featureMask_CV) ./ sbj_num .* 100;
featureMask_CV_common(find(hist_percent >= commonFeatureThreshold)) = 1;
common_feature_num = sum(featureMask_CV_common);

%- get featureMask_CV_MaskByThreshold
%   i.e., use the common mask accross all sbj, to mask individual subjects' masks
featureMask_CV_MaskByThreshold = zeros(1,feature_num);
for ii=1:sbj_num
    featureMask_CV_MaskByThreshold(ii,:) = featureMask_CV(ii,:) .* featureMask_CV_common;
end






