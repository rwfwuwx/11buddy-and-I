function [ch_label_cell_raw,ch_label_cell,ch_index_target,ch_index_trigger,ch_grouping,ch_grouping_name,reref_ch] = eleven_seeg_ch_pp_edf(edf_file)
% [ch_label_cell_raw,ch_label_cell,ch_index_target,ch_index_trigger,ch_grouping,ch_grouping_name,reref_ch] = eleven_seeg_ch_pp_edf(edf_file)
% Input
%   edf_file -- raw edf file
% Output
%   ch_label_cell_raw -- raw lables of channels. col 1: ch label; col 2: index of ch lable.
%   ch_label_cell -- the one that match the ch_index_target.
%   ch_index_target  
%   ch_index_trigger
%   ch_grouping -- grouping ch. e.g., for ch A1 A2 B1 B2 D1 D2, grouping as 1 1 2 2 3 3.
%   ch_grouping_name -- i.e., A A B B D D
%   reref_ch -- offline laplacian re-referencing.
%
% Note & todo
%   the post-handling of ch lables depending on the manual setting of hospital,
%       therefore, must check if it matches/includes the manual setting,
%       for new data type.
%   ! check if it matches all data from shengzhongyi.
%   ! check if it matches for foshanyiyuan.
%
% --- update history
% 2024-11-26 distinguish the names of the left and right side contacts
% 2024-11-18~21 extend&update handling no_need_ch_lable
% 2024-03-21/11-18
%   update DC channels for trigger.
% 2023-11-14
%   initial version.
%   modify based on eleven_seeg_import_edf.

if nargin~=1
    disp('eleven_seeg_ch_pp_edf requires 1 arguments!');
    return;
end


%--- Part 1: read edf file, get raw ch labels ---|

%--- read .edf file.
% read by eeglab, via biosig.
% EEG is the data structure of eeglab. in which, the needed info are:
%   EEG.data: ch*sample_points
%   EEG.chanlocs(ch).labels: ch lables.
EEG = pop_biosig(edf_file);

%--- get raw ch labels
ch_label_cell_raw=cell(length(EEG.chanlocs),2);
for ii=1:length(EEG.chanlocs)
    ch_label_cell_raw{ii,1} = EEG.chanlocs(ii).labels;
    ch_label_cell_raw{ii,2} = ii;
end
ch_label_cell = ch_label_cell_raw; % ch_label_cell as temporal for later post-handling


%|--- Part 2: post-handling of ch labels, get target ch and trigger ch ---|

%--- post-handling of ch lables
%- remove null ch: ie. label is just 'POL'
index_tmp = [];
for ii = 1:size(ch_label_cell,1)
    if strcmp(ch_label_cell{ii,1},'POL')
        index_tmp = [index_tmp;ii];
    end
end
if ~isempty(index_tmp)
    ch_label_cell(index_tmp,:)=[];
end

%- remove prefix,including 'POL ', 'EEG '
for ii = 1:size(ch_label_cell,1)
    if strcmp(ch_label_cell{ii,1}(1:4),'POL ') || strcmp(ch_label_cell{ii,1}(1:4),'EEG ')
        ch_label_cell{ii,1} = ch_label_cell{ii,1}(5:end);
    end
end

%- remove postfix,including '-Ref'
for ii = 1:size(ch_label_cell,1)
    if length(ch_label_cell{ii,1})>4
        if strcmp(ch_label_cell{ii,1}(end-3:end),'-Ref')
            ch_label_cell{ii,1} = ch_label_cell{ii,1}(1:end-4);
        end
    end
end

%- remove no-need ch
% Note, if there are more not included, add here
no_need_ch_lable_cell = {...
    'LDEL','LDEL1','LDEL2','L-DEL','L-DEL1','L-DEL2','L DEL','L DEL1','L DEL2',...
    'RDEL','RDEL1','RDEL2','R-DEL','R-DEL1','R-DEL2','R DEL','R DEL1','R DEL2',...
    'LEDL','LEDL1','LEDL2','L-EDL','L-EDL1','L-EDL2','L EDL','L EDL1','L EDL2',...
    'REDL','REDL1','REDL2','R-EDL','R-EDL1','R-EDL2','R EDL','R EDL1','R EDL2',...
    'LDE','RDE','EKG','EKG1','EKG2','BP'};

index_tmp = [];
for ii = 1:size(ch_label_cell,1)
    % search whether a contact is no need
    is_find = 0;
    for jj=1:length(no_need_ch_lable_cell)
        % note, here also handle 
        %   up/low case
        %   encluding blanks 
        if contains(ch_label_cell{ii,1},no_need_ch_lable_cell{jj},'IgnoreCase',true)
        %if strcmpi(no_need_ch_lable_cell{jj},ch_label_cell{ii,1}) 
            is_find = 1;
        end
    end
    
    if is_find
        index_tmp = [index_tmp;ii];
    end
end
if ~isempty(index_tmp)
    ch_label_cell(index_tmp,:)=[];
end

%-sort alphabetized
%convert e.g., 1->01, to avoid 10<2 in text sorting; and distinguish the names of the left and right side contacts
for ii = 1:size(ch_label_cell,1)
    
    if length(ch_label_cell{ii,1})==2 % e.g., 'A1', for left contacts
        ch_label_cell{ii,1} = [ch_label_cell{ii,1}(1) '_l0' ch_label_cell{ii,1}(2)]; % i.e., 'A_l01'
   
    elseif length(ch_label_cell{ii,1})==3 && sum(isstrprop(ch_label_cell{ii,1}, 'digit')) == 2 % e.g., 'A10', for left contacts
        ch_label_cell{ii,1} = [ch_label_cell{ii,1}(1)  '_l' ch_label_cell{ii,1}(2:3)]; % e.g., 'A_l10'    
        
    elseif length(ch_label_cell{ii,1})==3 && sum(isstrprop(ch_label_cell{ii,1}, 'digit')) == 1 % e.g., 'A''1', for right contacts
        ch_label_cell{ii,1} = [ch_label_cell{ii,1}(1) '_r0' ch_label_cell{ii,1}(3)]; % e.g., 'A_r01'
    
    elseif length(ch_label_cell{ii,1})==4 && sum(isletter(ch_label_cell{ii,1})) == 1 % e.g., 'A''10', for right contacts
        ch_label_cell{ii,1} = [ch_label_cell{ii,1}(1) '_r' ch_label_cell{ii,1}(3:4)];% e.g., 'A_r10'
    
    end
    
end

%sort
[~,index_tmp] = sortrows(ch_label_cell(:,1));
ch_label_cell = ch_label_cell(index_tmp,:);

%- further remove no-need ch: e.g., only 'E'
index_tmp = [];
for ii = 1:size(ch_label_cell,1)
    if length(ch_label_cell{ii,1})==1
        index_tmp = [index_tmp;ii];
    end
end
if ~isempty(index_tmp)
    ch_label_cell(index_tmp,:)=[];
end

%--- separate sig channel and trigger channel
index_tmp = [];

% for shengzhongyi, 
%   typically, trigger use the 'DC09'-'DC15' (among DC 01-16) (and has no specific 'TRIG' chanel)
%   by manually check, 
%       DC 9-16 are aways used, while DC 1-8 usually not
%   further bug of shengzhongyi,
%       given dec 11/bin 1011, accordingly channel 12,11,10,9; channel 13-15 are not used, then noisy and cause error in analysis, need to be excluded.
%       ! limitation, given dec 33/bin 100001; if limit channel to 9-12, trigger such as 33 cannot be analyzed
%   solution; 
%       given andy 
%           majorly always use 11
%           andy actrually identify trigger with even only 1 channel 
%               (to be most compatible for mistake, and for including the case of foshanyiyuan which has only 1 channel)
%       update to use DC 9-12

ch_index_DC = [];
% for foshanyiyuan, trigger use the 'TRIG' channel
%   ! check if it has DC channels. suppose no.
ch_index_TRIG = [];

for ii = 1:size(ch_label_cell,1)
    if strcmp(ch_label_cell{ii,1}(1:2),'DC')
        ch_index_DC = [ch_index_DC;ch_label_cell{ii,2}];
        index_tmp = [index_tmp;ii];
    end
    if strcmp(ch_label_cell{ii,1},'TRIG')
        ch_index_TRIG = [ch_index_TRIG;ch_label_cell{ii,2}];
        index_tmp = [index_tmp;ii];
    end
end

% get ch_index_trigger
if ~isempty(ch_index_DC)
    DC_num = length(ch_index_DC);
    ch_index_trigger = ch_index_DC(DC_num-7:DC_num-4);
end
if ~isempty(ch_index_TRIG)
    ch_index_trigger = ch_index_TRIG;
end

% get ch_index_target
if ~isempty(index_tmp)
    ch_label_cell(index_tmp,:)=[];
end

ch_index_target = [];
for ii = 1:size(ch_label_cell,1)
    ch_index_target = [ch_index_target;ch_label_cell{ii,2}];
end


%--- Part 3: ch grouping and reref ---|
%grouping
ch_grouping = [];
ch_grouping_name = [];
current_grouping_index = 1;
current_grouping_name = ch_label_cell{1,1}(1:3); % e.g., 'A_r'
ch_grouping_name = [ch_grouping_name; current_grouping_name];
for ii = 1:size(ch_label_cell,1)
    tmp_grouping_name = ch_label_cell{ii,1}(1:3);
    % update current grouping index and name if changed
    if ~strcmp(tmp_grouping_name,current_grouping_name)
        current_grouping_index = current_grouping_index + 1;
        current_grouping_name = ch_label_cell{ii,1}(1:3); % e.g., 'B_l'
        
        % add grouping name only when it changed
        ch_grouping_name = [ch_grouping_name; current_grouping_name];
    end
    
    ch_grouping = [ch_grouping; current_grouping_index];
end

%reref
 reref_ch = eleven_seeg_get_reref_ch(ch_grouping,1);

%
%disp('task done.');

