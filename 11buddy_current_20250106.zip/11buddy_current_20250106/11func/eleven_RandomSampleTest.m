function [pval_sample,CI_95_sample] = eleven_RandomSampleTest(stat_method,data_cell,resample_num,sample_method,tail_type)
%---Input
% stat_method
%   'one_sample_ttest'
%   'two_sample_ttest'
%   'pearson_correlation'
%   'classify_haxby2001_pearson'
%   (add further as needed)
% data_cell
%   a 1*n cell, with each one being an input data. each dat in the data cell is a column vector/matrix.
%       see application samples for setting data_cell.
%       (see more in below 'Further discription')
% resample_num
% sample_method 
%   'RP': random permutation. i.e., sample without replacement. 
%   'BS': bootstrap. i.e., sample with replacement.
% tail_type
%   'two_tail','one_tail';
%
%---Output
% pval_sample
% CI_95_sample
%
% Further discription
%   BS or RP, per se., is not the issue; which is just a type of randomization.
% 
%   the data, or feature that is to be involved, is the point.
%   it has to be separated from the randomization per se. Because, which data is of interest, 
%       is actually the feature selection, and is the biggest tricky part.
% 
%   the difficulty, is that the stat value varies, e.g., t value, r value, or even be customized in a varieties of cases.
%   matlab implement it in the bootstroop as a inline function, while this at least does not reduce the complexity.
%   Moreover, the structure of input data for calculating different stat values also varies, e.g., scala, matrix, 
%       and the corresponding meaning, e.g., sbj, ch/region/, cond.
% 
%   a possible general solution, might be, as needs, extend the complexity, from a a basic solution, which should incorparate the above considerations.
%
% Note
%   for one data, 
%       RP does not make sense, since the resamples give the same stat value (a related bug see below).
%       BS actually does not work, given the replace resample. 
%           it actually will give a middle stat val, thus the p of resample is always arround 0.5
%           this has been test by one-sample test, even the original p is much significant.
%   then, how to do for one data?
% Bug
%   see keyword #bug#
% Update history
% 2024-10-15 done testing
% 2024-10-10 
%   initial version. for develop background, see 'randomPermutation&bootstrap_develop_20240929.docx'.

%===get/set data===
%   data number is according to stat_method
%- one data
if length(data_cell)==1
    data1 = data_cell{1};
end

if length(data_cell)==2
    data1 = data_cell{1};
    data2 = data_cell{2};
end

%===the usual stat without resample===
%- 'one_sample_ttest'
if strcmp(stat_method, 'one_sample_ttest')
    [~,~,~,stats] = ttest(data1);
    stat_val_usual = stats.tstat;
end

%- 'two_sample_ttest'
if strcmp(stat_method, 'two_sample_ttest')
    [~,~,~,stats] = ttest(data1,data2);
    stat_val_usual = stats.tstat;
end

%- 'classify_haxby2001_pearson'
if strcmp(stat_method, 'classify_haxby2001_pearson')
    [~,~,~,~,coef_diff_loose_usual] = ...
        eleven_ClassifybyCor(data1,data2,'Pearson',[]);
    stat_val_usual = coef_diff_loose_usual;
end

%===resample===
%---initialize distribtion of stat value
if length(data_cell)==1
    stat_val_distribution = zeros(resample_num,length(stat_val_usual));
end

%|--- resample loop ---|
for ii=1:resample_num
    %--- reshape data to one column vector, and cat if two more data
    % one data
    tmpdata1 = reshape(data1,[size(data1,1)*size(data1,2),1]);
    tmpdata = tmpdata1;
    
    % if two data
    if length(data_cell)==2
        tmpdata2 = reshape(data2,[size(data2,1)*size(data2,2),1]);
        tmpdata = [tmpdata1;tmpdata2];
    end
    
    %--- resample
    if strcmp(sample_method,'RP')
        tmpdata_sample = datasample(tmpdata, length(tmpdata),'Replace',false);
    elseif strcmp(sample_method,'BS')
        tmpdata_sample = datasample(tmpdata, length(tmpdata),'Replace',true);
    else
        error('wrong input')
    end
    
    %--- uncat and reshape back
    tmpdata1 = tmpdata_sample(1:[size(data1,1)*size(data1,2)]);
    tmpdata1 = reshape(tmpdata1,[size(data1,1),size(data1,2)]);
    
    % if two data
    if length(data_cell)==2
        tmpdata2 = tmpdata_sample(([size(data1,1)*size(data1,2)]+1):end);
        tmpdata2 = reshape(tmpdata2,[size(data2,1),size(data2,2)]);
    end
    
    %--- stat
    %- 'one_sample_ttest'
    if strcmp(stat_method, 'one_sample_ttest')
        [~,~,~,stats] = ttest(tmpdata1);
        stat_val_usual_tmp = stats.tstat;
    end
    
    %- 'two_sample_ttest'
    if strcmp(stat_method, 'two_sample_ttest')
        [~,~,~,stats] = ttest(tmpdata1,tmpdata2);
        stat_val_usual_tmp = stats.tstat;
    end
    
    %- 'classify_haxby2001_pearson'
    if strcmp(stat_method, 'classify_haxby2001_pearson')
        [~,~,~,~,coef_diff_loose] = ...
            eleven_ClassifybyCor(tmpdata1,tmpdata2,'Pearson',[]);
        stat_val_usual_tmp = coef_diff_loose;
    end
    
    % fill in the stat_val_distribution
    stat_val_distribution(ii,:) = stat_val_usual_tmp;
end

%--- sort distribution
stat_val_distribution = sort( stat_val_distribution);

% an error control
%   #bug#. ! this type of error cannot be controled. ?
%       use RP for one data should lead to same stat val for all resampling.
%       manual visual check confirm this.
%       However, the digit check give wield results. due to digit precision? 
%{
if all(stat_val_distribution == stat_val_distribution(1))
    error('all elements in the distribution are the same.');
end
%}

%===get pval_sample===
% initialize
pval_sample = ones(1,length(stat_val_usual));
CI_95_sample = ones(2,length(stat_val_usual));

for ii = 1:length(stat_val_usual) % the loop for each column, i.e., if multiple data/features involved in stat
    tmp_stat_val = stat_val_usual(ii);
    tmp_stat_val_distribution = stat_val_distribution(:,ii);
    
    %---95 CI
    CI_95_sample(:,ii) = prctile(tmp_stat_val_distribution,[2.5,97.5])';
    
    %--- pval
    if tmp_stat_val>=0
        pval = length( find(tmp_stat_val_distribution>tmp_stat_val) ) /  resample_num;
    else
        pval = length( find(tmp_stat_val_distribution<tmp_stat_val) ) /  resample_num;
    end
    
    % tail
    if strcmp(tail_type,'two_tail') % two tail
        pval_sample(ii) = pval;
    elseif strcmp(tail_type,'one_tail') % one tail
        pval_sample(ii) = pval/2;
    else
        error('wrong input')
    end
end

