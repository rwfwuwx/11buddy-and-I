function sig_clean = eleven_extremeValue_remove(sig,is_detrend,outlier_threshold,norm_points)
% sig_clean = eleven_extremeValue_remove(sig,is_detrend,outlier_threshold,search_num,norm_points)
%   automatically and iterately detect and replace, + smooth
%Usage
%   sig_clean = eleven_extremeValue_remove(sig,is_detrend,outlier_threshold,search_num,norm_points)
%Inupts
%  is_detrend --- required for signal without preprocessing such as filter.
%   0 or 1.
%       typically, 0 for eeg; 1 for ecg and rsp.
%   outlier_threshold --- the threshold for outlier.
%       typically, this is 1.5.
%       in practice, 2.5 works here for rsp .... (further test later).
%Outputs
%   
% Update history
%   2020-11-25
%      for remaining 'outlier', add a whole signal smooth
%       + detection
%   2020-11-24 build.
%

if (nargin ~= 4)
    disp('eleven_extremeValue_remove 4 input arguments!')
	return
end


if is_detrend
    mean_sig = mean(sig);
    sig=detrend(sig)+mean_sig;
end

% detect outlier, and replace value
extremeValue_index = [];

is_there_outlier = 1;
while is_there_outlier == 1
    q1 = quantile(sig, .25);
    q3 = quantile(sig, .75);
    iqr = q3-q1;
    outlier_low = q1 - outlier_threshold*iqr;
    outlier_high = q3 + outlier_threshold*iqr;
    
    extremeValue_index_tmp = find( sig<=outlier_low | sig>=outlier_high );
    goodValue_index_tmp =  find( sig>outlier_low & sig<outlier_high );
    
    if isempty(extremeValue_index_tmp)
        is_there_outlier = 0;
    end
    
    if ~isempty(extremeValue_index_tmp)
        sig(extremeValue_index_tmp) = mean(sig(goodValue_index_tmp));
    
        extremeValue_index = union(extremeValue_index,extremeValue_index_tmp);
    end
end


%
%norm
%   about: 
%   
%   2. the norm is the same norm handling as mf_spec .       
%
if isempty(extremeValue_index)
    for ii=1:length(extremeValue_index)
        if extremeValue_index(ii)<=norm_points
            sig(extremeValue_index(ii)) = median(sig([extremeValue_index(ii):extremeValue_index(ii)+norm_points]));
        end
        if extremeValue_index(ii)>norm_points && extremeValue_index(ii)<(length(sig)-norm_points)
            sig(extremeValue_index(ii)) = median(sig([extremeValue_index(ii)-norm_points:extremeValue_index(ii)+norm_points]));
        end
        if extremeValue_index(ii)>=(length(sig)-norm_points)
            sig(extremeValue_index(ii)) = median(sig([extremeValue_index(ii)-norm_points:extremeValue_index(ii)]));
        end
    end
end
%
%{
%norm by smooth local sig instead of single point   
%
if isempty(extremeValue_index)
    for ii=1:length(extremeValue_index)
        if extremeValue_index(ii)<=norm_points
            sig([extremeValue_index(ii):extremeValue_index(ii)+norm_points]) = ...
                smooth(sig([extremeValue_index(ii):extremeValue_index(ii)+norm_points]));
        end
        if extremeValue_index(ii)>norm_points && extremeValue_index(ii)<(length(sig)-norm_points)
            sig([extremeValue_index(ii)-norm_points:extremeValue_index(ii)+norm_points]) = ...
                smooth(sig([extremeValue_index(ii)-norm_points:extremeValue_index(ii)+norm_points]));
        end
        if extremeValue_index(ii)>=(length(sig)-norm_points)
           sig([extremeValue_index(ii)-norm_points:extremeValue_index(ii)]) = ...
               smooth(sig([extremeValue_index(ii)-norm_points:extremeValue_index(ii)]));
        end
    end
end
%}

%
sig = smooth(sig,norm_points);
%
sig_clean = sig;


