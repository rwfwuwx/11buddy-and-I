function eleven_PsychoBuddy_set_expVariableParam
% eleven_PsychoBuddy_set_expVariableParam	
% Usage
%   eleven_PsychoBuddy_set_expVariableParam
% external varialbe (add later)
%  -- output
% 
% Todo
%  --- 'sudoRandom_[]'
%       Binomial
%       Multinomial
%       ...
% --- for sequence_present_order, add param now, for later if needs.
% Update history 
%   2023-07-17 add baseline_crt
%   2023-07-11
%       add 'fix' to sequence order
%       correction: remove duplicated trigger_study_type setting, which has been set in set optionVariable.
%   2022-12-22
%       update stim_present_order
%       add IOI_order
%       add sequence handling, update from existing task
%       add formal_test_number_raio
%   2022-12-19 modify from eleven_PsychoBuddy_set_expVariable


clear; % do not remove this

% |-----------------------------------|
% |----------no change setting ---------|
% |-----------------------------------|
% visual index; image index+1000; auditory index: sound index+2000;visual-auditory index; va index+3000
v_index_plus=1000; a_index_plus=2000; va_index_plus=3000;

% |-----------------------------------|
% |---------- basic setting ---------|
% |-----------------------------------|

% if a param has no default, it must appear in customize setting. 

formal_test_ratio_stim_number = 5;
formal_test_ratio_sequence_number = 5;

%--- stim_present_order
%           given stim indexNum 1:n, n>=1
%           (input format being [1:n])
%               'random_shuffle' (default): randomize by the Shuffle
%               'fix': 1:n
%               'sudoRandom_reverse': n:1
%               'sudoRandom_manual': specify manually as required.
stim_present_order = 'random_shuffle'; 
stim_repetition_num = 3; % default 1. set as needs. (Note: here repeat once equals to present once)
stim_duration = 0.8; % in s.  

%--- (stim_IOI_)order & (stim_)IOI
%           given IOI 1:n, n>=1, 
%           (input format being [IOI1 IOI 2 ... IOIn])
%               'random_shuffle'(default): randomize by the Shuffle 
%               'fix': 1:n
%               'Random_even': randomize by even distribution, which
%                   requires input IOI as [low bound, high bounnd]
%               'sudoRandom_manual': specify manually as required.

IOI_order = 'random_shuffle';
IOI = [0.4 0.6 0.8];

%IOI_order = 'fix';
%IOI = [0.6];

%
% IOI_order = 'Random_even';
% IOI = [1.1 1.5];

%--- sequence
sequence_num = 1; % default 1. set number as required
    % i.e., sequence_repetition num


%--- sequence_present_order
%           given stim indexNum 1:n, n>=1
%           (input format being [1:n])
%               'random_shuffle' : randomize by the Shuffle
%               'fix'(default): 1:n
%               'sudoRandom_reverse': n:1
%               'sudoRandom_manual': specify manually as required.
stim_present_order = 'fix'; 

%--- sequence_IOI_order & sequence IOI
%           given IOI 1:n, n>=1, 
%           (input format being [IOI1 IOI2 ... IOIn])
%               'random_shuffle'(default): randomize by the Shuffle
%               'fix': 1:n
%               'Random_even': randomize by even distribution, which
%                   requires input IOI as [low bound, high bounnd]
%               'sudoRandom_manual': specify manually as required.
sequence_IOI_order = 'random_shuffle';
sequence_IOI = [3.3 3.7 4.1 4.5];

%
% IOI_order = 'Random_even';
% IOI = [3.3 4.5];

% |-----------------------------------|
% |---------- extra setting ---------|
% |-----------------------------------|
%--- baseline correction
% default 0: no correction; 1: do correction. When 1, need to generate
%   baseline_correction.mat consisting of variables starting_rest or/and
%   ending_rest.
baseline_crt=0;


% |-----------------------------------|
% |--------- audition setting --------|
% |-----------------------------------|

% |-----------------------------------|
% |---- keyboard & related setting ---|
% |-----------------------------------|



% --- save
save eleven_PsychoBuddy_expVariableParam;

clear; % do not remove this
