function eleven_PsychoBuddy_set_expVariableParam_customize
% eleven_PsychoBuddy_set_expVariableParam_customize	
% Usage
%   eleven_PsychoBuddy_set_expVariableParam_customize
%
% Update history 
%   2022-12-19 modify from eleven_PsychoBuddy_set_OptionVariable_customize

clear; % do not remove this

load eleven_PsychoBuddy_expVariableParam;

% |--- add customized options here, if there are ---|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_PsychoBuddy_set_expVariableParam.m here 
%       2. modify here as needs
%       3. run eleven_PsychoBuddy_set_expVariableParam_customize here (make sure in the current program directory)



% --- save
save eleven_PsychoBuddy_expVariableParam_customize;

clear; % do not remove this
