% script of post checking.
%
% update history
%   2020-09-04 update with yangyang.
%   before 2004. initial written with PTB_template.m.

clear;

%--- input
%   to-be-checked variables are stim_sequence, IOI_sequence.
load eleven_PsychoBuddy_expVariable;

%--- output
% load data from recording file
file_name = 'record_2020     9     4    15    41    54.txt'; % change file name to to be checked file name
result_data = load(file_name);

% generate stim_sequence from recording
stim_index = find(result_data(:,1)>1000);
stim_sequence_record = result_data(stim_index,1);

% generate IOI_sequence from recording
stim_time_record = result_data(stim_index,2);
IOI_sequence_record = diff(stim_time_record);

%--- check between input and output
format short g;% do not display in scientific notions

% check stim_sequence
%   the difference should all be zero
if isempty(find((stim_sequence_record - stim_sequence')~=0)) % stim-sequence is row vector, change to column vector later, maybe
    disp('stimuli are OK');
else
    disp('well, somewhere wrong with stimulus recording !'); 
end

% check IOI_sequence
%   mean and SD of the differences. 
mean_IOI = mean((IOI_sequence_record - IOI_sequence(1:end-1))*1000);
std_IOI = std((IOI_sequence_record - IOI_sequence(1:end-1))*1000);
disp(['delay = ' num2str(mean_IOI) ' ms']);
disp(['delay std = ' num2str(std_IOI) ' ms']);

%--- handle response later
% key press f and j
%resp_recording = result_data(find(result_data(:,1)==88 | result_data(:,1)==99),:);

%--- handle others later




