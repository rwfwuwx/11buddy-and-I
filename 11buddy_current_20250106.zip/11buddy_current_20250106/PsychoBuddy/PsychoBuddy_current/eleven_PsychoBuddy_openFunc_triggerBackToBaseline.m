%openfunc eleven_PsychoBuddy_openFunc_trigger_and_response.m
%
% Note: record furthe update history not here, rather, in the main yangyang.
%
% Update history
% 2024-09-04 separate from eleven_PsychoBuddy.m


%--- count trigger_duration, then set to baseline ---|
if trigger_study_type == 2
    if is_trigger_sent == 1
        
        if (time_tmp-trigger_sent_time)>trigger_duration     
            
            if port_type == 1
                if which_system == 2
                    if bit_type == 1 || bit_type == 2
                        outp(address,0);
                        is_trigger_sent = 0;
                        trigger_sent_time = [];
                        %disp(0);% for debuging
                    end
                end
            end
            if port_type == 2
                IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                is_trigger_sent = 0;
                trigger_sent_time = [];
                %disp(0);% for debuging
            end

        end
        
    end
end
