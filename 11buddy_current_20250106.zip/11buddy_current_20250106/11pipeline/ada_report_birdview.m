
%
%Note for 11buddy keeper
%   arrange and set needs, where "$$" indicates.
%
%Update history
% 2024-12-11 current_analysis_dir->current_analysis_path
% 2023-12-29 ask java to free some memory for each ada.
%   this is for the known java gabbage collection bug:"low free heap" after
%   more than 100 adas have run
% 2023-12-26
%   add clear handling for ada run loop,to advoid memory leakage, 
%       potential interference between adas
%       out of memory 
% 2023-12-18
%   add add logo
% 2023-12-14
%   update "���ڼ����Ժ�����أ������Ժ��ٱȽ�" 
%       ��ada_report_eeg.mlxͬ������
% 2023-12-09
%   separate manual part to ada_ganhuola_template_[date].m / ���ð���ɻ���_template_[date].txt.
%   !!! from now on, totally automation.
%       ada_report_birdview_template_[date].m->ada_report_birdview.m. 
%           Although, given the user complexity ada faces,still keep it as script instead of function.
%       this should be general regardless of behavioral, eeg, fmri.
%   update compare
% 2023-12-07~08
%   add and handle SigStatTarget. together see ada_report_birdview_tmplate_[date].
%   add and handle CondGroup. together see ada_report_birdview_tmplate_[date].
%       add data structure ada_CondGroup_template.xlsx
%   add [%[11mod] back, otherwise the ada mlx can not be run independently: i.e., if the param is only decided in runtime.
% 2023-12-05
%   done end-do-end from requirement excel to word output
%   instead of eleven_xlsread.m, use readtable.from now on, use matlab
%       Table to replace the ugly xlsead to handle exel file
%   ---see ada_ganhuola_template_[date].m, Update history, 2023-12-05, 'the measureVar issue'
%       !!!no 'the sds issue' anymore
%       !!! no primary ada and secondary ada anymore
%   ---incorperate ada_ganhuola_SetInputParam_template_[data].m
%       #Note: since the to-be-change param is now separated out here, the setting can be done here.
%       which means, currently,
%           #the mechanism of change file content at specific places, by ['%[11mod]', is not needed anymore.
%           #the mechanism of change file content at all places, particularly for measureVar, is still needed.
%       for a recall backup: the develop of mechanism of change file content, is illustrated by sample at
%           'J:\analyze\test\ada_update_test_2023-11'
%   ---add get requirements.
%       #the old '�������һ��������_[����].txt' is now incorperated into the requirement excel.
%           'is_pca' is now closed defaultly.
%       #incorperate previous needs setting with  the requirement excel.
%       #automate requirement setting according to the the requirement excel.
%       #no need for description of each ada, which is already in the requirement excel.
% 2023-11-23~24 initial version
%
% Todo
%   clear and incorperate the beginning text
%

myicon = imread('ada.jpg');
h=msgbox('������Ϊ���������������ĵȴ�',' ','custom',myicon);

% default dir for SigStatTarget TimeStamp
if exist('SigStatTarget_TimeStamp')~=7
    mkdir('SigStatTarget_TimeStamp');
end

% ada_activity_classification. leave open for later further generalization.
%[
% ada_activity_classification = EEGSpecAlpha
%]

%--- read the ada_CondGroup_.xlsx; and save required variable for ada_ganhuola_template
T_tmp = readtable(ada_CondGroup_excel_file);

%- get groupSbjIndexDataName
groupSbjIndexDataName = T_tmp.Var1;
% clear out empty elements
tmp_index = [];
for ii = 1:length(groupSbjIndexDataName)
    if isempty(groupSbjIndexDataName{ii})
        tmp_index = [tmp_index; ii];
    end
end
groupSbjIndexDataName(tmp_index) = [];
save groupSbjIndexDataName groupSbjIndexDataName;

%- get groupSbjIndexDataName_Name
groupSbjIndexDataName_Name = cell(length(groupSbjIndexDataName),1);
for ii = 1:length(groupSbjIndexDataName)
    eval(sprintf('tmp_data = T_tmp.Var%d;',1+ii));
    % clear out empty elements
    tmp_index = [];
    for jj = 1:length(tmp_data)
        if isempty(tmp_data{jj})
            tmp_index = [tmp_index; jj];
        end
    end
    tmp_data(tmp_index) = [];
    groupSbjIndexDataName_Name{ii} = tmp_data;
end
save groupSbjIndexDataName_Name groupSbjIndexDataName_Name;

%- get groupSbjIndexDataName_Value
groupSbjIndexDataName_Value = cell(length(groupSbjIndexDataName),1);
for ii = 1:length(groupSbjIndexDataName)
    eval(sprintf('tmp_data = T_tmp.Var%d;',1+length(groupSbjIndexDataName)+ii));
    % clear out empty elements
    tmp_index = [];
    for jj = 1:length(tmp_data)
        if isnan(tmp_data(jj))
            tmp_index = [tmp_index; jj];
        end
    end
    tmp_data(tmp_index) = [];
    tmp_data = num2cell(tmp_data);
    groupSbjIndexDataName_Value{ii} = tmp_data;
end
save groupSbjIndexDataName_Value groupSbjIndexDataName_Value;

%--- read the ada_reqire_.xlsx;
%   Note, assume the vars according to the require excel
T_ada_require = readtable(ada_require_excel_file);


%|---------------------------------------|
%|------------ produce adas -------------|
%|---------------------------------------|

ada_num = length(T_ada_require.measureVar);
ada = cell(1,ada_num);
ada_need = cell(1,ada_num);

%--- get ada need, including ada name
for ii = 1:ada_num
    
    % !!! currently fix ada_need, according to fixed requirement excel. extend later
    if strcmp(T_ada_require.SigStatType{ii},'comp')
        ada_need_num = 6;
    end
    if strcmp(T_ada_require.SigStatType{ii},'corr')
        ada_need_num = 4;
    end
    ada_need{ii} = cell(ada_need_num,2); % row: needs; col 1 and 2: replace 1 with 2
    
    %- set param: SigStatType
    if strcmp(T_ada_require.SigStatType{ii},'comp')
        tmp_replace_text = 'stat_ana_type = stat_ana_type_comparison;';
    end
    if strcmp(T_ada_require.SigStatType{ii},'corr')
        tmp_replace_text = 'stat_ana_type = stat_ana_type_corr;';
    end
    ada_need{ii}(1,:) = {...
        ['%[11mod]' sprintf('\n') 'stat_ana_type = stat_ana_type_comparison;'],...
        ['%[11mod]' sprintf('\n') tmp_replace_text]};
    
    %- set param: isEEGSensor
    if T_ada_require.isEEGSensor(ii) == 1
        tmp_replace_text = 'is_eeg_sensor = 1;';
    else
        tmp_replace_text = 'is_eeg_sensor = 0;';
    end
    ada_need{ii}(2,:) = {...
        ['%[11mod]' sprintf('\n') 'is_eeg_sensor = 1;'],...
        ['%[11mod]' sprintf('\n') tmp_replace_text]};
    
    %- measureVar
    ada_need{ii}(3,:) = {...
        ['measureVarNO1'],...
        [T_ada_require.measureVar{ii}]};
    
    %- set param: SigStatTarget1. it is commone for both corr and comp
    SigStatTarget1 = T_ada_require.SigStatTarget1{ii}; % e.g., input a,b in excel; read as {'a,b'}; get out as 'a,b'
    
    % get a time stamp and add to var name
    timeStamp = [num2str(datetime().Year),...
        num2str(datetime().Month),...
        num2str(datetime().Day),...
        num2str(datetime().Hour),...
        num2str(datetime().Minute),...
        num2str(round(datetime().Second*1000))];
    SigStatTarget1_name_with_TimeStamp = ['SigStatTarget1' '_' timeStamp];
    
    % save the var while by a var name with a time stamp, into the default dir
    cd SigStatTarget_TimeStamp;
    eval(sprintf('save %s SigStatTarget1;',SigStatTarget1_name_with_TimeStamp));
    cd ../;
    
    % for the replace in ada
    tmp_text = ['load '];
    tmp_replace_text = [tmp_text SigStatTarget1_name_with_TimeStamp ';'];
    ada_need{ii}(4,:) = {...
        ['%[11mod]' sprintf('\n') 'load SigStatTargetNO1_[TimeStamp];'],...
        ['%[11mod]' sprintf('\n') tmp_replace_text]};
    
    pause(0.005); % i.e., avoid time overlapping with next time stamp
    
    %- set param: SigStatTarget2. only for comp
    if strcmp(T_ada_require.SigStatType{ii},'comp')
        SigStatTarget2 = T_ada_require.SigStatTarget2{ii};
        
        % get a time stamp and add to var name
        timeStamp = [num2str(datetime().Year),...
            num2str(datetime().Month),...
            num2str(datetime().Day),...
            num2str(datetime().Hour),...
            num2str(datetime().Minute),...
            num2str(round(datetime().Second*1000))];
        SigStatTarget2_name_with_TimeStamp = ['SigStatTarget2' '_' timeStamp];
        
        % save the var while by a var name with a time stamp, into the default dir
        cd SigStatTarget_TimeStamp;
        eval(sprintf('save %s SigStatTarget2;',SigStatTarget2_name_with_TimeStamp));
        cd ../;
        
        % for the replace in ada
        tmp_text = ['load '];
        tmp_replace_text = [tmp_text SigStatTarget2_name_with_TimeStamp ';'];
        ada_need{ii}(5,:) = {...
            ['%[11mod]' sprintf('\n') 'load SigStatTargetNO2_[TimeStamp];'],...
            ['%[11mod]' sprintf('\n') tmp_replace_text]};
        
        pause(0.005); % i.e., avoid time overlapping with next time stamp
    end
    
    %- set param: compare_group_type. only for comp
    if strcmp(T_ada_require.SigStatType{ii},'comp')
        if strcmp(T_ada_require.CompareGroupType{ii},'within')
            tmp_replace_text = 'compare_group_type = compare_group_type_within;';
        end
        if strcmp(T_ada_require.CompareGroupType{ii},'between')
            tmp_replace_text = 'compare_group_type = compare_group_type_between;';
        end
        ada_need{ii}(6,:) = {...
            ['%[11mod]' sprintf('\n') 'compare_group_type = compare_group_type_within;'],...
            ['%[11mod]' sprintf('\n') tmp_replace_text]};
    end
    
    %- output files
    ada{ii} = [T_ada_require.adaReportFileName{ii} '.mlx']; % ���븱�����ļ���
end

%--- produce adas

for ii=1:ada_num
    % initialize temporal iterate operation files, see below description
    %tmp_file_previous_operation = [];
    tmp_file_next_operation = 'tmp_file_next_operation.mlx';
    matlab.internal.liveeditor.createLiveScript(tmp_file_next_operation);
    
    tmp_ada_need_num = size(ada_need{ii},1);
    for jj=1:tmp_ada_need_num % loop of ada need
        % set input and output files
        %   for each current iterate operation,
        %       get input file from previous operation and send file for next operation,unless,
        %           for the first operation, input is the ada template
        %           for the last operation, output is the ada
        
        if jj==1
            tmp_file_input = ada_template;
        else
            tmp_file_input = tmp_file_previous_operation;
        end
        
        if jj==tmp_ada_need_num
            tmp_file_output = ada{ii};
        else
            tmp_file_output = tmp_file_next_operation;
        end
        
        %   set files after iteration done
        file_input = tmp_file_input;
        file_output = tmp_file_output;
        
        % set find string and replace string
        tmp_string_find = ada_need{ii}{jj,1};
        tmp_string_replace = ada_need{ii}{jj,2};
        
        % perform find & replace
        eleven_FindAndReplaceInFile(file_input,file_output,...
            tmp_string_find,tmp_string_replace);
        
        % update temporal iterate operation files
        if tmp_ada_need_num>1 % no need for only one need
            tmp_file_previous_operation = tmp_file_next_operation;
        end
        
    end
end

% clear out temporal iterate operation files
delete(tmp_file_next_operation);

%|-----------------------|
%|------- ada run -------|
%|-----------------------|

%--- run adas with outputs
save studyID studyID;
save current_rawdata_rootDir current_rawdata_rootDir;
save current_analysis_rootDir current_analysis_rootDir;
save current_11job_rootDir current_11job_rootDir;
save current_analysis_path current_analysis_path;

save ada_num ada_num;
save ada ada;

tmp_ii_abv=1;
save tmp_ii_abv tmp_ii_abv;

clear;
load tmp_ii_abv;
load ada_num;
load ada;

for ii_abv=1:ada_num
    % run
    % global variable from ada_ganhuola
    load studyID;
    load current_rawdata_rootDir;
    load current_analysis_rootDir;
    load current_11job_rootDir;
    load current_analysis_path;
    
    eleven_mlx_execute_convert(ada{ii_abv},'docx');
    
    tmp_ii_abv=tmp_ii_abv+1;
    save tmp_ii_abv tmp_ii_abv;
    
    clear;
    java.lang.System.gc(); % ask java to free some memory
    pause(0.01);
    
    load tmp_ii_abv;
    load ada_num;
    load ada;
    
    ii_abv=tmp_ii_abv;
end


disp('����׼���ý��������~����ȥ��һ���ɡ�')

%close(h)
myicon = imread('ada.jpg');
msgbox('���Ѿ�׼���ý��������~����ȥ��һ���ɡ�','Success','custom',myicon);
