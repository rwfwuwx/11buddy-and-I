function eleven_GLAutojob_routine_eegCfeAnafeatureExtract(dir_root_file,dir_tree_file,eeg_analyze_type_list_file,sbj_info_file,data_index,is_formal)
% Input
%   data_index --- which data is to analyze
%   (other inputs see eleven_GLAutojob_routine_eegRptAnaAvg)
%
% Description
%   --- The basic logic of the things tuns out to be simple: it's all there.
%       # go to data, as in eleven_GLAutojob_routine_eegRptAnaAvg.m.
%       # get the dir structure
%           loop
%       	in the loop, simply call the sub_procedure
%       (i.e., as in andy_result_report.mlx)
%       # the produce feature procedure needs read parameters, as in andy_image.
%   --- for whether the analysis is performed on a data, indicated by data_index.
%   --- use the 'avg' routine, rather than the 'command' routine, considering
%       the need of handling data_index
%       this is about 'allsbj', not totally 'individual'; e.g.,
%           'allsbj' 'allsbj_test'
%           (handling 'NaN')
%       For individual level, analysis is performed on data, thus sbj-data loop is natural.
%          !!! For allsbj level, i.e., step 3 and 4, analysis is performed on sbj,
%           the data-dataAnaDir-sbj,  is more natural.
%               !!! but before to to sbj, the dataAnaDir.mat cannot be read, thus preventing automation.
%               the solution can be, further copy dataAnaDir.mat from sbj-data -> each of sbj-data-dataAnaDir.
%                   then dataAnaDir.mat can be read from data-dataAnaDir
%       (the need of ada that extracted data are required to be consistent with avg).
%
% Todo
%
% Note
%
% Update history
%   2022-06-17 intial version. see Description for the logic.

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

atlasNames = {'DesikanKilliany'};

%--- decide whether include a data
data_include_index = ones(data_num,1);

% not include data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        data_include_index(ii) = 0;
    end
end

% a double check that the input data_index is already analyzed
data_include_index = data_include_index & data_index;

data_include_index_num = find(data_include_index==1);


for ii = 1:length(data_include_index_num)
    
%     allsbj_data_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{[data_include_index_num(ii)]}];
    sbj_data_path = [dir_root{1} '\' 'sbjxx' '\' dir_tree{[data_include_index_num(ii)]}];
    
    eeg_analyze_type_list = load(eeg_analyze_type_list_file);
    eeg_analyze_type = eeg_analyze_type_list([data_include_index_num(ii)],1);
    
    % set dir_list manually, i.e., data_path + the dataAnaDir.
    if ~isempty(find(eeg_analyze_type == [1 2 3 42]))
        % set dir_list
%         dir_list_allsbj = { ...
%             [allsbj_data_path '\' 'run2'],...
%             [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        
        dir_list_sbj = { ...
            [sbj_data_path '\' 'run2'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
    end
    
    if eeg_analyze_type == 4
%         dir_list_allsbj = { ...
%             [allsbj_data_path '\' 'run2' '\' 'srer'],...
%             [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srer'],...
%             [allsbj_data_path '\' 'run2' '\' 'srssep'],...
%             [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srssep']};
        
        dir_list_sbj = { ...
            [sbj_data_path '\' 'run2' '\' 'srer'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srer'],...
            [sbj_data_path '\' 'run2' '\' 'srssep'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srssep']};
    end
    
    % loop of dir_list
    for jj = 1:length(dir_list_sbj)
        
        % loop of sbj
        for kk = 1:length(sbj)
            
            % whether analyze this data
            tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
            eval(sprintf('tmp_is_analysis_cond = %s(kk);',tmp_var_name));
            
            if tmp_is_analysis_cond == 1
                current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{kk});
                cd(current_dir_sbj);
                
                
                % |--- do the job here ---|
                
                andy_autojob_produce_componentFeature;
                
                % |--- end do the job ---|
                
            end
            
        end 
    end
end


cd([dir_root{1} '\' allsbj_dirName]);
