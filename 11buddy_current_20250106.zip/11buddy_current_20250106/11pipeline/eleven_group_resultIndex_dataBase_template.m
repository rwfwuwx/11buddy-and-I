function eleven_group_resultIndex_dataBase_template(dir_root_file,dir_tree_file,which_in_dir_tree,sbj_info_file,resultIndex_list_file,dataBase_file)
% Input
%   dir_root. In a txt file
%   dir_tree. in a txt file
%   which_in_dir_tree. assign (currently) one in dir tree.
%   sbj & cond_special. in an excel file.
%   index_list_file. in a txt file
%   dataBase_file
%       file format, excel.
%       data format, data frame (as in R)
%
% Update history
%   2020-11-24
%   eleven_group_resultIndex_dataBase_template_psych->eleven_group_resultIndex_dataBase_template
%   by guozhihan
%   2020-11-23 modified by guozhihan
%   2020-11-20 modify from eleven_group_analysis_template.m

%{
dir_root_file = 'analysis_root_dir_ShengProject2020.txt';
dir_tree_file = 'analysis_dirTree_physio_ShengProject2020.txt';
which_in_dir_tree =1;
sbj_info_file = 'eleven_group_analysis_sbjInfo_template_2020-11-20_test.xlsx';
resultIndex_list_file = 'resultIndex_list_physio.txt';
dataBase_file = 'dataBase_physio_pre_resting_20201120.xlsx';
%}

%--- load dir_root
dir_root = importdata(dir_root_file);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

tree_loop_num = length(dir_tree); 

%--- load sbj info
sbj_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_var_name)
    tmp_var_name = sbj_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

resultIndex = importdata(resultIndex_list_file);
index_num = length(resultIndex);

data = []; % column index; row, sbj

% 
for ii = 1:length(sbj) % loop of sbj
    
        current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{which_in_dir_tree}]; 
        cd(current_analysis_path);
        
%        logic_do = 1; % modify this, as needs. and extending for situations
        
        % select analysis for the subject
        tmp_var_name = sbj_var_name{2};
        eval(sprintf('logic_do = %s(ii);',tmp_var_name));
        
        % select analysis for dir tree
        tmp_var_name = sbj_var_name{which_in_dir_tree+2};
        eval(sprintf('logic_do = logic_do && %s(ii);',tmp_var_name));
        
        % select analysis for all
        %         for kk = 2:length(sbj_var_name)
        %             tmp_var_name = sbj_var_name{kk};
        %             eval(sprintf('logic_do = logic_do && %s(ii);',tmp_var_name));
        %         end
        
        if logic_do
            tmp = [];
            for jj = 1:index_num 
                if exist([resultIndex{jj} '.mat'])
                eval(sprintf('load %s;',resultIndex{jj}));
                eval(sprintf('tmp = [tmp %s];',resultIndex{jj}));
                else
                eval([resultIndex{jj} '=nan;']);
                eval(sprintf('tmp = [tmp %s];',resultIndex{jj}));
                end
            end
            data = [data;tmp];
        end
end

% write file in root dir
cd([dir_root{1} '\allsbj']);

header = resultIndex';
A = [header; num2cell(data)];
xlswrite(dataBase_file,A);


