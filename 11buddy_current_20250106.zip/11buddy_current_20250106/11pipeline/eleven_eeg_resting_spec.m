function eleven_eeg_resting_spec
% eleven_eeg_resting_spec
% Usage
%   eleven_eeg_resting_spec
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   add resting_FreqNorm_method
%   2020-10-30 correct a bug of padding
%   2020-10-20 written

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|

%clear;
disp('resting spec processing');

% load option variables
load eleven_eeg_OptionVariable_customize;

% --- input
load eeg_raw_pp;

eeg_raw_pp = eeg_raw_pp([resting_padding_points+1:size(eeg_raw_pp,1)-resting_padding_points-1],:); % cut required data, by removing the starding and ending padding time

% --- spec
disp('  spec');
[eeg_resting_spec_am_raw,eeg_resting_spec_am_norm,eeg_resting_spec_phase,eeg_resting_spec_freq] = ...
    mf_rawspec(eeg_raw_pp,fs,resting_am_type,resting_phase_type,resting_FreqNorm_points,resting_FreqNorm_method);

%--- output
save eeg_resting_spec_am_raw eeg_resting_spec_am_raw;
save eeg_resting_spec_am_norm eeg_resting_spec_am_norm;
save eeg_resting_spec_phase eeg_resting_spec_phase;
save eeg_resting_spec_freq eeg_resting_spec_freq;

%clear;
