function eleven_GLAutojob_command(dir_root_file,dir_tree_file,sbj_info_file,eleven_job_path,exe_command_name)
% Input
%   dir_root_file. In a txt file
%   dir_tree_file. in a txt file
%   sbj_info_file. in an excel file.
%       !!! standarize format.
%       1) the first column name has to be 'sbj'.
%       2) for all cell, default 0. do not leave blank.
%       3) cond in sbj_info_file and dir_tree_file must be the same.
%       further 
%           (the first row has to be one row)
%   exe_command_name. a string containing the command to do a job.
%       can be one command, or more command separated by ;,. e.g., 'do_job1;do_job2'.
%       typically, command is the name of a script or func without explicit inputs/outputs.
%           prefer to use func. if script, mark out 'clear', otherwise global variable will be lost.
%   eleven_job_path. for error record file location.
% Todo
%   cannot get back to allsbj directory
%   path to compatible path (i.e., win->win/unix)
% Note
%   1. !!! eleven_group_analysis_template ->
%       1) eleven_GLAutojob_command
%           execute command(s). i.e., what the original eleven_group_analysis_template does.
%       2) eleven_GLAutojob_routine_routineName
%           e.g., eleven_GLAutojob_routine_eegDataPrepare.
%           The need of routines is flexible (i.e., unlimited routines), 
%               and may not be implemented as a func, while can be standarized. 
%               extend and standarize more routines in this manner.
%       3) eleven_GLAutojob_funcWithParam_funcName
%           e.g., eleven_GLAutojob_funcParam_eegSource.
%           Sometime, parameters of a func is needed as input.
%           extend and standarize more such needs in this manner.
%       !!! all of above situations share the same framework. The 
%       difference is in "% |--- do the job here ---|".
%   2. current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
%       !!! dir_tree must match conditions. i.e., length(dir_tree) is number of conditions. 
%   3. while named GL, use this for one subject, simply specify one sbj in sbj_info file.
%       !!! follow this to avoid unnecussary issues and wasting time.
% Update history
%   2023-04-17
%       (for background and design of this update of error catch, see
%           error_handle_mechanism.docx)
%       add eleven_job_path as func input
%       bug fix and update of error catch
%   2023-04-14
%       add "try...catch..."to record error message and the corresponding wrong sbjID and cond in 
%       'sbjData_analysis_errRpt_[date].txt', and save the TXT in 'J:\11job\studyID' file. see line 99-120.
%           The backup functions(20230412,20230411,20230406,20230327) to achieve the same goal, but 
%           catch error in a Excel file according the error step.
%   2020-11-17
%       first enter into 'allsbj', and forced to standarize as 'allsbj'
%       template -> func
%       clarify and update controlling whether perform analysis for sbj and cond
%           remove logic_do-> explicit and clear control
%       add note
%       GLAutojob. group level autojob, to avoid confusing with
%           group/individual level analysis, as well as analysis/statistical analysis, etc.
%       modified from eleven_group_analysis_template.

%--- load dir_root
dir_root = importdata(dir_root_file);
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);
 
%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree); 

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

% initialize for writing error record file
error_count = 0;
error_file_name = [eleven_job_path '\' sbj_info_file(1:end-4) '_errRpt.txt'];
error_file = fopen(error_file_name,'w');

 for ll = 1:length(sbj) % loop of sbj
    % whether analyze this sbj
        tmp_var_name = sbj_info_var_name{2};
        eval(sprintf('tmp_is_analysis_sbj = %s(ll);',tmp_var_name)); 
        if tmp_is_analysis_sbj == 1
            for jj = 1:data_num % loop of dir_tree\cond  
                try  
                % whether analyze this cond,of this sbj
                    tmp_var_name = sbj_info_var_name{jj+2};
                    eval(sprintf('tmp_is_analysis_cond = %s(ll);',tmp_var_name));
                    if tmp_is_analysis_cond == 1
                        current_analysis_path = [dir_root{1} '\' sbj{ll} '\' dir_tree{jj}];
                        if exist(current_analysis_path,'dir')
                            cd(current_analysis_path);

                            % |--- do the job here ---|
                            eval(exe_command_name);
                            % |--- end job ---|
                        
                        end
                    end
                catch exception
                    error_count = error_count + 1;
                    
                    % get required error info: sbjID, dataID, error message when an error occurs
                    error_sbjID = sbj{ll};
                    error_cond = sbj_info_var_name{jj+2};
                    error_message = [exception.message];
                        
                    % write error info to file
                    fprintf(error_file,'%s\n%s\n%s\n',error_sbjID,error_cond,error_message);
                end
                
            end
        end

 end

 % post handling of writing error record file
 fclose(error_file);
 if error_count == 0
    delete(error_file_name);
 end

cd([dir_root{1} '\allsbj']);
