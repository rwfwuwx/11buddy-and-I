function eleven_group_feature_selection_template(dir_root_file,dir_tree_file,which_in_dir_tree,sbj_info_file,feature_list_file)
% Input
%   dir_root. In a txt file
%   dir_tree. in a txt file
%   which_in_dir_tree. assign (currently) one in dir tree.
%   sbj & cond_special. in an excel file.
%   feature_list_file. in a txt file
% Output (implicit)
%   feature_file
%       sbj*feature.
%           the basic data structure for ML.
%           can be one or more,depending on the feature(s) in feature_list_file.
%
% Update history%
%   2021-09-30 
%       add data structure accroding to data size
%       eleven_group_feature_selection_template.m -> eleven_group_produce_featureData_template.m
%   2021-06-18
%       modify from eleven_group_resultIndex_dataBase_template.m

%--- load dir_root
dir_root = importdata(dir_root_file);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

% tree_loop_num = length(dir_tree); 

%--- load sbj info
sbj_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_var_name)
    tmp_var_name = sbj_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

feature_list = importdata(feature_list_file);
feature_num = length(feature_list);

for jj = 1:feature_num
    % initialize data structure accroding to data size
    tmp_current_analysis_path = [dir_root{1} '\' sbj{1} '\' dir_tree{which_in_dir_tree}];
    cd(tmp_current_analysis_path);
    eval(sprintf('load %s;',feature_list{jj}));
    eval(sprintf('[row, col] = size(%s);',feature_list{jj}));
    
    if col==1 % sbj*region
        data = zeros(length(sbj),row);
    end
    if col>1 % connection*connection*sbj or region*sample*sbj
        data = zeros(row,col,length(sbj));
    end
    
    % assign value in sbj loop
    for ii = 1:length(sbj) % loop of sbj
        current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{which_in_dir_tree}];
        cd(current_analysis_path);
        
        eval(sprintf('load %s;',feature_list{jj}));
        eval(sprintf('tmp_data = %s;',feature_list{jj}));
        if col==1 
            data(ii,:) = tmp_data';
        end
        if col>1 
            data(:,:,ii) = tmp_data;
        end
    end
    tmp_file_name = ['allsbj_' feature_list{jj}];
    eval(sprintf('%s = data;',tmp_file_name));
end

% write file in root dir
cd([dir_root{1} '\allsbj']);

for jj = 1:feature_num
    tmp_file_name = ['allsbj_' feature_list{jj}];
    eval(sprintf('save %s %s;',tmp_file_name,tmp_file_name));
end




