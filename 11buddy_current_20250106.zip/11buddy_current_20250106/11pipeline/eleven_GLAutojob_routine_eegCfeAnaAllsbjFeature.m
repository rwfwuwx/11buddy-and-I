function eleven_GLAutojob_routine_eegCfeAnaAllsbjFeature(dir_root_file,dir_tree_file,eeg_analyze_type_list_file,sbj_info_file,data_index,is_formal)
% Input
%   
%
% Description
%   ! where to save the structual feature data?
%       just with the corresponding avg data.
%       thus, follow andy convention, individual and all sbj, just like 'changing sbjname'
%   ! but anyway, compared to individual data, allsbj data add a dimention of sbj
%       no better way, simply add allsbj to the feature data name
%           e.g., allsbj_featureDataName for allsbj, featureDataName for individual
% Todo
%
% Note
%   nan, for nan or 0.
%   the feature name is the same for individual and allsbj feature data;
%       while the latter has a more demension of sbj
% Update history
%	2022-06-23
%		add saving componentFeature_list.txt (see line 203-207, by HYY)
%   2022-06-20
%       add saving componentFeature_list.mat in allsbj dir,just for know feature list, without see option file
%       update getting ch info
%       remove 'allsbj_' in feature_name for allsbj
%       in componentFeature_list loop, at allsbj directory, instead of using a cell, get
%           necessary info and initialize structure directly
%   2022-06-19
%       add handling of nan
%       add handling of componentFeature_list: loop and pool across all sbj
%   2022-06-17 intial version. modified from
%       eleven_GLAutojob_routine_eegCfeAnaFeatureExtract.
%       eleven_GLAutojob_routine_eegRptAnaAvg.m.

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

atlasNames = {'DesikanKilliany'};

%--- decide whether include a data
data_include_index = ones(data_num,1);

% not include data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        data_include_index(ii) = 0;
    end
end

% a double check that the input data_index is already analyzed
data_include_index = data_include_index & data_index;

data_include_index_num = find(data_include_index==1);


for ii = 1:length(data_include_index_num)
    
    allsbj_data_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{[data_include_index_num(ii)]}];
    sbj_data_path = [dir_root{1} '\' 'sbjxx' '\' dir_tree{[data_include_index_num(ii)]}];
    
    % decide eeg_analyze_type by data
    eeg_analyze_type_list = load(eeg_analyze_type_list_file);
    eeg_analyze_type = eeg_analyze_type_list([data_include_index_num(ii)],1);
    
    % set dir_list manually, i.e., data_path + the dataAnaDir.
    if ~isempty(find(eeg_analyze_type == [1 2 3 42]))
        % set dir_list
        dir_list_allsbj = { ...
            [allsbj_data_path '\' 'run2'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
        
        dir_list_sbj = { ...
            [sbj_data_path '\' 'run2'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany']};
    end
    
    if eeg_analyze_type == 4
        dir_list_allsbj = { ...
            [allsbj_data_path '\' 'run2' '\' 'srer'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srer'],...
            [allsbj_data_path '\' 'run2' '\' 'srssep'],...
            [allsbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srssep']};
        
        dir_list_sbj = { ...
            [sbj_data_path '\' 'run2' '\' 'srer'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srer'],...
            [sbj_data_path '\' 'run2' '\' 'srssep'],...
            [sbj_data_path '\' 'run3' '\' 'DesikanKilliany' '\' 'srssep']};
    end
    
    % loop of dir_list
    for jj = 1:length(dir_list_sbj)
        current_dir_allsbj = dir_list_allsbj{jj};
        cd(current_dir_allsbj);
        
        %--- get ch num
        tmp_dir=pwd;
        if exist([tmp_dir '\' 'source_atlas.mat'],'file')  % scalp eeg run3. (as andy_image)
            load source_atlas
            label_name = [source_atlas,'_label'];
            load(label_name);
            eval(sprintf('tmp_ch_num = length(%s);',label_name));
        else % scalp eeg run2. use reref_ch
            load eleven_eeg_OptionVariable_customize;
            tmp_ch_num = length(reref_ch);
        end
        
        %--- get componentFeature_list (componentFeature_list)
        eleven_eeg_set_OptionVariable_cfe_customize;
        load eleven_eeg_OptionVariable_cfe_customize;

        % loop of feature 
        for kk = 1:length(componentFeature_list)
            
            tmp_feature_name = componentFeature_list{kk};
            
            %--- initialize allsbj data
            %   the format depends on whether the feature is correlation matrix (simply by name here)
            %       (otherwise, can decide by whether symetric matrix)
            %       (if other format, handle here.)
            if ~isempty(strfind(tmp_feature_name,'cm_')) % cm
                tmp_allsbj_result = zeros(tmp_ch_num,tmp_ch_num,length(sbj)); % format: ch*ch*sbj
            else
                tmp_allsbj_result = zeros(length(sbj),tmp_ch_num); % format: sbj*ch
            end
            
            %--- loop of sbj
            for ll = 1:length(sbj)
                
                % whether this data is analyzed
                tmp_var_name = sbj_info_var_name{data_include_index_num(ii)+2};
                eval(sprintf('tmp_is_analysis_cond = %s(ll);',tmp_var_name));
                
                if tmp_is_analysis_cond == 1
                    current_dir_sbj = strrep(dir_list_sbj{jj}, 'sbjxx', sbj{ll});
                    cd(current_dir_sbj);
                    
                    eval(sprintf('load %s;',tmp_feature_name));
                    
                    if ~isempty(strfind(tmp_feature_name,'cm_')) % cm
                        eval(sprintf('tmp_allsbj_result(:,:,ll) = %s;',tmp_feature_name));
                    else
                        eval(sprintf('tmp_allsbj_result(ll,:) = %s;',tmp_feature_name));
                    end
                    
                else
                    if ~isempty(strfind(tmp_feature_name,'cm_')) % cm
                        eval(sprintf('tmp_allsbj_result(:,:,ll) = nan;'));
                    else
                        eval(sprintf('tmp_allsbj_result(ll,:) = nan;'));
                    end
                end
                
            end
            
            cd(current_dir_allsbj);
            
            
            %{
            % --- to allsbj name and save
            % add allsbj_ before feature name  
            tmp_allsbj_feature_name = ['allsbj_' componentFeature_list{kk}];
            
            eval(sprintf('tmp_allsbj_feature_name = %s;',tmp_allsbj_result));
            eval(sprintf('save %s %s;',tmp_allsbj_feature_name, tmp_allsbj_feature_name));
            %}
            
            % --- save          
            eval(sprintf('%s = tmp_allsbj_result;',tmp_feature_name));
            eval(sprintf('save %s %s;',tmp_feature_name,tmp_feature_name));
            
        end
        
        %cd(current_dir_allsbj);
        % just for know feature list, without see option file
        save componentFeature_list componentFeature_list;
        
        file_name=['componentFeature_list.txt'];
        fid_w=fopen(file_name,'w');
        for row=1:size(componentFeature_list,1)
            fprintf(fid_w, '%s\r\n', componentFeature_list{row,:});
        end
        fclose(fid_w);
        
		
		
    end
    
end


cd([dir_root{1} '\' allsbj_dirName]);
