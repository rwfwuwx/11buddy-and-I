function eleven_eeg_replace_badch
% 
%   1. replace bad ch on preprocessed mfeeg raw file, 
%   2. and update the data in eeglab file, which is used for ica.
% todo
%   
% update history
%   2024-11-06 update for ieeg
%       do nothing, just change name
%   2021-12-13 ch num -> reref_ch, thus generalize to all import_file_type
%   2021-11-18 script->function
%   2020-11-12 updating using eeg_raw_pp.set, instead of eeg_raw.set
%   2020-10-11 fake automation for resting. (update and extend real automation)
%   2020-07-31 build

%clear;
load eeg_type;
% load option variables
load eleven_eeg_OptionVariable_customize;

%--- mfeeg part
load eeg_raw_pp;
load ch_bad;

eeg_raw_pp_rbc = eeg_raw_pp;

if eeg_type==1 % only needed for scalp eeg
    if ~isempty(ch_bad)
        for ii=1:length(ch_bad)
            if ch_bad(ii)==1
                eeg_raw_pp_rbc(:,ch_bad(ii)) = (eeg_raw_pp(:,ch_bad(ii)+1) + eeg_raw_pp(:,ch_bad(ii)+2))/2;
            elseif ch_bad(ii) == size(eeg_raw_pp,2)
                eeg_raw_pp_rbc(:,ch_bad(ii)) = (eeg_raw_pp(:,ch_bad(ii)-1) + eeg_raw_pp(:,ch_bad(ii)-2))/2;
            else
                eeg_raw_pp_rbc(:,ch_bad(ii)) = (eeg_raw_pp(:,ch_bad(ii)-1) + eeg_raw_pp(:,ch_bad(ii)+1))/2;
            end
        end
    end
end

save eeg_raw_pp_rbc eeg_raw_pp_rbc;

%--- eeglab part
%EEG = pop_loadset('eeg_raw.set');
EEG = pop_loadset('eeg_raw_pp.set'); 

EEG.data = eeg_raw_pp_rbc';

EEG = eeg_checkset(EEG);
EEG = pop_saveset(EEG,'eeg_raw_pp_rbc.set',pwd);


