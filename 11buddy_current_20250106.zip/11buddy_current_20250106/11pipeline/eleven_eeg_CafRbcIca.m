function eleven_eeg_CafRbcIca
% clean artifacts,remove bad ch, ica
%
% todo
%
% Note
%   develop/test: see 'clean_rawdata_develop_20241104' dir
%
% update history
%   2024-11-21 for seeg, add control: bypass the whole func content if ch_bad_raw is not marked
%   2024-11-14 set rejchan_threshold in eleven_eeg_OptionVariable_customize
%   2024-11-11 add on/off for ica; add 'load eleven_eeg_OptionVariable_customize;'
%   2024-11-06 update for ieeg
%       note, ieeg, clean raw data does not has effect, thus reject ch is
%       put after ica.
%   2024-10-09
%       rename eleven_eeg_RbcIca -> eleven_eeg_CafRbcIca
%           apply the clean_artifacts procedure to seeg.
%   2021-12-13
%       other minor updates
%       incorporate eleven_eeg_eeglab2mfeeg_continuousData into eleven_eeg_ica_label;
%       rename andy_autojob_ppRbcIca -> eleven_eeg_RbcIca
%       -> func
%   2021-11-18 initial version, modified from andy_autojob_ppNormal_source_test_202108

load eeg_type;
load eleven_eeg_OptionVariable_customize;

is_run_this_func=1; % control whether to conduct the whole func content

% for seeg, bypass the whole func content if ch_bad_raw is not marked
if eeg_type==2
    load ch_bad_raw;
    if ismember(1,ch_bad_raw)==0 % ie. ch_bad_raw is not marked
        is_run_this_func=0;
    end
end

if is_run_this_func
    % |-------------------------|
    % |----------- caf & rbc ---------|
    % |-------------------------|
    disp('clean artifacts & remove bad ch');
    
    % clean artifacts & get bad ch
    ch_bad = eleven_eeg_cleanArtifacts_identifyBadch;
    save ch_bad ch_bad;
    
    % replace bad ch
    eleven_eeg_replace_badch;
    
    
    disp('clean artifacts & remove bad ch,done');
    
    % |-------------------------|
    % |----------- ica ---------|
    % |-------------------------|
    
    if is_ica==1
        
        disp('ica remove noise');
        
        %- run ica
        eleven_eeg_runica;
        
        %- get and remove ica_remove_component
        if eeg_type==1 % scalp eeg
            ica_remove_component = eleven_eeg_ica_label;
            save ica_remove_component ica_remove_component;
        end
        
        if eeg_type==2 % ieeg
            % Note, copy/mod from eleven_eeg_ica_label, for ieeg
            %   scalp eeg, use the toolbox to select components
            %   ieeg, use the first 25% components
            
            % load option
            load eleven_eeg_OptionVariable_customize;
            
            EEG = pop_loadset('eeg_raw_pp_rbc_ica.set');
            
            load eeg_raw_pp;
            ch_num = size(eeg_raw_pp,2);
            ica_remove_component = 1:round(ch_num*ica_remove_component_threshold);
            
            EEG = pop_subcomp(EEG,ica_remove_component);
            
            EEG = eeg_checkset(EEG);
            EEG = pop_saveset(EEG,'eeg_raw_pp_rbc_ica_remove_component.set',pwd);
            EEG = pop_saveset(EEG,'eeg_raw_pp_rbc_ica_final.set',pwd);
            
            % incorparate previous eleven_eeg_eeglab2mfeeg_continuousData here
            % Note, the mfeeg eeg_raw_pp is overrided here.A backup is eeg_raw_pp_backup_ppNormal.mat.
            EEG.data = double(EEG.data);
            
            tmp = EEG.data;
            eeg_raw_pp = tmp';
            save eeg_raw_pp eeg_raw_pp;
            
            save ica_remove_component ica_remove_component;
        end
        
        disp('ica remove noise,done');
        
        
        %=== get ch_bad for ieeg ===
        %   copy/mod from eleven_eeg_cleanArtifacts_identifyBadch.m
        if eeg_type==2
            % note, for ieeg, because clean_artifacts has no effect, do rejchan after ica
            elec_NO = 1:size(eeg_raw_pp,2); % get elec NO according to eeg_raw_pp
            
            [~,ch_bad] = pop_rejchan(EEG,'elec',elec_NO,'threshold',rejchan_threshold,'norm','on');
            
            save ch_bad ch_bad;
        end
        
    end
end
