function eleven_GLAutojob_routine_eegRerefRun3(dir_root_file,dir_tree_file,sbj_info_file)
% Input
%
% Todo
%
% Note
%
% Update history
%   2023-05-25
%       updates incorporating seeg
%       other minor optimization
%   2020-12-15 initial version as a new routine

%--- load dir_root
dir_root = importdata(dir_root_file);
% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

for ii = 1:length(sbj) % loop of sbj
    % whether analyze this sbj
    tmp_var_name = sbj_info_var_name{2};
    eval(sprintf('tmp_is_analysis_sbj = %s(ii);',tmp_var_name));
    if tmp_is_analysis_sbj == 1
        for jj = 1:data_num % loop of dir_tree\cond
            % whether analyze this cond,of this sbj
            tmp_var_name = sbj_info_var_name{jj+2};
            eval(sprintf('tmp_is_analysis_cond = %s(ii);',tmp_var_name));
            if tmp_is_analysis_cond == 1
                current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
                if exist(current_analysis_path,'dir')
                    cd(current_analysis_path);
                    
                    % |--- do the job here ---|
                    
                    %--- routine  ---
                    load eeg_type;
                    load import_file_type;
                    
                    if eeg_type == 1
                        if import_file_type==211 || import_file_type==212
                            eleven_eeg_reref;
                        end
                    end
                    
                    
                    % |--- end job ---|
                    
                end
            end
        end
    end
end

cd([dir_root{1} '\allsbj']);
