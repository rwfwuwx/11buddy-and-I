function eleven_eeg_er_ertf
% eleven_eeg_er_ertf	
% Usage
%   eleven_eeg_er_ertf
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2021-12-17 expVariable-> individual variable
%   2020-12-16
%    change eleven_eeg_OptionVariable to eleven_eeg_OptionVariable_customize;
%   2020-06-23 add normalization on single trial. 
%       set as default.
%       previous normalization on average tf may not be used any more.
%   2020-03-25
%   reorgize and rewrite from Andy. 
%   2020-01-07
%       ...
%       Andy is ready
%   2020-01-06
%       ...
%	2020-01-05 initially writen


% |-------------------------|
% |----------  tf  ---------|
% |-------------------------|

%clear;
disp('time-frequency processing');

% --- load option variables
load eleven_eeg_OptionVariable_customize;

% --- input
% exp variable
% for condition: condition name.
load cond_name;

% |--- processing loop by condition ---|
cond_num = length(cond_name);

for ii=1:cond_num
    % --- input
    % epo data
    input_data_name = ['eeg_epo' '_' cond_name{ii}];
    eval(sprintf('load %s;',input_data_name));
    eval(sprintf('eeg_epo_tmp = %s;',input_data_name));
    
    % --- time-frequency transform
    disp('  time-frequency transform');
    [eeg_tfboth_tmp,eeg_tfpl_tmp,eeg_tfnplone_tmp,eeg_tfnpltwo_tmp,eeg_tfplf_tmp]...
        = mf_epotf(eeg_epo_tmp,6,tf_frequency_range,fs,1,0.21,'power',is_tfnpltwo,is_tf_norm,tf_baseline_range,tf_normalize_method);
    
    % --- normalization
    if is_tf_norm == 0
        disp('  normalize');
        eeg_tfboth_tmp_norm = mf_tfnorm(eeg_tfboth_tmp,tf_baseline_range,tf_normalize_method);
        eeg_tfpl_tmp_norm = mf_tfnorm(eeg_tfpl_tmp,tf_baseline_range,tf_normalize_method);
        eeg_tfnplone_tmp_norm = mf_tfnorm(eeg_tfnplone_tmp,tf_baseline_range,tf_normalize_method);
        eeg_tfplf_tmp_norm = mf_tfnorm(eeg_tfplf_tmp,tf_baseline_range,tf_normalize_method);
        if is_tfnpltwo
            eeg_tfnpltwo_tmp_norm = mf_tfnorm(eeg_tfnpltwo_tmp,tf_baseline_range,tf_normalize_method);
        else
            eeg_tfnpltwo_tmp_norm = eeg_tfnpltwo_tmp;
        end
    end
    
    % --- output 
    for jj = 1:length(tf_names)
        % without normalization
        data_name = ['eeg_' tf_names{jj} '_tmp'];
        output_data_name = ['eeg_' tf_names{jj} '_' cond_name{ii}];
        eval(sprintf('%s = %s;',output_data_name,data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
        
        %  clear
        eval(sprintf('clear %s;',output_data_name));
        
        % with normalization
        if is_tf_norm == 0
            data_name = ['eeg_' tf_names{jj} '_tmp' '_norm'];
            output_data_name = ['eeg_' tf_names{jj} '_' 'norm' '_' cond_name{ii}];
            eval(sprintf('%s = %s;',output_data_name,data_name));
            eval(sprintf('save %s %s;',output_data_name,output_data_name));
        end
        
        %  clear
        eval(sprintf('clear %s;',output_data_name));
    end
    
    % --- clear
    eval(sprintf('clear %s;',input_data_name));
end

%clear
