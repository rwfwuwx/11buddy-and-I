function eleven_GLAutojob_routine_behavRptAnaDirPrepare(dir_root_file,dir_tree_file,is_formal)
% Input
%
% Todo
%
% Note  
%   # in allsbj dir, make dir for each data. regarding using dirTree instead of dataList. 
%   ## assume dataList is equal to dirTree. In this case, they are the same.
%   ##if dataList is not equal to dirTree, use dirTree has advantages, 
%   in terms of 
%       the uncontrolled complexity when people name and make dirs for data, as have always been keep met.
%       or, in needs, for example, add the behav_ana dir in dirTree.
%   # This routine does not have the sbj loop.
%   set dir for all data. i.e., without individual sbj info, becuase, at first, especially in test stage, not all data are analyzed for all sbj.
%
% Update history
% 2024-04-18 initial version, modify from eleven_GLAutojob_routine_eegRptAnaDirPrepare.m

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree); 

% --- open file to write
fid_w = fopen('rptAnaDir.txt','w');

for ii = 1:data_num % loop of dir_tree\cond
    
    current_analysis_path = [dir_root{1} '\' allsbj_dirName];
        
    % |--- do the job here ---|
    
    tmp_dir = [current_analysis_path '\' dir_tree{ii}];
    if ~exist(tmp_dir,'dir')
        mkdir(tmp_dir);
    end
    fprintf(fid_w,'%s\n',tmp_dir);
    
    % |--- end job ---|
    
end


cd([dir_root{1} '\' allsbj_dirName]);

% close file
fclose(fid_w);


