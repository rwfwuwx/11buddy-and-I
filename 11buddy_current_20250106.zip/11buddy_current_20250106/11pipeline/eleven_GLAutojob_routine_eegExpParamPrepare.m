function eleven_GLAutojob_routine_eegExpParamPrepare(dir_root_file,dir_tree_file,sbj_info_file,trigger_tobe_list_file,triggerTobe_ecd_correction_script_list_file,condName_list_file,expVariable_list_file)
% Input
%   trigger_tobe_list_file
%       if by_trigger_manner == 2,i.e., conventional manner, set []
% Todo
%
% Note
%
% Update history
%   2024-12-12 add customize epoch lenth for analyze type 2
%   2024-04-12
%       add handling of trigger_tobe not matching eeg_ecd_raw
%   2023-05-24
%       updates by_trigger_manner
%       other minor optimization
%   2020-12-17
%       load expVariable as a whole, while saveing as individual variable.
%       add expVariable_list file
%       add condName_list_file
%   2020-12-16
%       add trigger_tobe_list_file
%       initial version as a new routine

%--- load dir_root
dir_root = importdata(dir_root_file);
% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

for ii = 1:length(sbj) % loop of sbj
    % whether analyze this sbj
    tmp_var_name = sbj_info_var_name{2};
    eval(sprintf('tmp_is_analysis_sbj = %s(ii);',tmp_var_name));
    if tmp_is_analysis_sbj == 1
        for jj = 1:data_num % loop of dir_tree\cond
            % whether analyze this cond,of this sbj
            tmp_var_name = sbj_info_var_name{jj+2};
            eval(sprintf('tmp_is_analysis_cond = %s(ii);',tmp_var_name));
            if tmp_is_analysis_cond == 1
                current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
                if exist(current_analysis_path,'dir')
                    cd(current_analysis_path);
                    
                    % |--- do the job here ---|
                    
                    %--- routine ---
                    
                    load dataAnaDir;
                    dataAna_root_dir = pwd;
                    
                    for kk=1:length(dataAnaDir) % do this for each of dataAnaDir
                        cd(dataAnaDir{kk});
                        
                        load eeg_analyze_type;
                        
                        if ~isempty(find(eeg_analyze_type == [2 3 42 43])) % only for non resting
                            
                            % --- prepare eeg_ecd;
                            load by_trigger_manner;
                            % use trigger_tobe for yangyang's manner
                            if by_trigger_manner == 1
                                trigger_tobe_list = importdata(trigger_tobe_list_file);
                                trigger_tobe_name = trigger_tobe_list{jj};
                                eval(sprintf('load %s;',trigger_tobe_name));
                                save trigger_tobe trigger_tobe;
                                
                                triggerTobe_ecd_correction_script_list = importdata(triggerTobe_ecd_correction_script_list_file);
                                triggerTobe_ecd_correction_script = triggerTobe_ecd_correction_script_list{jj};
                                if triggerTobe_ecd_correction_script == 't'
                                    eleven_eeg_trigger_ecd_linking;
                                else
                                    run(triggerTobe_ecd_correction_script);
                                end
                                
                            end
                            
                            % for conventional manner, use eeg_ecd_raw directly
                            if by_trigger_manner == 2
                                load eeg_ecd_raw;
                                eeg_ecd = eeg_ecd_raw;  
                                save eeg_ecd eeg_ecd;
                            end
                            

                            % --- prepare cond_name;
                            condName_list = eleven_importdata_txt(condName_list_file);
                            cond_name = condName_list(jj,:);
                            % remove empty ones
                            non_empty_index = [];
                            for mm=1:length(cond_name)
                                if ~isempty(cond_name{mm})
                                    non_empty_index = [non_empty_index mm];
                                end
                            end
                            cond_name = cond_name(non_empty_index);
                            
                            save cond_name cond_name;
                            
                            
                            % --- prepare expVariable(s)
                            expVariable_list = importdata(expVariable_list_file);
                            expVariable_name = expVariable_list{jj};
                            eval(sprintf('load %s;',expVariable_name));
                            if eeg_analyze_type == 2 || eeg_analyze_type == 42
                                save cond_code cond_code;
                            end
                            if eeg_analyze_type == 2 % customize epoch lenth for 2
                                % for backward compatibility, in old cases this is no this variable
                                if exist('cond_code_epochLen')==1 % exist return 1, i.e, in workspace
                                    save cond_code_epochLen cond_code_epochLen;
                                end
                            end
                            if eeg_analyze_type == 3 || eeg_analyze_type == 43
                                save cond_code_sequence cond_code_sequence;
                                save cond_sequence_length cond_sequence_length;
                            end
                            
                        end
                        
                        cd(dataAna_root_dir);
                    end
                    
                    
                    % |--- end job ---|
                    
                end
            end
        end
    end
end

cd([dir_root{1} '\allsbj']);
