function andy_autojob_ppNormal(eleven_job_path)
% Usage andy_autojob_ppNormal
%
% todo
%   
% update history
%   2024-12-12 fix bug: control eleven_eeg_set_OptionVariable_customize.m in ppNormal
%   2024-12-02
%       fix bug: delete 'load ch_index_target' for scale eeg does not have it
%   2024-11-28
%       add param 'eleven_job_path'
%   2024-11-21
%       for seeg, some contacts have large noise because of epileptic seizure, thus these contacts have to be deleted.
%           add deleting ch of eeg_raw_pp, ch_grouping, ch_index_target,ch_label, reref_ch, according to ch_bad_raw.mat
%   2024-11-18
%       control eleven_eeg_set_OptionVariable_customize.m in ppNormal,
%       eleven_eeg_OptionVariable_customize_in_ppNormal 
%       default (11pipeline)=1, 11job=2, local=3 
%   2024-10-09 'eeg_raw_pp.mat -> eeg_raw_pp.set', also for seeg
%   2023-05-23 
%       updates incorporating seeg
%       other minor optimization
%   2021-12-13 add backup of eeg_raw_pp_backup_ppNormal.mat
%   2020-12-11
%       simplify get exp time setting
%       remove switch of pp. i.e., default run it.
%       !!! done "a final version in this update", and, script -> func
%   2020-12-08~09
%       --- handle geting exp_time according to eeg_analyze_type
%           !!! Note, ssep_sequence_time,or resting_time other than 5 min. set outside by GLAutojob
%       --- !!! setting, i.e., eleven_eeg_set_OptionVariable_customize.m, now run independently and automatically.
%           if need customize, do it as a GLAutojob.
%           if run2 needs change option, no need, and doesn't matter here.
%               what is need here, i.e., in preprocessing, is just eeg_analyze_type
%       --- template fun -> func
%       --- eeg_analyze_type update
%       1. old type list
%           11 resting_eeg; 12 er_eeg; 13 sr_eeg; these are for scalp eeg
%           21 resting_seeg; 22 er_seeg; 23 sr_seeg; these are for seeg
%       -> new type list
%           11 resting_eeg; 12 er_eeg; 13 ssep_eeg; 14 sr_eeg; these are for scalp eeg
%           21 resting_seeg; 22 er_seeg; 23 ssep_eeg; 24 sr_eeg; these are for seeg
%       2. use 'eeg_analyze_type_list_(studyName).txt'
%           strictly according to each line of 'analysis_dirTree_eeg_run2_(studyName).txt', set for each line.
%       --- remove exp setting, to autojob2
%       --- remove check trigger and produce eeg_ecd, to autojob2
%       --- remove design_type
%   2020-12 
%       script-> template func
%       incorporate into the updated CNAutojob frame work.
%   2020-05-17 update
%	2020-12-09 ShengProject -> ProfLijingrongGruop
%   2020-11-13
%       add produce eeg_raw_pp.set
%   2019 initial version, used in multiple projects. 


%--- set andy option ---
disp('set andy setting');

if  ~exist([eleven_job_path '\' 'eleven_eeg_OptionVariable_customize_in_ppNormal.mat'])
    run('eleven_eeg_set_OptionVariable_customize.m'); % default (11pipiline) 
else
    load([eleven_job_path '\' 'eleven_eeg_OptionVariable_customize_in_ppNormal.mat']);
    
    if eleven_eeg_OptionVariable_customize_in_ppNormal==1 % default (11pipiline)
        copyfile('H:\soft\11buddy\11buddy_current\11pipeline\eleven_eeg_set_OptionVariable_customize.m','OV_def.m');
        run('OV_def.m');
        delete('OV_def.m');
    end
    
    if eleven_eeg_OptionVariable_customize_in_ppNormal==2 % 11job
        if exist([eleven_job_path '\' 'eleven_eeg_set_OptionVariable_customize.m'],'file')
            copyfile([eleven_job_path '\' 'eleven_eeg_set_OptionVariable_customize.m'],'OV_11job.m');
            run('OV_11job.m');
            delete('OV_11job.m');
        else
            error('eleven_job_path of this project does not have eleven_eeg_set_OptionVariable_customize.m!');
        end
    end
    
    if eleven_eeg_OptionVariable_customize_in_ppNormal==3 % local
        current_dir=pwd;
        if exist([current_dir '\' 'eleven_eeg_set_OptionVariable_customize.m'],'file')
            run('eleven_eeg_set_OptionVariable_customize.m');
        else
            error('current dir does not have eleven_eeg_set_OptionVariable_customize.m!');
        end
    end
end
%}

disp('set andy setting, done.');

%--- load andy option ---
load eeg_type;
load eeg_analyze_type;
load eleven_eeg_OptionVariable_customize;


%--- get exp time ---
if eeg_type == 1
    if import_file_type == 1
        file_type_suffix = '.bdf';
    end
    if import_file_type == 211 || import_file_type == 212
        file_type_suffix = '.mff';
    end
    eeg_file_name = ['eeg_raw' file_type_suffix];
    
    exp_time = eleven_eeg_get_expTime(eeg_file_name);
    
    save exp_time exp_time;
end

% --- import ---
% Note, ignore possible warnings when reading seeg file
eleven_eeg_import;


% --- pre-processing ---
eleven_eeg_pp;


% ---eeg_raw_pp.mat -> eeg_raw_pp.set ---
%   for followig eeglab handling
load eeg_raw_pp;
load ch_label;

% further backup eeg_raw_pp in case required later
copyfile('eeg_raw_pp.mat','eeg_raw_pp_backup_ppNormal.mat');

if eeg_type == 2 %for seeg
    % initialize ch_bad_raw, if it does not exist
    if exist('ch_bad_raw.mat')==0
        ch_bad_raw = zeros(length(ch_label),1);
        save ch_bad_raw ch_bad_raw
    end
    
    load ch_bad_raw;
    % find if there is 1 in ch_bad_raw, ie. bad ch have been marked, deleting ch according to ch_bad_raw
    if ismember(1,ch_bad_raw) 
        % get index of ch to delete
        index_del=find(ch_bad_raw==1);
        
        % update eeg_raw_pp according to ch_bad_raw
        eeg_raw_pp(:,index_del)=[];
        save eeg_raw_pp eeg_raw_pp;
        
        % update .mat of structure according to ch_bad_raw
        load ch_grouping;
        load ch_index_target;
        load ch_label;
        load reref_ch;
        
        % further backup in case required later
        copyfile('ch_grouping.mat','ch_grouping_backup.mat');
        copyfile('ch_index_target.mat','ch_index_target_backup.mat');
        copyfile('ch_label.mat','ch_label_backup.mat');
        copyfile('reref_ch.mat','reref_ch_backup.mat');
        
        ch_grouping(index_del)=[];
        ch_index_target(index_del)=[];
        ch_label(index_del)=[]; 
        % for reref_ch
        % say,
         % ch 1 2 3 4 5, 
         % reref_ch:
         % 2 2
         % 1 3
         % 2 4
         % 3 5
         % 4 4
         %if bad ch 2 3, remove ch 2 3,remain
         %  note issue comes
         % ch 1 4 5, 
         % reref_ch:
         % 2 2 :issue here should be 4 4
         % 3 5 :issue here should be 1 5
         % 4 4 
         % so the corrected reref_ch should be
         % 4 4
         % 1 5
         % 4 4
         % ch 1 4 5 is now indexed by 1 2 3, accordingly the corrected reref_ch:
         % 2 2
         % 1 3
         % 2 2
        reref_ch([(size(reref_ch,1)-length(index_del)+1):end],:)=[];
        reref_ch(end,:)=[size(reref_ch,1)-1,size(reref_ch,1)-1];
        
        save ch_grouping ch_grouping;
        save ch_index_target ch_index_target;
        save ch_label ch_label;
        save reref_ch reref_ch;
    end
end

% replace data
EEG = pop_loadset('eeg_raw.set');
EEG.data = eeg_raw_pp';

% replace ch
EEG.nbchan = length(ch_label);

EEG.chanlocs = EEG.chanlocs(1:length(ch_label));
for ii=1:length(ch_label)
    EEG.chanlocs(ii).labels = ch_label{ii};
end

EEG = eeg_checkset(EEG);
EEG = pop_saveset(EEG,'eeg_raw_pp.set',pwd);





