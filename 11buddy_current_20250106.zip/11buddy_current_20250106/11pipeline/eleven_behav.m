function eleven_behav
% eleven_behav	
% Usage
%   eleven_behav
%
%   or load yangyang_ana;yangyang_ana()
%   (by yangyang_ana = @eleven_behav; save yangyang_ana yangyang_ana;)
%
% |------------------------|
% |-------description------|
% |------------------------|
% 1. eleven_behav.m (yangyang_ana)
% only one yangyang_ana for all analyses.
% 
% 2. eleven_behav_OptionVariable.mat (options of yangyang)
% % only one option file for all analyses, with different option settings.
%   
% todo 
%
% Update history
%   2024-04-06 initial version, modify from eleven_eeg.m


% |----------------------------------------|
% |----------------- import ---------------|
% |----------------------------------------|
% Note, yangyang_ana is now called by yangyang 2. yangyang 1 directly call import.
%   see more as andy.

% |----------------------------------------|
% |------ post-processing, and related -----|
% |----------------------------------------|
% Note, andy is now called by andy 2.andy 1 directly call eleven_eeg_pp.
%   thus, in option, related params are set, while is_import set to 0.
%   i.e., andy 1 does not needs is_pp; 
%       andy 2 does not involve the step of pp.
clear; load eleven_behav_OptionVariable_customize;
if is_postP
    eleven_behav_postP;
end

% |----------------------------------------|
% |------------------ epoch ------------------|
% |----------------------------------------|
clear; load eleven_behav_OptionVariable_customize;
if is_epoch
    eleven_behav_epoch;
end

% |----------------------------------------|
% |------------------ epoch cat ------------------|
% |----------------------------------------|
% to add 

% |----------------------------------------|
% |------------------ activity ------------------|
% |----------------------------------------|
% Note, it is here, comes diffrent types of behav analysis, 
%   standard,timingSyncTap, etc.
%   (simillarly to eeg, erp ertf,resting,etc)
clear; load eleven_behav_OptionVariable_customize;
if is_activity
    eleven_behav_activity;
end


%disp('yangyang job done.');
