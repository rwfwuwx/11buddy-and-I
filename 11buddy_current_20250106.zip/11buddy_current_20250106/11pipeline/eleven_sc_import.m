function eleven_sc_convert
% eleven_sc_convert
% Usage
%   eleven_eeg_import
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2020-11-17 update import data func
%   2020-10-30 modify from eleven_eeg_import

% |-------------------------|
% |--------- import --------|
% |-------------------------|

clear;
disp('import');

% --- input
% load exp variable
load eeg_analyze_type;
if ~isempty(find(eeg_analyze_type == [12 13]))
    load expVariable;
end

% load option variables
load eleven_eeg_OptionVariable_customize;

if design_type == 1
    
    load exp_time; 
    %load sc_raw;
    
    % --- import
    disp('  import');
    %eeg_raw = eleven_sc_convert_data(sc_raw,exp_time,fs_origin,is_import_resample,fs);
   [eeg_raw,~] = eleven_physio_import_data('physio_raw.mat',3,exp_time,is_import_resample,fs,fs_origin);
    
    % --- output
    save eeg_raw eeg_raw;
    
    % --- clear
    clear eeg_raw;
end

if design_type == 2
    % |--- processing loop by condition ---|
    cond_num = length(cond_name);
    
    for ii=1:cond_num
        physio_file_name = ['physio_raw' '_' cond_name{ii} '.mat'];
        %eval(sprintf('load %s;',sc_file_name));
        
        exp_time_name = ['exp_time' '_' cond_name{ii}];
        eval(sprintf('load %s;',exp_time_name));
        eval(sprintf('exp_time_tmp = %s;',exp_time_name));
        
        
        % --- import
        disp('  import');
        %eeg_raw = eleven_sc_convert_data(sc_file_name,exp_time_tmp,fs_origin,is_import_resample,fs);
        [eeg_raw,~] = eleven_physio_import_data(physio_file_name,3,exp_time,is_import_resample,fs,fs_origin);
        
        % --- output
        output_eeg_raw_name = ['eeg_raw' '_' cond_name{ii}];
        eval(sprintf('%s = eeg_raw;',output_eeg_raw_name));
        eval(sprintf('save %s %s;',output_eeg_raw_name,output_eeg_raw_name));
        
        
        % --- clear
        eval(sprintf('clear %s;',output_eeg_raw_name));
    end
end

clear; 
