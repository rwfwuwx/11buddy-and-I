function eleven_GLAutojob_routine_behavRptAnaCopyParam(dir_root_file,dir_tree_file,behav_analyze_type_list_file,sbj_info_file,is_formal)
% Input
%
% Todo
%   dir structure is now manually assigned
%   
% Note
%   the sbj loop and data loop are same as eleven_GLAutojob_routine_behavDataAnaDirPrepare.
%       the inner logic to find dir is the the similar to eleven_GLAutojob_routine_behavRptAnaDirPrepare.
% Update history
%   2024-04-18 initial version, modify from eleven_GLAutojob_routine_eegRptAnaCopyParam.m

%--- load dir_root
dir_root = importdata(dir_root_file);

if is_formal
    allsbj_dirName = 'allsbj';
else
    allsbj_dirName = 'allsbj_test';
end

% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\' allsbj_dirName],'dir')
    mkdir(allsbj_dirName);
end
cd([dir_root{1} '\' allsbj_dirName]);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
current_folder = pwd;
if exist([current_folder '\' sbj_info_file],'file') % check and delete local xlsx file
    delete(sbj_info_file);
end
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

%--- decide whether copy param for a data
is_CopyParam_data = ones(data_num,1);

% not copy data, if all the values are zero
for ii=1:data_num
    tmp_var_name = sbj_info_var_name{ii+2};
    eval(sprintf('tmp=isempty(find(%s==1));',tmp_var_name));
    if tmp == 1
        is_CopyParam_data(ii) = 0;
    end   
end

%--- initialize the switch whether param has been copied for data
is_ParamCopied_data = zeros(data_num,1);


for ii = 1:length(sbj) % loop of sbj
    
    for jj = 1:data_num % loop of dir_tree\cond
        
        % whether the value of this cond == 1,of this sbj
        tmp_var_name = sbj_info_var_name{jj+2};
        eval(sprintf('tmp_is_analyzed_cond = %s(ii);',tmp_var_name));
        
        % handling if nan
        if isnan(tmp_is_analyzed_cond)
            tmp_is_analyzed_cond = 0;
        end
        
        % whther the cond is to copy param, and the cond of the sbj is analyzed
        tmp_is_analysis_cond = is_CopyParam_data(jj) & tmp_is_analyzed_cond;
        
        % and whether param is allready copied
        if tmp_is_analysis_cond == 1 & is_ParamCopied_data(jj) == 0
            
            % copy, meanwhile set is_ParamCopied_data(jj) == 1;
            is_ParamCopied_data(jj) == 1;
            
            current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
            allsbj_analysis_path = [dir_root{1} '\' allsbj_dirName '\' dir_tree{jj}];
            
            if exist(current_analysis_path,'dir')
                cd(current_analysis_path);
                
                % |--- do the job here ---|
                
                %--- routine ---
                behav_analyze_type_list = load(behav_analyze_type_list_file);
                behav_analyze_type = behav_analyze_type_list(jj,1);
                
                
                if ~isempty(find(behav_analyze_type == [1 2]))
                    tmp_dir = [current_analysis_path];
                    tmp_dir_allsbj = [allsbj_analysis_path];
                    
                    copyfile([tmp_dir '\behav_analyze_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\import_file_type.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\eleven_behav_OptionVariable_customize.mat'],tmp_dir_allsbj);
                    copyfile([tmp_dir '\cond_name.mat'],tmp_dir_allsbj);
                    
                    if behav_analyze_type == 1

                    end
                    if behav_analyze_type == 2
                        copyfile([tmp_dir '\cond_IOI.mat'],tmp_dir_allsbj);
                    end

                end

                
       
                
                % |--- end job ---|
                
            end
        end
    end
    
end

cd([dir_root{1} '\' allsbj_dirName]);
