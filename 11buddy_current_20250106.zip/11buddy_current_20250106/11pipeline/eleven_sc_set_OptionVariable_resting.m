function eleven_sc_set_OptionVariable_resting
% eleven_sc_set_OptionVariable_resting	
% Usage
%   eleven_sc_set_OptionVariable_resting
% external varialbe (add later)
%  -- output
% Update history 
%   2020-10-22 modify from eleven_eeg_set_OptionVariable_resting_eeg.m

clear;

% |-------------------------|
% |----- common variable----|
% |-------------------------|


% sample rate. for most processing steps.
fs_origin = 2000;
fs = 200; 

% |-------------------------|
% |--------- import --------|
% |-------------------------|
% is_import = 1; % add the step import into eleven_physio later, after handling linking trigger_to_be and physio_ecd_raw 
is_import_resample = 1;
%import_file_type = 1;

% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|
is_pp = 1;

% default 0.5 Hz.for large drift noise, can be even higher than 1.
pp_high_cutoff = 1; 

% optionally add low pass, particulary for removing residual AC noise, when fs is below 500
is_pp_low_pass = 0;
pp_low_cutoff = 45; % note set this accordin to pp_AC_cutoff

% removing 50 Hz AC and harmonies
pp_AC_cutoff = [49 51;99 101;149 151;199 201];


%      |--------------------------------------------------|
%      |--------------------- er Part   ------------------|
%      |--------------------------------------------------|
%
is_epoch = 0;
is_erp = 0;
is_ersd = 0;
is_ertf = 0;
%
%      |--------------------------------------------------|
%      |------------------- ssep Part   ------------------|
%      |--------------------------------------------------|


%      |--------------------------------------------------|
%      |----------------- resting Part   -----------------|
%      |--------------------------------------------------|

is_resting_analysis = 1;

% define frequency bands, for both time and freq domain
resting_freq_band_name = {'theta','alpha','beta','lowGamma','highGamma','extrahighGamma'};
resting_freq_band = [4 7;8 14;15 30;31 47;53 97;103 247];

% |---------------------------------|
% |---------  resting_AMEnv  -------|
% |---------------------------------|
%is_resting_AMEnv = 1;


% |---------------------------------|
% |-------- resting_FreqSpec  ------|
% |---------------------------------|
%is_resting_FreqSpec = 1;
resting_am_type = 'amplitude';
resting_phase_type = 'degree';
% size of FreqNorm
%   require further testing
%   for 5 min, 100 Hz resampling, currently use 10
resting_FreqNorm_points = 10;
resting_padding_time = 5; % s
resting_padding_points = resting_padding_time*fs;


% --- save
save eleven_eeg_OptionVariable;

clear;
