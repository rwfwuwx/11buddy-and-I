function eleven_MLBuddy_set_OptionVariable
% eleven_MLBuddy_set_OptionVariable	
% Usage
%   eleven_MLBuddy_set_OptionVariable
% external varialbe (add later)
%  -- output
%
% Update history 
%   2024-06-20
%       update param for classify
%   2024-06-18
%       formalize param name, to avoid param confusion.
%       default 1 lay to 2 lays
%       add Spearman; add MLP;
%   2021-09-23 initial version

clear; % do not remove this

% |------------------------------------------------------|
% |------------------------ common ----------------------|
% |------------------------------------------------------|
%- for regression
trainRegression_correlation_method = 'Pearson';
%trainRegression_correlation_method = 'Spearman';

% for non-linear, use MLP, i.e., non model-specific. 
%   simply add other model-specific if needed. 
trainRegression_regression_method = 'Linear';
%trainRegression_regression_method = 'MLP';
 
trainRegression_p_threshold = 0.05;

%- for classification
% for non-linear, use MLP, i.e., non model-specific. 
%   simply add other model-specific if needed. 
%trainClassifier_Classifier_method = 'Logit';
trainClassifier_Classifier_method = 'MLP';
%trainClassifier_Classifier_method = 'SVM';

trainClassifier_p_threshold = 0.05;

% |------------------------------------------------------|
% |---------- eleven_trainRegression/Classifier ---------|
% |------------------------------------------------------|

% --- for fitlm
trainRegression_RobustOpts = 'off';
%trainRegression_RobustOpts = 'on';

%--- for fitrnet
%trainRegressionClassifier_LayerSizes = [10]; % one hidden layer
trainRegressionClassifier_LayerSizes = [10 10]; % two hidden layer
%trainRegressionClassifier_LayerSizes = [10 10 10]; % three hidden layer

% --- save
save eleven_MLBuddy_OptionVariable;

clear; % do not remove this

 