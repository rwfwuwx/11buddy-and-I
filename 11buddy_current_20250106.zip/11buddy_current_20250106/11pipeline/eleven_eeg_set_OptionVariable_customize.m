function eleven_eeg_set_OptionVariable_customize
% eleven_eeg_set_OptionVariable_customize	
% Usage
%   eleven_eeg_set_OptionVariable_customize
%
% Update history 
%   2021-12-10
%       now all in eleven_eeg_set_OptionVariable.m
%       here is now just for adding customization, if need (while aviod unnecessary customization, to fascilitate automation).
%   2021-12-09 
%       !!! from now on, avoiding uneccssary nanual setting, at least in preprocessing
%           in other words, remove customize part as far as possible
%       update type list
%       update default setting, avoiding unecessary manual setting 
%       is_pp is_reref: manual setting -> automatically modify in run2
%       remove design_type
%   2021-05-17 update for the vep, and other minors
%	2020-12-09 ShengProject -> ProfLijingrongGruop
%   2020-11-13 add setting AC for event related 250 Hz fs
%   2020-10-11 
%       add handling of design type
%           move assigning of design type in eleven_eeg_produce_expVariable_template.m  here, into option variable.
%   2020-09-30 modify from eleven_PsychoBuddy_set_OptionVariable_customize.

clear; % do not remove this

eleven_eeg_set_OptionVariable;
load eleven_eeg_OptionVariable;


% |-------------------------------------------------|
% |--- add customized options here, if there are ---|
% |-------------------------------------------------|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_eeg_set_OptionVariable.m. 
%       2. modify here as needs
%       3. run eleven_eeg_set_OptionVariable_customize here (make sure in the current analysis directory)

% --- settings 


% --- save
save eleven_eeg_OptionVariable_customize;

clear; % do not remove this
