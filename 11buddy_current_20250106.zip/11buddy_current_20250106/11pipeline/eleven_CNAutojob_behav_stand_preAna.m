function eleven_CNAutojob_behav_stand_preAna(studyName,sbj_info_file,eleven_job_path)
% Usage:
%   (has been incorperated in the yangyang_ganhuola.txt) 
%   nickname
%       yangyang_ganhuola_1:  load yangyang_ganhuola_1; yangyang_ganhuola_1(params)  
%       (by yangyang_ganhuola_1 = @eleven_CNAutojob_behav_stand_preAna; save yangyang_ganhuola_1 yangyang_ganhuola_1;)
% Note
% This is the 'all' template for conducting 'cognitive neuroscience research' (CN).
%   By 'cognitive neuroscience research', refers to behavioral, EEG, fMRI, etc., as in a CN lab.
%   By 'all', refers to the all-in-one automation.
% This stage is supposed for all types of behav anayses.
% Update history
%   2024-04-03 initial version, modify from eleven_CNAutojob_eeg_stand_preAna.m

%myicon = imread('yangyang.jpg');
%h=msgbox('������Ϊ������(��ǰִ������һ)���������ĵȴ�',' ','custom',myicon);

% |--------------------------------------------------------------------|
% |################# Part 1: pre analysis (preANA) ####################|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------------ common exp parameter -----------------|
% |---------------------------------------------------------|

file_name_tmp = ['extendParam_behav_' studyName '.txt'];
load(file_name_tmp);
eval(sprintf('param_tmp = %s;',['extendParam_behav_' studyName]));
import_file_type = param_tmp(1);

analysis_rootDir_behav_file = ['analysis_rootDir_behav_' studyName '.txt'];
analysis_dirTree_behav_file = ['analysis_dirTree_behav_' studyName '.txt'];

behav_analyze_type_list_file = ['behav_analyze_type_list_' studyName '.txt'];


% |---------------------------------------------------------|
% |----------------- behav data prepare ----------------------|
% |---------------------------------------------------------|
%--- (first manually copy from rawdata to analysis) 
%--- (manually make behav_ana directory) 
%---    (This can be automated, given that the organization of raw data is fixed and  clear)


% |---------------------------------------------------------|
% |----------------- set initial parameters --------------|
% |---------------------------------------------------------|
%--- this step includes
%   # make allsbj dir
%   # import_file_type, from the input parameter:
%   # behav_analyze_type, from the list file

%
eleven_GLAutojob_routine_behavSetInitParam( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    sbj_info_file, ...
    import_file_type, ...
    behav_analyze_type_list_file);
%}


% |---------------------------------------------------------|
% |----------------- behav normal preprocessing --------------|
% |---------------------------------------------------------|
% Note, compare to eeg
%   an yangyang_autojob_ppNormal is not needed now. Since only import is potentially needed.

%--- This step includes 
%   #set yangyang settings
%   #import data
%       yangyang record as standard. if not, add import.

%
eleven_GLAutojob_command( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    sbj_info_file, ...
    eleven_job_path, ...
    'yangyang_autojob_ppNormal');
%}



disp('~-~ yangyang ganhuola 1: all jobs are done ~-~ )');

% close(h)
%msgbox('���Ѿ��������1��','Success','custom',myicon);


