function eleven_CNAutojob_behav_stand_cfeAna(studyName,sbj_info_file,data_index,is_formal)
% Usage 
%       eleven_CNAutojob_behav_stand_cfeAna(studyName,sbj_info_file,sbj_index,data_index,is_formal)
%       or, load yangyang_ganhuola_4; yangyang_ganhuola_4(studyName,sbj_info_file,sbj_index,data_index,is_formal)
%           (by yangyang_ganhuola_4 = @eleven_CNAutojob_behav_stand_cfeAna; save yangyang_ganhuola_4 yangyang_ganhuola_4;)
% Input
%   data_index --- which data is to analyze
%   (other inputs see yangyang_ganhuola_4)
% Update history
%   2024-04-06 initial version, modify from eleven_CNAutojob_eeg_stand_cfeAna.m

%myicon = imread('yangyang.jpg');
%h=msgbox('������Ϊ������(��ǰִ��������)���������ĵȴ�',' ','custom',myicon);

% |---------------------------------------------------------|
% |------------------ common exp parameter -----------------|
% |---------------------------------------------------------|

analysis_rootDir_behav_file = ['analysis_rootDir_behav_' studyName '.txt'];
analysis_dirTree_behav_file = ['analysis_dirTree_behav_' studyName '.txt'];
behav_analyze_type_list_file = ['behav_analyze_type_list_' studyName '.txt'];

% |--------------------------------------------------------------------|
% |########### Part 4: component feature extraction analysis (cfeAna) ##########|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------- feature extract--------------|
% |---------------------------------------------------------|
% Note, about extraComponentFeature
%   if no setting in eleven_behav_set_OptionVariable_cfe,simply bypass.
%   if needs,
%       set in eleven_behav_set_OptionVariable_cfe
%       and add corresponding calculation in yangyang_autojob_produce_componentFeature.
% This step includes 

%
eleven_GLAutojob_routine_behavCfeAnafeatureExtract( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    behav_analyze_type_list_file, ...
    sbj_info_file, ...
    data_index, ...
    is_formal);
%}

% |---------------------------------------------------------|
% |------------------- allsbj feature ---------------------|
% |---------------------------------------------------------|
% This step includes 

%
eleven_GLAutojob_routine_behavCfeAnaAllsbjFeature( ...
    analysis_rootDir_behav_file, ...
    analysis_dirTree_behav_file, ...
    behav_analyze_type_list_file, ...
    sbj_info_file, ...
    data_index, ...
    is_formal);
%}

%
disp('~-~ yangyang ganhuola 4: all jobs are done ~-~ )');

%close(h)
%myicon = imread('yangyang.jpg');
%msgbox('���Ѿ���ɹ���4������а�����������','Success','custom',myicon);
