function yangyang_autojob_produce_componentFeature
%
%Todo
%
% Note:
% # add handle of extraComponentFeature_list
%   see note in eleven_behav_set_OptionVariable_cfe.m
% # add handle of cond for each data.
%   see note in eleven_behav_set_OptionVariable_cfe.m
%
% Update history
%   2024-04-18 initial version, modify from andy_autojob_produce_componentFeature.m


%--- load options, set options (same as yangyang_image)
load eleven_behav_OptionVariable_customize;

load behav_analyze_type;

load cond_name;

%--- cfe specific
eleven_behav_set_OptionVariable_cfe_customize;
load eleven_behav_OptionVariable_cfe_customize;



% |---calculate for extraComponentFeature_list---|
% only need to calculate extraComponentFeature
% !!! make sure the extraComponentFeature_list calculated here
%   be the same as in eleven_behav_set_OptionVariable_cfe.m

%- currently none. put a template below . add metric as need, by copy and
%   replace metric_name
if behav_analyze_type == 1
    
    %{
    % template. say the metric name is metricName in the extraComponentFeature_list
    for ii=1:length(cond_name)
        % necessary input if needed
        input_data_name = ['input' '_' cond_name{ii}];
        eval(sprintf('load %s;',input_data_name));
        eval(sprintf('input_tmp = %s;',input_data_name));
        
        % add calculation here
        
        % output
        output_data_name = ['metricName' '_' cond_name{ii}];
        eval(sprintf('%s = metricName_tmp;',output_data_name));
        eval(sprintf('save %s %s;',output_data_name,output_data_name));
    end
    %}
    
end

if behav_analyze_type == 2
    
end
