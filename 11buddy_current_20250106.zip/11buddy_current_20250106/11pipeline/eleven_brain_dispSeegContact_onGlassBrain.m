function eleven_brain_dispSeegContact_onGlassBrain(contact_coordinate,template_name,region_index)
%
% Todo
%   Now focus on emergency usage. 
%       incoporate full func of eleven_brain_play.m.
%       further needs.
%           an easy way to get region_index. e.g., see (if already exist)/produce a txt file
%           multiple regions and display properties setting
%       !for not glass brain, can do the display on a surface by brainnetview.
%           need 'dirty' work on atlas.
% Update history
% 2023-11-20
%   Update and clarification
%   script 'eleven_brain_play.m' -> func
% 2020-04-03 initial version

region_index = [0 region_index]; % add whole brain
region_num = length(region_index);

% get region info
[region_boundary,region_coord] = eleven_brain_getRegionByAtlas(template_name,region_index);

%|--- draw whole brain and region outline
brain_color{1} = [0.5 0.5 0.5];
brain_color{2} = [0.5 0.2 0.2];
for ii = 1:region_num
    tmp_coord = region_coord{ii};
    ax{ii} = trisurf(region_boundary{ii},...
        tmp_coord(:,1),tmp_coord(:,2),tmp_coord(:,3),'FaceAlpha',0.2);
    shading interp
    hold on
end

for ii = 1:region_num
    tmp_ax = ax{ii};
    set(tmp_ax,'FaceColor',brain_color{ii});
end

%|--- plot contacts
plot3(contact_coordinate(:,1),contact_coordinate(:,2),contact_coordinate(:,3),'b.','MarkerSize',15);
hold on