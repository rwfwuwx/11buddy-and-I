function [region_boundary,region_coord] = eleven_brain_getRegionByAtlas(atlas,region_index)
% [region_boundary,region_coord] = eleven_brain_getRegionByAtlas(atlas,region_index)
% Input
%   atlas -- currently 'brodmann_MRIcron', 'aal_MRIcron'
%   region_index -- get from the atlas
% Output
%   region_coord -- coordinates of the region. in cell format.
%   region_boundary -- boundary of a set of points in 2D/3D space, returned by matlab func 'boundary'. in cell format.
%
% Update history
% 2023-11-20
%   Update and clarification
%   'get_outline' -> eleven_brain_getRegionOutline
% 2020-04-09 initial version.

% get voxel value and coordinate(xyz) of the atlas
%   for atlas, voxel value is region index
eleven_atlas_path='H:\soft\11buddy\11buddy_develop\11pipeline\brain_atlas\';
V = spm_vol([eleven_atlas_path atlas '.nii']);
[voxel_value,coord] = spm_read_vols(V);

region_num = length(region_index);

region_coord = cell(region_num,1);

for ii = 1:region_num
    if region_index(ii) == 0 % i.e., whole brain
        voxel_index_of_region = find(voxel_value ~= region_index(ii));
    else % i.e., a specific region
        voxel_index_of_region = find(voxel_value == region_index(ii));
    end
    
    region_coord{ii} = coord(:,voxel_index_of_region)';
    region_boundary{ii} = boundary(region_coord{ii});
end