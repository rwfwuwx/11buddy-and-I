%
% Note 
% --- as always, $$ indicate where 11keeper would set/interfere
%
% --- about 'tricks'
% #
% the setting here,by rule, is simple, just tell ada the data and cond you needs.
% However, 
%   (1) depending on what you name data and cond (hope no confusion, but not always)
%   (2) for the question of metric A-B (A+B, A*B, etc.). 
%       you might have used the combination of only some data and only some cond !!!. 
%           i.e., the flexibale needs that no one could be sure about.
% Therefore, you may want some 'tricks', to bypass potential confusions/flexibilty.
%   The point is, whatever the confusions/flixibilities could be, for people; 
%       data are just data, for ada.
%   If not sure about the setting, check and follow given/existing samples.
%
% # possible confusions/flexibilities, and corresponding tricks.
% ## the names of data and cond are duplicated.
%   leave data or cond blank
% ## A B, plus A-B
%   add A-B to data/cond list
%   and, treat A-B also as a factor/level 
% ## 关于 只想进行 检查统计，无需进行检验统计
% Q: 已有2*2设计 A1B1 A2B1 A1B2 A2B2. 
%   但还有 与实验相关的 C, D... 只需要进行检查统计，无需检验统计。
% A:
%   方式一: 二者放同一个阿达
%   $$ 在'数据来源定义' 二者都放到数据里。
%   $$ 在'数据性质定义',后者不放 即可。
%   方式二: 后者自己单独阿达及阿达定义
%   $$ '数据性质定义'及之后步骤，填一个 1*n design. 即，伪统计：不需要看结果。
% ! 因此，数据/检查统计/检验统计，可分离，通过类似'trick'.  
% ## ...
%
% Update history
% 2024-04-30 add 'trick': 关于 只想进行 检查统计，无需进行检验统计
% 2024-04-28 initial version. 
%   implementation of '阿达需求表格_填写FAQ.docx'-'阿达行为: 数据结构/算法'-'ada 算法实现' 


%|---数据定义: 数据来源定义---| 
% 即，和狗狗说，要哪些数据(里的哪些子数据)

% Note, data, cond, condGroup 均可设置为空; 即数据设定 不包括此项。

%- data. set based on 'dataList'.
%$$
Data = {...
    'VTA202304_cond1_1',...
    'VTA202304_cond1_2',...
    'VTA202304_cond2_1',...
    'VTA202304_cond2_2',...
    'VTA202304_cond3_1',... 
    'VTA202304_cond3_2',...
    'VTA202304_cond4_1',...
    'VTA202304_cond4_2',...
    'VTA202304_cond1_1Sub2',... % ! from here, below are calculation
    'VTA202304_cond2_1Sub2',...
    'VTA202304_cond3_1Sub2',... 
    'VTA202304_cond4_1Sub2',...
}; 
%end $$

%- cond. set based on 'condName'.
% Note, 
%   each data has a list of cond
%   each data can have different numbers of conds，according to condName.
%$$
Cond = {... % leave blank, since duplicated with data name
}; 
%end $$

%- condGroup. set based on 'condGroup'.
% Note, the setting is the same as 'SigStatTarget' of 'adaReport_eegBehavRelate'.
%   while, simplify here without calculation.

%{
special Note for the case of all within factor, where 'no classification' of subjects.
   For general consistence of data_structure/file oganization, although no need,
       still make the groupInfo excel; and make the condGroup. 
       e.g., general, noClass, and same value 1 for all sbj.
   then, here, 
        #can set as below, i.e., take all sbj.
condGroup = {...
    'general,noClass',...
    }; 
        #or, simply set blank, i.e., neglect it. since it actually does not contribute to any comparison.
%}

%{
an example for setting when not empty
condGroup = {...
    'Patient,Pre',...
    'Patient,Post',...
    }; 
%}

%$$
condGroup = {...
    }; 
%end $$


%{ 
%--- 获取数据 算法体
for kk % given a metric metric-k . from feature list
    for ii % data
        For jj % cond
            metric_name_list = metric-k_data-i_cond-j (!!!名字和狗狗测量表格保持完全一致)
        end
    end
end

% further, + given condGroup-ll
 metric_name_list = metric-k_data-i_cond-j _condGroup-ll
%}

 
%|--- 数据定义：数据性质定义 (实验设计相关性质) (所谓 meta data)---|
% 即，和阳阳说，'数据来源定义'的数据 对应的实验设计；即阳阳'design mapping表格'
%   further simply, m*n design.

% 注: 如果condGroup不为空(见上)，这里需要加入定义。（参见sample）

%-factor name
% 与data, cond保持一致。 
% ! 如果觉得原本data,cond名字起的'不好'； 可在这里标记’有意义的名字’
% 'Factors' and 'Factor_name' might be confusing.
%   anyway, Factors is the common sense
%   Factor_name and Factor_level is bind to data
%$$
Factors = {...
    'Exp',...
    'fix',...
    };

Factor_name = {...
    'Exp1_fix',...
    'Exp1_nofix',...
    'Exp2_fix',...
    'Exp2_nofix',...
    'Exp3_fix',...
    'Exp3_nofix',...
    'Exp4_fix',...
    'Exp4_nofix',...
    'Exp1_fix_Sub_nofix',... % ! from here, below are calculation
    'Exp2_fix_Sub_nofix',...
    'Exp3_fix_Sub_nofix',...
    'Exp4_fix_Sub_nofix',...
    };
%end $$

%-factor level
% 与data, cond保持一致。
% 由此数据（只需要最后一个数值），可自动读出有几个factor, 每个factor几个level. 
% 例,3*2 design, the last number 32意味着，32设计，
%   即，(1)两个数字说有两个factor (2) 每个数字说各自factor的level数。
%$$
Factor_level = [...
    11 12 21 22 31 32 41 42 ... % original 4*2
    13 23 33 43 ... % !!! treat the calcullation as a level
    ]; 
%end $$

%- factor been within or between
% 1 within; 2 between.  元素数目保持与factor数目一致
%$$
Factor_withinBetween = [1 1]; 
%end $$
 

%|--- 统计定义：目标数据定义---|
% 给定数据来源定义，设定目标数据。
% 注: 对于给定数据，可以有多个 目标数据。
% 注：! 操作上只需依据'factor_level'进一步设设定。
%$$
Factor_level_targetData = cell(2); % the number is according to whatever your need
Factor_level_targetData{1}=[11 12 21 22 31 32 41 42]; % original 4*2 
Factor_level_targetData{2}=[13 23 33 43]; % 4*1 of the calculation
%end $$


%|--- 统计定义：统计检验定义 (即statistical test) ---|
%{
(注：无论什么test, 人根据需求如上设定定义；算法体将根据定义自动进行，此处为说明，无需设置。)

# anova
注：
默认进行ANOVA.
包括无矫正和green house 矫正。
依据上述定义，算法体自动进行,
factor 数目，level数目自动选择.
within/between因素自动选择.

# t-test
注：
默认进行t-test.
包括无矫正和tukey矫正。
包括one-sample, two-sample.
依据上述定义，算法体自动进行,
within/between因素自动选择。

# [其他test, 按需添加]

%}