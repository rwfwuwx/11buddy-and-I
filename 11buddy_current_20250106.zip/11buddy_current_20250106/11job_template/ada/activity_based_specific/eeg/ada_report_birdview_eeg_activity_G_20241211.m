% ada_report_birdview_eeg_activity_G
%
%Note for 11buddy keeper
%   arrange and set needs, where "$$" indicates.
%
%Note 
%--- actually, this file is much the same as ada_ganhuola_behav, excep for 
%   more columns in ada_require
%   ada_report_define, may be nan (i.e., no need); or different from behav
%   measureVar is handled in ada_define in ada_behav; whereas no such need here.
% later, may consider incorporate. 
%
% Note, currently, set ada_report_define file in ada require as nan, and neglect it (mark corresponding parts) here.
%
% Note, about the necessity ada_CondGroup_.xlsx
%   ada_report may or may not use it; while read and set it in the standard way. 
%
%Update history
%   2024-12-11 current_analysis_dir->current_analysis_path
%   2024-12-04 remove sbj_list, add frequency_feature_param 
%   2024-12-03 is laplas -> is eeg sensor
%   2024-11-29 rename from ada_report_birdview_predict_mvpa_20241129.mlx.
%       see: FAQ/ada_framework_develop&apply_FAQ_20241125.docx.
%
% Todo
%

myicon = imread('ada.jpg');
h=msgbox('������Ϊ���������������ĵȴ�',' ','custom',myicon);

% default dir for adaReport_defineVariable TimeStamp
%{
if exist('adaReport_defineVariable_TimeStamp')~=7
    mkdir('adaReport_defineVariable_TimeStamp');
end
%}

%--- read the ada_CondGroup_.xlsx; and save required variable for ada_ganhuola_template
T_tmp = readtable(ada_CondGroup_excel_file);

%- get groupSbjIndexDataName
groupSbjIndexDataName = T_tmp.Var1;
% clear out empty elements
tmp_index = [];
for ii = 1:length(groupSbjIndexDataName)
    if isempty(groupSbjIndexDataName{ii})
        tmp_index = [tmp_index; ii];
    end
end
groupSbjIndexDataName(tmp_index) = [];
save groupSbjIndexDataName groupSbjIndexDataName;

%- get groupSbjIndexDataName_Name
groupSbjIndexDataName_Name = cell(length(groupSbjIndexDataName),1);
for ii = 1:length(groupSbjIndexDataName)
    eval(sprintf('tmp_data = T_tmp.Var%d;',1+ii));
    % clear out empty elements
    tmp_index = [];
    for jj = 1:length(tmp_data)
        if isempty(tmp_data{jj})
            tmp_index = [tmp_index; jj];
        end
    end
    tmp_data(tmp_index) = [];
    groupSbjIndexDataName_Name{ii} = tmp_data;
end
save groupSbjIndexDataName_Name groupSbjIndexDataName_Name;

%- get groupSbjIndexDataName_Value
groupSbjIndexDataName_Value = cell(length(groupSbjIndexDataName),1);
for ii = 1:length(groupSbjIndexDataName)
    eval(sprintf('tmp_data = T_tmp.Var%d;',1+length(groupSbjIndexDataName)+ii));
    % clear out empty elements
    tmp_index = [];
    for jj = 1:length(tmp_data)
        if isnan(tmp_data(jj))
            tmp_index = [tmp_index; jj];
        end
    end
    tmp_data(tmp_index) = [];
    tmp_data = num2cell(tmp_data);
    groupSbjIndexDataName_Value{ii} = tmp_data;
end
save groupSbjIndexDataName_Value groupSbjIndexDataName_Value;

%--- read the ada_reqire_.xlsx;
%   Note, assume the vars according to the require excel
T_ada_require = readtable(ada_require_excel_file);


%|---------------------------------------|
%|------------ produce adas -------------|
%|---------------------------------------|

ada_num = length(T_ada_require.dataID);
ada = cell(1,ada_num);
ada_need = cell(1,ada_num);

%--- get ada need, including ada name
for ii = 1:ada_num
    
    % !!! currently fix ada_need, according to fixed requirement excel. extend later
    % note, relative to eegBehavRelate, behav is now updated requring only time stamp in ada need.
    %   see Update history '2024-04-28 simplification'
    ada_need_num = 5;
    ada_need{ii} = cell(ada_need_num,2); % row: needs; col 1 and 2: replace 1 with 2
    
    %- dataID
    ada_need{ii}(1,:) = {...
        ['dataID_NO1'],...
        [T_ada_require.dataID{ii}]};
    
    %- temporal_feature_param
    ada_need{ii}(2,:) = {...
        ['temporal_feature_param_NO1'],...
        [T_ada_require.temporal_feature_param{ii}]};
    
    %- frequency_feature_param
    ada_need{ii}(3,:) = {...
        ['frequency_feature_param_NO1'],...
        [T_ada_require.frequency_feature_param{ii}]};
    
    %- spatial_feature_param
    ada_need{ii}(4,:) = {...
        ['spatial_feature_param_NO1'],...
        [T_ada_require.spatial_feature_param{ii}]};
    
    %- is_eeg_sensor
    ada_need{ii}(5,:) = {...
        ['isEEGSensorOrSource'],...
        [num2str(T_ada_require.isEEGSensor(ii))]};
    
    %- adaReport_define_behav_FileName
    %{
    adaReport_define_behav_FileName = T_ada_require.adaReport_define_behav_FileName{ii};
    run([adaReport_define_behav_FileName '.m']);
    
    %- save adaReport_defineVariable TimeStamp
    % get a time stamp
    timeStamp = [num2str(datetime().Year),...
        num2str(datetime().Month),...
        num2str(datetime().Day),...
        num2str(datetime().Hour),...
        num2str(datetime().Minute),...
        num2str(round(datetime().Second*1000))];
    
    % add time stamp to the variable name
    adaReport_defineVariable_name_with_TimeStamp = ['adaReport_defineVariable' '_' timeStamp];
    
    % save the var while by a var name with a time stamp, into the default dir
    cd adaReport_defineVariable_TimeStamp;
    %   measureVar + the vars defined in the define file
    eval(sprintf(...
        'save %s measureVar Data Cond condGroup Factors Factor_name Factor_level Factor_withinBetween Factor_level_targetData;',...
        adaReport_defineVariable_name_with_TimeStamp));
    cd ../;
    
    % for the replace in ada
    tmp_text = ['load '];
    tmp_replace_text = [tmp_text adaReport_defineVariable_name_with_TimeStamp ';'];
    ada_need{ii}(1,:) = {...
        ['%[11mod]' sprintf('\n') 'load adaReport_defineVariable_[TimeStamp];'],...
        ['%[11mod]' sprintf('\n') tmp_replace_text]};
    
    pause(0.005); % i.e., avoid time overlapping with next time stamp
    %}
    
    %- output files
    ada{ii} = [T_ada_require.adaReportFileName{ii} '.mlx']; % ���븱�����ļ���
end

%--- produce adas

for ii=1:ada_num
    % initialize temporal iterate operation files, see below description
    %tmp_file_previous_operation = [];
    tmp_file_next_operation = 'tmp_file_next_operation.mlx';
    matlab.internal.liveeditor.createLiveScript(tmp_file_next_operation);
    
    tmp_ada_need_num = size(ada_need{ii},1);
    for jj=1:tmp_ada_need_num % loop of ada need
        % set input and output files
        %   for each current iterate operation,
        %       get input file from previous operation and send file for next operation,unless,
        %           for the first operation, input is the ada template
        %           for the last operation, output is the ada
        
        if jj==1
            tmp_file_input = ada_template;
        else
            tmp_file_input = tmp_file_previous_operation;
        end
        
        if jj==tmp_ada_need_num
            tmp_file_output = ada{ii};
        else
            tmp_file_output = tmp_file_next_operation;
        end
        
        %   set files after iteration done
        file_input = tmp_file_input;
        file_output = tmp_file_output;
        
        % set find string and replace string
        tmp_string_find = ada_need{ii}{jj,1};
        tmp_string_replace = ada_need{ii}{jj,2};
        
        % perform find & replace
        eleven_FindAndReplaceInFile(file_input,file_output,...
            tmp_string_find,tmp_string_replace);
        
        % update temporal iterate operation files
        if tmp_ada_need_num>1 % no need for only one need
            tmp_file_previous_operation = tmp_file_next_operation;
        end
        
    end
end

% clear out temporal iterate operation files
if exist([pwd '\' tmp_file_next_operation])
    delete(tmp_file_next_operation);
end

%|-----------------------|
%|------- ada run -------|
%|-----------------------|

%--- run adas with outputs

save ada_num ada_num;
save ada ada;


tmp_ii_abv=1;
save tmp_ii_abv tmp_ii_abv;

clear;
load tmp_ii_abv;
load ada_num;
load ada;

for ii_abv=1:ada_num
    % run
    % global variable from ada_ganhuola
    load studyID;
    load current_rawdata_Dir;
    load current_analysis_Dir;
    load current_11job_Dir;
    load current_analysis_path;
    
    eleven_mlx_execute_convert(ada{ii_abv},'docx');
    
    tmp_ii_abv=tmp_ii_abv+1;
    save tmp_ii_abv tmp_ii_abv;
    
    clear;
    java.lang.System.gc(); % ask java to free some memory
    pause(0.01);
    
    load tmp_ii_abv;
    load ada_num;
    load ada;
    
    ii_abv=tmp_ii_abv;
end


disp('����׼���ý��������~����ȥ��һ���ɡ�')

%close(h)
myicon = imread('ada.jpg');
msgbox('���Ѿ�׼���ý��������~����ȥ��һ���ɡ�','Success','custom',myicon);
