% to hanle the special situation ShortRestingTime_index

% 填写studyID
studyID = 'SZD_2020'; 

% 填写 11job 路径
eleven_job_path = 'J:\11job\Collab_FWB_project\SZD_2020';

analysis_allSbjData_eeg_file = ['analysis_allSbjData_eeg_' studyID '.xlsx'];

ShortRestingTime_index = eleven_GLAutojob_routine_eegCheckShortRestingTime(...
    ['analysis_rootDir_eeg_' studyID '.txt'],...
     ['analysis_dirTree_eeg_' studyID '.txt'],...
     1,...
     analysis_allSbjData_eeg_file);
 
 tmp_dir = pwd;
 cd(eleven_job_path);
 
 analysis_sbjIndex_ShortRestingTime = ShortRestingTime_index;
 save analysis_sbjIndex_ShortRestingTime analysis_sbjIndex_ShortRestingTime;
 cd(tmp_dir);
