% Update history
% 2024-04-15 initial version
%
% Note: $$ indicates where to modify
%
% Note
% This is supposed to be done in yangyang_design, rather than yangyang_ana.
%   similar to trigger_tobe, later move to yangyang_design after testing in practice, 
%       do this in yangyang_design for new exp;
%       supplement this in yangyang_design for old exp.

clear;

%--- load param/variable from yangyang_design
%- if yangyang_design is ready, load directly; otherwise, i.e., for old program, manually input.

% enter into a sbj/data_dir/behav_ana
%   current dir: behav_ana; previous dir: data_dir, i.e., the yangyang dir
% Note,if below yangyang_design param/variable is the same for all data, no
%   need to set the specific dir. just copy them to 11job.
%$$
a_behav_ana_dir = 'J:\analyze\Study\VTA202304\behav\sbj01_clq_20230425\VTA202304_cond1_1\behav_ana';
%end $$
cd(a_behav_ana_dir);cd ../;
load eleven_PsychoBuddy_expVariable;
% what are needed here are
%   stim_sequence
%   IOI_sequence
load eleven_PsychoBuddy_expVariableParam_customize;
% what are needed here are
%   sequence_num

%--- set 11job path of the studyID
%$$
path_11job = 'J:\11job\VTA202304';
%end $$

% |---------------------------------------------------------------|
% |------------- produce stim_resp_maping_related ----------------|
% |---------------------------------------------------------------|

%---Part 1: produce stim_resp_maping_assign_sbj_list
% Input: 
%   sbj_num (from the sbj exel)
%       Note, must be according to the sbj ordr in the sbj exel
%   response key assign (from the key asign of subjects)
% Output: stim_resp_maping_assign. 1: default; 2 swich of the default
%$$
sbj_num = 22;
stim_resp_maping_assign_sbj_list = ones(sbj_num,1);
%stim_resp_maping_assign_sbj_list = repmat([1;2],11,1);
%end $$

%---Part 2: produce stim_resp_maping
% Input: 
%   response key assign (from the key asign of subjects)
%   stim resp maping (from the maping)
%   stim code, resp code
% Output: stim_resp_maping
% Note,
%   if no swich, leave cell2 blank
%   each row is a pair of stim resp. fill out as they are.

%$$
stim_resp_maping = cell(1,2);
stim_resp_maping{1} = [1001 9];
%end $$

%---Part 3: produce response_tobe
% Input: 
%   stim_sequence 
%   stim_resp_maping
% Output:
%   stim_sequence_to_response_index
%   response_tobe
% Note
%   when set condNameList_behav_studyID.txt, be consistent with here. 
%       i.e., only conName of those in stim_to_response_list

stim_list = unique(stim_sequence,'stable'); % get the list of stim (not use here, get in potential needs)
resp_list = stim_resp_maping{1}(:,2);% get the list of resp (not use here, get in potential needs)
stim_to_response_list = stim_resp_maping{1}(:,1); % get the list of which stim to response

%-stim_sequence_to_response_index
stim_sequence_to_response_index = stim_sequence'; % stim_sequence is 1*n in yangyang design
for ii=1:length(stim_sequence)
    if isempty(find(stim_to_response_list==stim_sequence(ii)))
        stim_sequence_to_response_index(ii) = 0;
    else
        stim_sequence_to_response_index(ii) = 1;
    end
end

%-response_tobe
response_tobe = cell(1,2); % the cell corresponds to that of stim_resp_maping

for ii=1:2 % i.e., assign
    if ~isempty(stim_resp_maping{ii}) % if no switch, i.e., cell 2 is empty, bypass it
        tmp_response_tobe = zeros(length(stim_sequence),1); 
        for jj=1:length(stim_sequence)
            if stim_sequence_to_response_index(jj)~=0 % bypass stim without response
                tmp_index = find(stim_to_response_list==stim_sequence(jj)); % which stim in stim_resp_mapping
                tmp_response_tobe(jj) = stim_resp_maping{ii}(tmp_index,2);
            end
        end
        response_tobe{ii} = tmp_response_tobe;
    end
end

%---Part 4: other related
%-sequence_num
%$$
behav_analyze_type = 2;
%end $$

% Currently for fixed sequence length, 
%   for which either sequence_num or sequence length can determin the info.
% Note, generalize and handle varying sequence length later.
%   for generalization, use sequence length with data structure, e.g., [len1 len2 ... lenN]
%       and sequence_num is already indicated by length(sequence_length)
if behav_analyze_type == 1
    sequence_num = 1; % the default. when it is 1, yangyang_design does not set it. thus set here.
end 
if behav_analyze_type == 2
    % use the loaded sequence_num from yangyang_design
end 


%--- back to 11job path, and save
cd(path_11job);

save behav_StimRespMapingRelated_VTA202304_cond1_1 ...
    stim_sequence ...
    stim_resp_maping_assign_sbj_list stim_resp_maping ...
    stim_list resp_list stim_to_response_list stim_sequence_to_response_index response_tobe ...
    sequence_num;


% |---------------------------------------------------------------|
% |------------- produce expVariable ----------------|
% |---------------------------------------------------------------|

%--- cond code
% it is just stim_to_response_list, with mat->cell conversion
cond_code = cell(1,length(stim_to_response_list));
for ii=1:length(stim_to_response_list)
    cond_code{ii} = stim_to_response_list(ii);
end

% additional info/param.
if behav_analyze_type == 1
     % IOI_sequece
     % search range
     %  e.g. IOIs 1~2s. find response in this range after stim
     %      default, min(IOI_sequence). 
     %      can modify as needs, by setting additional_range_modify.
     additional_range_modify = 0;
     standard_searchResp_range = min(IOI_sequence)+additional_range_modify;
     save behav_expVariable_VTA202304_cond1_1 cond_code IOI_sequece standard_searchResp_range;
end

if behav_analyze_type == 2
    cond_IOI = IOI;
    save behav_expVariable_VTA202304_cond1_1 cond_code cond_IOI;
end




