% update history
%   2022-12-19 add cd to the path
%   2020-09

clear;

eleven_PsychoBuddy_path = 'H:\soft\11buddy\11buddy_current\PsychoBuddy\PsychoBuddy_current';

cd(eleven_PsychoBuddy_path);
save eleven_PsychoBuddy_global_setting;

clear;