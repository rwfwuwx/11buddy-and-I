function eleven_PsychoBuddy_testing
% eleven_PsychoBuddy
% Usage
%   eleven_PsychoBuddy
%   or load yangyang;yangyang()
%       (by yangyang = @eleven_PsychoBuddy; save yangyang yangyang;)
%
% Copyright: 2020 -- XiangLab,11buddy.
%
% |---------------------------------------------------------|
% |--------------------update histroy ----------------------|
% |---------------------------------------------------------|
%   2023-07-11
%   add fMRI - sysu scanner
%       scanner setting
%       loop waiting RT sig
%       mapping between response keys and records
%	2023-06-09 further handle playing sound
%	todo 1: add function for playing long sound.
%	todo 2: bug fix for 2021-01-12: PsychPortAudio Stop cause ~ 8 ms delay
%	How to generally handle playing sound, given the characteristic and limitation of playing sound.
%		Sound is played asynchroied (not prefer synchony given at list, 1. sound playing is inaccutate; 2 allow 'parallel processing' with vision and input ets.)
%			if sound is short, e.g., less then an IOI, no need to stop. thus resolve the 2021-01-12 bug.
%			if sound is long, e.g., listen a mucic piece, simply start it when required, and do what ever other things (nothing, seeing, key pressing), given async.
%	In short, simply start sound asynchroniously, let it stop 'naturally'.
%	This is can also be the logic for playing vedios, add later.
%	testing code
%       open audio
%{
InitializePsychSound;
pahandle = PsychPortAudio('Open');
%{
%       short sound, 50 ms duration, 1s IOI
% --- test and make sure sound card is working
    % make a beep sound of
    beep = MakeBeep(1000,0.05,44100); % 1000 Hz, 50ms duration, 44100 sample rate
    beep = [beep;beep];
    beep = beep/(max(max(abs(beep))) * 1); % intention nomalization.
    PsychPortAudio('FillBuffer', pahandle,beep); % put contents
    
    IOI=1;
for ii = 1:5
      
    IOI_start_time = GetSecs;
    PsychPortAudio('Start', pahandle); % play
    while 1
        tmp_time = GetSecs;
        
        % !!! with or without stop, the effect is the same. test passed.
%          if tmp_time-IOI_start_time > 0.05
%               PsychPortAudio('Stop', pahandle); % stop
%          end
        
        
        if tmp_time-IOI_start_time > IOI
            break
        end
    end
end
%}


%long sound, 5s duration
% --- test and make sure sound card is working
    % make a beep sound of
    beep = MakeBeep(1000,3,44100); % 1000 Hz, 1s duration, 44100 sample rate
    beep = [beep;beep];
    beep = beep/(max(max(abs(beep))) * 1); % intention nomalization.
    PsychPortAudio('FillBuffer', pahandle,beep); % put contents
    
PsychPortAudio('Start', pahandle); % play
start_time=GetSecs;
while 1
    tmp_time = GetSecs;
    if tmp_time-start_time > 6
        break
    end
end
disp('program end');
% !!! long sound test passed.

PsychPortAudio('Close', pahandle);
%}

% Specific update
% # mask PsychPortAudio Stop
% # mask the state indicate is_sound_start

%   2023-05-11 update for the need of using customized background image in a.
%       implementation logic for stim loading and setting:
%       previously, [v av] and [a av] are separate by 'exp type', by if-then.
%           the difficulty is, as exp needs becomes complecated, 'exp type' becomes 'ambiguous'
%       Now, just go though steps as long as required, whihe apply if-then on each step.
%   2021-10-18 bug fix.in 08-05 update, "move line 798-840 -> line 1148-1191" ,move
%   should be copy. now correct,copy 1150-1193 -> 804-847.
%   2021-08-05
%       small bug fix about stim and response trigger initialization.(move line 678-680 ->612-614; move line 779-788 ->617-626).
%       for single frame task, separate sending trigger.(comment line 1171
%            and 1186. move line 798-840 -> line 1148-1191).
%       futher see "yangyang_Update.docx"
%   2021-07-09 remove displaying fixation in instruction stage to avoid fixation not on center of image in instruction.
%   2021-06-30 change line 818: if ~isempty(find(stim_trigger==stim_sequence(ii))) -> if stim_trigger(ii)
%   2021-01-25 comments in Chinese turned into messy code. now change messy code to Chinese.
%   2021-01-21
%       for further trigger clarification (zhihan)
%       (todo: further packing trigger sending part to func. handle later
%   2021-01-12
%       "PsychPortAudio('Stop', pahandle)" cause ~8 ms delay, thus cause flip issue for auditory program ( report,Liying).
%       use 01-11 plan, further adding a state of whether sound is played. this is a temporal solution.
%       furthe see eleven_PsychoBuddy_20210112_1.m 2020-01-12 comment. and yangyangbushu_issue_list related issue. test and handle later
%   2021-01-11
%   for display_rect,
%       change default setting to display_rect_mode = 2, set by visual angele.
% 		further handle when image is not square.
%   2021-01-10 small bug fix about "IOPort('Close',address);"
%   2021-01-06 small bug fix about trigger port
%   2021-01-05
%       update trigger, according to system and port type
%   2020-12-16
%       change  'if ~isempty(find(stim_trigger==stim_sequence(ii)))' to 'if stim_trigger(ii)'
%   2020-10-21~22
%       add audio file reading, according to matlab version.
%   2020-10-07
%       small bug fix: when use background image, 'Press Space to start' is not displayed (zhihan).
%       change 'flip_start_time' to 'flip_end_time', to avoid confusion/misleading.
%       add reporting exp_total_time in command window after program done running
%   2020-09-29 small bug fix: backgroud->background (zhihan).
%   2020-09-18
%       add back key f and j
%       improvement of OptionVariable
%           one common OptionVariable
%           one commone  OptionVariable_customize. empty.
%           for individual exp, if there are customized OptionVariable; define only modified options.
%           yangyang, instead of users, run options.
%   2020-09-17
%       fix a bug sending multiple 0 trigger
%       add whether send trigger when key press (not release, which is too fast for sending trigger)
%           in situation such as rivalry exp
%       add fixation shape
%       add multiple instruction pages
%       add port type, and bit type
%       add frame by frame
%   2020-09-16
%       move 'Press Space to start' to center, to avoid eye movement when no fixation
%       add whether to display a backgroud image
%       add whether to display fixtion
%   2020-08-28
%       a bug fix of image scaling
%       add display_rect_mode
%   2020-08-27 add image size modulation
%   2020-08-18  first run of yangyang
%
%   2020-08-13 !!!
%       PTB_template -> eleven_PsychoBuddy. from now on, Software -> Robot.
%       coresponding development, further see "PsychoBuddy_develp.docx".
%   11-04-2019
%       Fix a bug that pressing "p", i.e., pressing "p" pause and then pressing "p" again continue the program, does not work.
%       Now, pressing "p" works during the stim presentation (not the interval) stage.
%           (in case pressing "p" is needed in the interval, mark corresponding code in the stim stage and unmark in the interval stage. Do not unmark both.)
%   10-25-2019
%       For sending EEG trigger by parallel port.
%           (1) an update: mark the line "outp(address,mod(ii,255)", and unmark the line "outp(address,11)".
%               i.e., sent "11" for all events. This was done to simplfy complex situations.
%           (2) bug fix 1:  in "outp(address,mod(ii,255)", change 255 to 127. Because the largest number is 127 by 7, rather than 8 pins.
%           (3) bug fix 2: The first trigger might be missed. (A similar issue for auditory stimuli).
%               Therefore, send a "33" at the program initialization stage.
%   10-11-2019
%       a bug fix.
%           For sending EEG trigger by parallel port, a limitation is that the max output is 255.
%           Therefore, change "outp(address,stim_sequence(ii))" to "outp(address,mod(ii,255))".
%               i.e., totally not sending the meaning of a stimulus, only sending its order.
%               moreover, when the order > 255, count from 0 again.
%               The meaning of a stimulus can be easily obtained from the order, by the mapping in the design.
%
%	10-10-2019 !!!
%       This is a substantial update.
%       It totally separates psychological design and programing. This is done by
%           (1) "PTB_template.m" only handles sequentially presenting stimuli. In other words, for programing, there is only a sequence of v, a, or va stimuli.
%               There is no "psychological program".
%               !!! for inputs and outputs of "PTB_template.m", do not add any psychological factors.(also see the version of 6-10-2014 for outputs)
%           (2) Do psychological design without thinking of any programing. See "exp_design.docx" in a sample, for how this is done by just
%           document work; as well as how the document work is connected to programming, i.e., converted into inputs of "PTB_template.m".
%       From this update, overall
%           (1) without programing,preparing most psychological experiments can be done by
%               document work in "exp_design.docx" and a few coding of converting parameters in "PTB_template_produce_data.m".
%           (2) PTB_template is not a template requireing further modifying "PTB_template.m" anymore. It is now serves as a pipeline, whithout the need of modifying "PTB_template.m".
%
%		Other major changes
%			(1) Remove the section of "Record subject information". Instead, use more formal subject information forms.
%			(2) For simplicity of program logic, particularly keeping consistency among all exp in task sets, there is only one selection page of formal or test exp.
%               Selection page of which exp is removed, which, note, is useful for e.g., one program including multiple exp, and one exp including multiple conditions.
%               If need, check and copy the design of which exp from the version of 6-10-2014.
%			(3) The current default keys are left, right and down keys on the small keyboard. 7, 8,9 (70, 80,90)-- left, right and down press (release).
%               for other keyboard keys, or mouse, check the version of 6-10-2014 as well as this version to modify.
%			(4) new logic to handle and classify v, a, and "va" stimuli. see details above in pipeline.
%           (5) substantial new logic of exp type. from 1 repeat, 2 altenative, 2more random, and multiple loop, e.g., working memory (see, the version of 6-10-2014), to "only one sequence". see above.
%           (6) For interval, i.e., IOI-stim_duration, change it to optional. Thus incorparate the no-interval situations. see detials below.
%           Others
%		Minor changes
%			Others
%
%   6-10-2014
%       Major changes
%           (1) Presenting stimuli by frames.
%               --- about presenting by time or by frame ---
%               Computer displays images frame by frame, according to a refresh rate. Therefore, by frame is accurate in timing.
%                   Now the template uses frames to display stimuli.
%               !!! But what a user (experimenter) cares about is time, not frame (which is dealed with by a programer).
%                   So  still prepare and set time parameters using time (seconds).
%                   The thing that need to handle is to make sure a time that is set includes an integer number of frames.
%                   e.g., for 60 Hz refresh rate, 0.15 s is fine, because 0.15*60=9 frames. But do not use 0.12 s, because 0.12*60=7.2 frames.
%                   (if use the previous version of the template,  don't have to change anything. Just make sure the times that are set include an integer number of frames)
%               Search "flip" for details.
%           (2) Add recording of key releases, so how long a key is pressed can be obtained. Search "key release" for details.
%           (3) Add recording of mouse clicks and mouse click positions.
%           (4) Output data are writen in integer numbers (for stimulus/response indexes: column 1) and floating number (for stimulus/response times: column 2),
%                   instead of scientific notation, which helps inspect data quickly.
%                   stimulus/response indexes: 1,2 -- stimuli number; 8,9 (80,90)-- f and j press (release); 88,99 (880,990)--left and right mouse buttons press (release)
%                   (do not press multiple keys or buttons at the same time, which is not handled now)
%           (5) Add absolute stimuli size. Search "about absolute size".Default commented(disabled).
%           (6) The moving part is made more clearly.
%                   Specifically, given a moving distance,
%                       (a)change moving speed by modifing moving time (stim_delay here).
%                       (b) change moving smoothness by changing refresh rate, or by modifying the frames of each moving step.
%                   Note that given n moving steps, there are n+1 moving positions. How to handle initial and last positions is indicated.
%                   The moving (left and right) is separate by an interval in the template. Simply commenting the interval will give continuous reverse moving.
%       Minor changes
%           Add another key (f). Now f and j are recorded thoughout the experiment.
%               !!! Emphasize again, during recording, just record. Do not do any analysis during recording !!!
%           Always display on the main screen,regardless of the number of screens.
%       Other minor modifications.
%   11-12-2013. Minor modifications on comments.
%   11-11-2013. Add moving examples. Add step-by-step programing guide.
%   11-10-2013. Add response recording.
%   11-06-2013. Original version.
%

%--- set OptionVariable and OptionVariable_customize
eleven_PsychoBuddy_set_OptionVariable; % this is not open to users
eleven_PsychoBuddy_set_OptionVariable_customize; % default empty. If there are, user define in exp current direcoty, and override default option setting.

%--- clear enviroment
clear all;
Screen('CloseAll');

try
    
    % |---------------------------------------------------------|
    % |---------- Initialize and set program parameters --------|
    % |---------------------------------------------------------|
    
    AssertOpenGL; % use OpenGL to control hardwares
    
    % --- load OptionVariable
    load eleven_PsychoBuddy_OptionVariable; % not necessary, delete later
    load eleven_PsychoBuddy_OptionVariable_customize;
    
    % |------------------------------------ vision setting --------|
    
    Screen('Preference', 'SkipSyncTests', 2); %for develop testing. mask for formal exp
    
    % Open the main window with black background (display on the main screen, regardless of the number of screens)
    screens=Screen('Screens');
    if length(screens)==1
        screenNumber=0;
    end
    if length(screens)>1
        screenNumber=1;
    end
    
    % --- screen window
    % [window,rect_window]=Screen('OpenWindow',screenNumber,background_color); %for fomral exp
    [window,rect_window]=Screen('OpenWindow',screenNumber,background_color,[0 0 1024 768]); % for develop testing. mask for formal exp
    %frame_rate = Screen('FrameRate',window);
    
    % characters of the screen window
    [window_center_x,window_center_y] = RectCenter(rect_window);
    [win_width,win_height] = RectSize(rect_window);
    
    % set font
    font_size = round(win_height/font_size_factor);
    Screen('TextFont',window,font_name);
    Screen('TextSize',window,font_size);
    
    % rect for displaying fixation point
    fix_rect = [0 0 round(win_height/fixation_size_factor) round(win_height/fixation_size_factor)];
    fix_rect = CenterRectOnPoint(fix_rect,window_center_x,window_center_y);
    
    % |------------------------------- audition setting --------|
    InitializePsychSound;
    
    % Open the default audio device. default two sound chanels
    pahandle = PsychPortAudio('Open');
    
    % --- test and make sure sound card is working
    % make a beep sound of 0.1s
    beep = MakeBeep(1000,1,44100); % 1000 Hz, 1s duration, 44100 sample rate
    beep = [beep;beep];
    beep = beep/(max(max(abs(beep))) * 1); % intention nomalization.
    
    PsychPortAudio('FillBuffer', pahandle,beep); % put contents
    
    %Somehow, the below two lines are required for initialization.
    %   in 2020 test, this is now not necessary. thus mask.
    %PsychPortAudio('Start', pahandle); % play
    %PsychPortAudio('Stop', pahandle); % stop
    
    %play for 0.05s
    PsychPortAudio('Start', pahandle); % play
    time_start=GetSecs;
    while 1
        time_tmp=GetSecs;
        if time_tmp-time_start>0.05
            PsychPortAudio('Stop', pahandle); % stop
            break;
        end
    end
    
    %     is_sound_start = 0;
    
    
    % |-------------------------------- keyboard and mouse setting --------|
    
    % hide mouse cursor
    HideCursor;
    % otherwise, "ShowCursor" to show mouse cursor.
    
    
    % |--------------------------------- for EEG study sending trigger by port--------|
    % --- parallel port
    % plp, linux
    %   finish later
    % plp, windows
    %   This is done by "Mex-File Plug-in for Fast MATLAB Port I/O". For installation and more detailes, check http://apps.usd.edu/coglab/psyc770/IO64.html.
    % plp, mac
    %   finish later
    % usb2plp, linux
    % usb2plp, windows
    % ub2plp, mac
    % (recording, Linux/mac part, as well as usb2plp part, were originally modified based on Zhang yang's instruction on 2020/12. )
    
    if trigger_study_type == 2 %
        
        if port_type == 1
            %{
            if which_system == 1
                % linux: handle later as needs.
            end
            %}
            if which_system == 2
                if bit_type == 1 || bit_type == 2
                    config_io;% initialize. clear when escape.
                    
                    % optional step: verify that the inpoutx64/32 driver was successfully initialized
                    global cogent;
                    if( cogent.io.status ~= 0 )
                        error('inp/outp installation failed');
                    end
                    
                    address=hex2dec(parallel_port_address); %standard parallel (LPT1) port address. (Check this on new computers)
                    outp(address,0); % set 0 (as baseline)
                    
                    %Somehow, the below are required for initialization, thus avoiding missing the first trigger.
                    outp(address,33);
                    time_start=GetSecs;
                    while 1
                        time_tmp=GetSecs;
                        if time_tmp-time_start>trigger_duration
                            outp(address,0);
                            break;
                        end
                    end
                    
                end
            end
            %{
            if which_system == 3
            % mac: handle later as needs.
            end
            %}
        end
        
        if port_type == 2
            % 1. same for different types of systems
            % 2. all use usb2plp, no need for 32bit anymore
            address = IOPort('OpenSerialPort',parallel_port_address);
            
            IOPort('Write',address,['CU,1,0',char(13)]);% Turn off "OK" packets
            IOPort('Write',address,['CU,2,0',char(13)]);% Turn off echoing of bytes back to PC
            
            IOPort('Write',address,['C,0,0,0,0,0,0,0',char(13)]);%configure port for output
            
            IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);%set 0 (as baseline)
            
            %Somehow, the below are required for initialization, thus avoiding missing the first trigger.
            IOPort('Write',address,['O,33,0,0,0,0,0,0',char(13)]);
            time_start=GetSecs;
            while 1
                time_tmp=GetSecs;
                if time_tmp-time_start>trigger_duration
                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                    break;
                end
            end
        end
        
    end
    
    
    % |--------------------------------- other--------|
    % set the program run under the highest priority
    % (mask if for develop testing)
    %{
    priorityLevel=MaxPriority(window);
    Priority(priorityLevel);
    %}
    
    
    % |--------------------------------------------------------------|
    % |----------------- main experiment process --------------------|
    % |--------------------------------------------------------------|
    % 1 exp instruction
    % 2 load and set exp parameters
    % 3 starting exp
    % 4 exp main loop
    % 5 ending exp
    
    % |------------------------------------------------------------|
    % |-------- exp instruction, and select test or formal --------|
    % |------------------------------------------------------------|
    % The main page of the program. When an exp ends, the program will come back here. Press ESC to exit program.
    while 1
        
        if instruction_page_num == 1
            % display instruction image
            %   note, in instruction image, add "test: press 1; formal: press 2".
            image_instruction = imread('instruction.jpg');
            image_size_tmp = size(image_instruction);
            % rect for displaying image
            image_rect_tmp = [0 0 image_size_tmp(2) image_size_tmp(1)];
            image_rect_tmp = CenterRectOnPoint(image_rect_tmp,window_center_x,window_center_y);
            % convert image into texture
            img_tex_tmp = Screen('MakeTexture',window,image_instruction);
            % put image on window
            Screen('DrawTexture', window, img_tex_tmp, [], image_rect_tmp);
            %             if is_fixation == 1
            %                 if fixation_shape == 1
            %                     Screen('FillOval',window,fixation_color,fix_rect);
            %                 end
            %             end
            
            Screen('Flip',window);
            
            while KbCheck; end % Wait until all keys are released.(If the user holds down a key, KbCheck will report multiple events.)
            while 1
                [key_is_down,key_secs,key_code] = KbCheck;% Check the state of the keyboard.
                if key_is_down
                    if key_code(key_esc) % press ESC to exit program
                        ShowCursor;
                        Priority(0);
                        PsychPortAudio('Close', pahandle);
                        if trigger_study_type == 2
                            if port_type == 2
                                IOPort('Close',address);
                            end
                        end
                        clear all;
                        Screen('Closeall');
                        return
                    end
                    if key_code(key_1)
                        is_test = 1;
                        break;
                    end
                    if key_code(key_2)
                        is_test = 0;
                        break;
                    end
                end
            end
            
        end
        
        
        
        % |------------------------------------------------------------|
        % |----------------- load and set exp parameters --------------|
        % |------------------------------------------------------------|
        
        % |----- load exp data, i.e., the input; and open record file,i.e., the output--------|
        exp_time = num2str(round(clock)); % the date and time when the exp is performed. add this in record file name, to avoid overlapping record file.
        
        switch is_test
            case 1 % test
                load eleven_PsychoBuddy_expVariable_test;
                record_file_name=['record_test_',exp_time,'.txt'];
            case 0 % formal
                load eleven_PsychoBuddy_expVariable;
                record_file_name=['record_',exp_time,'.txt'];
            otherwise
                ShowCursor;
                Priority(0);
                PsychPortAudio('Close', pahandle);
                if trigger_study_type == 2
                    if port_type == 2
                        IOPort('Close',address);
                    end
                end
                clear all;
                Screen('Closeall');
                return
        end
        
        record_data=[]; % matrix to record data
        fid_w = fopen(record_file_name,'w'); % txt file to save 'record_data'.
        
        
        % |----- load stimuli, depending on stimulus type--------|
        % Stimulus type, 1 visual; 2 auditory; 3 visual-auditory; which is indicated by index_plus,
        %   visual index_plus; v index+1000; auditory index_plus: a index+2000; visual-auditory index_plus; av index+3000
        % Decide stimulus type by index, and produce a sequence of stimulus type
        stim_type_sequence = round(stim_sequence/v_index_plus);
        
        image_size = []; % a safe code, in case image_size is non empty unexpectedly
        
        % ------load visual image
        if isempty(find(stim_type_sequence==1)) == 0 || isempty(find(stim_type_sequence==3)) == 0 % if v or av
            image_cell = cell(1,pic_num);
            for ii=1:pic_num
                image_cell{ii} = imread([num2str(ii),'.jpg']);
            end
            image_size = size(image_cell{1});
        end
        
        % ------load sound
        if isempty(find(stim_type_sequence==2)) == 0 || isempty(find(stim_type_sequence==3)) == 0 % if a or av
            % default 2 channels stereo sound file and output
            sound_cell = cell(1,sound_num);
            for ii=1:sound_num
                %wavread was replaced by audioread in MATLAB version R2013a.
                %7.11.0.584 (R2010b)
                %8.1.0.47 (R2013a)
                %8.2.0.29 (R2013b)
                %9.0.0.341360 (R2016a)
                matlab_version = version; matlab_version = str2num(matlab_version(1));
                if matlab_version<8
                    sound_cell{ii} = wavread([num2str(ii),'.wav']); sound_cell{ii} = sound_cell{ii}'; sound_cell{ii} = sound_cell{ii}/(max(max(abs(sound_cell{ii}))) * 1);
                else
                    [tmp_sound,tmp_fs] = audioread([num2str(ii),'.wav']);sound_cell{ii} = tmp_sound;
                    sound_cell{ii} = sound_cell{ii}'; sound_cell{ii} = sound_cell{ii}/(max(max(abs(sound_cell{ii}))) * 1);
                end
            end
        end
        
        % ------background image
        if is_bg_image == 1
            image_bg = imread('background.jpg');
            
            % for a, with the need to use background image, set image_size according to the background image
            if isempty(find(stim_type_sequence==2)) == 0
                image_size = size(image_bg);
            end
        end
        
        % ------ set display rect
        %   as long as image is there; including  v or av, or a+background image
        %   for v or av, set by visual image
        %   for a+background image, set by background image
        if ~isempty(image_size)
            %--- rect for displaying image ---|
            %{
            % 2019 version use image_rect, which is accroding to image directly. Now change to display_rect.
            image_rect = [0 0 image_size(2) image_size(1)];
            image_rect = CenterRectOnPoint(image_rect,window_center_x,window_center_y);
            %}
            
            % display_rect_mode 1
            if display_rect_mode == 1
                % when set display rect accrording to original image size
                %   Note, when making pic, keep all the same size; if not, handle later as need
                display_rect = [0 0 image_size(2) image_size(1)];
                % scale
                display_rect = round(display_rect./display_rect_size_factor);
                [display_rect_width,display_rect_height] = RectSize(display_rect);
                % cented on win senter.
                %   change this if not presenting image on the center
                display_rect = CenterRectOnPoint(display_rect,window_center_x,window_center_y);
                [display_rect_center_x,display_rect_center_y] = RectCenter(display_rect);
            end
            
            % display_rect_mode 2
            if display_rect_mode == 2
                % when set display rect manually, i.e., pre-defined.
                %   display_rect,display_rect_center,are pre-defined
                %                 if isempty(display_rect)
                %                     display_rect = [0 0 800 800];
                %                     [display_rect_width,display_rect_height] = RectSize(display_rect);
                %                 end
                display_rect_size = round(eleven_visual_angle(1,visual_angle,view_distance)/screen_voxel_size);
                if image_size(2)==image_size(1)
                    display_rect = [0 0 display_rect_size display_rect_size];
                end
                % if rectangle, set the longer side as display_rect_size
                if image_size(2)<image_size(1)
                    display_rect = [0 0 display_rect_size*image_size(2)/image_size(1) display_rect_size];
                end
                if image_size(2)>image_size(1)
                    display_rect = [0 0 display_rect_size display_rect_size*image_size(1)/image_size(2)];
                end
                [display_rect_width,display_rect_height] = RectSize(display_rect);
                
                if isempty(display_rect_center)
                    display_rect_center_x = window_center_x;
                    display_rect_center_y = window_center_y;
                    display_rect = CenterRectOnPoint(display_rect,display_rect_center_x,display_rect_center_y);
                else
                    display_rect_center_x = display_rect_center(1);
                    display_rect_center_y = display_rect_center(2);
                    display_rect = CenterRectOnPoint(display_rect,display_rect_center_x,display_rect_center_y);
                end
            end
            
            % display_rect_mode 3
            % add later as needs.
        end
        
        % ------convert image into texture
        % for visual image in v or av
        if isempty(find(stim_type_sequence==1)) == 0 || isempty(find(stim_type_sequence==3)) == 0 % if v or av
            img_tex_cell = cell(1,length(image_cell));
            for ii=1:length(image_cell)
                img_tex_cell{ii} = Screen('MakeTexture',window,image_cell{ii});
            end
        end
        
        % as long as a backgroud image is there; including  v or av, or a+background image
        if is_bg_image == 1
            img_tex_bg = Screen('MakeTexture',window,image_bg);
        end
        
        
        
        % |---------------------------------------------------|
        % |-------------------- starting exp -----------------|
        % |---------------------------------------------------|
        
        % |--- press space key to start experiment ---|
        
        if is_bg_image == 1
            Screen('DrawTexture', window, img_tex_bg, [], display_rect);
        end
        
        if trigger_study_type == 1 || trigger_study_type == 2
            DrawFormattedText(window,'Press Space to start','center',window_center_y,gray_color);
        end
        if trigger_study_type == 3
            DrawFormattedText(window,'Wait for TR sig to start','center',window_center_y,gray_color);
        end
        
        if is_fixation == 1
            if fixation_shape == 1
                Screen('FillOval',window,fixation_color,fix_rect);
            end
        end
        
        Screen('Flip',window);
        
        while KbCheck; end
        while 1
            [key_is_down,key_secs,key_code] = KbCheck;
            if key_is_down
                if key_code(key_esc) % return
                    fclose(fid_w);
                    ShowCursor;
                    Priority(0);
                    PsychPortAudio('Close', pahandle);
                    if trigger_study_type == 2
                        if port_type == 2
                            IOPort('Close',address);
                        end
                    end
                    clear all;
                    Screen('Closeall');
                    return
                end
                if key_code(key_space)
                    break;
                end
                if trigger_study_type == 3
                    if key_code(TR_sig_key)
                        break;
                    end
                end
                
            end
        end
        
        
        % |-------starting rest, in which prepare first stimuli---------|
        %Screen('FillRect',window,backgroud_color,display_rect); % not necessary
        %DrawFormattedText(window,'starting rest','center',window_center_y-font_size*4,gray_color); % for debuging
        if is_bg_image == 1
            Screen('DrawTexture', window, img_tex_bg, [], display_rect);
        end
        if is_fixation == 1
            if fixation_shape == 1
                Screen('FillOval',window,fixation_color,fix_rect);
            end
        end
        flip_end_time=Screen('Flip',window); %
        exp_starting_time =  flip_end_time; %%% the time to start the exp.
        
        % initialize key press here, further see below response recording
        is_key_left_record = 1;
        is_key_right_record = 1;
        is_key_down_record = 1;
        
        is_key_f_record = 1;
        is_key_j_record = 1;
        
        is_key_1_record = 1;
        is_key_2_record = 1;
        
        % initialize trigger for stim
        if trigger_study_type == 2
            is_trigger_sent = 0;
        end
        
        % initialize state of trigger for response
        if trigger_study_type == 2
            if is_trigger_for_response == 1
                is_key_left_trigger_sent = 0;
                is_key_right_trigger_sent = 0;
                is_key_down_trigger_sent = 0;
                
                is_key_f_trigger_sent = 0;
                is_key_j_trigger_sent = 0;
                
                is_key_1_trigger_sent = 0;
                is_key_2_trigger_sent = 0;
            end
        end
        
        % preparing fist stimulus
        %   for high timing accuracy and effeciency, always prepare material at (1) the non-busy (i.e., after stim presentation)and (2) pre-presentation (i.e., ii-1) time.
        %       here is for ii=1, before the presentation of trial ii. See below preparing material for ii+1, after presentation of ii.
        if is_bg_image == 1
            Screen('DrawTexture', window, img_tex_bg, [], display_rect);
        end
        
        if stim_type_sequence(1)==1
            Screen('DrawTexture', window, img_tex_cell{stim_sequence(1)-v_index_plus}, [], display_rect);
        end
        if stim_type_sequence(1)==2
            PsychPortAudio('FillBuffer', pahandle,sound_cell{stim_sequence(1)-a_index_plus});
        end
        if stim_type_sequence(1)==3
            va_index_tmp = stim_sequence(1)-va_index_plus;
            Screen('DrawTexture', window, img_tex_cell{va_pair(va_index_tmp,1)}, [], display_rect);
            PsychPortAudio('FillBuffer', pahandle,sound_cell{va_pair(va_index_tmp,2)});
        end
        
        if is_fixation == 1
            if fixation_shape == 1
                Screen('FillOval',window,fixation_color,fix_rect);
            end
        end
        
        while 1
            time_tmp = GetSecs;
            if (time_tmp-flip_end_time)>starting_rest-flip_ahead_time;
                break;
            end
        end
        
        % now less than one frame time is left for starting rest time,  will flip at next frame
        flip_end_time=Screen('Flip',window);
        
        
        
        % |------------------------------------------------------------|
        % |------------------- experiment main loop -------------------|
        % |------------------------------------------------------------|
        % A trial typically contain a stim duration and an interval, the sum of them is the IOI.
        % when an interval is not involved, stimu duration=IOI. e.g., the reversal VEP, or motion that does not involve intervals.
        
        for ii=1:trial_num
            
            % |---------------------------------------------------|
            % |-------------------- stim stage -------------------|
            % |---------------------------------------------------|
            
            % |-----record stimuli-----|
            record_tmp = [stim_sequence(ii) flip_end_time];
            record_data = [record_data;record_tmp];
            
            
            % |-----display stimuli------|
            % Simply present current stimuli, because all stimulus materials have been prepared in ii-1 trial.
            
            % display visual stimulus
            % !!! note, visual stimulus is already presented when the "previous, i.e., ii-1" flip ends.
            % For programming by visual frames, a visual stimulus is presented, i.e., flipped at ii-1 trial. Other types of events, are presented at the current ii trial.
            
            % display auditory stimulus.
            if stim_type_sequence(ii)==2
                PsychPortAudio('Start', pahandle);
                %                 is_sound_start = 1;
            end
            if stim_type_sequence(ii)==3
                PsychPortAudio('Start', pahandle);
                %                 is_sound_start = 1;
            end
            
            % send trigger
            if trigger_study_type == 2
                
                if is_frame_by_frame_program == 1
                    if port_type == 1
                        if which_system == 2
                            if bit_type == 1 || bit_type == 2
                                outp(address,11);
                                is_trigger_sent = 1;
                                %disp(11);% for debuging
                            end
                        end
                    end
                    if port_type == 2
                        IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                        is_trigger_sent = 1;
                        %disp(11);% for debuging
                    end
                end
                if is_frame_by_frame_program == 2
                    if stim_trigger(ii)
                        if port_type == 1
                            if which_system == 2
                                if bit_type == 1 || bit_type == 2
                                    outp(address,11);
                                    is_trigger_sent = 1;
                                    %disp(11);% for debuging
                                end
                            end
                        end
                        if port_type == 2
                            IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                            is_trigger_sent = 1;
                            %disp(11);% for debuging
                        end
                    end
                end
                
            end
            
            
            % |------prepare materials for after-presentation-----|
            % If there is an interval; here simply prepare fixation, and prepare next trial manerial in the interval
            if stim_delay(ii)<IOI_sequence(ii)
                % prepare interval stimulus, which is displayed at the beginning of the interval.
                if is_bg_image == 1
                    Screen('DrawTexture', window, img_tex_bg, [], display_rect);
                end
                if is_fixation == 1
                    if fixation_shape == 1
                        Screen('FillOval',window,fixation_color,fix_rect);
                    end
                end
            end
            
            % If no interval; prepare next trial manerial here
            if stim_delay(ii)==IOI_sequence(ii)
                if ii<trial_num
                    if is_bg_image == 1
                        Screen('DrawTexture', window, img_tex_bg, [], display_rect);
                    end
                    
                    if stim_type_sequence(ii+1)==1
                        Screen('DrawTexture', window, img_tex_cell{stim_sequence(ii+1)-v_index_plus}, [], display_rect);
                    end
                    if stim_type_sequence(ii+1)==2
                        PsychPortAudio('FillBuffer', pahandle,sound_cell{stim_sequence(ii+1)-a_index_plus});
                    end
                    if stim_type_sequence(ii+1)==3
                        va_index_tmp = stim_sequence(ii+1)-va_index_plus;
                        Screen('DrawTexture', window, img_tex_cell{va_pair(va_index_tmp,1)}, [], display_rect);
                        PsychPortAudio('FillBuffer', pahandle,sound_cell{va_pair(va_index_tmp,2)});
                    end
                    
                    if is_fixation == 1
                        if fixation_shape == 1
                            Screen('FillOval',window,fixation_color,fix_rect);
                        end
                    end
                end
                if ii==trial_num
                    %DrawFormattedText(window,'ending rest','center',window_center_y-font_size*4,gray_color); % for debuging
                    if is_bg_image == 1
                        Screen('DrawTexture', window, img_tex_bg, [], display_rect);
                    end
                    if is_fixation == 1
                        if fixation_shape == 1
                            Screen('FillOval',window,fixation_color,fix_rect);
                        end
                    end
                end
            end
            
            % |-----stim_delay and record responses-----|
            % !!! note how to separate key presses
            
            while 1
                time_tmp = GetSecs;
                % count and quit stim_delay
                if (time_tmp-flip_end_time)>stim_delay(ii)-flip_ahead_time % by "-flip_ahead_time", leave the time less than one frame time,  will flip at next frame
                    break;
                end
                
                % count trigger_duration, then set to baseline
                if trigger_study_type == 2
                    if is_trigger_sent == 1
                        if (time_tmp-flip_end_time)>trigger_duration
                            
                            if is_frame_by_frame_program == 1
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            is_trigger_sent = 0;
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    is_trigger_sent = 0;
                                    %disp(0);% for debuging
                                end
                            end
                            if is_frame_by_frame_program == 2
                                % if ~isempty(find(stim_trigger==stim_sequence(ii)))
                                %if stim_trigger(ii)
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            is_trigger_sent = 0;
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    is_trigger_sent = 0;
                                    %disp(0);% for debuging
                                end
                                %end
                            end
                            
                        end
                    end
                end
                
                % send trigger to 0 for key press
                if trigger_study_type == 2
                    if is_trigger_for_response == 1
                        
                        if is_key_left_trigger_sent == 1
                            if (time_tmp-key_left_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_left_trigger_sent = 0;
                            end
                        end
                        if is_key_right_trigger_sent == 1
                            if (time_tmp-key_right_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_right_trigger_sent = 0;
                            end
                        end
                        if is_key_down_trigger_sent == 1
                            if (time_tmp-key_down_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_down_trigger_sent = 0;
                            end
                        end
                        
                        if is_key_f_trigger_sent == 1
                            if (time_tmp-key_f_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_f_trigger_sent = 0;
                            end
                        end
                        if is_key_j_trigger_sent == 1
                            if (time_tmp-key_j_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_j_trigger_sent = 0;
                            end
                        end
                        
                        if is_key_1_trigger_sent == 1
                            if (time_tmp-key_1_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_1_trigger_sent = 0;
                            end
                        end
                        if is_key_2_trigger_sent == 1
                            if (time_tmp-key_2_press_trigger_time)>trigger_duration
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,0);
                                            %disp(0);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                    %disp(0);% for debuging
                                end
                                is_key_2_trigger_sent = 0;
                            end
                        end
                        
                    end
                end
                
                [key_is_down,key_secs,key_code] = KbCheck;
                % key release
                if key_is_down==0 && is_key_left_record==0
                    record_tmp = [70 key_secs]; % 70 -- record left release as 70
                    record_data = [record_data;record_tmp];
                end
                if key_is_down==0 && is_key_right_record==0
                    record_tmp = [80 key_secs]; % 80 -- record right release as 80
                    record_data = [record_data;record_tmp];
                end
                if key_is_down==0 && is_key_down_record==0
                    record_tmp = [90 key_secs]; % 90 -- record down release as 90
                    record_data = [record_data;record_tmp];
                end
                
                if key_is_down==0 && is_key_f_record==0
                    record_tmp = [70 key_secs]; % 70 -- record f release as 70
                    record_data = [record_data;record_tmp];
                end
                if key_is_down==0 && is_key_j_record==0
                    record_tmp = [80 key_secs]; % 80 -- record j release as 80
                    record_data = [record_data;record_tmp];
                end
                
                if key_is_down==0 && is_key_1_record==0
                    record_tmp = [70 key_secs]; % 70 -- record 1 release as 70
                    record_data = [record_data;record_tmp];
                end
                if key_is_down==0 && is_key_2_record==0
                    record_tmp = [80 key_secs]; % 80 -- record 2 release as 80
                    record_data = [record_data;record_tmp];
                end
                
                if key_is_down==0
                    is_key_left_record = 1;
                    is_key_right_record = 1;
                    is_key_down_record = 1;
                    
                    is_key_f_record = 1;
                    is_key_j_record = 1;
                    
                    is_key_1_record = 1;
                    is_key_2_record = 1;
                end
                
                % key press
                if key_is_down && key_code(key_left) && is_key_left_record
                    record_tmp = [7 key_secs]; % 7 -- record left press as 7
                    record_data = [record_data;record_tmp];
                    is_key_left_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_left_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_left_trigger_sent = 1;
                        end
                    end
                end
                if key_is_down && key_code(key_right) && is_key_right_record
                    record_tmp = [8 key_secs]; % 8 -- record right press as 8
                    record_data = [record_data;record_tmp];
                    is_key_right_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_right_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_right_trigger_sent = 1;
                        end
                    end
                end
                if key_is_down && key_code(key_down) && is_key_down_record
                    record_tmp = [9 key_secs]; % 9 -- record right press as 9
                    record_data = [record_data;record_tmp];
                    is_key_down_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_down_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_down_trigger_sent = 1;
                        end
                    end
                end
                
                if key_is_down && key_code(key_f) && is_key_f_record
                    record_tmp = [7 key_secs]; % 7 -- record f press as 7
                    record_data = [record_data;record_tmp];
                    is_key_f_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_f_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_f_trigger_sent = 1;
                        end
                    end
                end
                if key_is_down && key_code(key_j) && is_key_j_record
                    record_tmp = [8 key_secs]; % 8 -- record j press as 8
                    record_data = [record_data;record_tmp];
                    is_key_j_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_j_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_j_trigger_sent = 1;
                        end
                    end
                end
                
                if key_is_down && key_code(key_1) && is_key_1_record
                    record_tmp = [7 key_secs]; % 7 -- record 1 press as 7
                    record_data = [record_data;record_tmp];
                    is_key_1_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_1_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_1_trigger_sent = 1;
                        end
                    end
                end
                if key_is_down && key_code(key_2) && is_key_2_record
                    record_tmp = [8 key_secs]; % 8 -- record 2 press as 8
                    record_data = [record_data;record_tmp];
                    is_key_2_record = 0;
                    % send trigger
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            key_2_press_trigger_time = key_secs;
                            if port_type == 1
                                if which_system == 2
                                    if bit_type == 1 || bit_type == 2
                                        outp(address,11);
                                        %disp(11);% for debuging
                                    end
                                end
                            end
                            if port_type == 2
                                IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                %disp(11);% for debuging
                            end
                            is_key_2_trigger_sent = 1;
                        end
                    end
                end
                
                % If want to exit program during testing program. comment this during formal exp.
                if key_is_down && key_code(key_esc)
                    record_data(:,2) = record_data(:,2)-exp_starting_time;
                    record_data=record_data'; fprintf(fid_w,'%d\t %f\n',record_data);
                    fclose(fid_w);
                    ShowCursor;
                    Priority(0);
                    PsychPortAudio('Close', pahandle);
                    if trigger_study_type == 2
                        if port_type == 2
                            IOPort('Close',address);
                        end
                    end
                    clear all;
                    Screen('Closeall');
                    return
                end
                
                % If want to pause program during testing exp, or in case of the need of formal exp.Otherwise, comment this during formal exp.
                %{
                if key_is_down && key_code(key_p)
                    while KbCheck; end
                    while 1
                        [key_is_down,key_secs,key_code] = KbCheck;
                        if key_is_down
                            if key_code(key_p)
                                break;
                            end
                            while KbCheck; end
                        end
                    end
                end
                %}
                
            end
            
            flip_end_time=Screen('Flip',window);
            % end of stim_duration
            
            
            
            % |---------------------------------------------------|
            % |------ interval after stimuli,if there is ---------|
            % |---------------------------------------------------|
            
            if stim_delay(ii)<IOI_sequence(ii)
                %prepare stimuli for the next trial. same codes as above in the stim stage.
                if ii<trial_num
                    if is_bg_image == 1
                        Screen('DrawTexture', window, img_tex_bg, [], display_rect);
                    end
                    
                    if stim_type_sequence(ii+1)==1
                        Screen('DrawTexture', window, img_tex_cell{stim_sequence(ii+1)-v_index_plus}, [], display_rect);
                    end
                    if stim_type_sequence(ii+1)==2
                        PsychPortAudio('FillBuffer', pahandle,sound_cell{stim_sequence(ii+1)-a_index_plus});
                    end
                    if stim_type_sequence(ii+1)==3
                        va_index_tmp = stim_sequence(ii+1)-va_index_plus;
                        Screen('DrawTexture', window, img_tex_cell{va_pair(va_index_tmp,1)}, [], display_rect);
                        PsychPortAudio('FillBuffer', pahandle,sound_cell{va_pair(va_index_tmp,2)});
                    end
                    
                    if is_fixation == 1
                        if fixation_shape == 1
                            Screen('FillOval',window,fixation_color,fix_rect);
                        end
                    end
                end
                if ii==trial_num
                    %DrawFormattedText(window,'ending rest','center',window_center_y-font_size*4,gray_color); % for debuging
                    if is_bg_image == 1
                        Screen('DrawTexture', window, img_tex_bg, [], display_rect);
                    end
                    if is_fixation == 1
                        if fixation_shape == 1
                            Screen('FillOval',window,fixation_color,fix_rect);
                        end
                    end
                end
                
                
                while 1
                    time_tmp = GetSecs;
                    if time_tmp-flip_end_time > IOI_sequence(ii)-stim_delay(ii)-flip_ahead_time
                        break;
                    end
                    
                    % stop auditory stimulus
                    %                     if stim_type_sequence(ii)==2 || stim_type_sequence(ii)==3
                    %                         if is_sound_start == 1
                    %                             PsychPortAudio('Stop', pahandle);
                    %                         end
                    %                     end
                    
                    % count trigger_duration, then set to baseline
                    if trigger_study_type == 2
                        if is_trigger_sent == 1
                            if (time_tmp-flip_end_time)>trigger_duration
                                
                                if is_frame_by_frame_program == 1
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                is_trigger_sent = 0;
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        is_trigger_sent = 0;
                                        %disp(0);% for debuging
                                    end
                                end
                                if is_frame_by_frame_program == 2
                                    % if ~isempty(find(stim_trigger==stim_sequence(ii)))
                                    %if stim_trigger(ii)
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                is_trigger_sent = 0;
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        is_trigger_sent = 0;
                                        %disp(0);% for debuging
                                    end
                                    %end
                                end
                                
                            end
                        end
                    end
                    
                    %--- below key recording codes are the same as above in the stim stage ---|
                    %   % this 'copy code' is dirty, handle later
                    
                    % send trigger to 0 for key press
                    if trigger_study_type == 2
                        if is_trigger_for_response == 1
                            
                            if is_key_left_trigger_sent == 1
                                if (time_tmp-key_left_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_left_trigger_sent = 0;
                                end
                            end
                            if is_key_right_trigger_sent == 1
                                if (time_tmp-key_right_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_right_trigger_sent = 0;
                                end
                            end
                            if is_key_down_trigger_sent == 1
                                if (time_tmp-key_down_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_down_trigger_sent = 0;
                                end
                            end
                            
                            if is_key_f_trigger_sent == 1
                                if (time_tmp-key_f_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_f_trigger_sent = 0;
                                end
                            end
                            if is_key_j_trigger_sent == 1
                                if (time_tmp-key_j_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_j_trigger_sent = 0;
                                end
                            end
                            
                            if is_key_1_trigger_sent == 1
                                if (time_tmp-key_1_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_1_trigger_sent = 0;
                                end
                            end
                            if is_key_2_trigger_sent == 1
                                if (time_tmp-key_2_press_trigger_time)>trigger_duration
                                    if port_type == 1
                                        if which_system == 2
                                            if bit_type == 1 || bit_type == 2
                                                outp(address,0);
                                                %disp(0);% for debuging
                                            end
                                        end
                                    end
                                    if port_type == 2
                                        IOPort('Write',address,['O,0,0,0,0,0,0,0',char(13)]);
                                        %disp(0);% for debuging
                                    end
                                    is_key_2_trigger_sent = 0;
                                end
                            end
                            
                        end
                    end
                    
                    [key_is_down,key_secs,key_code] = KbCheck;
                    % key release
                    if key_is_down==0 && is_key_left_record==0
                        record_tmp = [70 key_secs]; % 70 -- record left release as 70
                        record_data = [record_data;record_tmp];
                    end
                    if key_is_down==0 && is_key_right_record==0
                        record_tmp = [80 key_secs]; % 80 -- record right release as 80
                        record_data = [record_data;record_tmp];
                    end
                    if key_is_down==0 && is_key_down_record==0
                        record_tmp = [90 key_secs]; % 90 -- record down release as 90
                        record_data = [record_data;record_tmp];
                    end
                    
                    if key_is_down==0 && is_key_f_record==0
                        record_tmp = [70 key_secs]; % 70 -- record f release as 70
                        record_data = [record_data;record_tmp];
                    end
                    if key_is_down==0 && is_key_j_record==0
                        record_tmp = [80 key_secs]; % 80 -- record j release as 80
                        record_data = [record_data;record_tmp];
                    end
                    
                    if key_is_down==0 && is_key_1_record==0
                        record_tmp = [70 key_secs]; % 70 -- record 1 release as 70
                        record_data = [record_data;record_tmp];
                    end
                    if key_is_down==0 && is_key_2_record==0
                        record_tmp = [80 key_secs]; % 80 -- record 2 release as 80
                        record_data = [record_data;record_tmp];
                    end
                    
                    if key_is_down==0
                        is_key_left_record = 1;
                        is_key_right_record = 1;
                        is_key_down_record = 1;
                        
                        is_key_f_record = 1;
                        is_key_j_record = 1;
                        
                        is_key_1_record = 1;
                        is_key_2_record = 1;
                    end
                    
                    % key press
                    if key_is_down && key_code(key_left) && is_key_left_record
                        record_tmp = [7 key_secs]; % 7 -- record left press as 7
                        record_data = [record_data;record_tmp];
                        is_key_left_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_left_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_left_trigger_sent = 1;
                            end
                        end
                    end
                    if key_is_down && key_code(key_right) && is_key_right_record
                        record_tmp = [8 key_secs]; % 8 -- record right press as 8
                        record_data = [record_data;record_tmp];
                        is_key_right_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_right_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_right_trigger_sent = 1;
                            end
                        end
                    end
                    if key_is_down && key_code(key_down) && is_key_down_record
                        record_tmp = [9 key_secs]; % 9 -- record right press as 9
                        record_data = [record_data;record_tmp];
                        is_key_down_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_down_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_down_trigger_sent = 1;
                            end
                        end
                    end
                    
                    if key_is_down && key_code(key_f) && is_key_f_record
                        record_tmp = [7 key_secs]; % 7 -- record f press as 7
                        record_data = [record_data;record_tmp];
                        is_key_f_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_f_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_f_trigger_sent = 1;
                            end
                        end
                    end
                    if key_is_down && key_code(key_j) && is_key_j_record
                        record_tmp = [8 key_secs]; % 8 -- record j press as 8
                        record_data = [record_data;record_tmp];
                        is_key_j_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_j_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_j_trigger_sent = 1;
                            end
                        end
                    end
                    
                    if key_is_down && key_code(key_1) && is_key_1_record
                        record_tmp = [7 key_secs]; % 7 -- record 1 press as 7
                        record_data = [record_data;record_tmp];
                        is_key_1_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_1_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_1_trigger_sent = 1;
                            end
                        end
                    end
                    if key_is_down && key_code(key_2) && is_key_2_record
                        record_tmp = [8 key_secs]; % 8 -- record 2 press as 8
                        record_data = [record_data;record_tmp];
                        is_key_2_record = 0;
                        % send trigger
                        if trigger_study_type == 2
                            if is_trigger_for_response == 1
                                key_2_press_trigger_time = key_secs;
                                if port_type == 1
                                    if which_system == 2
                                        if bit_type == 1 || bit_type == 2
                                            outp(address,11);
                                            %disp(11);% for debuging
                                        end
                                    end
                                end
                                if port_type == 2
                                    IOPort('Write',address,['O,11,0,0,0,0,0,0',char(13)]);
                                    %disp(11);% for debuging
                                end
                                is_key_2_trigger_sent = 1;
                            end
                        end
                    end
                    
                    % If want to exit program during testing program. comment this during formal exp.
                    if key_is_down && key_code(key_esc)
                        record_data(:,2) = record_data(:,2)-exp_starting_time;
                        record_data=record_data'; fprintf(fid_w,'%d\t %f\n',record_data);
                        fclose(fid_w);
                        ShowCursor;
                        Priority(0);
                        PsychPortAudio('Close', pahandle);
                        if trigger_study_type == 2
                            if port_type == 2
                                IOPort('Close',address);
                            end
                        end
                        clear all;
                        Screen('Closeall');
                        return
                    end
                    
                    % for some reason that hard to debug, the below pause code can be in either the stim or the interval stage,
                    %   but cannot appear twice.
                    % If want to pause program during testing exp, or in case of the need of formal exp.Otherwise, comment this during formal exp.
                    %                     if key_is_down & key_code(key_p)
                    %                         while KbCheck; end
                    %                         while 1
                    %                             [key_is_down,key_secs,key_code] = KbCheck;
                    %                             if key_is_down
                    %                                 if key_code(key_p)
                    %                                     break;
                    %                                 end
                    %                                 while KbCheck; end
                    %                             end
                    %                         end
                    %                     end
                    
                end
                
                flip_end_time=Screen('Flip',window);
            end
            % end of interval
            
            
            
        end
        % end main loop
        
        
        % |---------------------------------------------------|
        % |-------------------- ending exp -------------------|
        % |---------------------------------------------------|
        % ending rest and save recording
        
        % ending rest
        while 1
            time_tmp = GetSecs;
            if time_tmp-flip_end_time>ending_rest;
                break;
            end
        end
        
        % exp_total_time, not for saving, only for checking. necessary for fMRI exp.
        exp_ending_time = GetSecs;
        exp_total_time = exp_ending_time-exp_starting_time; % check this for the total time of the exp
        disp(['exp_total_time = ' num2str(exp_total_time) ' s ' '(with starting and ending rests)']);
        
        % save recorded data
        record_data(:,2) = record_data(:,2)-exp_starting_time; % in record, convert computer-based times into exp-based times
        %save(record_file_name,'record_data','-ASCII','-DOUBLE','-TABS');
        record_data=record_data'; fprintf(fid_w,'%d\t %f\n',record_data);
        fclose(fid_w);
        
        
        
    end % go to program main page
    
catch
    %   if trigger_study_type == 2
    %     if port_type == 2
    %         IOPort('Close',address);
    %     end
    %   end
    clear all;
    Screen('CloseAll');
    ShowCursor;
    Priority(0);
    psychrethrow(psychlasterror);
end

