function eleven_PsychoBuddy_set_OptionVariable_customize
% eleven_PsychoBuddy_set_OptionVariable_customize	
% Usage
%   eleven_PsychoBuddy_set_OptionVariable_customize
%
% Update history 
%   2020-09-29 small bug fix.
%   2020-09-18 build

clear; % do not remove this

load eleven_PsychoBuddy_OptionVariable;

% |--- add customized options here, if there are ---|
%   customized options are produced by: 
%       1. copy to-be-change default options in eleven_PsychoBuddy_set_OptionVariable.m here 
%       2. modify here as needs
%       3. run eleven_PsychoBuddy_set_OptionVariable_customize here (make sure in the current program directory)



% --- save
save eleven_PsychoBuddy_OptionVariable_customize;

clear; % do not remove this
