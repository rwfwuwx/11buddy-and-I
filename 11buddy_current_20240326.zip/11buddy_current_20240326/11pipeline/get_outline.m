function [k,roi] = get_outline(atlas,ind)

% Written by liying Zhan 20200409.
roi_num = length(ind);

fn = [atlas '.nii']
V = spm_vol(fn);
[v,xyz] = spm_read_vols(V);


for ii = 1:roi_num
    if ind(ii) == 0
        ind_v{ii} = find(v ~= ind(ii));
    else
        ind_v{ii} = find(v == ind(ii));
    end
        
    temp = ind_v{ii};
    roi{ii} = xyz(:,temp);
    P = roi{ii}';
    k{ii} = boundary(P);
end

end