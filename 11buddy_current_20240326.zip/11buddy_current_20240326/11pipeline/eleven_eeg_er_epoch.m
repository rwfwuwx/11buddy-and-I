function eleven_eeg_er_epoch
% eleven_eeg_er_epoch	
% Usage
%   eleven_eeg_er_epoch
% external varialbe (add later)
%  -- input 
%  -- option
%  -- output
%
% Update history
%   2021-12-20 incorporate epoch for ssep
%   2021-12-17 expVariable-> individual variable
%   2021-12-11 remove design_type
%   2020-07-30 add design_type
%   2020-04-01
%       add afr in epoch
%   2020-03-25
%   reorgize and rewrite from Andy. 
%   2020-01-07
%       ...
%       Andy is ready
%   2020-01-06
%       ...
%	2020-01-05 initially writen

% |-------------------------|
% |---------- epoch --------|
% |-------------------------|

%clear;
disp('epoch processing');

% --- load exp variables and option variables
load eeg_type;
load eeg_analyze_type;

load cond_name;
if eeg_analyze_type == 2 || eeg_analyze_type == 42
    load cond_code;
end
if eeg_analyze_type == 3 || eeg_analyze_type == 43
    load cond_code_sequence;
%    load cond_sequence_length;
end

load eleven_eeg_OptionVariable_customize;


% --- input
% preprecessed eeg data
load eeg_raw_pp;

% ecd data
load eeg_ecd;

% |--- processing loop by condition ---|
cond_num = length(cond_name);

for ii=1:cond_num
    % --- epoch
    disp('  epoch');
    if eeg_analyze_type == 2 || eeg_analyze_type == 42
        eeg_epo_tmp = mf_epoch(eeg_raw_pp,eeg_ecd,cond_code{ii},epoch_points_before_onest,epoch_points_after_onest);
        
        % --- afr
        if is_afr
            afr_recording_name = ['eeg_epo_afr' '_' cond_name{ii} '.txt'];
            eeg_epo_tmp = mf_epoafr(eeg_epo_tmp,afr_epoch_range,afr_criterion,afr_ch,afr_recording_name,afr_is_pp,fs);
        end
    end
    
    if eeg_analyze_type == 3 || eeg_analyze_type == 43
        eeg_epo_tmp = mf_epoch(eeg_raw_pp,eeg_ecd,cond_code_sequence{ii},epoch_points_before_onest,epoch_points_after_onest);
    end
    
    % --- output
    output_data_name = ['eeg_epo' '_' cond_name{ii}];
    eval(sprintf('%s = eeg_epo_tmp;',output_data_name));
    eval(sprintf('save %s %s;',output_data_name,output_data_name));
    
    % --- clear
    eval(sprintf('clear %s;',output_data_name));
end

%clear; 
