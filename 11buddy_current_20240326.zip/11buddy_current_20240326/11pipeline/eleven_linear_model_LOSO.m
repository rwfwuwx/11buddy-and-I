function [b,y_hat,mse]=eleven_linear_model_LOSO(X,Y)

% the function use the leave one out method, and it can be used to predict multiple dependent variable.
%input
% X - independent variable, the first dimention(row) is the participant,the second(column) is the feature;
% Y - dependent variable,the first dimention(row) is the participant, the second(column) is the variable to be predicted.
%output
% b:regression parameter
% y_hat: predicted value
% mse:MSE
% -- writed by liying

[obj,fea] = size(X);
[obj,v] = size(Y);

Xadd = [ones(obj,1) X];

for i = 1:obj
      Y_1 = Y;
      Y_1(i,:) = [];
      X_1 = Xadd;
      X_1(i,:) = [];
      Xcell = cell(1,obj-1);
      for j = 1:obj-1
         Xcell{j} = [kron([X_1(j,:)],eye(v))];
      end
      [beta,sigma,E,V] = mvregress(Xcell,Y_1,'algorithm','cwls');
      B = reshape(beta,fea+1,v);
      y_hat(i,:) = Xadd(i,:)*B;
      b(i,:,:) = B;
      y_diff = power((Y(i,:) - y_hat(i,:)),2);
end

mse = y_diff/obj;

end
 