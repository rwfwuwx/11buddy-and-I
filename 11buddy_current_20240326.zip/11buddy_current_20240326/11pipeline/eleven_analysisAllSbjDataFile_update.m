function eleven_analysisAllSbjDataFile_update(sbjDataFile,allSbjDataFile,path_of_allSbjDataFile)
% Usage eleven_analysisAllSbjDataFile_update(sbjDataFile,allSbjDataFile,path_of_allSbjDataFile)
%   In sbjDataFile, for a subject, if 'analysis' == 1, a 'Data' == 1; in
%   allSbjDataFile, that Data of that subject (regardless of 0 or 1) will be updated as 1.
% Input
%   
%   sbjDataFile --- analysis_sbjData excel file. (before, called sbj_info_file.
%   allSbjDataFile --- analysis_allSbjData excel file. this is the file to be update.
%   path_of_allSbjDataFile.  
% Todo
%
% Note:
%   sbj and Datas must be the same in sbjDataFile, allSbjDataFile. !!! 
% Update history
%   2022-06-13
%       initial version.
%           based on eleven_xlsread, and the framework of eleven_GLAutojob_command. 
%           instead of using eleven_xlsread.m, use matlab xlsread and write directly, i.e., work on cell directly.

% get current posision
currentDir=pwd;

%--- load 
[~, ~, raw_sbjDataFile] = xlsread(sbjDataFile);
[~, ~, raw_allSbjDataFile] = xlsread(allSbjDataFile);

[m,n] = size(raw_allSbjDataFile);

% main
for ii = 2:m % i.e., not update header
    if raw_sbjDataFile{ii,2} == 1 % i.e., if is_analysis ==1
        for jj = 3:n % i.e., only update Datas. not update 'sbj', 'is analysis'.
            if raw_sbjDataFile{ii,jj} == 1
                raw_allSbjDataFile(ii,jj) = {1};
            end
        end
    end
end

% write
xlswrite([path_of_allSbjDataFile '\' allSbjDataFile], raw_allSbjDataFile);

% back to current position
cd(currentDir);
