function ShortRestingTime_index = eleven_GLAutojob_routine_eegCheckShortRestingTime(dir_root_file,dir_tree_file,which_dir_tree,sbj_info_file,standard_resting_time)
%
%Note
%   which_dir_tree, the index of resting in dir_tree. optimize later.
% Update history
%   2024-01-05 add standard_resting_time
%   2022-08-09 ShortRestingTime_index -> explicit output; then in andy ganhuola, save to 11job. 
%       Note, do this before andy3, otherwise andy 3 cannot run due to different data structure size. 
%   2022-07-18 modified from eleven_GLAutojob_routine_eegSetInitParam.m

%--- load dir_root
dir_root = importdata(dir_root_file);
% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

ShortRestingTime_index = zeros(length(sbj),1);
for ii = 1:length(sbj) % loop of sbj
    current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{which_dir_tree} '\run2'];
    if exist(current_analysis_path,'dir')
        cd(current_analysis_path);
        if exist('short_resting_time.mat')
            ShortRestingTime_index(ii) = 1;
        end
        load resting_time
        if resting_time~=standard_resting_time
            ShortRestingTime_index(ii) = 1;
        end
    end
end

cd([dir_root{1} '\allsbj']);
% save ShortRestingTime_index ShortRestingTime_index
