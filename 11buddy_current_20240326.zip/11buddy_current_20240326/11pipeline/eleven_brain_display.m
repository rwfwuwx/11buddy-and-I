

%--- display contacts, and chs

% e.g., B1-B15
B_contact = ...
[
-20	-12	-28
-23	-12	-27
-27	-11	-26
-30	-11	-25
-34	-11	-25
-37	-11	-24
-41	-10	-23
-44	-10	-22
-47	-10	-21
-51	-9	-20
-54	-9	-19
-58	-9	-19
-61	-9	-18
-65	-8	-17
-68	-8	-16
];

figure;
% to do:
% plot the outline of the brain, or a region
% check if there is existing one
% or make masks from a template, and calculate the outline

% plot the electrode as a line, in green
plot3(B_contact([1,end],1),B_contact([1,end],2),B_contact([1,end],3),'g','LineWidth',3);
hold

% plot the contacts as points, in red
plot3(B_contact(:,1),B_contact(:,2),B_contact(:,3),'r.','MarkerSize',25);

% range of mni coordinates (modify later)
axis([-80 80 -80 80 -80 80]);
xlabel('x coordinate'); ylabel('y coordinate'); zlabel('z coordinate');

