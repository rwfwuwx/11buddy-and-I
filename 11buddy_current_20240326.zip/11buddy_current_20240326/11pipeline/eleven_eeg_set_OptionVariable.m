function eleven_eeg_set_OptionVariable
% eleven_eeg_set_OptionVariable
% Usage
%   eleven_eeg_set_OptionVariable
% external varialbe (add later)
%  -- output
%
% todo
%   # about step switch. later, may, consider to make the switch setting as txt file.
% Update history
%   2023-10-23
%       move 'short_resting_data_init_time = 30;'from eleven_eeg_get_expTime.m 
%           -> eleven_eeg_OptionVariable.mat
%   2023-05-23 
%       updates incorporating seeg.
%           !!! begin from seeg; now, finally back to it and done eeg(seeg and scalp eeg)
%                eleven_eeg_set_OptionVariable_er_seeg.m & eleven_eeg_set_OptionVariable_sr_eeg.m
%                are not no need any more.
%       other minor optimization
%   2022-06-21
%       change theta,alpha,beta band [4 7;8 14;15 30] -> [4 6;7 13;14 30].
%   2022-03-01
%       mark setting of source_level_analysis. 
%           currently not using it as a global variable. (if needs increase, handle later)
%           instead, handle it in local functions, includes:
%               eleven_eeg_resting_connect
%               eleven_eeg_resting_ConnectIndexTS
%               eleven_eeg_resultImage
%   2022-01-23
%       --- freq updates
%       add resting_FreqNorm_method
%       add ssep_FreqNorm_method
%       ssep_FreqNorm_points 
%       	10->20 for 3
%       	3 for 43
%       --- correction: erp_high_cutoff = 0.5 only for 42
%   2022-01-18 
%       change is_ertf = 1 if ~isempty(find(eeg_analyze_type == [2 42])). !!! prohibit such causal manipulation.
%   2022-01-16
%       add pp_high_cutoff = 0.1 if eeg_analyze_type = 4.
%       add erp_high_cutoff = 0.5;
%   2021-12-20 start ssep: 
%       epoch
%       spec
%   2021-12-20 resting_am_type, 'amplitude'->'db'
%   2021-12-16 update load cond_IOI after changing eeg_analyze_type
%   2021-12-15 switch off steps untill reref.separate them out.
%   2021-12-11
%       set sttings only when switch is on.
%           this also avoid setting in consistency between switches.
%       set step switch untill pp to 0.
%           i.e., seprate run of pre-analysis outside.
%       unmark is_import
%       add loading eeg_analyze_type related param
%   2021-12-09
%       !!! sr: 4 preprocessing -> after preprocessing
%               sr_er 42
%               sr_ssep 43
%       type list is now :
%           1 resting; 2 er; 3 ssep; 4 sr
%               after preprocessing, 4-> 42 and 43
%           common preprocessing; then separate later analysis, by GLAutojob
%       !incorperate scalp eeg, and seeg. later add seeg detials.
%       !!! incorperate all (resting, er, ssep, sr) into one
%           load eeg_analyze_type at beginning; clear before saving, for later in run2 sr -> er and ssep
%       add rawdata_padding_time
%       set ersd_freq_band_name,ersd_freq_band according to fs
%       set pp_AC_cutoff according to fs
%       default is_pp_low_pass=1 for egi 128
%       separate import_file_type and fs out
%       change default fs to 500
%       correct import_file_type==2 -> import_file_type==211 || import_file_type==212
%   2021-05-19 unmark seeg afr
%   2020-11-30  mark seeg afr.
%	2020-011-03 modify from eleven_eeg_set_OptionVariable_er_seeg.m & eleven_eeg_set_OptionVariable_sr_eeg.m

clear;

% these two param as individual variables, not saving into the combined variable.
%   (for the combined variable, 'structure' is a typical option; while avoid as far as possible)
load eeg_type;
load eeg_analyze_type;

% |-------------------------|
% |----- common variable----|
% |-------------------------|

% sample rate. for most processing steps.
load fs; 

rawdata_padding_time = 5; % before and after 5 s

% |-------------------------|
% |--------- import --------|
% |-------------------------|
is_import = 0;

is_import_resample = 1;
load import_file_type;

if eeg_analyze_type == 1
    load resting_time;
    short_resting_data_init_time = 10;
end
if eeg_analyze_type == 3 || eeg_analyze_type == 43
    load cond_sequence_length;
end
if ~isempty(find(eeg_analyze_type == [4 42 43]))
    load cond_IOI;
end

if eeg_type == 2
    load sbjData_belong_to_which_ieegRawData_day;
    load exp_time;
    load ch_index_target; load ch_index_trigger;
    load reref_ch;
end



% |-------------------------|
% |----- preprocessing -----|
% |-------------------------|
is_pp = 0;% 1 for run1; 0 for run2 

% default 0.5 Hz.for large drift noise, can be even higher than 1.
pp_high_cutoff = 0.5; 
if eeg_analyze_type == 4
    pp_high_cutoff = 0.1; 
end

% optionally add low pass, particulary for removing residual AC noise, when fs is below 500
is_pp_low_pass = 0;
if eeg_type == 1
    if import_file_type==211 || import_file_type==212
        is_pp_low_pass = 1;
    end
end
pp_low_cutoff = 45;

% removing 50 Hz AC and harmonies
if fs >= 500
    pp_AC_cutoff = [49 51;99 101;149 151;199 201];
end
if fs == 250
    pp_AC_cutoff = [49 51;99 101];
end
if fs == 200
    pp_AC_cutoff = [49 51;98 99];
end
if fs == 100
    pp_AC_cutoff = [48 49];
end

if is_pp_low_pass==1 && fs>100
    pp_AC_cutoff = [49 51]; 
end


% |-------------------------|
% |--------- reref ---------|
% |-------------------------|
% reref
% 0 for run1; 
% 1 
%   for run2
%       scalp eeg: 
%           egi
%   for run3
%       scalp eeg
%           biosemi
%       seeg
is_reref = 0;  

if eeg_type == 1
    if import_file_type==1
        reref_ch = 1:64;
    end
    
    if import_file_type==211 || import_file_type==212
        reref_ch = 1:128;
    end
end

% |-------------------------|
% |---------- epoch --------|
% |-------------------------|
if eeg_analyze_type == 1
    is_epoch = 0;
end

if ~isempty(find(eeg_analyze_type == [2 3 42 43]))
    is_epoch = 1;
    
    if eeg_analyze_type == 2
        % for epoch: epoch length
        % these information are also used later, when related time info is needed
        % 1. actual epoch range -100~600 ms. This is a typical setting. modify this as exp needs.
        % 2. add 400 ms, i.e., padding time, on left and right ends to avoid boundry noise.
        % toatal length (400+100)+1+(600+400) ms. Given fs=1000, 1501 sample points.
        % 3. baseline refers to -100~0 ms
        actual_epoch_points_before_onest = 0.1*fs; % -100~-1 ms
        actual_epoch_points_after_onest = 0.6*fs;  % 1~600 ms
        padding_points = 0.4*fs; % 400 ms
        epoch_points_before_onest = actual_epoch_points_before_onest+padding_points; % -500~-1 ms
        epoch_points_after_onest = actual_epoch_points_after_onest+padding_points;  % 1~1000 ms
        actual_epoch_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+1+actual_epoch_points_after_onest]; % i.e., -100~600 ms
        baseline_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+1];
    end
    
    if eeg_analyze_type == 3 || eeg_analyze_type == 43
        % for epoch: epoch length
        % these information are also used later, when related time info is needed
        % 1. actual epoch range 0~cond_sequence_length ms. 
        % 2. add 400 ms, i.e., padding time, on left and right ends to avoid boundry noise.
        % 
        actual_epoch_points_before_onest = 0.4*fs; % -400~-1 ms. Note, this corresponding to padding_points before
        actual_epoch_points_after_onest = cond_sequence_length*fs;  % cond_sequence_length
        ssep_padding_points = 0.4*fs; % 400 ms. Note, only add this after
        epoch_points_before_onest = actual_epoch_points_before_onest; % 
        epoch_points_after_onest = actual_epoch_points_after_onest+ssep_padding_points;  
    end
    
    if eeg_analyze_type == 42
        % for epoch: epoch length
        % 1. actual epoch range IOI*3: 1 pre IOI + current IOI + 1 after IOI. The trigger is at 0 of the current IOI
        % 2. add 400 ms, i.e., padding time, on left and right ends to avoid boundry noise.
        % toatal length  400+IOI+IOI*2+400 ms.(note, relative to er, there is no an additional 0 point).
        % 3. baseline refers to -100~0 of current IOI. Or, can use the actual epoch range in such cases.
        % (also see eleven_eeg_set_OptionVariable_er_seeg)
        actual_epoch_points_before_onest = cond_IOI*fs; % 1 pre IOI
        actual_epoch_points_after_onest = cond_IOI*2*fs;  % current and 1 after IOI
        padding_points = 0.4*fs; % 400 ms
        epoch_points_before_onest = actual_epoch_points_before_onest+padding_points; %-400+IOI ~ -1 ms
        epoch_points_after_onest = actual_epoch_points_after_onest+padding_points-1;  % 0~IOI*2+400 ms
        % note, for the +0 point in epoching, minus 1 in here. may modify mf_epoch later.
        actual_epoch_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+actual_epoch_points_after_onest+1]; % add 1 back
        %baseline_range = [padding_points+1:padding_points+actual_epoch_points_before_onest];
        baseline_range = actual_epoch_range; % if use whole epoch for baseline
    end
end
% --- for afr
is_afr = 0;
% - for scalp eeg
% after ica, there is no need to perform afr for seeg.
%{
is_afr = 0; % whether to perform afr
afr_epoch_range = actual_epoch_range;
afr_criterion = 50; % this can only be determined arbitarily
afr_ch = []; % fill this with eye movement ch, depending on eeg equipment and setting.
afr_is_pp = 1;
%}

% - for seeg
% There is no need to perform afr for seeg.
%{
is_afr = 0; % whether to perform afr
afr_epoch_range = [padding_points+1:padding_points+actual_epoch_points_before_onest+1+actual_epoch_points_after_onest+1]; % i.e., the actual epoch_range
afr_criterion = 350; % this can only be determined arbitarily
afr_ch = []; % for seeg. use all ch.
afr_is_pp = 1;
%}

% |-------------------------|
% |----------  erp  --------|
% |-------------------------|
if ~isempty(find(eeg_analyze_type == [1 3 43]))
    is_erp = 0;
end

if ~isempty(find(eeg_analyze_type == [2 42]))
    is_erp = 1;

    % for filter
    if eeg_analyze_type == 42
        erp_high_cutoff = 0.5; % This would be supplementary to the high-pass filter on raw data, when having large drift.Can unmark and set this to 1 or 1.5.
    end
    erp_low_cutoff = 25; % instead of typical 30, 25 is better. can even set to 15 for large high-frequency noise
    
    % for remove baseline
    erp_baseline_range = baseline_range;
    
    % 0 for scalp eeg.1 for seeg;
    if eeg_type == 1
        is_output_epo_before_erp = 0;
    end
    if eeg_type == 2
        is_output_epo_before_erp = 1;
    end
end

% |-------------------------|
% |----------  ersd  -------|
% |-------------------------|
is_ersd = 0; % no need to perform. set later if need.
%{
% define frequency bands, for filter
if fs >= 500
    ersd_freq_band_name = {'theta','alpha','beta','lowGamma','highGamma','extrahighGamma'};
    ersd_freq_band = [4 6;7 13;14 30;31 47;53 97;103 247];
end
if fs == 250 || fs == 200
    ersd_freq_band_name = {'theta','alpha','beta','lowGamma','highGamma'};
    ersd_freq_band = [4 6;7 13;14 30;31 47;53 97];
end
if fs == 100
    ersd_freq_band_name = {'theta','alpha','beta','lowGamma'};
    ersd_freq_band = [4 6;7 13;14 30;31 47];
end

if is_pp_low_pass==1 
    ersd_freq_band_name = {'theta','alpha','beta','lowGamma'};
    ersd_freq_band = [4 6;7 13;14 30;31 44];
end

% for normalization
ersd_baseline_range = baseline_range;
ersd_normalize_method = 3; % percent change

% 0 for scalp eeg.1 for seeg; 
    if eeg_type == 1
        is_output_epo_before_ersd = 0;
    end
    if eeg_type == 2
        is_output_epo_before_ersd = 1;
    end
%}

% |-------------------------|
% |----------  tf  ---------|
% |-------------------------|
if ~isempty(find(eeg_analyze_type == [1 3 43]))
    is_ertf = 0;
end

if ~isempty(find(eeg_analyze_type == [2 42]))
    is_ertf = 1;

    % for tf calculation
    % tf_frequency_range = [1:247]; % for seeg result including extra high gamma
    % tf_frequency_range = [1:97]; %for including high gamma
    %tf_frequency_range = [1:47]; %for typical frequency range
    %tf_frequency_range = [1:5]; % for quick test
    
    tf_frequency_range = [1:47];
    %{
    if eeg_type == 1
        tf_frequency_range = [1:47];
    end
    if eeg_type == 2
        tf_frequency_range = [1:97];
    end
    %}
    
    % for normalization
    tf_baseline_range = baseline_range;
    tf_normalize_method = 3; % percent change
    tf_names = {'tfboth','tfpl','tfnplone','tfnpltwo','tfplf'};
    
    % for whether calculate tfnpltwo
    is_tfnpltwo = 1;
    
    % for whether perform normalization on single trial
    is_tf_norm =1;
end

%      |--------------------------------------------------|
%      |------------------- ssep Part   ------------------|
%      |--------------------------------------------------|
if ~isempty(find(eeg_analyze_type == [1 2 42]))
    is_ssep = 0;
end
if ~isempty(find(eeg_analyze_type == [3 43]))
    is_ssep = 1;
    
    % |---------------------------------|
    % |-------- ssep_FreqSpec  ------|
    % |---------------------------------|
    %is_ssep_FreqSpec = 1;
    %ssep_am_type = 'amplitude';
    ssep_am_type = 'amplitude';
    ssep_phase_type = 'degree';
    % size of FreqNorm
    %   require further testing
    %   10 for 3; 3 for 43 
    if eeg_analyze_type == 3
        ssep_FreqNorm_points = 8;
        ssep_FreqNorm_method = 2; % 1 devide (i.e., SNR)
    end
    if eeg_analyze_type == 43
        ssep_FreqNorm_points = 3;
        ssep_FreqNorm_method = 1; % 1 subtraction
    end
    
end

% add later

%      |--------------------------------------------------|
%      |----------------- resting Part   -----------------|
%      |--------------------------------------------------|

if ~isempty(find(eeg_analyze_type == [2 3 42 43]))
    is_resting_analysis = 0;
end

if eeg_analyze_type == 1;
    is_resting_analysis = 1;
    
    % define frequency bands, for both time and freq domain
    if fs >= 500
        resting_freq_band_name = {'theta','alpha','beta','lowGamma','highGamma','extrahighGamma'};
        resting_freq_band = [4 6;7 13;14 30;31 47;53 97;103 247];
    end
    if fs == 250 || fs == 200
        resting_freq_band_name = {'theta','alpha','beta','lowGamma','highGamma'};
        resting_freq_band = [4 6;7 13;14 30;31 47;53 97];
    end
    if fs == 100
        resting_freq_band_name = {'theta','alpha','beta','lowGamma'};
        resting_freq_band = [4 6;7 13;14 30;31 47];
    end
    
    if is_pp_low_pass==1
        resting_freq_band_name = {'theta','alpha','beta','lowGamma'};
        resting_freq_band = [4 6;7 13;14 30;31 44];
    end
    
    % |---------------------------------|
    % |---------  resting_AMEnv  -------|
    % |---------------------------------|
    %is_resting_AMEnv = 1;
    
    
    % |---------------------------------|
    % |-------- resting_FreqSpec  ------|
    % |---------------------------------|
    %is_resting_FreqSpec = 1;
    %resting_am_type = 'amplitude';
    resting_am_type = 'amplitude';
    resting_phase_type = 'degree';
    % size of FreqNorm
    %   require further testing
    %   for 5 min, 100 Hz resampling, currently use 50
    resting_FreqNorm_points = 25;
    resting_FreqNorm_method = 3; % smoothing
    resting_padding_points = rawdata_padding_time*fs;
    
    % |---------------------------------|
    % |---------  resting_connect  -------|
    % |---------------------------------|
    %is_resting_connect = 1;
    resting_connect_type = 1;
    
    if import_file_type==1
        resting_ch_include = 1:64;
    end
    
    if import_file_type==211 || import_file_type==212
        resting_ch_include = 1:128;
    end
    
    %{
    source_level_analysis = 0; % change this when enter into source analysis
    % if flexible brain regions are need, run eleven_eeg_resting connect separately.
    if source_level_analysis == 1
        resting_ch_include = []; % default all sources
    end
    %}
    
    % |---------------------------------|
    % |---------  resting_ConnectIndexTS  -------|
    % |---------------------------------|
    %is_resting_ConnectIndexTS = 1;
    resting_connect_index = 1;
    % time window require further testing
    %   currently use 100 ms
    resting_moving_window = 0.1*fs;
    resting_moving_step = 1;
    
end

% --- save
clear eeg_type;
clear eeg_analyze_type;
save eleven_eeg_OptionVariable;

clear;
