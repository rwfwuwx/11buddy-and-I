function eleven_GLAutojob_routine_eegDataAnaDirPrepare(dir_root_file,dir_tree_file,sbj_info_file)
% Input
%
% Todo
%
% Note
%
% Update historyda
%   2023-05-24
%       updates incorporating seeg
%       other minor optimization
%   2022-01-23
%       add copyfile eleven_eeg_OptionVariable_eegSource_customize.mat
%   2022-01-16
%       add copyfile 'source_atlas.mat'to 'srssep\' and 'srer\'.
%   2021-12-24
%       move eleven_eeg_set_OptionVariable_customize.m from
%           eleven_GLAutojob_routine_eegDataAnaDirPrepare.m to
%           andy_autojob_dataAnalysis.m
%   2021-12-22
%       fix a bug not copying file for run3\atlasNames for eeg_analyze_type == [1 2 3 42]
%   2021-12-20
%       copy only required file
%       no deleting file
%   2021-12-17
%       for run3/atlasName, add copying file from run3
%       currently, not delete file
%   2021-12-15 initial version as a new routine

%--- load dir_root
dir_root = importdata(dir_root_file);
% make sure 'allsbj' exist, and enter to it
cd(dir_root{1});
if ~exist([dir_root{1} '\allsbj'],'dir')
    mkdir('allsbj');
end
cd([dir_root{1} '\allsbj']);

%--- load dir_tree
dir_tree = importdata(dir_tree_file);

data_num = length(dir_tree);

%--- load sbj info file related
sbj_info_var_name = eleven_xlsread(sbj_info_file);
% load implict variable
for ii=1:length(sbj_info_var_name)
    tmp_var_name = sbj_info_var_name{ii};
    eval(sprintf('load %s;',tmp_var_name));
end

for ii = 1:length(sbj) % loop of sbj
    % whether analyze this sbj
    tmp_var_name = sbj_info_var_name{2};
    eval(sprintf('tmp_is_analysis_sbj = %s(ii);',tmp_var_name));
    if tmp_is_analysis_sbj == 1
        for jj = 1:data_num % loop of dir_tree\cond
            % whether analyze this cond,of this sbj
            tmp_var_name = sbj_info_var_name{jj+2};
            eval(sprintf('tmp_is_analysis_cond = %s(ii);',tmp_var_name));
            if tmp_is_analysis_cond == 1
                current_analysis_path = [dir_root{1} '\' sbj{ii} '\' dir_tree{jj}];
                if exist(current_analysis_path,'dir')
                    cd(current_analysis_path);
                    
                    % |--- do the job here ---|
                    
                    %--- routine ---
                    
                    cd run2;
                    load eeg_analyze_type;
                    tmp_eeg_analyze_type = eeg_analyze_type;
                    clear eeg_analyze_type;
                    
                    load eeg_type;
                    cd ../;
                    
                    %--- set the dataAnaDir cell for: resting, er, ssep ---
                    
                    % get atlasNames
                    if eeg_type == 1
                        cd run3;
                        load eleven_eeg_OptionVariable_eegSource_customize;
                        cd ../;
                    end
                    
                    % dataAnaDir
                    % for scalp eeg, includes run2 & run3\atlasNames
                    if eeg_type == 1
                        dataAnaDir = cell(1+length(atlasNames),1);
                    end
                    % for seeg, includes only run2 and run3
                    if eeg_type == 2
                        dataAnaDir = cell(2,1);
                    end
                    
                    dataAnaDir{1} = 'run2';
                    
                    if eeg_type == 1
                        for kk=1:length(atlasNames)
                            dataAnaDir{1+kk} = ['run3' '\' atlasNames{kk}];
                        end
                    end
                    if eeg_type == 2
                        dataAnaDir{2} = 'run3';
                    end
                    
                    if ~isempty(find(tmp_eeg_analyze_type == [1 2 3 42]))
                        % save dataAnaDir
                        save dataAnaDir dataAnaDir;
                        
                        % copy file for run3\atlasNames
                        if eeg_type == 1
                            for kk=1:length(dataAnaDir)
                                tmp_dir = [current_analysis_path '\' dataAnaDir{kk}];
                                cd(tmp_dir);
                                
                                if kk>1 % run3
                                    copyfile('../eeg_ecd_raw.mat');
                                    
                                    copyfile('../eeg_type.mat');
                                    copyfile('../eeg_analyze_type.mat');
                                    copyfile('../import_file_type.mat');
                                    copyfile('../fs.mat');
                                    if tmp_eeg_analyze_type == 42
                                        copyfile('../cond_IOI.mat');
                                    end
                                    if tmp_eeg_analyze_type == 1
                                        copyfile('../resting_time.mat');
                                    end
                                    copyfile('../by_trigger_manner.mat');
                                    
                                    copyfile('../eleven_eeg_OptionVariable_customize.mat');
                                    
                                    copyfile('../eleven_eeg_OptionVariable_eegSource_customize.mat');
                                end
                                
                                cd(current_analysis_path);
                            end
                        end
                        
                    end
                    
                    %--- set the dataAnaDir cell for: sr ---
                    if tmp_eeg_analyze_type == 4
                        tmp_dataAnaDir = dataAnaDir;
                        clear dataAnaDir;
                        
                        % |sr -> srer & srssep: make dir & copy file|
                        for kk=1:length(tmp_dataAnaDir)
                            tmp_dir = [current_analysis_path '\' tmp_dataAnaDir{kk}];
                            cd(tmp_dir);
                            
                            %sr -> srer
                            % make dir
                            if ~exist([tmp_dir '\srer'],'dir')
                                mkdir('srer');
                            end
                            %
                            % copy file
                            copyfile('eeg_raw_pp.mat','srer\');
                            if kk==1 % run2
                                copyfile('eeg_ecd_raw.mat','srer\');
                                
                                copyfile('eeg_type.mat','srer\');
                                copyfile('eeg_analyze_type.mat','srer\');
                                copyfile('import_file_type.mat','srer\');
                                copyfile('fs.mat','srer\');
                                copyfile('cond_IOI.mat','srer\');
                                copyfile('by_trigger_manner.mat','srer\');
                                
                                copyfile('eleven_eeg_OptionVariable_customize.mat','srer\');
                            end
                            if kk>1 % run3
                                if eeg_type == 1
                                    copyfile('../eeg_ecd_raw.mat','srer\');
                                    
                                    copyfile('../eeg_type.mat','srer\');
                                    copyfile('../eeg_analyze_type.mat','srer\');
                                    copyfile('../import_file_type.mat','srer\');
                                    copyfile('../fs.mat','srer\');
                                    copyfile('../cond_IOI.mat','srer\');
                                    copyfile('../by_trigger_manner.mat','srer\');
                                    
                                    copyfile('../eleven_eeg_OptionVariable_customize.mat','srer\');
                                    
                                    copyfile('source_atlas.mat','srer\');
                                    copyfile('../eleven_eeg_OptionVariable_eegSource_customize.mat','srer\');
                                end
                                if eeg_type == 2
                                    copyfile('eeg_ecd_raw.mat','srer\');
                                    
                                    copyfile('eeg_type.mat','srer\');
                                    copyfile('eeg_analyze_type.mat','srer\');
                                    copyfile('import_file_type.mat','srer\');
                                    copyfile('fs.mat','srer\');
                                    copyfile('cond_IOI.mat','srer\');
                                    copyfile('by_trigger_manner.mat','srer\');
                                    
                                    copyfile('eleven_eeg_OptionVariable_customize.mat','srer\');
                                end
                            end
                            % change eeg_analyze_type
                            cd srer;
                            eeg_analyze_type = 42;
                            save eeg_analyze_type eeg_analyze_type;
                            % re-set option after changing eeg_analyze_type
                            %eleven_eeg_set_OptionVariable_customize;
                            cd ../;
                            
                            %sr -> srssep
                            % make dir
                            if ~exist([tmp_dir '\srssep'],'dir')
                                mkdir('srssep');
                            end
                            %
                            % copy file
                            copyfile('eeg_raw_pp.mat','srssep\');
                            if kk==1 % run2
                                copyfile('eeg_ecd_raw.mat','srssep\');
                                
                                copyfile('eeg_type.mat','srssep\');
                                copyfile('eeg_analyze_type.mat','srssep\');
                                copyfile('import_file_type.mat','srssep\');
                                copyfile('fs.mat','srssep\');
                                copyfile('cond_IOI.mat','srssep\');
                                copyfile('by_trigger_manner.mat','srssep\');
                                
                                copyfile('eleven_eeg_OptionVariable_customize.mat','srssep\');
                                
                            end
                            if kk>1 % run3
                                if eeg_type == 1
                                    copyfile('../eeg_ecd_raw.mat','srssep\');
                                    
                                    copyfile('../eeg_type.mat','srssep\');
                                    copyfile('../eeg_analyze_type.mat','srssep\');
                                    copyfile('../import_file_type.mat','srssep\');
                                    copyfile('../fs.mat','srssep\');
                                    copyfile('../cond_IOI.mat','srssep\');
                                    copyfile('../by_trigger_manner.mat','srssep\');
                                    
                                    copyfile('../eleven_eeg_OptionVariable_customize.mat','srssep\');
                                    
                                    copyfile('source_atlas.mat','srssep\');
                                    copyfile('../eleven_eeg_OptionVariable_eegSource_customize.mat','srssep\');
                                end
                                if eeg_type == 2
                                    copyfile('eeg_ecd_raw.mat','srssep\');
                                    
                                    copyfile('eeg_type.mat','srssep\');
                                    copyfile('eeg_analyze_type.mat','srssep\');
                                    copyfile('import_file_type.mat','srssep\');
                                    copyfile('fs.mat','srssep\');
                                    copyfile('cond_IOI.mat','srssep\');
                                    copyfile('by_trigger_manner.mat','srssep\');
                                    
                                    copyfile('eleven_eeg_OptionVariable_customize.mat','srssep\');
                                end
                            end
                            % change eeg_analyze_type
                            cd srssep;
                            eeg_analyze_type = 43;
                            save eeg_analyze_type eeg_analyze_type;
                            % re-set option after changing eeg_analyze_type
                            %                                 eleven_eeg_set_OptionVariable_customize;
                            cd ../;
                            
                            cd(current_analysis_path);
                        end
                        
                        % |set the dataAnaDir cell|
                        dataAnaDir = cell(length(tmp_dataAnaDir)*2,1);
                        for kk=1:length(tmp_dataAnaDir)
                            dataAnaDir{(kk-1)*2+1} = [tmp_dataAnaDir{kk} '\' 'srer'];
                            dataAnaDir{(kk-1)*2+2} = [tmp_dataAnaDir{kk} '\' 'srssep'];
                        end
                        
                        % save
                        save dataAnaDir dataAnaDir;
                        
                    end
                    
                    
                    % |--- end job ---|
                    
                end
            end
        end
    end
end

cd([dir_root{1} '\allsbj']);
