function eleven_CNAutojob_eeg_stand_dataAna(studyName,sbj_info_file,eleven_job_path)
%       
% Update history
%   2023-04-17 
%       update eleven_GLAutojob_command call.
%       add eleven_job_path as func input,for error record file location.
%   2022-06-17 unmask the final msgbox.
%   2022-02-28 add ruunning logo
%   2022-01-16 script-> final func
%           nickname andy_ganhuola_2:  load andy_ganhuola_2; andy_ganhuola_2(studyName,sbj_info_file)  
%               (by andy_ganhuola_2 = @eleven_CNAutojob_eeg_stand_dataAna; save andy_ganhuola_2 andy_ganhuola_2;)
%   20221-12-20 done
%   2021-12-15 separate from part 1 and begin part 2 here.

myicon = imread('andy.jpg');
h=msgbox('������Ϊ������(��ǰִ�������)���������ĵȴ�',' ','custom',myicon);

analysis_rootDir_eeg_file = ['analysis_rootDir_eeg_' studyName '.txt'];
analysis_dirTree_eeg_file = ['analysis_dirTree_eeg_' studyName '.txt'];
%dataList_eeg_file = ['dataList_eeg_' studyName '.txt'];
trigger_tobe_list_file = ['trigger_tobe_list_' studyName '.txt'];
condNameList_eeg_file = ['condNameList_eeg_' studyName '.txt'];
expVariable_list_file = ['expVariable_list_' studyName '.txt'];



% |--------------------------------------------------------------------|
% |################# Part 2: data analysis (dataAna) ##################|
% |--------------------------------------------------------------------|

% |---------------------------------------------------------|
% |------------- prepare dataAna dir structure--------------|
% |---------------------------------------------------------|
% This step includes 
%   # prepare dataAnaDir 
%       # for sr(4) -> srer(42) & srssep(43)
%           make dir 
%           copy file
%           change eeg_analyze_type; and re-set option accordingly

%
eleven_GLAutojob_routine_eegDataAnaDirPrepare( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    sbj_info_file);
%}


% |---------------------------------------------------------|
% |------------------- prepare exp param--------------------|
% |---------------------------------------------------------|
% first prepare
%   --- trigger_tobe
%       # trigger_tobe mat file(s): by
%           eleven_eeg_produce_trigTobe_tpl_ST_202108_AEP_irregular.m
%       # trigger_tobe_list file
%   --- con_name
%       condName_list file
%   --- expVariable
%       # expVariable mat file(s): by
%           eleven_eeg_produce_expVariable_tpl_ST_202108_AEP_regular.m

%
eleven_GLAutojob_routine_eegExpParamPrepare( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    sbj_info_file, ...
    trigger_tobe_list_file, ...
    condNameList_eeg_file, ...
    expVariable_list_file);
%}


% |---------------------------------------------------------|
% |------------------- eeg "data analysis" -----------------|
% |---------------------------------------------------------|
%
eleven_GLAutojob_command( ...
    analysis_rootDir_eeg_file, ...
    analysis_dirTree_eeg_file, ...
    sbj_info_file, ...
    eleven_job_path, ...
    'andy_autojob_dataAnalysis');
%}

disp('~-~ andy ganhuola 2: all jobs are done ~-~ )');

% close(h)
msgbox('���Ѿ��������2��','Success','custom',myicon);
