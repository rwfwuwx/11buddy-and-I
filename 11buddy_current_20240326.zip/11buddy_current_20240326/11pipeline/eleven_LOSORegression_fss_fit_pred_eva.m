function eleven_LOSORegression_fss_fit_pred_eva(feature_data,y_observe,is_fss,fss_threshold,usePosNeg)
% eleven_LOSORegression_fss_fit_pred_eva(feature_data,y_observe,is_fss,fss_threshold,usePosNeg)
%   fss -- feature selection and summarization
% Input
%   feature_data
%       format: sbj*feature
%       for network data, format: node*node*sbj
%   y_observe
%   is_fss --- feature selection and summarization
%       1: yes; 0:no
%   fss_threshold
%       for is_fss==1, set a threshold
%   usePosNeg
%       for is_fss==1, set usePosNeg
%           1: pos and neg; 2 pos; 3 neg
% Update history
%	2021-06-24 first fersion in practical use in ada
%   2021-06-23 
%       original version, modify from the code available in 
%           Shen X, Finn ES, Scheinost D, Rosenberg MD, Chun MM, Papademetris X, Constable RT (2017) Using connectome-based predictive modeling to predict individual behavior from brain connectivity. Nat Protocols 12:506�C518.Copyright 2015 Xilin Shen and Emily Finn 

% ------------ initialization -------------------
% typical feature_data format is sbj*feature
%   if network, the conventional format is node*node*sbj,thus turn into sbj*[node*node]
%       at the end, for output consistent with the convention, trun back into node*node*sbj
if ndims(feature_data) == 3
    feature_data = reshape(feature_data,[],size(feature_data,3))';
end

sbj_num = size(feature_data,1);
feature_data_num =  size(feature_data,2); % for network data, this is edge_num
% if ndims(feature_data) == 3
%     node_num = sqrt(size(feature_data,2));
% end

y_pred = zeros(sbj_num,1);

if is_fss
    y_pred_pos = zeros(sbj_num,1);
    y_pred_neg = zeros(sbj_num,1);
end

%--- LOSO loop
for leftout = 1:sbj_num;
    fprintf('Leaving out subj # %6.3f\n ',leftout);
    
    % leave out subject from matrices and behavior, producing train data
    train_mats = feature_data;
    train_mats(leftout,:) = [];
    
    train_y = y_observe;
    train_y(leftout) = [];
    
    if is_fss
        %--- feature selection: correlation all edges with behavior
        r_mat = zeros(1, feature_data_num);
        p_mat = zeros(1, feature_data_num);
        
        % using Pearson correlation
        [r_mat, p_mat] = corr(train_mats, train_y);
        
        %     % using partial correlation
        %     [r_mat, p_mat] = partialcorr(train_mats, train_y, age);
        
        %     % using rank correlation
        %     [r_mat, p_mat] = corr(train_mats, train_y, 'type', 'Spearman');
        
        %     % using partial rank correlation
        %       [add]
        
        % using robust fit
        %     for edge_i = 1: feature_data_num;
        %         [~, stats] = robustfit(train_mats(edge_i,:), train_y);
        %         cur_t = stats.t(2);
        %         r_mat(edge_i) = sign(cur_t)*sqrt(cur_t^2/(sbj_num-1-2+cur_t^2));
        %         p_mat(edge_i) = 2*(1-tcdf(abs(cur_t), sbj_num-1-2));  %two tailed
        %     end
        %
        
        %--- feature selection: define feature masks
        pos_mask = zeros(feature_data_num, 1);
        neg_mask = zeros(feature_data_num, 1);
        
        % by threshold
        pos_edge = find( r_mat >0 & p_mat < fss_threshold);
        neg_edge = find( r_mat <0 & p_mat < fss_threshold);
        
        pos_mask(pos_edge) = 1;
        neg_mask(neg_edge) = 1;
        
        pos_mask=pos_mask';
        neg_mask=neg_mask';
        
        
        %     % by sigmoidal weighting
        %     pos_edges = find(r_mat > 0 );
        %     neg_edges = find(r_mat < 0 );
        %
        %     % covert p threshold to r threshold
        %     T = tinv(fss_threshold/2, sbj_num-1-2);
        %     R = sqrt(T^2/(sbj_num-1-2+T^2));
        %
        %     % create a weighted mask using sigmoidal function
        %     % weight = 0.5, when correlation = R/3;
        %     % weight = 0.88, when correlation = R;
        %     pos_mask(pos_edges) = sigmf( r_mat(pos_edges), [3/R, R/3]);
        %     neg_mask(neg_edges) = sigmf( r_mat(neg_edges), [-3/R, R/3]);
        %     %
        
        %   --- feature summarization
        % get sum of those edges bypassing feature selection
        %   Note, divide by 2 to control for the fact that matrices are symmetric
        train_sumpos = zeros(sbj_num-1,1);
        train_sumneg = zeros(sbj_num-1,1);
        
        for ss = 1:(sbj_num-1);
            train_sumpos(ss) = sum(train_mats(ss,:).*pos_mask)/2;
            train_sumneg(ss) = sum(train_mats(ss,:).*neg_mask)/2;
        end
    end
    
    %--- model fitting on TRAIN subs
    % 
    if is_fss==0
        x_train_mat = train_mats;
    end
    
    if is_fss==1
        if usePosNeg==1
            x_train_mat = [train_sumpos, train_sumneg];
        end
        if usePosNeg==2
            x_train_mat = [train_sumpos];
        end
        if usePosNeg==3
            x_train_mat = [train_sumneg];
        end
        x_train_mat
    end
    
    %x_train_mat
    b = regress(train_y,[x_train_mat, ones(sbj_num-1,1)]);
    %--- model predict: run model on TEST sub
    test_mat = feature_data(leftout,:);
    b
    if is_fss==0
        x_test_mat = test_mat;
    end
    
    if is_fss==1
        test_sumpos = sum(test_mat.*pos_mask)/2;
        test_sumneg = sum(test_mat.*neg_mask)/2;
        
        if usePosNeg==1
            x_test_mat = [test_sumpos, test_sumneg];
        end
        if usePosNeg==2
            x_test_mat = [test_sumpos];
        end
        if usePosNeg==3
            x_test_mat = [test_sumneg];
        end
    end
    
    y_pred(leftout) = b(1:(end-1))'*x_test_mat'+b(end);
    %y_pred(leftout) = b(1)*test_sumpos + b(2)*test_sumneg + b(3);
end

%--- compare observed and predicted y
[R_value, P_value] = corr(y_observe,y_pred)
figure; plot(y_observe,y_pred,'ko'); lsline
xlabel('observed data');
ylabel('predicted data');
title(['Prediction evaluation. ' 'R: ' num2str(R_value) '; P: ' num2str(P_value)]);



