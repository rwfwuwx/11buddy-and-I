function sbj_var_name = eleven_xlsread(excel_file)
% Input an excel file
% Output
%   explicit output
%       sbj_var_name. headers, in cell format.
%   implicit outpurt
%       for each variable, i.e., column in excel file, generate a variable.
%           header = value.
%       cell for string/char; num for num
%
% Todo
%   due to the 'nan' issue. the func is now limited. see update 2022-06-24.
%       to generalize later.
% Note
%   except for the first sbj, remaining must be numarized.
% Update history
%   2022-06-24
%       issue: for cell_all, nan in excel is read as 'nan'
%       for [Num_noHead,cell_char,c] = xlsread()
%           Num_noHead, remove head, only num column, as a num matrix
%           cell_char, cell, num->'', 
%           cell_all, all as cell
%       update solution
%           use cell_all for sbj
%           use Num_noHead for remaining.
%       merit: handle the 'nan' issue.
%       limit: not general anymore. input exel must be numarized.
%   2020-11-04 modify from the audo-generate script of gui importdata.

% Import the data
% [num_noHead, cell_char, cell_all] = xlsread(excel_file,'Sheet1','A2:B4'); % if specfic sheet ,column are to be assigned
[num_noHead, cell_char, cell_all] = xlsread(excel_file);

%cell_all(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),cell_all)) = {''}; % some checking operation of matlab

[m,n] = size(cell_all);
% first row: header; column is each variable

sbj_var_name = cell_all(1,:);


% generate each variable, by header = value 

%--- for sbj
tmp_var_name = sbj_var_name{1};
eval(sprintf('%s = cell_all(2:m,1);',tmp_var_name));
eval(sprintf('save %s %s;',tmp_var_name,tmp_var_name));

%--- for remainning
for ii=2:n
    tmp_var_name = sbj_var_name{ii};
    eval(sprintf('%s = num_noHead(:,ii-1);',tmp_var_name));
    eval(sprintf('save %s %s;',tmp_var_name,tmp_var_name));
end
