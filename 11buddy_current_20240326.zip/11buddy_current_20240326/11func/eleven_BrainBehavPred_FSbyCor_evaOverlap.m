function [featureMask_CV_percent,pass_feature_num,featureMask_CV_MaskByPercent] = eleven_BrainBehavPred_FSbyCor_evaOverlap(featureMask_CV,percent)
% [featureMask_CV_percent,pass_feature_num] = eleven_BrainBehavPred_FSbyCor_evaOverlap(featureMask_CV,percent)
%   
% Input
%   featureMask_CV: sbj*feature_num, returnded from eleven_BrainBehavPred_FSbyCor_FS
%   percent: e.g., 50. more (encluding equal) than percent of subjects who has this pass the given percent
%
% Output
%   featureMask_CV_percent: 1*feature_num. 
%       note, the percent mask will be a mask of the mask of featureMask.
%   featureMask_CV_MaskByPercent: featureMask_CV masked by featureMask_CV_percent
%
% Update history
%   2021-06-27 initial version

sbj_num = size(featureMask_CV,1);
feature_num = size(featureMask_CV,2);

% get featureMask_CV_percent as well as pass_feature_num
featureMask_CV_percent = zeros(1,feature_num);
hist_percent = sum(featureMask_CV) ./ sbj_num .* 100;
featureMask_CV_percent(find(hist_percent >= percent)) = 1;
pass_feature_num = sum(featureMask_CV_percent);

% get eatureMask_CV_MaskByPercent
featureMask_CV_MaskByPercent = zeros(1,feature_num);
for ii=1:sbj_num
    featureMask_CV_MaskByPercent(ii,:) = featureMask_CV(ii,:) .* featureMask_CV_percent;
end






