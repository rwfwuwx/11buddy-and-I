function [p_corrected,FDR,Q] = eleven_fdr(p)
%
% Note: about the less and more rigous FDR
%   # first , about p, FDR, q.
%       R return p, use directly. (p equals FDR: to be sure).
%       matlab here, no returns of p values. 
%           use FDR = 0.05.
%           for q,wich is less regious, use 0.01, or specifically describe.
%   # the less reigous FDR, Storey (2002)。
%       the defualt in matlab here.
%   # the more rigous FDR, or that replicate R FDR.
%       Benjamini and Hochberg (1995)， set 'BHFDR' false(default)|true to true.
%        return only FDR, which give the same results as in R use FDR.
% Update history
%   2022-08-10 use defulat lambda + use only these origin p <=0.05 & ma <=0.05
%       see detailed implementation
%   2022-08-05 initial version based on previous tests

p_threshold = 0.05;

[FDR,Q] = mafdr(p);

idx_sig_origin = find(p<=p_threshold);
idx_sig_ma = find(FDR<=p_threshold);
idx_nonsig_ma = find(FDR>p_threshold);

idx_sig_origin_and_sig_ma = intersect(idx_sig_origin,idx_sig_ma);
idx_sig_origin_and_nonsig_ma = intersect(idx_sig_origin,idx_nonsig_ma);

p_corrected = p;
p_corrected(idx_sig_origin_and_sig_ma) = FDR(idx_sig_origin_and_sig_ma);
p_corrected(idx_sig_origin_and_nonsig_ma) = FDR(idx_sig_origin_and_nonsig_ma);

