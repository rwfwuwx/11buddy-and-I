function ica_remove_component = eleven_eeg_ica_label
% Input
%
% Output
% ica_remove_component -- removed componet
% todo
%   whether threshold is updated
% Update history
% 2022-02-17
%   iclabel_threshold_biosemi: eye:0.8->0.5, muscel:0.8->0.55
%   iclabel_threshold_egi: eye:0.7->0.5, muscel:0.8->0.55
% 2022-01-07
%   remove editing channel file.
% 2021-12-24
%   fix bug,eeg_raw_pp -> double,same as eleven_eeg_import_data.m
% 2021-11-13
%   incorparate previous eleven_eeg_eeglab2mfeeg_continuousData here
%   refine if procedure
%   separate parameters, later can enter into settings
%   load setting inside to use setting
%   import_import_file_type -> hidden input
%   2021-11-16 initial verson

% load option
load eleven_eeg_OptionVariable_customize;
iclabel_threshold_biosemi = [0 0.01;0.55 1; 0.5 1; 0 0; 0 0; 0.99 1; 0 0];
iclabel_threshold_egi = [0 0.01;0.55 1; 0.5 1; 0 0; 0 0; 0.95 1; 0 0];

EEG = pop_loadset('eeg_raw_pp_rbc_ica.set');
if import_file_type == 1
    EEG = iclabel(EEG);
    EEG = pop_icflag(EEG, iclabel_threshold_biosemi);
end
if import_file_type == 211 || import_file_type == 212
    EEG = iclabel(EEG);
    EEG = pop_icflag(EEG, iclabel_threshold_egi);
end
ica_remove_component = find(EEG.reject.gcompreject == 1);
EEG = pop_subcomp(EEG,ica_remove_component);
EEG = eeg_checkset(EEG);
EEG = pop_saveset(EEG,'eeg_raw_pp_rbc_ica_remove_component.set',pwd);
EEG = pop_saveset(EEG,'eeg_raw_pp_rbc_ica_final.set',pwd);

% incorparate previous eleven_eeg_eeglab2mfeeg_continuousData here
% Note, the mfeeg eeg_raw_pp is overrided here.A backup is eeg_raw_pp_backup_ppNormal.mat.
EEG.data = double(EEG.data);

tmp = EEG.data;
eeg_raw_pp = tmp';
save eeg_raw_pp eeg_raw_pp;


