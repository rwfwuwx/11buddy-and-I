function [behavData_fit_CV] = eleven_BrainBehavPred_FSbyCor_CV(brainData,behavData,pos_featureMask_CV,neg_featureMask_CV,learnMethod,usePosNeg)
% [behavData_fit_CV] = eleven_BrainBehavPred_FSbyCor_CV(brainData,behavData,pos_featureMask_CV,neg_featureMask_CV,learnMethod,usePosNeg)
%   
% Input
%   brainData,behavData,pos_featureMask_CV,neg_featureMask_CV, see eleven_BrainBehavPred_FSbyCor_FS.m
%  learnMethod: see eleven_trainRegression.m
%   usePosNeg
%       for is_fss==1, set usePosNeg
%           1: pos and neg; 2 pos; 3 neg
%
% Output
%   behavData_fit_CV. see eleven_trainRegression.m.
%
% Update history
%   2021-09-26 initial version. further see eleven_BrainBehavPred_FSbyCor_CV.m

sbj_num = size(brainData,1);
feature_num = size(brainData,2);

behavData_fit_CV = zeros(sbj_num,1);

%--- LOSO loop
for leftout = 1:sbj_num
    % fprintf('Leaving out subj # %6.3f\n ',leftout);
    
    % leave out one subject from x and y, producing CV train data
    brainData_CV = brainData;
    brainData_CV(leftout,:) = [];
    
    behavData_CV = behavData;
    behavData_CV(leftout) = [];
    
    % |--- CV model training ---| 
    
    %- feature value summarization
    % get sum values of selected features
    %   Note, divide by 2 to control for the fact that matrices are symmetric
    sum_pos_featureData_CV = zeros(sbj_num-1,1);
    sum_neg_featureData_CV = zeros(sbj_num-1,1);
    
    for ii = 1:(sbj_num-1)
        sum_pos_featureData_CV(ii) = sum(brainData_CV(ii,:).*pos_featureMask_CV(leftout,:))/2;
        sum_neg_featureData_CV(ii) = sum(brainData_CV(ii,:).*neg_featureMask_CV(leftout,:))/2;
    end
    
    % summed feature value -> x in the model
    if usePosNeg==1
        x_CV = [sum_pos_featureData_CV, sum_neg_featureData_CV];
    end
    if usePosNeg==2
        x_CV = [sum_pos_featureData_CV];
    end
    if usePosNeg==3
        x_CV = [sum_neg_featureData_CV];
    end
    
    % perform train 
    [Mdl,~] = eleven_trainRegression(x_CV,behavData_CV,learnMethod,0);


    % |--- CV model predict ---| 
    %   given x of the leftout sbj, use the trained CV model, to predict y of the left out sbj
    
    % brainData of the leftout sbj
    brainData_leftout = brainData(leftout,:);

    %- feature value summarization
    sum_pos_featureData_leftout = sum(brainData_leftout.*pos_featureMask_CV(leftout,:))/2;
    sum_neg_featureData_leftout = sum(brainData_leftout.*neg_featureMask_CV(leftout,:))/2;
    
    if usePosNeg==1
        x_brainData_leftout = [sum_pos_featureData_leftout, sum_neg_featureData_leftout];
    end
    if usePosNeg==2
        x_brainData_leftout = [sum_pos_featureData_leftout];
    end
    if usePosNeg==3
        x_brainData_leftout = [sum_neg_featureData_leftout];
    end
    
    % predict
    behavData_fit_CV(leftout) = predict(Mdl,x_brainData_leftout);
end





