function [stat_val,p,ci]=eleven_comparison(data1,data2,group_type,parametric_type)
% input:
%   data1/data2: same as matlab, except for
%       !!! the handling of two sample vs. one sample:
%           if one sample, set data = [];
%   group_type: 1--within; 2--between 
%   parametric_type: 1--parametric; 2--non parametric
%   for two populations when the observations are paired.
% output
%   stat_val: t value for parametric; z value for non parametric
%   ci: nan for non parametric.
%   others same as matlab. 
%
% todo
%
% Note: about one-sample test against scalar value a,
%   input x-a as data1
%
% Note: the non-parametric func in matlab only operate on vector but not matrix.
%   currently, for non-parametric, eleven_comparison extends to matrix.
%       (extends to dim>3 later if need)
%
% Note: summarize comparison
% [parametric]
% one-sample test 
% 	(against 0)
% 		ttest
% 		[h,p,ci,stats] = ttest(x);
% 		(t=stats.ttstat)
% 	(against scalar value a)
% 		ttest
% 		manner 1:
% 		[h,p,ci,stats] = ttest(x-a);
% 		manner 2:
% 		[h,p,ci,stats] = ttest(x,a);
% 
% two-sample test: within group
% 	ttest
% 	[h,p,ci,stats] = ttest(x,y);
% 	
% two-sample test: between group
% 	test
% 	[h,p,ci,stats] = ttest2(x,y);
% 	
% [non-parametric]
% one-sample test 
% 	(against 0)
% 		Wilcoxon
% 		[p,h,stats] = signrank(x)
% 		(z=stats.zval)
% 	(against scalar value a)
% 		Wilcoxon
% 		manner 1:
% 		[p,h,stats] = signrank(x-a);
% 		manner 2:
% 		[p,h,stats] = signrank(x,a);
% 
% two-sample test: within group
% 	ttest
% 	[p,h,stats] = signrank(x,y);
% 	
% two-sample test: between group
% 	Mann-Whitney U-test
% 	[p,h,stats] = ranksum(x,y);
% 	(z=stats.zval)
%
% update history
%   2022-08-28 handling problems that signrank stats sometimes don't have zval value
%   2022-08-5 incorporate eleven_ttest eleven_ttest2, and update to eleven_comparison
%   2022-07-05 initial version

if isempty(data2)
    if parametric_type == 1
        [~,p,ci,stats]=ttest(data1);
        stat_val = stats.tstat;
    end
    
    if parametric_type == 2
        sz = size(data1);
        
        p = ones(1,sz(2));
        stat_val = zeros(1,sz(2));
        ci = NaN(2,sz(2));
        
        for ii = 1:sz(2)
            [p(ii),~,stats]=signrank(data1(:,ii));
            stat_val(ii) = stats.zval;
        end
    end
    
end

if ~isempty(data2)
    if parametric_type == 1
        if group_type == 1
            [~,p,ci,stats]=ttest(data1,data2);
        end
        if group_type == 2
            [~,p,ci,stats]=ttest2(data1,data2);
        end
        stat_val = stats.tstat;
    end
    
    
    if parametric_type == 2
        sz = size(data1);
        
        p = ones(1,sz(2));
        stat_val = zeros(1,sz(2));
        ci = NaN(2,sz(2));
        
        for ii = 1:sz(2)
            if group_type == 1
                [p(ii),~,stats]=signrank(data1(:,ii),data2(:,ii));
                stat_val(ii) = stats.signedrank;
                %stat_val(ii) = stats.zval;
            end
            if group_type == 2
                [p(ii),~,stats]=ranksum(data1(:,ii),data2(:,ii));
                stat_val(ii) = stats.zval;
            end
        end
        
    end
    
end