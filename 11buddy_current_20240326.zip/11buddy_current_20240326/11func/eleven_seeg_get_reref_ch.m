function reref_ch = eleven_seeg_get_reref_ch(ch_grouping,reref_method)
% reref_ch = eleven_seeg_get_reref_ch(ch_grouping,reref_method)
% Input
%   ch_grouping ---  a column vecotor, e.g., 1 for all contacts in ch1; 2 for all contacts in ch2.
%   reref_method --- 1 for laplacian, i.e., two adjacent contacts. add other methods later, if needed.
%       according to 'Li G, Jiang S, Paraskevopoulou SE, Wang M, Xu Y, Wu Z, Chen L, Zhang D, Schalk G (2018) 
%       Optimal referencing for stereo-electroencephalographic (SEEG) recordings. Neuroimage 183:327�C335'.
% Output
%   reref_ch  ---  ch num x reref_ch num. reref_ch num depends on reref method.
%       each row is a list reref_ch for the ch of the given row.
%       for laplacian, two adjacent ch of a contact. 
%           for contact 1 on a ch, use [contact2 contact2]; for the last contact on a ch, use [contact-1 contact-1]
%
% --- update history
% 2020-05-28 initially written

if nargin~=2
    disp('eleven_seeg_get_reref_ch requires 2 input arguments!')
	return
end

reref_ch = [];

ch_num = max(ch_grouping);

for ii=1:ch_num
    ch_contact_index = find(ch_grouping==ii);
    for jj=1:length(ch_contact_index)
        if jj==1
            if reref_method ==1
                reref_ch = [reref_ch; [ch_contact_index(jj+1) ch_contact_index(jj+1)]];
            end
        elseif jj==length(ch_contact_index)
            if reref_method ==1
                reref_ch = [reref_ch; [ch_contact_index(jj-1) ch_contact_index(jj-1)]];
            end
        else
            if reref_method ==1
                reref_ch = [reref_ch; [ch_contact_index(jj-1) ch_contact_index(jj+1)]];
            end
        end
    end
end