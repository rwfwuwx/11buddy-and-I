function [x_clean,index_outlier] = eleven_rmOutlier_matrix(x,is_while,std_criterion,rm_method)
% Usage
%   x_clean = eleven_rmOutlier_matrix(x,is_while,std_criterion)
%   perform outlier handling on each column of x.
% Input
%   x --- typically sbj*feature(s)
%   is_while --- 0: perform once. 1: untile no outlier. 
%   std_criterion --- 3 should be fine. (2 might be too strict).
%   hendle_method --- 1: set nan 2: interpolate use mean
% Output
%   x_clean --- the clean x
%   index_outlier --- same size as x, with outlier indicated by 1.
% update history
%   2022-06-29 
%       add return outlier index
%       add rm_method
%       add description 
%       mean + 'omitnan'; nanstd, -> std + ,'omitnan' 
%   2021-11-08 add removing outlier untill none
%   2021-11-04 initial version

% std_criterion = 2;

x_clean = x;
index_outlier = zeros(size(x));

for ii=1:size(x,2)
    x_tmp=x(:,ii);
    index_outlier_tmp = index_outlier(:,ii);
    if is_while
        while 1
            % find outlier
            outlier_index_num = find( abs(x_tmp-mean(x_tmp,'omitnan')) >= std(x_tmp,'omitnan')*std_criterion);

            if isempty(outlier_index_num)
                break;
            else
                % set for index_outlier
                index_outlier_tmp(outlier_index_num) = 1;
                
                % set for x_clean
                if rm_method == 1
                    x_tmp(outlier_index_num) = nan;
                end
                if rm_method == 2
                    x_tmp(outlier_index_num) = mean(x_tmp,'omitnan');
                end
            end
        end
    else
        % find outlier
         outlier_index_num = find( abs(x_tmp-mean(x_tmp,'omitnan')) >= std(x_tmp,'omitnan')*std_criterion);
         
         % set for index_outlier
         index_outlier_tmp(outlier_index_num) = 1;
         
         % set for x_clean
         if rm_method == 1
             x_tmp(outlier_index_num) = nan;
         end
         if rm_method == 2
             x_tmp(outlier_index_num) = mean(x_tmp,'omitnan');
         end
    end
         
    x_clean(:,ii) = x_tmp;
    index_outlier(:,ii) = index_outlier_tmp;
end
