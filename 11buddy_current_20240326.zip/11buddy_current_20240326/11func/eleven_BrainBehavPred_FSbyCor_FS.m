function [pos_featureMask_CV,neg_featureMask_CV] = eleven_BrainBehavPred_FSbyCor_FS(brainData,behavData,corMethod,fs_threshold)
% [pos_featureMask_CV,neg_featureMask_CV] = eleven_BrainBehavPred_FSbyCor_FS(brainData,behavData,corMethod,fs_threshold)
%   
% Input
%   brainData: sbj*features (matrix)
%           features can be regions/electrodes, or regions*regions/electrodes*electrodes. 
%   behavData: sbj* feature (column vector)
%   corMethod: 'Pearson', (add later)
%   fs_threshold: feature selection threshold
% 
% Output
%   pos_featureMask_CV,neg_featureMask_CV
%       This actually the model parameter
%
% !!! Clarification of train, CV, and test, for this method (later to describe in detail)
%   1. select feature by CV.
%       overlap can be 100%, ...0. if 0, stop.
%   2. CV
%       use an overlap > 0, while < 100%. Note cannot be, 100%, otherwise will be circular analysis.
%   3. test.
%       use 100% overlap in step 1 for new sbj.
%
% Todo
%   test the matrix operation.
%   quantify overlap
%   outlier handle, such as eleven_trainRegression_2tabular.
%
% Update history
%   2021-09-26
%       %  to avoid all 0 in featureMask, randomly assign one 1. see detail
%       remove data structure handling, leave it to an outer-layer func (add later).
%       get rid of reduntant code and minor updates 
%   2021-09-24 
%       seperate eleven_LOSORegression_fss_fit_pred_eva into:
%           feature selection:eleven_eleven_BrainBehavPred_FSbyCor_FS.m 
%           CV train: see eleven_eleven_BrainBehavPred_FSbyCor_CV.m.
%           test: see eleven_eleven_BrainBehavPred_FSbyCor_test.m
%       Reasons for this seperation
%           1. extend trainRegression methods from linear to more.
%           2. The key of the Finn approach is actually the overlap of the selected features among sbjs.
%               This feature selection step, particulary the overlap, has to be handled separately and evaluated.
%               Without a satisfied feature selection, i.e., statisfied overlap, it is nonsense to further do the trainRegression step.
%           !!!. This is actuall the method that has already been  realized and established when handling reginal data, see 
%               Esterman M, Tamber-Rosenau BJ, Chiu Y-C, Yantis S (2010) Avoiding non-independence in fMRI data analysis: Leave one subject out. NeuroImage 50:572�C576.
%	2021-06-24 first version in practice in ada, whereas did not work.
%   2021-06-23 
%       original version, modify from the code available in 
%           Shen X, Finn ES, Scheinost D, Rosenberg MD, Chun MM, Papademetris X, Constable RT (2017) 
%           Using connectome-based predictive modeling to predict individual behavior from brain connectivity. Nat Protocols 12:506�C518. 

sbj_num = size(brainData,1);
feature_num = size(brainData,2);

pos_featureMask_CV = [];
neg_featureMask_CV = [];

%--- LOSO loop
for leftout = 1:sbj_num
    % fprintf('Leaving out subj # %6.3f\n ',leftout);
    
    % leave out one subject from x and y, producing CV train data
    brainData_CV = brainData;
    brainData_CV(leftout,:) = [];
    
    behavData_CV = behavData;
    behavData_CV(leftout) = [];
    
    
    %--- feature selection: brain - behav correlation
    % using Pearson correlation
    if strcmp(corMethod,'Pearson')
        [r_CV, p_CV] = corr(brainData_CV, behavData_CV);
    end
    %     % using partial correlation
    %     [r_CV, p_CV] = partialcorr(brainData_CV, behavData_CV, age);
    
    %     % using rank correlation
    %     [r_CV, p_CV] = corr(brainData_CV, behavData_CV, 'type', 'Spearman');
    
    %     % using partial rank correlation
    %       [add]
    
    % using robust fit
    %     for edge_i = 1: feature_num;
    %         [~, stats] = robustfit(brainData_CV(edge_i,:), behavData_CV);
    %         cur_t = stats.t(2);
    %         r_CV(edge_i) = sign(cur_t)*sqrt(cur_t^2/(sbj_num-1-2+cur_t^2));
    %         p_CV(edge_i) = 2*(1-tcdf(abs(cur_t), sbj_num-1-2));  %two tailed
    %     end
    %
    
    %--- feature selection: set selected feature in mask format, thresholded by p value of correlation
    pos_featureMask_CV_t = zeros(feature_num, 1);
    neg_featureMask_CV_t = zeros(feature_num, 1);
    
    pos_featureMask_CV_t(find( r_CV > 0 & p_CV <= fs_threshold)) = 1;
    if isempty(find(pos_featureMask_CV_t==1))
        %  to avoid all 0, randomly assign one 1
        temp = ceil((feature_num-2).*rand + 1);
        pos_featureMask_CV_t(temp)=1;
    end
    neg_featureMask_CV_t(find( r_CV < 0 & p_CV <= fs_threshold)) = 1;
    if isempty(find(neg_featureMask_CV_t==1))
        temp = ceil((feature_num-2).*rand + 1);
        neg_featureMask_CV_t(temp)=1;
    end
    
    pos_featureMask_CV_t=pos_featureMask_CV_t';
    neg_featureMask_CV_t=neg_featureMask_CV_t';
    
    pos_featureMask_CV = [pos_featureMask_CV; pos_featureMask_CV_t];
    neg_featureMask_CV = [neg_featureMask_CV; neg_featureMask_CV_t];
end





