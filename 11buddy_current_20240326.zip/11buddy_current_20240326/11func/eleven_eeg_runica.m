function eleven_eeg_ica
% Input
% 
% Update history
% 2022-01-07
%   bug fix. add editing channel file.
% 2021-11-13
%   rename eleven_eeg_ica-> eleven_eeg_runica
%   remove import_file_type input (no need to distinguish) 
% 2021-11-16 initial version
load eleven_eeg_OptionVariable_customize;

EEG = pop_loadset('eeg_raw_pp_rbc.set');

if import_file_type == 1
    EEG=pop_chanedit(EEG,'load',{'biosemi64_XiangLab.sph'});
end
if import_file_type == 211 || import_file_type == 212
    EEG=pop_chanedit(EEG,'load',{'egi128_XiangLab.sph'});
end

EEG = pop_runica(EEG,'icatype','runica','extended',1);
EEG = eeg_checkset(EEG);
EEG = pop_saveset(EEG,'eeg_raw_pp_rbc_ica.set',pwd);
