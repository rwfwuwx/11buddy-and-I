function [r,p]=eleven_corr(data1,data2,type,data3)
%input:
%   data1/data2: corr data
%   type: 1--Pearson correlation. 2--Spearman correlation.
%   data3:control data.
%       if data3 is empty,no control of non interesting data.
%       if data3 is not empty, control of non interesting data, use partical correlation.
%
% todo
% update history
%   2022-07-05 initial version

if isempty(data3)
    if type == 1
        [r,p]=corr(data1,data2,'Rows','Complete');
    end
    if type == 2
        [r,p]=corr(data1,data2,'Rows','Complete','type','Spearman');
    end
end

if ~isempty(data3)
    if type == 1
        [r,p]=partialcorr(data1,data2,data3,'Rows','Complete');
    end
    if type == 2
        [r,p]=partialcorr(data1,data2,data3,'Rows','Complete','type','Spearman');
    end
end
    