function [TemplateClassIndex_pred] = eleven_crossCor(templateData,compareData,corMethod)
% [TemplateClassIndex_pred] = eleven_crossCor(templateData,compareData,corMethod)
% 
% Usage
%   For each subject, this serves as a decoder, for .i.e., the so-called mvpa.
%   For across subjects, this can serves as a ID identifier.Simply treat subject as class.
%
% Input
%   templateData: matrix. features * classes. classes >1.
%   compareData: matrix. features * classes. classes>=1.
%   corMethod: 
%
% Output
%   TemplateClassIndex_pred: for each class in compareData, which class in templateData it belongs to (most like). 
%
% Description
%   This is an implementation of Haxby JV, Gobbini MI, Furey ML, Ishai A, Schouten JL, Pietrini P (2001) 
%       Distributed and Overlapping Representations of Faces and Objects in Ventral Temporal Cortex. Science 293:2425–2430.
%
% Update history
%   2021-09-27 initial version. 

% using Pearson correlation
if strcmp(corMethod,'Pearson')
    [r, p] = corr(templateData,compareData);
end

[~,TemplateClassIndex_pred] = max(r);








