% open func
%   eleven_openFunc_UpdateSbjIndex_SameSbjLongitudinalData.m
%
% --- FAQ
% Q: 这个函数干什么的？
%   A: update data for within-subject comparison.
% Q: 为什么函数名叫做 'SameSbjLongitudinalData'
%   A: 最初开发的时候 用于 Longitudinal, 例如治疗前后，学习前后
%       Q: 实际上呢？
%           A：general的winthin-sbject, Longitudinal只是一个具体例子。
%           所以，后续如果觉得名字费解，可改名字。
% Q: sbj 和 sbjNO的区别是什么？
%   A: sbj 指 数据id, 例如 sbj01_before_treat, sbj01_after_treat, sbj02_before_treat, sbj03_after_treat，sbj04_before_treat
%       sbjNO 指 被试编号，对应 为 1,1,2,3,4
%       Q: 很简单的事情，好像变复杂了？
%           A: 对人好像很简单，如果数据很少，条件也很少，手动选选。复杂的情况下，就选来选去 糊涂了。
%           所以，11伙伴 数据驱动: sbj 不是'被试 id'，是‘数据id’。
%               被试编号只是数据的一个feature. 就都结束了。
%           ！同时注意：数据id,和被试编号 都保持按序排列。(不要随意的安排被试顺序，比如 被试 3 2 1 4，等；避免不必要的额外复杂性。 )
% Q: 举个例子?
%   A: 上面的例子，条件/分组 是 before_treat vs. after_treat
%       between-subject comparison为：sbj01_before_treat, sbj02_before_treat, sbj04_before_treat vs. sbj01_after_treat, sbj03_after_treat
%       !!! within-sbject comparison为：sbj01_before_treat vs. sbj01_after_treat
%       所以逻辑很简单；但数据大了/因素多了 就容易糊涂了。
% Q: 摘要的说一下到底怎么干的吧？
%   A: 上面的例子，
%       #对于 before_teat, 和after_treat的数据id；
%       #根据被试编号 找到不同数据 共同的 被试编号
%       #before_teat, 和after_treat的数据iD, 都只保留共同被试编号的数据id
%
% ---description
% 对于输入的 analysis_sbjIndex(s) (应用上通常两个)，
%   根据sbjNo, 找到共同的被试编号，
%   更新 输入的 analysis_sbjIndex(s)，都仅保留 共同被试编号
%
% Note
%   for LongitudinalData, get and update the index of the same sbj of multiple data.
%       For background about the indexing algorism, see the corresponding
%       description in ada oprate manual.
%       !!! this indexing belongs to gougou(see the corresponding description in 
%           11buddy_FAQ.docx, later into gougou rawdata manual), not ada.
%           (again, for global data selection, do not use relative index)
%
% Input
%   --- sbjNO (被试编号，说明见上)
%   --- tmpInputVar: analysis_sbjIndex(s) (数据id, 说明见上). e.g.,
%[
% tmpInputVar = {...
%         'analysis_sbjIndex_Patient_InterventionType12_Pre_clean',...
%         'analysis_sbjIndex_Patient_InterventionType12_Post_clean'
%         };
%]
% Output
%   --- updated tmpInputVar: analysis_sbjIndex(s) 
%       (更新输入数据，每个数据都 保留共同的被试编号)
%   --- within_sbj_common_sbj_number: 共同被试数目
%   --- 报告：每个数据索引原本多少个被试；以及共同被试数目
%
% Update history
% 2023-12-12 
%   ---add description
%   ---add within_sbj_common_sbj_number = length(com_sbjNO);
%       注: in case, this value is required as a variable.
%          also note：每个数据 原被试数目-共同被试数目 也是一种缺失值
%   update 报告，说明这是对于within-subject report
% 2022-10-20 add reporting sbj number
% 2022-10-18 initial version

disp('对于within-subject analysis, 以下报告每个数据被试数目，以及共同被试数目：')

% !!! first check whether sbjNO is sorted
if issorted(sbjNO)==0
    error('sbjNO is not sortted, Please check and correct it in gougou!' )
end

% get inputs
tmp_data_name = cell(length(tmpInputVar),1);
for ii_ssld = 1:length(tmpInputVar)
    tmp_data_name{ii_ssld} = ['tmp_data_' num2str(ii_ssld)];
    eval(sprintf('%s = %s;',tmp_data_name{ii_ssld},tmpInputVar{ii_ssld}));
    %
    eval(sprintf('ttt = length(find(%s==1));',tmpInputVar{ii_ssld}));
    sprintf('输入数据 %d 被试数目为: %d',ii_ssld,ttt)
end

% get sbjNO of inputs
tmp_sbjNO_name = cell(length(tmpInputVar),1);
for ii_ssld = 1:length(tmpInputVar)
    tmp_sbjNO_name{ii_ssld} = ['tmp_sbjNO_' num2str(ii_ssld)];
    eval(sprintf('%s = sbjNO(find(%s==1));',...
        tmp_sbjNO_name{ii_ssld},tmp_data_name{ii_ssld}));
end

% check repeated sbjNO. report error if there are repeated
for ii_ssld = 1:length(tmpInputVar)
    eval(sprintf('tmp_num_1 = length(%s);',tmp_sbjNO_name{ii_ssld}));
    eval(sprintf('tmp_num_2 = length(unique(%s));',tmp_sbjNO_name{ii_ssld}));
    if tmp_num_1 ~= tmp_num_2
        error('there are repeated sbjNO in gougou, Please check and correct it in gougou!' )
    end
end

% get sortted common sbjNo,
%   note: the func intersect 1 sorted, and 2 remove repeated)
%   Note: for logic rhythm, a*b*c should be (a*b)*c.
%       or specific for the func intersect, it supports only two inputs
% when inputs = 2. also as the initial com for inputs >2
eval(sprintf('[com_sbjNO,~,~] = intersect(%s,%s);',tmp_sbjNO_name{1},tmp_sbjNO_name{2}));
if length(tmpInputVar)>2
    for ii_ssld = 3:length(tmpInputVar)
        eval(sprintf('[com_sbjNO,~,~] = intersect(com_sbjNO,%s);',tmp_sbjNO_name{ii_ssld}));
    end
end
%
sprintf('输入数据 共同被试数目为: %d',length(com_sbjNO))
within_sbj_common_sbj_number = length(com_sbjNO);

% get the analysis_sbjIndexNO of com_sbjNO.
%   note:
%       analysis_sbjIndexNO is also sorted.
%       analysis_sbjIndexNO includes repeated sbjNO for all inputs.
%           given two inputs, analysis_sbjIndexNO would be like
%               sbjIndexNO for sbjNO1 of input1
%               sbjIndexNO for sbjNO1 of input2
%               sbjIndexNO for sbjNO2 of input1
%               sbjIndexNO for sbjNO2 of input2
%               ...
%           note for each sbjNO, the order of inputs does not matter. see below.
analysis_sbjIndexNO_com_sbjNO = [];
for ii_com_sbjNO = 1:length(com_sbjNO)
    tmp_sbjIndexNO = find(sbjNO == com_sbjNO(ii_com_sbjNO));
    analysis_sbjIndexNO_com_sbjNO = [analysis_sbjIndexNO_com_sbjNO; tmp_sbjIndexNO];
end

% sbjIndexNO->sbjIndex
% !!! Note
%   Unless gogo is sorted, while sbjIndexNO is sorted, sbjIndex will not.
analysis_sbjIndex_com_sbjNO = zeros(length(sbj),1);
analysis_sbjIndex_com_sbjNO(analysis_sbjIndexNO_com_sbjNO) = 1;

% Update inputs via & analysis_sbjIndex_com_sbjNO
for ii_ssld = 1:length(tmpInputVar)
    eval(sprintf('%s = %s & analysis_sbjIndex_com_sbjNO;',...
        tmpInputVar{ii_ssld},tmpInputVar{ii_ssld}));
end

% futher check consistency between sbj order for the outputs, make sure the one-one
%   correspone of different data of one sbj
for ii_ssld = 2:length(tmpInputVar)
    eval(sprintf('tmp_indexNO_1 = find(%s==1);',tmpInputVar{1}));
    eval(sprintf('tmp_indexNO_2 = find(%s==1);',tmpInputVar{ii_ssld}));
    tmp = sbjNO(tmp_indexNO_1) - sbjNO(tmp_indexNO_2);
    if ~isempty(find(tmp~=0))
        error('index inconsistency found here, Please check and correct it in gougou!');
    end
end
