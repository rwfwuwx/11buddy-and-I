function eleven_eegSource_Forward(ProtocolName,SubjectName,sFile_FileName,is_noise_cov,CorV) 
% Usage
% Input
%   ProtocolName --- see eleven_eegSource_Import.m. 
%   SubjectName
%   sFile_FileName --- that returned by eleven_eegSource_Import.m.
%   SourceSpace --- 1: Cortex surface or 2: volume 
%   is_noise_cov --- 1 or 0
%   CorV: 1 cortex; 2 volume
% Hidden Output
%   see eleven_eegSource_Import.m
% todo
%   1. check Note 2
%   2. automation
%        'baseline',       [0, 137.1], ...
%        'datatimewindow', [0, 137.1], ...
%   3. simplify noise_cov parameters
% Note
%   1. about Output.
%       1) The Forward process processes on the imported sFile. The effect is stored on it, whithout explict output.
%   2. about effect range.
%       The forward is shared by all conditions of a subject.(test this, sample script said no) 
%   	Combine 1&2, regarding processing pipeline
%       (Could be: do import and fowrward, then reverse for one condition of a subject, 
%           for other conditions, reverse directly follows import.
%           good: save time (not too much), save disk).
%           bad: file oranizaton.waist brain
%       !!! Or, do foward for every sbj/cond/run.
%           good: clear file organiaton. save brain.In case, use indiviidual head shape/sensor location file
%           bad: more time, disk.
%           (assume, for the same subject, given common head shape/sensor location,do forward for different run give same result)
%   Others see eleven_eegSource_Import.m.
% todo
%   
% Description
%   Others see eleven_eegSource_Import.m.
% Update history
% 2022-02-28 mark open/close bs.
% 20220227
%   perform forward when no headmodel, for a given sbj
% 2022-02-25 add handling ProtocolName_C (cortex) ProtocolName_V (colume)
% 2021-10-22
%   decide do foward for every sbj/cond/run. see Note 2.
% 2021-10-19~20 
%   see eleven_eegSource_Import.m


% Start BrainStorm in silent mode. 
% if ~brainstorm('status')
%     brainstorm nogui
% end

% load Protocol
iProtocol = bst_get('Protocol', ProtocolName);

if ~isempty(iProtocol)
   gui_brainstorm('SetCurrentProtocol', iProtocol);
end
if isempty(iProtocol)
    error(['Unknown protocol: ' ProtocolName]);
end


% get info about whethere there is head model for a sbj
tmp = bst_get('ProtocolSubjects');  
subject_struct = tmp.Subject;
for ii=1:length(subject_struct)
    if strcmp(SubjectName,subject_struct(ii).Name)
        index_sbj = ii;
        break;
    end
end

[tmp, iStudiesNew] = bst_get('DefaultStudy', index_sbj);
if isempty(tmp.iHeadModel)
    %--- Forward
    % GUI process: Compute head model
    %   !!! Note here that, the input "sFile_FileName" and the output sFile_Import are same, in other words,
    %       no need to define the input
    %       remember to keep the naming sFile according to note 2
    %       currently, leave current arrangement. optimize after further testing.
    if CorV == 1
        sFile_Import = bst_process('CallProcess', 'process_headmodel', sFile_FileName, [], ...
            'sourcespace', 1);
    end
    if CorV == 2
        sFile_Import = bst_process('CallProcess', 'process_headmodel', sFile_FileName, [], ...
            'sourcespace', 2,...
            'volumegrid',  struct(...
            'Method',        'isotropic', ...
            'nLayers',       17, ...
            'Reduction',     3, ...
            'nVerticesInit', 4000, ...
            'Resolution',    0.005, ...
            'FileName',      ''));
    end
    
    %--- noise_cov
    if is_noise_cov
        % Process: Compute covariance (noise or data)
        sFile_Import = bst_process('CallProcess', 'process_noisecov', sFile_Import, [], ...
            'baseline',       [], ...
            'datatimewindow', [], ...
            'sensortypes',    'MEG, EEG, SEEG, ECOG', ...
            'target',         1, ...  % Noise covariance     (covariance over baseline time window)
            'dcoffset',       1, ...  % Block by block, to avoid effects of slow shifts in data
            'replacefile',    1);  % Replace
    end
    
end

 % Quit Brainstorm
% brainstorm stop;
